/* MyFileOpenDlg.cpp : implementation file
Written by Bruce Ralston
*/

#include "stdafx.h"
#include "tgr2shp.h"
#include "dlgs.h"
#include "MyFileOpenDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMyFileOpenDlg

IMPLEMENT_DYNAMIC(CMyFileOpenDlg, CFileDialog)

CMyFileOpenDlg::CMyFileOpenDlg(BOOL bOpenFileDialog, LPCTSTR lpszDefExt, LPCTSTR lpszFileName,
		DWORD dwFlags, LPCTSTR lpszFilter, CWnd* pParentWnd) :
		CFileDialog(bOpenFileDialog, lpszDefExt, lpszFileName, dwFlags, lpszFilter, pParentWnd)
{
}


BEGIN_MESSAGE_MAP(CMyFileOpenDlg, CFileDialog)
	//{{AFX_MSG_MAP(CMyFileOpenDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL CMyFileOpenDlg::OnInitDialog() 
{
	CFileDialog::OnInitDialog();
	
	CenterWindow();
     
	ModifyStyleEx(0, WS_EX_CONTEXTHELP);

	GetDlgItem(stc2)->ShowWindow(SW_HIDE);
	GetDlgItem(stc3)->ShowWindow(SW_HIDE);
	GetDlgItem(edt1)->ShowWindow(SW_HIDE);
	GetDlgItem(lst1)->ShowWindow(SW_HIDE);
	GetDlgItem(cmb1)->ShowWindow(SW_HIDE);
	GetDlgItem(chx1)->ShowWindow(SW_HIDE);
	GetDlgItem(pshHelp)->ShowWindow(SW_HIDE);
	
	SetDlgItemText(edt1, "Junk");//need this line
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
