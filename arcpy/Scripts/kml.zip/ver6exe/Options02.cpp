// Options02.cpp : implementation file
//

#include "stdafx.h"
#include "tgr2shp.h"
#include "Options02.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Options02 dialog


Options02::Options02(CWnd* pParent /*=NULL*/)
	: CDialog(Options02::IDD, pParent)
{
	//{{AFX_DATA_INIT(Options02)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void Options02::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(Options02)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(Options02, CDialog)
	//{{AFX_MSG_MAP(Options02)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Options02 message handlers
