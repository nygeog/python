// MyFileOpenDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMyFileOpenDlg dialog

class CMyFileOpenDlg : public CFileDialog
{
	DECLARE_DYNAMIC(CMyFileOpenDlg)

public:
	CMyFileOpenDlg(BOOL bOpenFileDialog, // TRUE for FileOpen, FALSE for FileSaveAs
		LPCTSTR lpszDefExt = NULL,
		LPCTSTR lpszFileName = NULL,
		DWORD dwFlags = OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		LPCTSTR lpszFilter = NULL,
		CWnd* pParentWnd = NULL);

protected:
	//{{AFX_MSG(CMyFileOpenDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
