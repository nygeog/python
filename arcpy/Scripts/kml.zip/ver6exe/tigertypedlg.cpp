/* tigertypedlg.cpp : implementation file
Written by Bruce Ralston
This file manages the LUCA or tigertype dialog
*/

#include "stdafx.h"
#include "tgr2shp.h"
#include "tigertypedlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
extern int CurrentVersion;
extern int Type97Check;
/////////////////////////////////////////////////////////////////////////////
// tigertypedlg dialog


tigertypedlg::tigertypedlg(CWnd* pParent /*=NULL*/)
	: CDialog(tigertypedlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(tigertypedlg)
	m_Standard = 0;
	m_bType97 = FALSE;
	//}}AFX_DATA_INIT
}


void tigertypedlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(tigertypedlg)
	DDX_Radio(pDX, IDC_STANDARD, m_Standard);
	DDX_Check(pDX, IDC_TYPE97, m_bType97);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(tigertypedlg, CDialog)
	//{{AFX_MSG_MAP(tigertypedlg)
	//ON_WM_CANCELMODE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// tigertypedlg message handlers


void tigertypedlg::OnOK() 
{
	// TODO: Add extra validation here
	UpdateData(TRUE);	
	CurrentVersion += m_Standard;
	if (m_bType97)
		Type97Check = m_Standard;
	CDialog::OnOK();
}

BOOL tigertypedlg::OnInitDialog() 
{
	
	CDialog::OnInitDialog();
	CString text;
	text = "Please choose the version of TIGER you wish to process.";	
	this->SetDlgItemText(IDC_TGRTYPE,text);	
	if (Type97Check < 0)
	{
		m_Standard = 11; //default choice
		m_bType97 = 1;
	}
	UpdateData(false);
	
	// TODO: Add extra initialization here
		
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}


