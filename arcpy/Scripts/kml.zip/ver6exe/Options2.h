#if !defined(AFX_OPTIONS2_H__07D4048E_3187_4FDE_B955_C8191848A9CF__INCLUDED_)
#define AFX_OPTIONS2_H__07D4048E_3187_4FDE_B955_C8191848A9CF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Options2.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// Options2 dialog

class Options2 : public CDialog
{
// Construction
public:
	Options2(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(Options2)
	enum { IDD = IDD_OPTIONS2_DIALOG };
	BOOL	m_bTypeA;
	BOOL	m_bTypeB;
	BOOL	m_bTypeC;
	BOOL	m_bTypeD;
	BOOL	m_bTypeE;
	BOOL	m_bTypeF;
	BOOL	m_bTypeH;
	BOOL	m_bTypeX;
	BOOL	m_bClip;
	BOOL	m_bSetforAll;
	BOOL	m_bCounty00;
	BOOL	m_bBlock00;
	BOOL	m_bBlockCU;
	BOOL	m_bCountyCQ;
	BOOL	m_bCountyCU;
	BOOL	m_bGroup00;
	BOOL	m_bGroupCU;
	BOOL	m_bTract00;
	BOOL	m_bTractCQ;
	BOOL	m_bTractCU;
	BOOL	m_bAIANHH00;
	BOOL	m_bAIANHHCQ;
	BOOL	m_bAIANHHCU;
	BOOL	m_bAITS00;
	BOOL	m_bAITSCQ;
	BOOL	m_bAITSCU;
	BOOL	m_bAll;
	BOOL	m_bANRC00;
	BOOL	m_bANRCCQ;
	BOOL	m_bANRCCU;
	BOOL	m_bBlockCQ;
	BOOL	m_bCd106;
	BOOL	m_bCdCU;
	BOOL	m_bConcit00;
	BOOL	m_bConcitCQ;
	BOOL	m_bConcitCU;
	BOOL	m_bCousub00;
	BOOL	m_bCousubCQ;
	BOOL	m_bCousubCU;
	BOOL	m_bElem00;
	BOOL	m_bElemCU;
	BOOL	m_bLand;
	BOOL	m_bMsa00;
	BOOL	m_bMsaCU;
	BOOL	m_bNecmaCU;
	BOOL	m_bPlace00;
	BOOL	m_bPlaceCQ;
	BOOL	m_bPlaceCU;
	BOOL	m_bPmsa00;
	BOOL	m_bPmsaCU;
	BOOL	m_bSec00;
	BOOL	m_bSldl;
	BOOL	m_bSldu;
	BOOL	m_bSubmcdCQ;
	BOOL	m_bSubmcd00;
	BOOL	m_bSubmcdCU;
	BOOL	m_bTaz;
	BOOL	m_bUga;
	BOOL	m_bUni00;
	BOOL	m_bUniCU;
	BOOL	m_bUrban00;
	BOOL	m_bUrbanCQ;
	BOOL	m_bVote;
	BOOL	m_bWater;
	BOOL	m_bZcta300;
	BOOL	m_bZcta3CU;
	BOOL	m_bZcta500;
	BOOL	m_bZcta5CU;
	BOOL	m_bGroupCQ;
	BOOL	m_bSecCU;
	BOOL	m_bNecma00;
	BOOL	m_bPuma5;
	BOOL	m_bPuma1;
	BOOL	m_bCbsa;
	BOOL	m_bCnecta;
	BOOL	m_bComreg;
	BOOL	m_bCountyec;
	BOOL	m_bCsa;
	BOOL	m_bMetdiv;
	BOOL	m_bNecta;
	BOOL	m_bNectadiv;
	BOOL	m_bPlaceec;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(Options2)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(Options2)
	virtual BOOL OnInitDialog();
	afx_msg void OnSelectall();
	afx_msg void OnClearall();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OPTIONS2_H__07D4048E_3187_4FDE_B955_C8191848A9CF__INCLUDED_)
