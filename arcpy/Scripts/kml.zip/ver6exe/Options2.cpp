/* Options2.cpp : implementation file
Written by Bruce Ralston
This code manages the layer options for TIGER versions 2002 - 2005 SE
*/

#include "stdafx.h"
#include "tgr2shp.h"
#include "Options2.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
extern CString CurrentDir;
extern CString CurrentOptions;
extern CString GlobalOptions;
extern int SetForAll;
extern int CurrentVersion;
extern int GlobalVersion;

/////////////////////////////////////////////////////////////////////////////
// Options2 dialog


Options2::Options2(CWnd* pParent /*=NULL*/)
	: CDialog(Options2::IDD, pParent)
{
	//{{AFX_DATA_INIT(Options2)
	m_bTypeA = FALSE;
	m_bTypeB = FALSE;
	m_bTypeC = FALSE;
	m_bTypeD = FALSE;
	m_bTypeE = FALSE;
	m_bTypeF = FALSE;
	m_bTypeH = FALSE;
	m_bTypeX = FALSE;
	m_bClip = FALSE;
	m_bSetforAll = FALSE;
	m_bCounty00 = FALSE;
	m_bBlock00 = FALSE;
	m_bBlockCU = FALSE;
	m_bCountyCQ = FALSE;
	m_bCountyCU = FALSE;
	m_bGroup00 = FALSE;
	m_bGroupCU = FALSE;
	m_bTract00 = FALSE;
	m_bTractCQ = FALSE;
	m_bTractCU = FALSE;
	m_bAIANHH00 = FALSE;
	m_bAIANHHCQ = FALSE;
	m_bAIANHHCU = FALSE;
	m_bAITS00 = FALSE;
	m_bAITSCQ = FALSE;
	m_bAITSCU = FALSE;
	m_bAll = FALSE;
	m_bANRC00 = FALSE;
	m_bANRCCQ = FALSE;
	m_bANRCCU = FALSE;
	m_bBlockCQ = FALSE;
	m_bCd106 = FALSE;
	m_bCdCU = FALSE;
	m_bConcit00 = FALSE;
	m_bConcitCQ = FALSE;
	m_bConcitCU = FALSE;
	m_bCousub00 = FALSE;
	m_bCousubCQ = FALSE;
	m_bCousubCU = FALSE;
	m_bElem00 = FALSE;
	m_bElemCU = FALSE;
	m_bLand = FALSE;
	m_bMsa00 = FALSE;
	m_bMsaCU = FALSE;
	m_bNecmaCU = FALSE;
	m_bPlace00 = FALSE;
	m_bPlaceCQ = FALSE;
	m_bPlaceCU = FALSE;
	m_bPmsa00 = FALSE;
	m_bPmsaCU = FALSE;
	m_bSec00 = FALSE;
	m_bSldl = FALSE;
	m_bSldu = FALSE;
	m_bSubmcdCQ = FALSE;
	m_bSubmcd00 = FALSE;
	m_bSubmcdCU = FALSE;
	m_bTaz = FALSE;
	m_bUga = FALSE;
	m_bUni00 = FALSE;
	m_bUniCU = FALSE;
	m_bUrban00 = FALSE;
	m_bUrbanCQ = FALSE;
	m_bVote = FALSE;
	m_bWater = FALSE;
	m_bZcta300 = FALSE;
	m_bZcta3CU = FALSE;
	m_bZcta500 = FALSE;
	m_bZcta5CU = FALSE;
	m_bGroupCQ = FALSE;
	m_bSecCU = FALSE;
	m_bNecma00 = FALSE;
	m_bPuma5 = FALSE;
	m_bPuma1 = FALSE;
	m_bCbsa = FALSE;
	m_bCnecta = FALSE;
	m_bComreg = FALSE;
	m_bCountyec = FALSE;
	m_bCsa = FALSE;
	m_bMetdiv = FALSE;
	m_bNecta = FALSE;
	m_bNectadiv = FALSE;
	m_bPlaceec = FALSE;
	//}}AFX_DATA_INIT
}


void Options2::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(Options2)
	DDX_Check(pDX, IDC_TYPEA, m_bTypeA);
	DDX_Check(pDX, IDC_TYPEB, m_bTypeB);
	DDX_Check(pDX, IDC_TYPEC, m_bTypeC);
	DDX_Check(pDX, IDC_TYPED, m_bTypeD);
	DDX_Check(pDX, IDC_TYPEE, m_bTypeE);
	DDX_Check(pDX, IDC_TYPEF, m_bTypeF);
	DDX_Check(pDX, IDC_TYPEH, m_bTypeH);
	DDX_Check(pDX, IDC_TYPEX, m_bTypeX);
	DDX_Check(pDX, IDC_CLIP, m_bClip);
	DDX_Check(pDX, IDC_SETALL, m_bSetforAll);
	DDX_Check(pDX, IDC_COUNTY00, m_bCounty00);
	DDX_Check(pDX, IDC_BLOCK00, m_bBlock00);
	DDX_Check(pDX, IDC_BLOCKCU, m_bBlockCU);
	DDX_Check(pDX, IDC_COUNTYCQ, m_bCountyCQ);
	DDX_Check(pDX, IDC_COUNTYCU, m_bCountyCU);
	DDX_Check(pDX, IDC_GROUP00, m_bGroup00);
	DDX_Check(pDX, IDC_GROUPCU, m_bGroupCU);
	DDX_Check(pDX, IDC_TRACT00, m_bTract00);
	DDX_Check(pDX, IDC_TRACTCQ, m_bTractCQ);
	DDX_Check(pDX, IDC_TRACTCU, m_bTractCU);
	DDX_Check(pDX, IDC_AIANHH00, m_bAIANHH00);
	DDX_Check(pDX, IDC_AIANHHCQ, m_bAIANHHCQ);
	DDX_Check(pDX, IDC_AIANHHCU, m_bAIANHHCU);
	DDX_Check(pDX, IDC_AITS00, m_bAITS00);
	DDX_Check(pDX, IDC_AITSCQ, m_bAITSCQ);
	DDX_Check(pDX, IDC_AITSCU, m_bAITSCU);
	DDX_Check(pDX, IDC_ALL, m_bAll);
	DDX_Check(pDX, IDC_ANRC00, m_bANRC00);
	DDX_Check(pDX, IDC_ANRCCQ, m_bANRCCQ);
	DDX_Check(pDX, IDC_ANRCCU, m_bANRCCU);
	DDX_Check(pDX, IDC_BLOCKCQ, m_bBlockCQ);
	DDX_Check(pDX, IDC_CD106, m_bCd106);
	DDX_Check(pDX, IDC_CDCU, m_bCdCU);
	DDX_Check(pDX, IDC_CONCIT00, m_bConcit00);
	DDX_Check(pDX, IDC_CONCITCQ, m_bConcitCQ);
	DDX_Check(pDX, IDC_CONCITCU, m_bConcitCU);
	DDX_Check(pDX, IDC_COUSUB00, m_bCousub00);
	DDX_Check(pDX, IDC_COUSUBCQ, m_bCousubCQ);
	DDX_Check(pDX, IDC_COUSUBCU, m_bCousubCU);
	DDX_Check(pDX, IDC_ELEM00, m_bElem00);
	DDX_Check(pDX, IDC_ELEMCU, m_bElemCU);
	DDX_Check(pDX, IDC_LAND, m_bLand);
	DDX_Check(pDX, IDC_MSA00, m_bMsa00);
	DDX_Check(pDX, IDC_MSACU, m_bMsaCU);
	DDX_Check(pDX, IDC_NECMACU, m_bNecmaCU);
	DDX_Check(pDX, IDC_PLACE00, m_bPlace00);
	DDX_Check(pDX, IDC_PLACECQ, m_bPlaceCQ);
	DDX_Check(pDX, IDC_PLACECU, m_bPlaceCU);
	DDX_Check(pDX, IDC_PMSA00, m_bPmsa00);
	DDX_Check(pDX, IDC_PMSACU, m_bPmsaCU);
	DDX_Check(pDX, IDC_SEC00, m_bSec00);
	DDX_Check(pDX, IDC_SLDL, m_bSldl);
	DDX_Check(pDX, IDC_SLDU, m_bSldu);
	DDX_Check(pDX, IDC_SUBMCDCQ, m_bSubmcdCQ);
	DDX_Check(pDX, IDC_SUBMCD00, m_bSubmcd00);
	DDX_Check(pDX, IDC_SUBMCDCU, m_bSubmcdCU);
	DDX_Check(pDX, IDC_TAZ, m_bTaz);
	DDX_Check(pDX, IDC_UGA, m_bUga);
	DDX_Check(pDX, IDC_UNI00, m_bUni00);
	DDX_Check(pDX, IDC_UNICU, m_bUniCU);
	DDX_Check(pDX, IDC_URBAN00, m_bUrban00);
	DDX_Check(pDX, IDC_URBANCQ, m_bUrbanCQ);
	DDX_Check(pDX, IDC_VOTE, m_bVote);
	DDX_Check(pDX, IDC_WATER, m_bWater);
	DDX_Check(pDX, IDC_ZCTA300, m_bZcta300);
	DDX_Check(pDX, IDC_ZCTA3CU, m_bZcta3CU);
	DDX_Check(pDX, IDC_ZCTA500, m_bZcta500);
	DDX_Check(pDX, IDC_ZCTA5CU, m_bZcta5CU);
	DDX_Check(pDX, IDC_GROUPCQ, m_bGroupCQ);
	DDX_Check(pDX, IDC_SECCU, m_bSecCU);
	DDX_Check(pDX, IDC_NECMA00, m_bNecma00);
	DDX_Check(pDX, IDC_PUMA5, m_bPuma5);
	DDX_Check(pDX, IDC_PUMA1, m_bPuma1);
	DDX_Check(pDX, IDC_CBSA, m_bCbsa);
	DDX_Check(pDX, IDC_CNECTA, m_bCnecta);
	DDX_Check(pDX, IDC_COMREG, m_bComreg);
	DDX_Check(pDX, IDC_COUNTYEC, m_bCountyec);
	DDX_Check(pDX, IDC_CSA, m_bCsa);
	DDX_Check(pDX, IDC_METDIV, m_bMetdiv);
	DDX_Check(pDX, IDC_NECTA, m_bNecta);
	DDX_Check(pDX, IDC_NECTADIV, m_bNectadiv);
	DDX_Check(pDX, IDC_PLACEEC, m_bPlaceec);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(Options2, CDialog)
	//{{AFX_MSG_MAP(Options2)
	ON_BN_CLICKED(IDC_SELECTALL, OnSelectall)
	ON_BN_CLICKED(IDC_CLEARALL, OnClearall)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Options2 message handlers

BOOL Options2::OnInitDialog() 
{
	CString titlestring;
/*off for kml
	if (CurrentOptions[0] == '0')
		m_bTypeA = FALSE;
	else
		m_bTypeA = TRUE;
	if (CurrentOptions[1] == '0')
		m_bTypeB = FALSE;
	else
		m_bTypeB = TRUE;
	if (CurrentOptions[2] == '0')
		m_bTypeC = FALSE;
	else
		m_bTypeC = TRUE;
	if (CurrentOptions[3] == '0')
		m_bTypeD = FALSE;
	else
		m_bTypeD = TRUE;
	if (CurrentOptions[4] == '0')
		m_bTypeE = FALSE;
	else
		m_bTypeE = TRUE;
	if (CurrentOptions[5] == '0')
		m_bTypeF = FALSE;
	else
		m_bTypeF = TRUE;
	if (CurrentOptions[6] == '0')
		m_bTypeH = FALSE;
	else
		m_bTypeH = TRUE;
	if (CurrentOptions[7] == '0')
		m_bTypeX = FALSE;
	else
		m_bTypeX = TRUE;	
		*/
	if (CurrentOptions[8] == '0')
		m_bCounty00 = FALSE;
	else
		m_bCounty00 = TRUE;
	if (CurrentOptions[9] == '0')
		m_bCountyCU = FALSE;
	else
		m_bCountyCU = TRUE;
	if (CurrentOptions[10] == '0')
		m_bCountyCQ = FALSE;
	else
		m_bCountyCQ = TRUE;
	if (CurrentOptions[11] == '0')
		m_bTract00 = FALSE;
	else
		m_bTract00 = TRUE;
	if (CurrentOptions[12] == '0')
		m_bTractCU = FALSE;
	else
		m_bTractCU = TRUE;
	if (CurrentOptions[13] == '0')
		m_bTractCQ = FALSE;
	else
		m_bTractCQ = TRUE;
	if (CurrentOptions[14] == '0')
		m_bGroup00 = FALSE;
	else
		m_bGroup00 = TRUE;
	if (CurrentOptions[15] == '0')
		m_bGroupCU = FALSE;
	else
		m_bGroupCU = TRUE;
	if (CurrentOptions[16] == '0')
		m_bGroupCQ = FALSE;
	else
		m_bGroupCQ = TRUE;
	if (CurrentOptions[17] == '0')
		m_bBlock00 = FALSE;
	else
		m_bBlock00 = TRUE;
	if (CurrentOptions[18] == '0')
		m_bBlockCU = FALSE;
	else
		m_bBlockCU = TRUE;
	if (CurrentOptions[19] == '0')
		m_bBlockCQ = FALSE;
	else
		m_bBlockCQ = TRUE;
	if (CurrentOptions[20] == '0')
		m_bAIANHH00 = FALSE;
	else
		m_bAIANHH00 = TRUE;
	if (CurrentOptions[21] == '0')
		m_bAIANHHCU = FALSE;
	else
		m_bAIANHHCU = TRUE;
	if (CurrentOptions[22] == '0')
		m_bAIANHHCQ = FALSE;
	else
		m_bAIANHHCQ = TRUE;
	if (CurrentOptions[23] == '0')
		m_bANRC00 = FALSE;
	else
		m_bANRC00 = TRUE;
	if (CurrentOptions[24] == '0')
		m_bANRCCU = FALSE;
	else
		m_bANRCCU = TRUE;
	if (CurrentOptions[25] == '0')
		m_bANRCCQ = FALSE;
	else
		m_bANRCCQ = TRUE;
	if (CurrentOptions[26] == '0')
		m_bAITS00 = FALSE;
	else
		m_bAITS00 = TRUE;
	if (CurrentOptions[27] == '0')
		m_bAITSCU = FALSE;
	else
		m_bAITSCU = TRUE;
	if (CurrentOptions[28] == '0')
		m_bAITSCQ = FALSE;
	else
		m_bAITSCQ = TRUE;
	if (CurrentOptions[29] == '0')
		m_bConcit00 = FALSE;
	else
		m_bConcit00 = TRUE;
	if (CurrentOptions[30] == '0')
		m_bConcitCU = FALSE;
	else
		m_bConcitCU = TRUE;
	if (CurrentOptions[31] == '0')
		m_bConcitCQ = FALSE;
	else
		m_bConcitCQ = TRUE;
	if (CurrentOptions[32] == '0')
		m_bCousub00 = FALSE;
	else
		m_bCousub00 = TRUE;
	if (CurrentOptions[33] == '0')
		m_bCousubCU = FALSE;
	else
		m_bCousubCU = TRUE;
	if (CurrentOptions[34] == '0')
		m_bCousubCQ = FALSE;
	else
		m_bCousubCQ = TRUE;
	if (CurrentOptions[35] == '0')
		m_bSubmcd00 = FALSE;
	else
		m_bSubmcd00 = TRUE;
	if (CurrentOptions[36] == '0')
		m_bSubmcdCU = FALSE;
	else
		m_bSubmcdCU = TRUE;
	if (CurrentOptions[37] == '0')
		m_bSubmcdCQ = FALSE;
	else
		m_bSubmcdCQ = TRUE;
	if (CurrentOptions[38] == '0')
		m_bPlace00 = FALSE;
	else
		m_bPlace00 = TRUE;
	if (CurrentOptions[39] == '0')
		m_bPlaceCU = FALSE;
	else
		m_bPlaceCU = TRUE;
	if (CurrentOptions[40] == '0')
		m_bPlaceCQ = FALSE;
	else
		m_bPlaceCQ = TRUE;
	if (CurrentOptions[41] == '0')
		m_bElem00 = FALSE;
	else
		m_bElem00 = TRUE;
	if (CurrentOptions[42] == '0')
		m_bElemCU = FALSE;
	else
		m_bElemCU = TRUE;
	if (CurrentOptions[43] == '0')
		m_bSec00 = FALSE;
	else
		m_bSec00 = TRUE;
	if (CurrentOptions[44] == '0')
		m_bSecCU = FALSE;
	else
		m_bSecCU = TRUE;
	if (CurrentOptions[45] == '0')
		m_bUni00 = FALSE;
	else
		m_bUni00 = TRUE;
	if (CurrentOptions[46] == '0')
		m_bUniCU = FALSE;
	else
		m_bUniCU = TRUE;
	if (CurrentOptions[47] == '0')
		m_bMsa00 = FALSE;
	else
		m_bMsa00 = TRUE;
	if (CurrentOptions[49] == '0')
		m_bPmsa00 = FALSE;
	else
		m_bPmsa00 = TRUE;
	if (CurrentOptions[51] == '0')
		m_bNecma00 = FALSE;
	else
		m_bNecma00 = TRUE;
	//space 53 reserved for type flag
	if (CurrentOptions[54] == '0')
		m_bCd106 = FALSE;
	else
		m_bCd106 = TRUE;
	if (CurrentOptions[55] == '0')
		m_bCdCU = FALSE;
	else
		m_bCdCU = TRUE;
	if (CurrentOptions[56] == '0')
		m_bZcta500 = FALSE;
	else
		m_bZcta500 = TRUE;
	if (CurrentOptions[57] == '0')
		m_bZcta5CU = FALSE;
	else
		m_bZcta5CU = TRUE;
	if (CurrentOptions[58] == '0')
		m_bZcta300 = FALSE;
	else
		m_bZcta300 = TRUE;
	if (CurrentOptions[59] == '0')
		m_bZcta3CU = FALSE;
	else
		m_bZcta3CU = TRUE;
	if (CurrentOptions[60] == '0')
		m_bUrban00 = FALSE;
	else
		m_bUrban00 = TRUE;
	if (CurrentOptions[61] == '0')
		m_bUrbanCQ = FALSE;
	else
		m_bUrbanCQ = TRUE;
	if (CurrentOptions[62] == '0')
		m_bTaz = FALSE;
	else
		m_bTaz = TRUE;
	if (CurrentOptions[63] == '0')
		m_bVote = FALSE;
	else
		m_bVote = TRUE;
	if (CurrentOptions[64] == '0')
		m_bSldu = FALSE;
	else
		m_bSldu = TRUE;
	if (CurrentOptions[65] == '0')
		m_bSldl = FALSE;
	else
		m_bSldl = TRUE;
	if (CurrentOptions[66] == '0')
		m_bUga = FALSE;
	else
		m_bUga = TRUE;
	if (CurrentOptions[67] == '0')
		m_bLand = FALSE;
	else
		m_bLand = TRUE;
	if (CurrentOptions[68] == '0')
		m_bWater = FALSE;
	else
		m_bWater = TRUE;
	if (CurrentOptions[69] == '0')
		m_bPuma5 = FALSE;
	else
		m_bPuma5 = TRUE;
	if (CurrentOptions[70] == '0')
		m_bPuma1 = FALSE;
	else
		m_bPuma1 = TRUE;
	if (CurrentOptions[71] == '0')
		m_bAll = FALSE;
	else
		m_bAll = TRUE;
	//save some buffer space
	// this is pushpins for kml
	if (CurrentOptions[80] == '0')
		m_bClip = FALSE;
	else
		m_bClip = TRUE;
	titlestring.Format("Layer Extraction Options for TIGER 2002");
	SetWindowText(titlestring);
	if (CurrentVersion >= 105) 
	{
		GetDlgItem(IDC_MSACU)->EnableWindow(FALSE);
		GetDlgItem(IDC_PMSACU)->EnableWindow(FALSE);
		GetDlgItem(IDC_NECMACU)->EnableWindow(FALSE);
		//this->SetDlgItemText(IDC_CD106,"106th&108th Congressional Districts");
		//this->SetDlgItemText(IDC_CDCU,"108th Congressional Districts");
		//make the economic census section visible
		if (!GetDlgItem(IDC_ECON)->IsWindowVisible())
		{
			GetDlgItem(IDC_ECON)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_ECON)->UpdateWindow();
			GetDlgItem(IDC_COUNTYEC)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_COUNTYEC)->UpdateWindow();
			GetDlgItem(IDC_PLACEEC)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_PLACEEC)->UpdateWindow();
			GetDlgItem(IDC_COMREG)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_COMREG)->UpdateWindow();
			GetDlgItem(IDC_CBSA)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_CBSA)->UpdateWindow();
			GetDlgItem(IDC_CSA)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_CSA)->UpdateWindow();
			GetDlgItem(IDC_METDIV)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_METDIV)->UpdateWindow();
			GetDlgItem(IDC_NECTA)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_NECTA)->UpdateWindow();
			GetDlgItem(IDC_CNECTA)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_CNECTA)->UpdateWindow();
			GetDlgItem(IDC_NECTADIV)->ShowWindow(SW_SHOW);
			GetDlgItem(IDC_NECTADIV)->UpdateWindow();
			if (CurrentVersion == 105)
				titlestring.Format("Layer Extraction Options for TIGER 2003");
			if (CurrentVersion == 106)
			{
				titlestring.Format("Layer Extraction Options for TIGER 2004, First Edition");
				this->SetDlgItemText(IDC_CD106,"106th Congressional Districts");			
				this->SetDlgItemText(IDC_CDCU,"108th Congressional Districts");
			}
			if (CurrentVersion == 107)
			{
				titlestring.Format("Options for TIGER 2004, 2nd Edition/TIGER 2005, TIGER 2006 1st Edition");
				this->SetDlgItemText(IDC_CD106,"106th and 108th Congressional Districts");			
				this->SetDlgItemText(IDC_CDCU,"109th Congressional Districts");
			}
			if (CurrentVersion == 108)
		{
				titlestring.Format("Options for TIGER 2006 2nd Edition");
				this->SetDlgItemText(IDC_CD106,"106th and 108th Congressional Districts");			
				this->SetDlgItemText(IDC_CDCU,"110th Congressional Districts");
				this->SetDlgItemText(IDC_URBAN00,"Urban 2000 and Current");
				this->SetDlgItemText(IDC_SLDU,"State Upper House 2000 and Current");
				this->SetDlgItemText(IDC_SLDL,"State Lower House 2000 and Current");
			}
			

			SetWindowText(titlestring);
		}
		if (CurrentOptions[48] == '0')
			m_bCountyec = FALSE;
		else
			m_bCountyec = TRUE;
		if (CurrentOptions[50] == '0')
			m_bPlaceec = FALSE;
		else
			m_bPlaceec = TRUE;
		if (CurrentOptions[52] == '0')
			m_bComreg = FALSE;
		else
			m_bComreg = TRUE;
		if (CurrentOptions[72] == '0')
			m_bCbsa = FALSE;
		else
			m_bCbsa = TRUE;
		if (CurrentOptions[73] == '0')
			m_bCsa = FALSE;
		else
			m_bCsa = TRUE;
		if (CurrentOptions[74] == '0')
			m_bMetdiv = FALSE;
		else
			m_bMetdiv = TRUE;
		if (CurrentOptions[75] == '0')
			m_bNecta = FALSE;
		else
			m_bNecta = TRUE;
		if (CurrentOptions[76] == '0')
			m_bCnecta = FALSE;
		else
			m_bCnecta = TRUE;
		if (CurrentOptions[77] == '0')
			m_bNectadiv = FALSE;
		else
			m_bNectadiv = TRUE;



	}
	else
	{
		if (CurrentOptions[48] == '0')
			m_bMsaCU = FALSE;
		else
			m_bMsaCU = TRUE;
		if (CurrentOptions[50] == '0')
			m_bPmsaCU = FALSE;
		else
			m_bPmsaCU = TRUE;
		if (CurrentOptions[52] == '0')
			m_bNecmaCU = FALSE;
		else
			m_bNecmaCU = TRUE;


	}
	if (SetForAll == 1) 
		GetDlgItem(IDC_SETALL)->EnableWindow(FALSE);
	CDialog::OnInitDialog();
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void Options2::OnSelectall() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
/* off for KML
	m_bTypeA = true;
	m_bTypeB = true;
	m_bTypeC = true;
	m_bTypeD = true;
	m_bTypeE = true;
	m_bTypeF = true;
	m_bTypeH = true;
	m_bTypeX = true;*/
	m_bClip = true;
	m_bSetforAll = true;
	m_bCounty00 = true;
	m_bBlock00 = true;
	m_bBlockCU = true;
	m_bCountyCQ = true;
	m_bCountyCU = true;
	m_bGroup00 = true;
	m_bGroupCU = true;
	m_bTract00 = true;
	m_bTractCQ = true;
	m_bTractCU = true;
	m_bAIANHH00 = true;
	m_bAIANHHCQ = true;
	m_bAIANHHCU = true;
	m_bAITS00 = true;
	m_bAITSCQ = true;
	m_bAITSCU = true;
	m_bAll = true;
	m_bANRC00 = true;
	m_bANRCCQ = true;
	m_bANRCCU = true;
	m_bBlockCQ = true;
	m_bCd106 = true;
	m_bCdCU = true;
	m_bConcit00 = true;
	m_bConcitCQ = true;
	m_bConcitCU = true;
	m_bCousub00 = true;
	m_bCousubCQ = true;
	m_bCousubCU = true;
	m_bElem00 = true;
	m_bElemCU = true;
	m_bLand = true;
	m_bMsa00 = true;
	m_bMsaCU = true;
	m_bNecma00 = true;
	m_bNecmaCU = true;
	m_bPlace00 = true;
	m_bPlaceCQ = true;
	m_bPlaceCU = true;
	m_bPmsa00 = true;
	m_bPmsaCU = true;
	m_bPuma5 = true;
	m_bPuma1 = true;
	m_bSec00 = true;
	m_bSldl = true;
	m_bSldu = true;
	m_bSubmcdCQ = true;
	m_bSubmcd00 = true;
	m_bSubmcdCU = true;
	m_bTaz = true;
	m_bUga = true;
	m_bUni00 = true;
	m_bUniCU = true;
	m_bUrban00 = true;
	m_bUrbanCQ = true;
	m_bVote = true;
	m_bWater = true;
	m_bZcta300 = true;
	m_bZcta3CU = true;
	m_bZcta500 = true;
	m_bZcta5CU = true;
	m_bGroupCQ = true;
	m_bSecCU = true;
	if (CurrentVersion >= 105) 
	{		
		m_bMsaCU = false;
		m_bPmsaCU = false;
		m_bNecmaCU = false;
		m_bCountyec = true;
		m_bPlaceec = true;
		m_bComreg = true;
		m_bCbsa = true;
		m_bCsa = true;
		m_bMetdiv = true;
		m_bNecta = true;
		m_bCnecta = true;
		m_bNectadiv = true;

	}
	UpdateData(FALSE);	
}

void Options2::OnClearall() 
{
	// TODO: Add your control notification handler code here
	UpdateData(true);
/* off for kml
	m_bTypeA = false;
	m_bTypeB = false;
	m_bTypeC = false;
	m_bTypeD = false;
	m_bTypeE = false;
	m_bTypeF = false;
	m_bTypeH = false;
	m_bTypeX = false;*/
	m_bClip = false;
	m_bSetforAll = false;
	m_bCounty00 = false;
	m_bBlock00 = false;
	m_bBlockCU = false;
	m_bCountyCQ = false;
	m_bCountyCU = false;
	m_bGroup00 = false;
	m_bGroupCU = false;
	m_bTract00 = false;
	m_bTractCQ = false;
	m_bTractCU = false;
	m_bAIANHH00 = false;
	m_bAIANHHCQ = false;
	m_bAIANHHCU = false;
	m_bAITS00 = false;
	m_bAITSCQ = false;
	m_bAITSCU = false;
	m_bAll = false;
	m_bANRC00 = false;
	m_bANRCCQ = false;
	m_bANRCCU = false;
	m_bBlockCQ = false;
	m_bCd106 = false;
	m_bCdCU = false;
	m_bConcit00 = false;
	m_bConcitCQ = false;
	m_bConcitCU = false;
	m_bCousub00 = false;
	m_bCousubCQ = false;
	m_bCousubCU = false;
	m_bElem00 = false;
	m_bElemCU = false;
	m_bLand = false;
	m_bMsa00 = false;
	m_bMsaCU = false;
	m_bNecma00 = false;
	m_bNecmaCU = false;
	m_bPlace00 = false;
	m_bPlaceCQ = false;
	m_bPlaceCU = false;
	m_bPmsa00 = false;
	m_bPmsaCU = false;
	m_bPuma5 = false;
	m_bPuma1 = false;
	m_bSec00 = false;
	m_bSldl = false;
	m_bSldu = false;
	m_bSubmcdCQ = false;
	m_bSubmcd00 = false;
	m_bSubmcdCU = false;
	m_bTaz = false;
	m_bUga = false;
	m_bUni00 = false;
	m_bUniCU = false;
	m_bUrban00 = false;
	m_bUrbanCQ = false;
	m_bVote = false;
	m_bWater = false;
	m_bZcta300 = false;
	m_bZcta3CU = false;
	m_bZcta500 = false;
	m_bZcta5CU = false;
	m_bGroupCQ = false;
	m_bSecCU = false;
	if (CurrentVersion >= 105) //|| (CurrentVersion == 106)) //if (CurrentVersion == 105)
	{
		m_bCountyec = false;
		m_bPlaceec = false;
		m_bComreg = false;
		m_bCbsa = false;
		m_bCsa = false;
		m_bMetdiv = false;
		m_bNecta = false;
		m_bCnecta = false;
		m_bNectadiv = false;
	}	
	UpdateData(FALSE);	
}

void Options2::OnOK() 
{

					//	        1         2         3         4         5         6         7         8
                    //01234567890123456789012345678901234567890123456789012345678901234567890123456789012345
    CurrentOptions = "00000000000000000000000000000000000000000000000000000000000000000000000000000000000000";
	UpdateData(TRUE);
/* off for kml
	if (m_bTypeA)
		CurrentOptions.SetAt(0,'1');
	else
		CurrentOptions.SetAt(0,'0');
	if (m_bTypeB)
		CurrentOptions.SetAt(1,'1');
	else
		CurrentOptions.SetAt(1,'0');
	if (m_bTypeC)
		CurrentOptions.SetAt(2,'1');
	else
		CurrentOptions.SetAt(2,'0');			
	if (m_bTypeD)
		CurrentOptions.SetAt(3,'1');
	else
		CurrentOptions.SetAt(3,'0');			
	if (m_bTypeE)
		CurrentOptions.SetAt(4,'1');
	else
		CurrentOptions.SetAt(4,'0');			
	if (m_bTypeF) 
		CurrentOptions.SetAt(5,'1');
	else
		CurrentOptions.SetAt(5,'0');			
	if (m_bTypeH)
		CurrentOptions.SetAt(6,'1');
	else
		CurrentOptions.SetAt(6,'0');						
	if (m_bTypeX)
		CurrentOptions.SetAt(7,'1');
	else
		CurrentOptions.SetAt(7,'0');									
		*/
	if (m_bCounty00)
		CurrentOptions.SetAt(8,'1');
	else
		CurrentOptions.SetAt(8,'0');									
	if (m_bCountyCU)
		CurrentOptions.SetAt(9,'1');
	else
		CurrentOptions.SetAt(9,'0');									
	if (m_bCountyCQ)
		CurrentOptions.SetAt(10,'1');
	else
		CurrentOptions.SetAt(10,'0');									
	if (m_bTract00)
		CurrentOptions.SetAt(11,'1');
	else
		CurrentOptions.SetAt(11,'0');
	if (m_bTractCU)
		CurrentOptions.SetAt(12,'1');
	else
		CurrentOptions.SetAt(12,'0');
	if (m_bTractCQ)
		CurrentOptions.SetAt(13,'1');
	else
		CurrentOptions.SetAt(13,'0');
	if (m_bGroup00)
		CurrentOptions.SetAt(14,'1');
	else
		CurrentOptions.SetAt(14,'0');
	if (m_bGroupCU)
		CurrentOptions.SetAt(15,'1');
	else
		CurrentOptions.SetAt(15,'0');
	if (m_bGroupCQ)
		CurrentOptions.SetAt(16,'1');
	else
		CurrentOptions.SetAt(16,'0');
	if (m_bBlock00)
		CurrentOptions.SetAt(17,'1');
	else
		CurrentOptions.SetAt(17,'0');
	if (m_bBlockCU)
		CurrentOptions.SetAt(18,'1');
	else
		CurrentOptions.SetAt(18,'0');
	if (m_bBlockCQ)
		CurrentOptions.SetAt(19,'1');
	else
		CurrentOptions.SetAt(19,'0');
	if (m_bAIANHH00)
		CurrentOptions.SetAt(20,'1');
	else
		CurrentOptions.SetAt(20,'0');
	if (m_bAIANHHCU)
		CurrentOptions.SetAt(21,'1');
	else
		CurrentOptions.SetAt(21,'0');	
	if (m_bAIANHHCQ)
		CurrentOptions.SetAt(22,'1');
	else
		CurrentOptions.SetAt(22,'0');
	if (m_bANRC00)
		CurrentOptions.SetAt(23,'1');
	else
		CurrentOptions.SetAt(23,'0');
	if (m_bANRCCU)
		CurrentOptions.SetAt(24,'1');
	else
		CurrentOptions.SetAt(24,'0');
	if (m_bANRCCQ)
		CurrentOptions.SetAt(25,'1');
	else
		CurrentOptions.SetAt(25,'0');
	if (m_bAITS00)
		CurrentOptions.SetAt(26,'1');
	else
		CurrentOptions.SetAt(26,'0');
	if (m_bAITSCU)
		CurrentOptions.SetAt(27,'1');
	else
		CurrentOptions.SetAt(27,'0');
	if (m_bAITSCQ)
		CurrentOptions.SetAt(28,'1');
	else
		CurrentOptions.SetAt(28,'0');
	if (m_bConcit00)
		CurrentOptions.SetAt(29,'1');
	else
		CurrentOptions.SetAt(29,'0');
	if (m_bConcitCU)
		CurrentOptions.SetAt(30,'1');
	else
		CurrentOptions.SetAt(30,'0');
	if (m_bConcitCQ)
		CurrentOptions.SetAt(31,'1');
	else
		CurrentOptions.SetAt(31,'0');
	if (m_bCousub00)
		CurrentOptions.SetAt(32,'1');
	else
		CurrentOptions.SetAt(32,'0');
	if (m_bCousubCU)
		CurrentOptions.SetAt(33,'1');
	else
		CurrentOptions.SetAt(33,'0');
	if (m_bCousubCQ)
		CurrentOptions.SetAt(34,'1');
	else
		CurrentOptions.SetAt(34,'0');
	if (m_bSubmcd00)
		CurrentOptions.SetAt(35,'1');
	else
		CurrentOptions.SetAt(35,'0');
	if (m_bSubmcdCU)
		CurrentOptions.SetAt(36,'1');
	else
		CurrentOptions.SetAt(36,'0');
	if (m_bSubmcdCQ)
		CurrentOptions.SetAt(37,'1');
	else
		CurrentOptions.SetAt(37,'0');
	if (m_bPlace00)
		CurrentOptions.SetAt(38,'1');
	else
		CurrentOptions.SetAt(38,'0');
	if (m_bPlaceCU)
		CurrentOptions.SetAt(39,'1');
	else
		CurrentOptions.SetAt(39,'0');
	if (m_bPlaceCQ)
		CurrentOptions.SetAt(40,'1');
	else
		CurrentOptions.SetAt(40,'0');
	if (m_bElem00)
		CurrentOptions.SetAt(41,'1');
	else
		CurrentOptions.SetAt(41,'0');
	if (m_bElemCU)
		CurrentOptions.SetAt(42,'1');
	else
		CurrentOptions.SetAt(42,'0');
	if (m_bSec00)
		CurrentOptions.SetAt(43,'1');
	else
		CurrentOptions.SetAt(43,'0');
	if (m_bSecCU)
		CurrentOptions.SetAt(44,'1');
	else
		CurrentOptions.SetAt(44,'0');
	if (m_bUni00)
		CurrentOptions.SetAt(45,'1');
	else
		CurrentOptions.SetAt(45,'0');
	if (m_bUniCU)
		CurrentOptions.SetAt(46,'1');
	else
		CurrentOptions.SetAt(46,'0');
	if (m_bMsa00)
		CurrentOptions.SetAt(47,'1');
	else
		CurrentOptions.SetAt(47,'0');
	if (m_bMsaCU)
		CurrentOptions.SetAt(48,'1');
	else
		CurrentOptions.SetAt(48,'0');
	if (m_bPmsa00)
		CurrentOptions.SetAt(49,'1');
	else
		CurrentOptions.SetAt(49,'0');
	if (m_bPmsaCU)
		CurrentOptions.SetAt(50,'1');
	else
		CurrentOptions.SetAt(50,'0');
	if (m_bNecma00)
		CurrentOptions.SetAt(51,'1');
	else
		CurrentOptions.SetAt(51,'0');
	if (m_bNecmaCU)
		CurrentOptions.SetAt(52,'1');
	else
		CurrentOptions.SetAt(52,'0');
	//space 53 reserved for version flag
	if (CurrentVersion == 104)
		CurrentOptions.SetAt(53,'9');
	if (CurrentVersion == 105)
		CurrentOptions.SetAt(53,'a');
	if (CurrentVersion == 106)
		CurrentOptions.SetAt(53,'b');
	if (CurrentVersion == 107)
		CurrentOptions.SetAt(53,'c');
	if (CurrentVersion == 108)
		CurrentOptions.SetAt(53,'d');
	if (m_bCd106)
		CurrentOptions.SetAt(54,'1');
	else
		CurrentOptions.SetAt(54,'0');
	if (m_bCdCU)
		CurrentOptions.SetAt(55,'1');
	else
		CurrentOptions.SetAt(55,'0');
	if (m_bZcta500)
		CurrentOptions.SetAt(56,'1');
	else
		CurrentOptions.SetAt(56,'0');
	if (m_bZcta5CU)
		CurrentOptions.SetAt(57,'1');
	else
		CurrentOptions.SetAt(57,'0');
	if (m_bZcta300)
		CurrentOptions.SetAt(58,'1');
	else
		CurrentOptions.SetAt(58,'0');
	if (m_bZcta3CU)
		CurrentOptions.SetAt(59,'1');
	else
		CurrentOptions.SetAt(59,'0');
	if (m_bUrban00)
		CurrentOptions.SetAt(60,'1');
	else
		CurrentOptions.SetAt(60,'0');
	if (m_bUrbanCQ)
		CurrentOptions.SetAt(61,'1');
	else
		CurrentOptions.SetAt(61,'0');
	if (m_bTaz)
		CurrentOptions.SetAt(62,'1');
	else
		CurrentOptions.SetAt(62,'0');
	if (m_bVote)
		CurrentOptions.SetAt(63,'1');
	else
		CurrentOptions.SetAt(63,'0');
	if (m_bSldu)
		CurrentOptions.SetAt(64,'1');
	else
		CurrentOptions.SetAt(64,'0');
	if (m_bSldl)
		CurrentOptions.SetAt(65,'1');
	else
		CurrentOptions.SetAt(65,'0');
	if (m_bUga)
		CurrentOptions.SetAt(66,'1');
	else
		CurrentOptions.SetAt(66,'0');
	if (m_bLand)
		CurrentOptions.SetAt(67,'1');
	else
		CurrentOptions.SetAt(67,'0');
	if (m_bWater)
		CurrentOptions.SetAt(68,'1');
	else
		CurrentOptions.SetAt(68,'0');
	if (m_bPuma5)
		CurrentOptions.SetAt(69,'1');
	else
		CurrentOptions.SetAt(69,'0');
	if (m_bPuma1)
		CurrentOptions.SetAt(70,'1');
	else
		CurrentOptions.SetAt(70,'0');
	if (m_bAll)
		CurrentOptions.SetAt(71,'1');
	else
		CurrentOptions.SetAt(71,'0');
	if (CurrentVersion >= 105)
	{
		if (m_bCountyec)
			CurrentOptions.SetAt(48,'1');
		else
			CurrentOptions.SetAt(48,'0');
		if (m_bPlaceec)
			CurrentOptions.SetAt(50,'1');
		else
			CurrentOptions.SetAt(50,'0');
		if (m_bComreg)
			CurrentOptions.SetAt(52,'1');
		else
			CurrentOptions.SetAt(52,'0');
		if (m_bCbsa)
			CurrentOptions.SetAt(72,'1');
		else
			CurrentOptions.SetAt(72,'0');
		if (m_bCsa)
			CurrentOptions.SetAt(73,'1');
		else
			CurrentOptions.SetAt(73,'0');
		if (m_bMetdiv)
			CurrentOptions.SetAt(74,'1');
		else
			CurrentOptions.SetAt(74,'0');
		if (m_bNecta)
			CurrentOptions.SetAt(75,'1');
		else
			CurrentOptions.SetAt(75,'0');
		if (m_bCnecta)
			CurrentOptions.SetAt(76,'1');
		else
			CurrentOptions.SetAt(76,'0');
		if (m_bNectadiv)
			CurrentOptions.SetAt(77,'1');
		else
			CurrentOptions.SetAt(77,'0');
	}
	//save some buffer space
	//Pushpins
	if (m_bClip)
		CurrentOptions.SetAt(80,'1');
	else
		CurrentOptions.SetAt(80,'0');
	if ((m_bSetforAll) && (!SetForAll))
	{
		GlobalOptions = CurrentOptions;
		GlobalVersion = CurrentVersion;
		SetForAll = 1;
		GetDlgItem(IDC_SETALL)->EnableWindow(FALSE);

	}
	
	CDialog::OnOK();
}
