#if !defined(AFX_OUTPUTOPTIONS_H__40FD2E93_6895_4E41_825C_3037C8448C5A__INCLUDED_)
#define AFX_OUTPUTOPTIONS_H__40FD2E93_6895_4E41_825C_3037C8448C5A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// OutputOptions.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// OutputOptions dialog

class OutputOptions : public CDialog
{
// Construction
public:
	OutputOptions(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(OutputOptions)
	enum { IDD = IDD_OUTPUTOPTIONS_DIALOG };
	int		m_Organize;
	CString	m_strOutputDir2;
	int		m_Ads;
	BOOL	m_Pushpins;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(OutputOptions)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(OutputOptions)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnBrowse2();
	afx_msg void OnClose();
	afx_msg void OnCancelMode();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OUTPUTOPTIONS_H__40FD2E93_6895_4E41_825C_3037C8448C5A__INCLUDED_)
