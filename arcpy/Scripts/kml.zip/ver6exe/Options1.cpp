/* Options1.cpp : implementation file
Written by Bruce Ralston
This code manages the dialog for tiger options.  It applies to TIGER versions 1994 to CD 108
*/

#include "stdafx.h"
#include "tgr2shp.h"
#include "Options1.h"
#include "MyFileOpenDlg.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
extern CString CurrentDir;
extern CString CurrentOptions;
//extern CString GlobalDir;
extern CString GlobalOptions;
extern int SetForAll;
extern int CurrentVersion;
extern int GlobalVersion;
/////////////////////////////////////////////////////////////////////////////
// Options1 dialog


Options1::Options1(CWnd* pParent /*=NULL*/)
	: CDialog(Options1::IDD, pParent)
{
	//{{AFX_DATA_INIT(Options1)
	m_strOutputDir = _T("");
	m_bTypeA = FALSE;
	m_bTypeB = FALSE;
	m_bTypeC = FALSE;
	m_bTypeD = FALSE;
	m_bTypeE = FALSE;
	m_bTypeF = FALSE;
	m_bTypeH = FALSE;
	m_bTypeX = FALSE;
	m_bAnrc = FALSE;
	m_bBlock = FALSE;
	m_bCounty = FALSE;
	m_bGroup = FALSE;
	m_bKgl = FALSE;
	m_bLand = FALSE;
	m_bTaz = FALSE;
	m_bTract = FALSE;
	m_bSetForAll = FALSE;
	m_bCmsa = FALSE;
	m_bCongress = FALSE;
	m_bElementary = FALSE;
	m_bPmsa = FALSE;
	m_bSecondary = FALSE;
	m_bStsenate = FALSE;
	m_bUnified = FALSE;
	m_bWater = FALSE;
	m_bSthouse = FALSE;
	m_bCollection = FALSE;
	m_bMcdcu = FALSE;
	m_bPlacescu = FALSE;
	m_bUrban00 = FALSE;
	m_bVoting00 = FALSE;
	m_bAir90 = FALSE;
	m_bAircu = FALSE;
	m_bMcd90 = FALSE;
	m_bPlaces90 = FALSE;
	m_bUrban90 = FALSE;
	m_bVoting90 = FALSE;
	m_bMiddle2 = FALSE;
	m_bClip = FALSE;
	m_bCountycu = FALSE;
	m_strType = _T("");
	m_bAllpolys = FALSE;
	m_bZcta = FALSE;
	m_bCD106 = FALSE;
	m_bUGA = FALSE;
	m_bGroup00 = FALSE;
	m_bPuma = FALSE;
	m_bBlock00 = FALSE;
	m_bTract00 = FALSE;
	m_bTribal = FALSE;
	m_bUA00 = FALSE;
	m_bUA90Red = FALSE;
	//}}AFX_DATA_INIT
}


void Options1::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(Options1)
	DDX_Text(pDX, IDC_OUTPUTDIR, m_strOutputDir);
	DDX_Check(pDX, IDC_TYPEA, m_bTypeA);
	DDX_Check(pDX, IDC_TYPEB, m_bTypeB);
	DDX_Check(pDX, IDC_TYPEC, m_bTypeC);
	DDX_Check(pDX, IDC_TYPED, m_bTypeD);
	DDX_Check(pDX, IDC_TYPEE, m_bTypeE);
	DDX_Check(pDX, IDC_TYPEF, m_bTypeF);
	DDX_Check(pDX, IDC_TYPEH, m_bTypeH);
	DDX_Check(pDX, IDC_TYPEX, m_bTypeX);
	DDX_Check(pDX, IDC_ANRC, m_bAnrc);
	DDX_Check(pDX, IDC_BLOCK, m_bBlock);
	DDX_Check(pDX, IDC_COUNTY, m_bCounty);
	DDX_Check(pDX, IDC_GROUP, m_bGroup);
	DDX_Check(pDX, IDC_KGL, m_bKgl);
	DDX_Check(pDX, IDC_LAND, m_bLand);
	DDX_Check(pDX, IDC_TAZ, m_bTaz);
	DDX_Check(pDX, IDC_TRACT, m_bTract);
	DDX_Check(pDX, IDC_SETALL, m_bSetForAll);
	DDX_Check(pDX, IDC_CMSA, m_bCmsa);
	DDX_Check(pDX, IDC_CONGRESS, m_bCongress);
	DDX_Check(pDX, IDC_ELEMENTARY, m_bElementary);
	DDX_Check(pDX, IDC_PMSA, m_bPmsa);
	DDX_Check(pDX, IDC_SECONDARY, m_bSecondary);
	DDX_Check(pDX, IDC_STSENATE, m_bStsenate);
	DDX_Check(pDX, IDC_UNIFIED, m_bUnified);
	DDX_Check(pDX, IDC_WATER, m_bWater);
	DDX_Check(pDX, IDC_STHOUSE, m_bSthouse);
	DDX_Check(pDX, IDC_COLLECTION, m_bCollection);
	DDX_Check(pDX, IDC_MCDCU, m_bMcdcu);
	DDX_Check(pDX, IDC_PLACESCU, m_bPlacescu);
	DDX_Check(pDX, IDC_URBAN00, m_bUrban00);
	DDX_Check(pDX, IDC_VOTING00, m_bVoting00);
	DDX_Check(pDX, IDC_AIR90, m_bAir90);
	DDX_Check(pDX, IDC_AIRCU, m_bAircu);
	DDX_Check(pDX, IDC_MCD90, m_bMcd90);
	DDX_Check(pDX, IDC_PLACES90, m_bPlaces90);
	DDX_Check(pDX, IDC_URBAN90, m_bUrban90);
	DDX_Check(pDX, IDC_VOTING90, m_bVoting90);
	DDX_Check(pDX, IDC_MIDDLE2, m_bMiddle2);
	DDX_Check(pDX, IDC_CLIP, m_bClip);
	DDX_Check(pDX, IDC_COUNTYCU, m_bCountycu);
	DDX_Check(pDX, IDC_ALLPOLY, m_bAllpolys);
	DDX_Check(pDX, IDC_ZCTA, m_bZcta);
	DDX_Check(pDX, IDC_CD106, m_bCD106);
	DDX_Check(pDX, IDC_UGA, m_bUGA);
	DDX_Check(pDX, IDC_GROUP2000, m_bGroup00);
	DDX_Check(pDX, IDC_PUMA, m_bPuma);
	DDX_Check(pDX, IDC_BLOCK2000, m_bBlock00);
	DDX_Check(pDX, IDC_TRACT2000, m_bTract00);
	DDX_Check(pDX, IDC_TRIBAL, m_bTribal);
	DDX_Check(pDX, IDC_UA00, m_bUA00);
	DDX_Check(pDX, IDC_UA90RED, m_bUA90Red);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(Options1, CDialog)
	//{{AFX_MSG_MAP(Options1)
	ON_BN_CLICKED(IDBROWSE, OnBrowse)
	ON_BN_CLICKED(IDC_SELECTALL, OnSelectall)
	ON_BN_CLICKED(IDC_CLEARALL, OnClearall)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Options1 message handlers

void Options1::OnBrowse() 
{
	
	CMyFileOpenDlg  cfdlg(TRUE, NULL, NULL, 
        OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | 
        OFN_ENABLETEMPLATE, NULL, this);
    cfdlg.m_ofn.hInstance      = AfxGetInstanceHandle();
    cfdlg.m_ofn.lpTemplateName = MAKEINTRESOURCE(FILEOPENORD);
    cfdlg.m_ofn.Flags         &= ~OFN_EXPLORER;
	cfdlg.m_ofn.lpstrInitialDir = m_strOutputDir;
	UpdateData(TRUE);
    if (IDOK == cfdlg.DoModal())
    {
        WORD wFileOffset;
        wFileOffset = cfdlg.m_ofn.nFileOffset;

        cfdlg.m_ofn.lpstrFile[wFileOffset-1] = 0;
		CString curdrive;
		curdrive = cfdlg.m_ofn.lpstrFile;
		int dtype = GetDriveType(curdrive.Left(3));
		if (dtype == DRIVE_CDROM)
		{
			AfxMessageBox("The Output Directory cannot be a CD-ROM");
			OnBrowse();		
		}
		else
			m_strOutputDir = cfdlg.m_ofn.lpstrFile;
		UpdateData(FALSE);
	}
		
}

BOOL Options1::OnInitDialog() 
{
	CDialog::OnInitDialog();
	CString titlestring;	
	switch (CurrentVersion)
	{
	case 94:		
	case 95:
	case 97:
		titlestring.Format("Layer Extraction Options for TIGER %d",CurrentVersion);
		SetWindowText(titlestring);
		break;
	case 98:
		titlestring.Format("Layer Extraction Options for TIGER %d",CurrentVersion);
		SetWindowText(titlestring);		
		this->SetDlgItemText(IDC_TYPEF,"Types F and G");
		break;
	case 99:
		titlestring.Format("Layer Extraction Options for Census 2000 Dress Rehearsal");
		SetWindowText(titlestring);				
		this->SetDlgItemText(IDC_TYPEF,"Types F and G");
		this->SetDlgItemText(IDC_COUNTYCU,"County 2000");
		this->SetDlgItemText(IDC_PLACESCU,"Places 2000");
		this->SetDlgItemText(IDC_MCDCU,"MCD/CCD 2000");
		GetDlgItem(IDC_VOTING00)->EnableWindow(TRUE);
		this->SetDlgItemText(IDC_AIRCU,"AIR 2000");
		this->SetDlgItemText(IDC_ANRC,"ANRC 2000");
		this->SetDlgItemText(IDC_CMSA,"CMSA/MA 2000");
		this->SetDlgItemText(IDC_PMSA,"PMSA 2000");
		this->SetDlgItemText(IDC_STHOUSE,"State House Districts 2000");
		this->SetDlgItemText(IDC_STSENATE,"State Senate Districts 2000");
		GetDlgItem(IDC_COLLECTION)->EnableWindow(TRUE);
		GetDlgItem(IDC_TRACT2000)->EnableWindow(TRUE);
		GetDlgItem(IDC_BLOCK2000)->EnableWindow(TRUE);
		GetDlgItem(IDC_ZCTA)->EnableWindow(TRUE);
		break;
	case 100:
		titlestring.Format("Layer Extraction Options for TIGER99/2000 Redistricting");
		SetWindowText(titlestring);
		this->SetDlgItemText(IDC_COUNTYCU,"County 2000");
		this->SetDlgItemText(IDC_PLACESCU,"Places 2000");
		this->SetDlgItemText(IDC_MCDCU,"MCD/CCD 2000");
		this->SetDlgItemText(IDC_AIRCU,"AIANHHCE00");
		this->SetDlgItemText(IDC_AIR90,"AIANHHCE90");
		this->SetDlgItemText(IDC_STHOUSE,"State Upper Chamber");
		this->SetDlgItemText(IDC_STSENATE,"State Lower Chamber");
		this->SetDlgItemText(IDC_ANRC,"ANRC Current");
		GetDlgItem(IDC_TRACT2000)->EnableWindow(TRUE);
		GetDlgItem(IDC_BLOCK2000)->EnableWindow(TRUE);
		GetDlgItem(IDC_GROUP2000)->EnableWindow(TRUE);
		GetDlgItem(IDC_VOTING00)->EnableWindow(TRUE);
		GetDlgItem(IDC_URBAN00)->EnableWindow(TRUE);
		GetDlgItem(IDC_CD106)->EnableWindow(TRUE);
		GetDlgItem(IDC_UGA)->EnableWindow(TRUE);
		GetDlgItem(IDC_TRIBAL)->EnableWindow(TRUE);
		break;
	case 101:
		titlestring.Format("Layer Extraction Options for TIGER 2000");
		SetWindowText(titlestring);
		this->SetDlgItemText(IDC_COUNTYCU,"County 2000");
		this->SetDlgItemText(IDC_PLACESCU,"Places 2000");
		this->SetDlgItemText(IDC_MCDCU,"MCD/CCD 2000");
		this->SetDlgItemText(IDC_AIRCU,"AIANHHCE00");
		this->SetDlgItemText(IDC_AIR90,"AIANHHCE90");
		this->SetDlgItemText(IDC_STHOUSE,"State Upper Chamber");
		this->SetDlgItemText(IDC_STSENATE,"State Lower Chamber");
		this->SetDlgItemText(IDC_ANRC,"ANRC Current");
		GetDlgItem(IDC_TRACT2000)->EnableWindow(TRUE);
		GetDlgItem(IDC_BLOCK2000)->EnableWindow(TRUE);
		GetDlgItem(IDC_GROUP2000)->EnableWindow(TRUE);
		GetDlgItem(IDC_VOTING00)->EnableWindow(TRUE);
		GetDlgItem(IDC_URBAN00)->EnableWindow(TRUE);
		GetDlgItem(IDC_CD106)->EnableWindow(TRUE);
		GetDlgItem(IDC_UGA)->EnableWindow(TRUE);
		GetDlgItem(IDC_TRIBAL)->EnableWindow(TRUE);
		GetDlgItem(IDC_ZCTA)->EnableWindow(TRUE);
		break;
	case 102:
		titlestring.Format("Layer Extraction Options for TIGER 2000 Urban Areas");
		SetWindowText(titlestring);
		this->SetDlgItemText(IDC_COUNTYCU,"County 2000");
		this->SetDlgItemText(IDC_PLACESCU,"Places 2000");
		this->SetDlgItemText(IDC_MCDCU,"MCD/CCD 2000");
		this->SetDlgItemText(IDC_AIRCU,"AIANHHCE00");
		this->SetDlgItemText(IDC_AIR90,"AIANHHCE90");
		this->SetDlgItemText(IDC_STHOUSE,"State Upper Chamber");
		this->SetDlgItemText(IDC_STSENATE,"State Lower Chamber");
		this->SetDlgItemText(IDC_ANRC,"ANRC Current");
		GetDlgItem(IDC_TRACT2000)->EnableWindow(TRUE);
		GetDlgItem(IDC_BLOCK2000)->EnableWindow(TRUE);
		GetDlgItem(IDC_GROUP2000)->EnableWindow(TRUE);
		GetDlgItem(IDC_VOTING00)->EnableWindow(TRUE);
		GetDlgItem(IDC_URBAN00)->EnableWindow(TRUE);
		GetDlgItem(IDC_CD106)->EnableWindow(TRUE);
		GetDlgItem(IDC_UGA)->EnableWindow(TRUE);
		GetDlgItem(IDC_TRIBAL)->EnableWindow(TRUE);
		GetDlgItem(IDC_ZCTA)->EnableWindow(TRUE);
		GetDlgItem(IDC_UA00)->EnableWindow(TRUE);
		GetDlgItem(IDC_PUMA)->EnableWindow(TRUE);
		break;
	case 103:
		titlestring.Format("Layer Extraction Options for 108th Congressional Districts TIGER 2000");
		SetWindowText(titlestring);
		this->SetDlgItemText(IDC_COUNTYCU,"County 2000");
		this->SetDlgItemText(IDC_PLACESCU,"Places 2000");
		this->SetDlgItemText(IDC_MCDCU,"MCD/CCD 2000");
		this->SetDlgItemText(IDC_AIRCU,"AIANHHCE00");
		this->SetDlgItemText(IDC_AIR90,"AIANHHCE90");
		this->SetDlgItemText(IDC_STHOUSE,"State Upper Chamber");
		this->SetDlgItemText(IDC_STSENATE,"State Lower Chamber");
		this->SetDlgItemText(IDC_ANRC,"ANRC Current");
		this->SetDlgItemText(IDC_COLLECTION,"Urban 2000 Corrected");
		this->SetDlgItemText(IDC_CONGRESS,"Congressional Districts Current (108th)");
		GetDlgItem(IDC_TRACT2000)->EnableWindow(TRUE);
		GetDlgItem(IDC_BLOCK2000)->EnableWindow(TRUE);
		GetDlgItem(IDC_GROUP2000)->EnableWindow(TRUE);
		GetDlgItem(IDC_VOTING00)->EnableWindow(TRUE);
		GetDlgItem(IDC_URBAN00)->EnableWindow(TRUE);
		GetDlgItem(IDC_CD106)->EnableWindow(TRUE);
		GetDlgItem(IDC_UGA)->EnableWindow(TRUE);
		GetDlgItem(IDC_TRIBAL)->EnableWindow(TRUE);
		GetDlgItem(IDC_ZCTA)->EnableWindow(TRUE);
		GetDlgItem(IDC_UA00)->EnableWindow(TRUE);
		GetDlgItem(IDC_PUMA)->EnableWindow(TRUE);
		GetDlgItem(IDC_UA90RED)->EnableWindow(TRUE);
		break;
	}

/*off for kml
	if (CurrentOptions[0] == '0')
		m_bTypeA = FALSE;
	else
		m_bTypeA = TRUE;
	if (CurrentOptions[1] == '0')
		m_bTypeB = FALSE;
	else
		m_bTypeB = TRUE;
	if (CurrentOptions[2] == '0')
		m_bTypeC = FALSE;
	else
		m_bTypeC = TRUE;
	if (CurrentOptions[3] == '0')
		m_bTypeD = FALSE;
	else
		m_bTypeD = TRUE;
	if (CurrentOptions[4] == '0')
		m_bTypeE = FALSE;
	else
		m_bTypeE = TRUE;
	if (CurrentOptions[5] == '0')
		m_bTypeF = FALSE;
	else
		m_bTypeF = TRUE;
	if (CurrentOptions[6] == '0')
		m_bTypeH = FALSE;
	else
		m_bTypeH = TRUE;
	if (CurrentOptions[7] == '0')
		m_bTypeX = FALSE;
	else
		m_bTypeX = TRUE;
		*/
	if (CurrentOptions[8] == '0')
		m_bCounty = FALSE;
	else
		m_bCounty = TRUE;
	if (CurrentOptions[9] == '0')
		m_bCountycu = FALSE;
	else
		m_bCountycu = TRUE;
	if (CurrentOptions[10] == '0')
		m_bTract = FALSE;
	else
		m_bTract = TRUE;
	if (CurrentOptions[11] == '0')
		m_bGroup = FALSE;
	else
		m_bGroup = TRUE;
	if (CurrentOptions[12] == '0')
		m_bBlock = FALSE;
	else
		m_bBlock = TRUE;
	if (CurrentOptions[13] == '0')
		m_bPlaces90 = FALSE;
	else
		m_bPlaces90 = TRUE;
	if (CurrentOptions[14] == '0')
		m_bPlacescu = FALSE;
	else
		m_bPlacescu = TRUE;
	
	if (CurrentOptions[15] == '0')
		m_bMcd90 = FALSE;
	else
		m_bMcd90 = TRUE;
	if (CurrentOptions[16] == '0')
		m_bMcdcu = FALSE;
	else
		m_bMcdcu = TRUE;
	
	if (CurrentOptions[17] == '0')
		m_bVoting90 = FALSE;
	else
		m_bVoting90 = TRUE;
	if (CurrentOptions[18] == '0')
		m_bVoting00 = FALSE; //18
	else
		m_bVoting00 = TRUE;
	if (CurrentOptions[19] == '0')
		m_bAir90 = FALSE;
	else
		m_bAir90 = TRUE;
	if (CurrentOptions[20] == '0')
		m_bAircu = FALSE;
	else
		m_bAircu = TRUE;
	
	if (CurrentOptions[21] == '0')
		m_bAnrc = FALSE;
	else
		m_bAnrc = TRUE;
	if (CurrentOptions[22] == '0')
		m_bKgl = FALSE;
	else
		m_bKgl = TRUE;
	if (CurrentOptions[23] == '0')
		m_bLand = FALSE;
	else
		m_bLand = TRUE;
	if (CurrentOptions[24] == '0')
		m_bTaz = FALSE;
	else
		m_bTaz = TRUE;
	if (CurrentOptions[25] == '0')
		m_bUrban90 = FALSE;
	else
		m_bUrban90 = TRUE;
	if (CurrentOptions[26] == '0')
		m_bUrban00 = FALSE;
	else
		m_bUrban00 = TRUE;
	if (CurrentOptions[27] == '0')
		m_bElementary = FALSE;
	else
		m_bElementary = TRUE;
	if (CurrentOptions[28] == '0')
		m_bMiddle2 = FALSE;
	else
		m_bMiddle2 = TRUE;
	if (CurrentOptions[29] == '0')
		m_bSecondary = FALSE;
	else
		m_bSecondary = TRUE;
	if (CurrentOptions[30] == '0')
		m_bUnified = FALSE;
	else
		m_bUnified = TRUE;
	if (CurrentOptions[31] == '0')
		m_bWater = FALSE;
	else
		m_bWater = TRUE;
	if (CurrentOptions[32] == '0')
		m_bCmsa = FALSE;
	else
		m_bCmsa = TRUE;
	if (CurrentOptions[33] == '0')
		m_bPmsa = FALSE;
	else
		m_bPmsa = TRUE;
	if (CurrentOptions[34] == '0')
		m_bCongress = FALSE;
	else
		m_bCongress = TRUE;
	if (CurrentOptions[35] == '0')
		m_bSthouse = FALSE;
	else
		m_bSthouse = TRUE;
	if (CurrentOptions[36] == '0')
		m_bStsenate = FALSE;
	else
		m_bStsenate = TRUE;
	if (CurrentOptions[37] == '0')
		m_bCollection = FALSE;
	else
		m_bCollection = TRUE;
	if (CurrentOptions[38] == '0')
		m_bAllpolys = FALSE;
	else
		m_bAllpolys = TRUE;
	if (CurrentOptions[39] == '0')
		m_bTract00 = FALSE;
	else
		m_bTract00 = TRUE;
	if (CurrentOptions[40] == '0')
		m_bBlock00 = FALSE;
	else
		m_bBlock00 = TRUE;
	if (CurrentOptions[41] == '0')
		m_bZcta = FALSE;
	else
		m_bZcta = TRUE;
	if (CurrentOptions[42] == '0')
		m_bGroup00 = FALSE;
	else
		m_bGroup00 = TRUE;
	if (CurrentOptions[44] == '0')
		m_bTribal = FALSE;
	else
		m_bTribal = TRUE;
	if (CurrentOptions[45] == '0')
		m_bPuma = FALSE;
	else
		m_bPuma = TRUE;
	if (CurrentOptions[46] == '0')
		m_bCD106 = FALSE;
	else
		m_bCD106 = TRUE;
	if (CurrentOptions[47] == '0')
		m_bUGA = FALSE;
	else
		m_bUGA = TRUE;
	if (CurrentOptions[48] == '0')
		m_bUA00 = FALSE;
	else
		m_bUA00 = TRUE;
	if (CurrentOptions[49] == '0')
		m_bUA90Red = FALSE;
	else
		m_bUA90Red = TRUE;
//	pushpins for kml
	if (CurrentOptions[54] == '0')
		m_bClip = FALSE;
	else
		m_bClip = TRUE;
	
	if (SetForAll)
	{
		CButton* pBU = (CButton *) GetDlgItem(IDC_SETALL);	
		pBU->SetCheck(1);
		pBU->EnableWindow(false);
	}
	if (CurrentVersion < 97)
	{
		GetDlgItem(IDC_AIR90)->EnableWindow(FALSE);
		GetDlgItem(IDC_COLLECTION)->EnableWindow(FALSE);
		GetDlgItem(IDC_COUNTYCU)->EnableWindow(FALSE);
		GetDlgItem(IDC_ALLPOLY)->EnableWindow(FALSE);
		GetDlgItem(IDC_ALLPOLY)->EnableWindow(FALSE);	
	}
	if (CurrentVersion < 98)
	{
		GetDlgItem(IDC_COLLECTION)->EnableWindow(FALSE);
	
	}
	if (CurrentVersion >= 97)
		GetDlgItem(IDC_MIDDLE2)->EnableWindow(FALSE);

	if (CurrentVersion == 100)
	{
		GetDlgItem(IDC_ZCTA)->EnableWindow(FALSE);
		GetDlgItem(IDC_VOTING90)->EnableWindow(FALSE);
	}
	if (CurrentVersion >= 101)//||(CurrentVersion == 102))
	{
		GetDlgItem(IDC_VOTING90)->EnableWindow(FALSE);
	}
	UpdateData(false);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void Options1::OnOK() 
{
					//	        1         2         3         4         5
                    //01234567890123456789012345678901234567890123456789012345
    CurrentOptions = "00000000000000000000000000000000000000000000000000000000";
	UpdateData(TRUE);
	/*off for kml
	if (m_bTypeA)
		CurrentOptions.SetAt(0,'1');
	else
		CurrentOptions.SetAt(0,'0');
	if (m_bTypeB)
		CurrentOptions.SetAt(1,'1');
	else
		CurrentOptions.SetAt(1,'0');
	if (m_bTypeC)
		CurrentOptions.SetAt(2,'1');
	else
		CurrentOptions.SetAt(2,'0');			
	if (m_bTypeD)
		CurrentOptions.SetAt(3,'1');
	else
		CurrentOptions.SetAt(3,'0');			
	if (m_bTypeE)
		CurrentOptions.SetAt(4,'1');
	else
		CurrentOptions.SetAt(4,'0');			
	if (m_bTypeF) 
		CurrentOptions.SetAt(5,'1');
	else
		CurrentOptions.SetAt(5,'0');			
	if (m_bTypeH)
		CurrentOptions.SetAt(6,'1');
	else
		CurrentOptions.SetAt(6,'0');						
	if (m_bTypeX)
		CurrentOptions.SetAt(7,'1');
	else
		CurrentOptions.SetAt(7,'0');									
		*/
	if (m_bCounty)
		CurrentOptions.SetAt(8,'1');
	else
		CurrentOptions.SetAt(8,'0');												
	if (m_bCountycu)
		CurrentOptions.SetAt(9,'1');
	else
		CurrentOptions.SetAt(9,'0');
	if (m_bTract)
		CurrentOptions.SetAt(10,'1');
	else
		CurrentOptions.SetAt(10,'0');															
	if (m_bGroup)
		CurrentOptions.SetAt(11,'1');
	else
		CurrentOptions.SetAt(11,'0');																		
	if (m_bBlock)
		CurrentOptions.SetAt(12,'1');
	else
		CurrentOptions.SetAt(12,'0');			
	if (m_bPlaces90)
		CurrentOptions.SetAt(13,'1');
	else
		CurrentOptions.SetAt(13,'0');			
	if (m_bPlacescu)
		CurrentOptions.SetAt(14,'1');
	else
		CurrentOptions.SetAt(14,'0');			
	if (m_bMcd90)
		CurrentOptions.SetAt(15,'1');
	else
		CurrentOptions.SetAt(15,'0');
	if (m_bMcdcu)
		CurrentOptions.SetAt(16,'1');
	else
		CurrentOptions.SetAt(16,'0');
	if (m_bVoting90)
		CurrentOptions.SetAt(17,'1');
	else
		CurrentOptions.SetAt(17,'0');			
	if (m_bVoting00)
		CurrentOptions.SetAt(18,'1');
	else
		CurrentOptions.SetAt(18,'0'); //voting 2000
	if (m_bAir90)
		CurrentOptions.SetAt(19,'1');
	else
		CurrentOptions.SetAt(19,'0');			
	if (m_bAircu)
		CurrentOptions.SetAt(20,'1');
	else
		CurrentOptions.SetAt(20,'0');			
	if (m_bAnrc)
		CurrentOptions.SetAt(21,'1');
	else
		CurrentOptions.SetAt(21,'0');			
	if (m_bKgl)
		CurrentOptions.SetAt(22,'1');
	else
		CurrentOptions.SetAt(22,'0');			
	if (m_bLand)
		CurrentOptions.SetAt(23,'1');
	else
		CurrentOptions.SetAt(23,'0');			
	if (m_bTaz)
		CurrentOptions.SetAt(24,'1');
	else
		CurrentOptions.SetAt(24,'0');
	if (m_bUrban90)
		CurrentOptions.SetAt(25,'1');
	else
		CurrentOptions.SetAt(25,'0');
	if (m_bUrban00)
		CurrentOptions.SetAt(26,'1');
	else
		CurrentOptions.SetAt(26,'0'); //concity 
	if (m_bElementary)
		CurrentOptions.SetAt(27,'1');
	else
		CurrentOptions.SetAt(27,'0');
	if (m_bMiddle2)
		CurrentOptions.SetAt(28,'1');
	else
		CurrentOptions.SetAt(28,'0');
	if (m_bSecondary)
		CurrentOptions.SetAt(29,'1');
	else
		CurrentOptions.SetAt(29,'0');
	if (m_bUnified)
		CurrentOptions.SetAt(30,'1');
	else
		CurrentOptions.SetAt(30,'0');
	if (m_bWater)
		CurrentOptions.SetAt(31,'1');
	else
		CurrentOptions.SetAt(31,'0');
	if (m_bCmsa)
		CurrentOptions.SetAt(32,'1');
	else
		CurrentOptions.SetAt(32,'0');
	if (m_bPmsa)
		CurrentOptions.SetAt(33,'1');
	else
		CurrentOptions.SetAt(33,'0');
	if (m_bCongress)
		CurrentOptions.SetAt(34,'1');
	else
		CurrentOptions.SetAt(34,'0');
	if (m_bSthouse)
		CurrentOptions.SetAt(35,'1');
	else
		CurrentOptions.SetAt(35,'0');
	if (m_bStsenate)
		CurrentOptions.SetAt(36,'1');
	else
		CurrentOptions.SetAt(36,'0');
	if (m_bCollection)
		CurrentOptions.SetAt(37,'1');
	else
		CurrentOptions.SetAt(37,'0');
	if (m_bAllpolys)
		CurrentOptions.SetAt(38,'1');
	else
		CurrentOptions.SetAt(38,'0');
	//new for Dress Rehearsal
	if (m_bTract00)
		CurrentOptions.SetAt(39,'1');
	else
		CurrentOptions.SetAt(39,'0');
	if (m_bBlock00)
		CurrentOptions.SetAt(40,'1');
	else
		CurrentOptions.SetAt(40,'0');
	if (m_bZcta)
		CurrentOptions.SetAt(41,'1');
	else
		CurrentOptions.SetAt(41,'0');
	//new for vtdp
	if (m_bGroup00)
		CurrentOptions.SetAt(42,'1');
	else
		CurrentOptions.SetAt(42,'0');
	/*if (m_bConcit)
		CurrentOptions.SetAt(43,'1');
	else
		CurrentOptions.SetAt(43,'0');*/
	CurrentOptions.SetAt(43,'0');
	if (m_bTribal)
		CurrentOptions.SetAt(44,'1');
	else
		CurrentOptions.SetAt(44,'0');
	if (m_bPuma)
		CurrentOptions.SetAt(45,'1');
	else
		CurrentOptions.SetAt(45,'0');
	if (m_bCD106)
		CurrentOptions.SetAt(46,'1');
	else
		CurrentOptions.SetAt(46,'0');
	if (m_bUGA)
		CurrentOptions.SetAt(47,'1');
	else
		CurrentOptions.SetAt(47,'0');
	if (m_bUA00)
		CurrentOptions.SetAt(48,'1');
	else
		CurrentOptions.SetAt(48,'0');
	if (m_bUA90Red)
		CurrentOptions.SetAt(49,'1');
	else
		CurrentOptions.SetAt(49,'0');
	CurrentOptions.SetAt(50,'0');
	CurrentOptions.SetAt(51,'0');
	CurrentOptions.SetAt(52,'0');
	CurrentOptions.SetAt(55,'0');//switched location of type on release of 4.1
	//renumber from here
	
	if (m_bClip)
		CurrentOptions.SetAt(54,'1');
	else
		CurrentOptions.SetAt(54,'0');
	
	switch (CurrentVersion)
	{
	case 94:
		CurrentOptions.SetAt(53,'0');
		break;
	case 95:
		CurrentOptions.SetAt(53,'1');
		break;
	case 97:
		CurrentOptions.SetAt(53,'2');
		break;
	case 98:
		CurrentOptions.SetAt(53,'3');
		break;
	case 99: //dress rehearsal
		CurrentOptions.SetAt(53,'4');
		break;
	case 100:
		CurrentOptions.SetAt(53,'5');
		break;
	case 101:
		CurrentOptions.SetAt(53,'6');
		break;
	case 102:
		CurrentOptions.SetAt(53,'7');
		break;
	case 103:
		CurrentOptions.SetAt(53,'8');
		break;
	default:
		CurrentOptions.SetAt(53,'6');
		break;
	}

	if ((m_bSetForAll) && (!SetForAll))
	{
		GlobalOptions = CurrentOptions;
		GlobalVersion = CurrentVersion;
		SetForAll = 1;
	}
	CDialog::OnOK();
}

void Options1::OnSelectall() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	/*off for kml
	m_bTypeA = TRUE;
	m_bTypeB = TRUE;
	m_bTypeC = TRUE;
	m_bTypeD = TRUE;
	m_bTypeE = TRUE;
	m_bTypeF = TRUE;
	m_bTypeH = TRUE;
	m_bTypeX = TRUE;
	*/
	m_bCounty = TRUE;
	m_bCountycu = TRUE;
	m_bTract = TRUE;
	m_bGroup = TRUE;
	m_bBlock = TRUE;
	m_bPlaces90 = TRUE;
	m_bPlacescu = TRUE;
	m_bMcd90 = TRUE;
	m_bMcdcu = TRUE;
	m_bAir90 = TRUE;
	m_bAircu = TRUE;
	m_bVoting90 = TRUE;
	m_bVoting00 = TRUE;
	m_bAnrc = TRUE;
	m_bKgl = TRUE;
	m_bLand = TRUE;
	m_bTaz = TRUE;
	m_bUrban90 = TRUE;
	m_bUrban00 = TRUE;
	m_bElementary = TRUE;
	m_bMiddle2 = TRUE;
	m_bSecondary = TRUE;
	m_bUnified = TRUE;
	m_bWater = TRUE;
	m_bCmsa = TRUE;
	m_bPmsa = TRUE;
	m_bCongress = TRUE;
	m_bSthouse = TRUE;
	m_bStsenate = TRUE;	
	m_bCollection = TRUE;
	m_bAllpolys = TRUE;
	m_bTract00 = TRUE;
	m_bBlock00 = TRUE;
	m_bZcta = TRUE;
	m_bGroup00 = TRUE;
	//m_bConcit = TRUE;	
	m_bTribal = TRUE;
	//m_bPuma = TRUE;
	m_bCD106 = TRUE;
	m_bUGA = TRUE;
	if (CurrentVersion < 97)
	{
		m_bAir90 = FALSE;
		m_bCountycu = FALSE;
		m_bAllpolys = FALSE;
		
	}
	if (CurrentVersion < 98)
	{
		m_bCollection = FALSE;
	
	}
	if (CurrentVersion  > 95)
		m_bMiddle2 = FALSE;
	if (CurrentVersion < 99)
	{
		m_bVoting00 = FALSE;
		m_bTract00 = FALSE;
		m_bBlock00 = FALSE;
		m_bZcta = FALSE;
	}
	if (CurrentVersion < 100)
	{
		m_bGroup00 = FALSE;
		//m_bConcit = FALSE;
		m_bTribal = FALSE;
		m_bPuma = FALSE;
		m_bCD106 = FALSE;
		m_bUGA = FALSE;
		m_bUrban00 = FALSE;		
	}
	else
	{
		//m_bAnrc = FALSE;
		m_bPuma = FALSE;
		//m_bZcta = FALSE;
		m_bVoting90 = FALSE;
	}
	if (CurrentVersion == 100)
		m_bZcta = FALSE;
	if (CurrentVersion == 102)
	{
		m_bPuma = TRUE;
		m_bUA00 = TRUE;
	}
	if (CurrentVersion == 103)
	{
		m_bPuma = TRUE;
		m_bUA00 = TRUE;
		m_bUA90Red = TRUE;
	}


	m_bClip = TRUE;
	UpdateData(FALSE);

}

void Options1::OnClearall() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	/*off for kml
	m_bTypeA = FALSE;
	m_bTypeB = FALSE;
	m_bTypeC = FALSE;
	m_bTypeD = FALSE;
	m_bTypeE = FALSE;
	m_bTypeF = FALSE;
	m_bTypeH = FALSE;
	m_bTypeX = FALSE;
	*/
	m_bCounty = FALSE;
	m_bCountycu = FALSE;
	m_bTract = FALSE;
	m_bGroup = FALSE;
	m_bBlock = FALSE;
	m_bPlaces90 = FALSE;
	m_bPlacescu = FALSE;
	m_bMcd90 = FALSE;
	m_bMcdcu = FALSE;
	m_bVoting90 = FALSE;
	m_bVoting00 = FALSE;
	m_bAir90 = FALSE;
	m_bAircu = FALSE;	
	m_bAnrc = FALSE;
	m_bKgl = FALSE;
	m_bLand = FALSE;
	m_bTaz = FALSE;
	m_bUrban90 = FALSE;
	m_bUrban00 = FALSE;
	m_bElementary = FALSE;
	m_bMiddle2 = FALSE;
	m_bSecondary = FALSE;
	m_bUnified = FALSE;
	m_bWater = FALSE;
	m_bCmsa = FALSE;
	m_bPmsa = FALSE;
	m_bCongress = FALSE;
	m_bSthouse = FALSE;
	m_bStsenate = FALSE;	
	m_bCollection = FALSE;
	m_bAllpolys = FALSE;
	m_bTract00 = FALSE;
	m_bBlock00 = FALSE;
	m_bZcta = FALSE;
	m_bGroup00 = FALSE;
	//m_bConcit = FALSE;	
	m_bTribal = FALSE;
	m_bPuma = FALSE;
	m_bCD106 = FALSE;
	m_bUGA = FALSE;
	
	m_bClip = FALSE;
	m_bUA00 = FALSE;
	m_bUA90Red = FALSE;
	UpdateData(FALSE);
	
}
