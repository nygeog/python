#if !defined(AFX_OPTIONS1_H__A58EF500_B39A_11D1_A112_446113C10000__INCLUDED_)
#define AFX_OPTIONS1_H__A58EF500_B39A_11D1_A112_446113C10000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// Options1.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// Options1 dialog

class Options1 : public CDialog
{
// Construction
public:
	Options1(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(Options1)
	enum { IDD = IDD_OPTIONS1 };
	CString	m_strOutputDir;
	BOOL	m_bTypeA;
	BOOL	m_bTypeB;
	BOOL	m_bTypeC;
	BOOL	m_bTypeD;
	BOOL	m_bTypeE;
	BOOL	m_bTypeF;
	BOOL	m_bTypeH;
	BOOL	m_bTypeX;
	BOOL	m_bAnrc;
	BOOL	m_bBlock;
	BOOL	m_bCounty;
	BOOL	m_bGroup;
	BOOL	m_bKgl;
	BOOL	m_bLand;
	BOOL	m_bTaz;
	BOOL	m_bTract;
	BOOL	m_bSetForAll;
	BOOL	m_bCmsa;
	BOOL	m_bCongress;
	BOOL	m_bElementary;
	BOOL	m_bMiddle;
	BOOL	m_bPmsa;
	BOOL	m_bSecondary;
	BOOL	m_bStsenate;
	BOOL	m_bUnified;
	BOOL	m_bWater;
	BOOL	m_bSthouse;
	BOOL	m_bCollection;
	BOOL	m_bMcdcu;
	BOOL	m_bPlacescu;
	BOOL	m_bUrban00;
	BOOL	m_bVoting00;
	BOOL	m_bAir90;
	BOOL	m_bAircu;
	BOOL	m_bMcd90;
	BOOL	m_bPlaces90;
	BOOL	m_bUrban90;
	BOOL	m_bVoting90;
	BOOL	m_bMiddle2;
	BOOL	m_bClip;
	BOOL	m_bCountycu;
	CString	m_strType;
	BOOL	m_bAllpolys;
	BOOL	m_bZcta;
	BOOL	m_bCD106;
	BOOL	m_bUGA;
	BOOL	m_bGroup00;
	BOOL	m_bPuma;
	BOOL	m_bBlock00;
	BOOL	m_bTract00;
	BOOL	m_bTribal;
	BOOL	m_bUA00;
	BOOL	m_bUA90Red;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(Options1)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(Options1)
	afx_msg void OnBrowse();
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnSelectall();
	afx_msg void OnClearall();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OPTIONS1_H__A58EF500_B39A_11D1_A112_446113C10000__INCLUDED_)
