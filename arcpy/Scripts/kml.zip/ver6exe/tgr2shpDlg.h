// tgr2shpDlg.h : header file
//
//{{AFX_INCLUDES()
#include "xceedzip.h"
//}}AFX_INCLUDES

#if !defined(AFX_TGR2SHPDLG_H__AE12C208_B2D8_11D1_A112_00616E0214C5__INCLUDED_)
#define AFX_TGR2SHPDLG_H__AE12C208_B2D8_11D1_A112_00616E0214C5__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

/////////////////////////////////////////////////////////////////////////////
// CTgr2shpDlg dialog

class CTgr2shpDlg : public CDialog
{
// Construction
public:
	CTgr2shpDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CTgr2shpDlg)
	enum { IDD = IDD_TGR2SHP_DIALOG };
	CString	m_strOutDir;
	CXceedZip	m_zip;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTgr2shpDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CTgr2shpDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnAbout();
	afx_msg void OnAdd();
	afx_msg void OnDelete();
	afx_msg void OnEdit();
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnListingXceedzipctrl1(BSTR FAR* FileName, long Size, long PSize, long Processed, short FileAttr, BSTR FAR* FTime, long CRC, short Ratio, short Completion, short Method, short Encrypted, short ComLen, BSTR FAR* Comment);
	DECLARE_EVENTSINK_MAP()
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TGR2SHPDLG_H__AE12C208_B2D8_11D1_A112_00616E0214C5__INCLUDED_)
