/* OutputOptions.cpp : implementation file
Written by Bruce Ralston
This file manages the output options dialog
*/

#include "stdafx.h"
#include "tgr2shp.h"
#include "OutputOptions.h"
#include "MyFileOpenDlg.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
extern int ChosenOutputOption;
extern int Pushpins;
extern CString CurrentDir;
extern BOOLEAN AllSame;
extern BOOLEAN Adsasnum;
int OutOptionsCanceled;
/////////////////////////////////////////////////////////////////////////////
// OutputOptions dialog


OutputOptions::OutputOptions(CWnd* pParent /*=NULL*/)
	: CDialog(OutputOptions::IDD, pParent)
{
	//{{AFX_DATA_INIT(OutputOptions)
	m_Organize = 0;
	m_strOutputDir2 = _T("");
	m_Ads = 0;
	m_Pushpins = FALSE;
	//}}AFX_DATA_INIT
}


void OutputOptions::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(OutputOptions)
	DDX_Radio(pDX, IDC_COUNTY, m_Organize);
	DDX_Text(pDX, IDC_OUTPUTDIR2, m_strOutputDir2);
	DDX_Radio(pDX, IDC_ADS, m_Ads);
	DDX_Check(pDX, IDC_PUSHPINS, m_Pushpins);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(OutputOptions, CDialog)
	//{{AFX_MSG_MAP(OutputOptions)
	ON_BN_CLICKED(IDC_BROWSE2, OnBrowse2)
	ON_WM_CLOSE()
	ON_WM_CANCELMODE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// OutputOptions message handlers

BOOL OutputOptions::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	CString text;
	text = "There are four ways to organize your output files:\n";
	text = text + "\tGroup shapes by county (a directory for each county's shapes)\n";
	text = text + "\tPut all shapes in a single directory\n";
	text = text + "\tGroup shapes by theme (a directory for each type of shape, eg,roads, tracts, etc)\n";
	text = text + "\tGroup shapes by theme and merge (a single shape for each map layer)";
	text = text + "\nPlease choose an option\n\n";
	text = text + "You can also choose to create pushpins for the KML polygons";
	this->SetDlgItemText(IDC_HEADER,text);	
	CString curdrive;
	curdrive = CurrentDir.Left(3);
	int dtype = GetDriveType(curdrive);
	
	if (dtype == DRIVE_CDROM)
	{	
		m_strOutputDir2 = "C:";	
	}
	else
	{
		m_strOutputDir2 = CurrentDir;		
	}
    //UpdateData(false);
	this->SetDlgItemText(IDC_OUTPUTDIR2,m_strOutputDir2);
	if (!AllSame)
		GetDlgItem(IDC_MERGE)->EnableWindow(FALSE);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void OutputOptions::OnOK() 
{
	// TODO: Add extra validation here
	UpdateData(TRUE);
	ChosenOutputOption = m_Organize;
	
	Pushpins = m_Pushpins;
	CurrentDir = m_strOutputDir2;
	if (m_Ads == 0)
		Adsasnum = TRUE;
	else
		Adsasnum = FALSE;
	CDialog::OnOK();
}

void OutputOptions::OnBrowse2() 
{
CMyFileOpenDlg  cfdlg(TRUE, NULL, NULL, 
        OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | 
        OFN_ENABLETEMPLATE, NULL, this);
    cfdlg.m_ofn.hInstance      = AfxGetInstanceHandle();
    cfdlg.m_ofn.lpTemplateName = MAKEINTRESOURCE(FILEOPENORD);
    cfdlg.m_ofn.Flags         &= ~OFN_EXPLORER;
	cfdlg.m_ofn.lpstrInitialDir = m_strOutputDir2;
	UpdateData(TRUE);
    if (IDOK == cfdlg.DoModal())
    {
        WORD wFileOffset;
        wFileOffset = cfdlg.m_ofn.nFileOffset;

        cfdlg.m_ofn.lpstrFile[wFileOffset-1] = 0;
		CString curdrive;
		curdrive = cfdlg.m_ofn.lpstrFile;
		int dtype = GetDriveType(curdrive.Left(3));
		if (dtype == DRIVE_CDROM)
		{
			AfxMessageBox("The Output Directory cannot be a CD-ROM");
			OnBrowse2();
		}
		else
			m_strOutputDir2 = cfdlg.m_ofn.lpstrFile;
		UpdateData(FALSE);
	}
		
}

void OutputOptions::OnClose() 
{
	// TODO: Add your message handler code here and/or call default
	
	OutOptionsCanceled = 1;
	OnOK();
	
	CDialog::OnClose();
}

void OutputOptions::OnCancelMode() 
{
	CDialog::OnCancelMode();
	
	// TODO: Add your message handler code here
	
}
