/* tgr2shpDlg.cpp : implementation file
Written by Bruce Ralston
This file manages the main dialog and calls all other dialogs.  It takes the user inputs
and calls the appropriate dll to process the TIGER archive
*/

#include "stdafx.h"

#include "tgr2shp.h"
#include "tgr2shpDlg.h"
#include "options1.h"
#include "options2.h"
#include "tigertypedlg.h"
#include "MyFileOpenDlg.h"
#include "OutputOptions.h"
#include "direct.h"
#include "stdlib.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#define XcdErrorNothingToDo 140
extern "C" __declspec(dllimport) int Display(char * fips, char * outdir, char *flags, int cur, int total);
extern "C" __declspec(dllimport) int DisplayV2(char *fips, char *outdir, char *flags, int cur, int total);
BOOLEAN Adsasnum;
CString GetFileDirectory(const CString&);
CString GetFileExtension(const CString&);
CString GetFileName(const CString&);
CString GetFileTitle(const CString&);
CString CurrentDir;
CString CurrentOptions;
CString GlobalOptions;
CString Zipdirectory;
int Unlinkthem;
BOOLEAN AllSame;
extern int  SetForAll;
int GlobalVersion, CurrentVersion, Type97Check, ChosenOutputOption;
int Pushpins;

float Vernum;
extern int OutOptionsCanceled;
/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	CString	m_strVersion;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	m_strVersion = _T("");
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	DDX_Text(pDX, IDC_Version, m_strVersion);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTgr2shpDlg dialog

CTgr2shpDlg::CTgr2shpDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTgr2shpDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTgr2shpDlg)
	m_strOutDir = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CTgr2shpDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTgr2shpDlg)
	DDX_LBString(pDX, IDC_OUTDIR, m_strOutDir);
	DDX_Control(pDX, IDC_XCEEDZIPCTRL1, m_zip);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CTgr2shpDlg, CDialog)
	//{{AFX_MSG_MAP(CTgr2shpDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_ABOUT, OnAbout)
	ON_BN_CLICKED(IDC_ADD, OnAdd)
	ON_BN_CLICKED(IDC_DELETE, OnDelete)
	ON_BN_CLICKED(IDC_EDIT, OnEdit)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTgr2shpDlg message handlers

BOOL CTgr2shpDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, TRUE);		// Set small icon
	// TODO: Add extra initialization here
	Vernum = 2.0; //7.01;
	
	CString titlestring;
	titlestring.Format("TGR2KML");
	SetWindowText(titlestring);

	Zipdirectory = "NOT_SET";	
	Unlinkthem = 0;
	GlobalVersion = -1;
	CurrentVersion = 0;
	Type97Check = -1;

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CTgr2shpDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CTgr2shpDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CTgr2shpDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CTgr2shpDlg::OnAbout() 
{
	CAboutDlg abtdlg;
	abtdlg.m_strVersion.Format("Version %.2f",Vernum);
	abtdlg.DoModal();	
}

void CTgr2shpDlg::OnAdd() 
{
	char *FileName;
	char *FileTitle;
	CString repval;


	FileName = (char *)calloc(10001,sizeof(char));
	FileTitle = (char *)calloc(151,sizeof(char));
	UpdateData(TRUE);
	OPENFILENAME ofn;
	memset(&ofn, 0, sizeof(ofn));
	ofn.lStructSize = sizeof(OPENFILENAME);
	ofn.hwndOwner = NULL;
	ofn.hInstance = NULL;
	ofn.lpstrFilter =  
		TEXT("TIGER files\0*.rt1;*.bw1;*.f61;*.zip\0\0");
	ofn.lpstrCustomFilter = NULL;
	ofn.nMaxCustFilter = 0;
	ofn.lpstrFile = FileName;
	ofn.nMaxFile = 5000;
	ofn.lpstrFileTitle = FileTitle;
	ofn.nMaxFileTitle = 100;
	ofn.lpstrInitialDir = NULL;
	ofn.lpstrTitle = "Open TIGER File";
	ofn.Flags = OFN_FILEMUSTEXIST|OFN_ALLOWMULTISELECT|OFN_EXPLORER;
	ofn.lpstrDefExt = "BW1";
	ofn.lCustData = NULL;
	ofn.lpfnHook = NULL;
	ofn.lpTemplateName = NULL;
	FileName[0] = '\0';
	
	GetOpenFileName(&ofn);
	
	if(FileName[0] == '\0')
	{
		return;
	}

    int cumlength = 0;
	int length = strlen(FileName);
	char curFileName[500];	
	cumlength += length + 1;
	length = strlen(&FileName[cumlength]);
	int isZipOK;
	int drvlen;
	int n;
	do
	{		
		isZipOK = 1;
		if (length == 0) //only one chosen
			sprintf(curFileName,"%s",FileName);
		else
		{
			drvlen = strlen(FileName);
			if (FileName[drvlen - 1] == '\\')
				sprintf(curFileName,"%s%s",FileName, &FileName[cumlength]);
			else
				sprintf(curFileName,"%s\\%s",FileName, &FileName[cumlength]);
		}
		CurrentDir = GetFileDirectory(curFileName);	
		CString extension = GetFileExtension(curFileName);
		extension.MakeUpper();
		if (  extension == "ZIP")
		{
			m_zip.SetZipFileName(curFileName);
			while(1)
			{
				m_zip.SetFilesToProcess("*.rt?"); 
				//now get list and see if it is a tiger file
				int retval = m_zip.List();
				if (retval != XcdErrorNothingToDo)
				{
					CurrentVersion = 97;
					if (Type97Check < 0)
					{
						tigertypedlg typedlg;
						typedlg.DoModal();
					}
					else
						CurrentVersion = Type97Check + 97;
					break;
				}
				m_zip.SetFilesToProcess("*.bw?");
				retval = m_zip.List();
				if (retval != XcdErrorNothingToDo)
				{
					CurrentVersion = 95;
					break;
				}
				m_zip.SetFilesToProcess("*.f6?");
				retval = m_zip.List();
				if (retval != XcdErrorNothingToDo)
				{
					CurrentVersion = 94;
					break;
				}

				//if we get here, we have an error
				AfxMessageBox("This zip archive does not contain TIGER files");
				isZipOK = 0;
				break;

			}					
		}
		else
		{
			if (  extension == "RT1")
			{
					CurrentVersion = 97;
					if (Type97Check < 0)
					{
						tigertypedlg typedlg;
						typedlg.DoModal();
					}
					else
						CurrentVersion = Type97Check + 97;
		
			}
			else
			{
				if (extension == "BW1")
					CurrentVersion = 95;
				else
					CurrentVersion = 94;
			}

		}
		if (isZipOK)
		{
			CListBox* pLB = (CListBox *) GetDlgItem(IDC_FILELIST);
			pLB->InsertString(-1,curFileName);
			CListBox* pLB3 = (CListBox *) GetDlgItem(IDC_CHOICES);
			if (SetForAll)
				if(CurrentVersion != GlobalVersion)
				{
					AfxMessageBox("You cannot use the \"Set for All\" option with different versions of TIGER");
					repval.Format("global %d current %d",GlobalVersion, CurrentVersion);
					AfxMessageBox(repval);

					SetForAll = FALSE;
				}
			if (!SetForAll)
			{
								//          1111111111222222222233333333334444444444555555
				                //01234567890123456789012345678901234567890123456789012345
				switch(CurrentVersion)
				{
				case 94:
					CurrentOptions.SetAt(53,'0');
					break;
				case 95:
					CurrentOptions.SetAt(53,'1');
					break;
				case 97:
					CurrentOptions.SetAt(53,'2');
					break;
				case 98:
					CurrentOptions.SetAt(53,'3');
					break;
				case 99:
					CurrentOptions.SetAt(53,'4');
					break;
				case 100:
					CurrentOptions.SetAt(53,'5');
					break;
				case 101:
					CurrentOptions.SetAt(53,'6');
					break;
				case 102:
					CurrentOptions.SetAt(53,'7');
					break;
				case 103:
					CurrentOptions.SetAt(53,'8');
					break;
				case 104:
					CurrentOptions.SetAt(53,'9');
					break; 
				case 105:
					CurrentOptions.SetAt(53,'a');					
					break;
				case 106:
					CurrentOptions.SetAt(53,'b');	
					break;
				case 107:
					CurrentOptions.SetAt(53,'c');	
					break;
				case 108:
					CurrentOptions.SetAt(53,'d');
				//	AfxMessageBox("case 108");
					break;				
				}
				
				Options1 dlg;
				Options2 dlg2;
				if (CurrentVersion <= 103)
				{
					                //01234567890123456789012345678901234567890123456789012345
					CurrentOptions = "00000000000000000000000000000000000000000000000000000000";				
					dlg.DoModal();			
				}
				else
				{
						            //01234567890123456789012345678901234567890123456789012345678901234567890123456789012345
					CurrentOptions = "00000000000000000000000000000000000000000000000000000000000000000000000000000000000000";				
					dlg2.DoModal();
				}
				
				CListBox* pLB = (CListBox *) GetDlgItem(IDC_FILELIST);
				n = pLB->GetCount();
				pLB->SetCurSel(n-1);
				
				pLB3->InsertString(-1,CurrentOptions);
			}
			else
			{
				pLB3->InsertString(-1,GlobalOptions);
			}		
		}
		cumlength += length + 1;
		length = strlen(&FileName[cumlength]);		
	}while(length > 0);	
	free(FileName);
	free(FileTitle);
}

void CTgr2shpDlg::OnDelete() 
{
	CListBox* pLB = (CListBox *) GetDlgItem(IDC_FILELIST);
	
	int current = pLB->GetCurSel();	
	if (current >= 0)
	{
		pLB->DeleteString(current);	
		CListBox* pLB3 = (CListBox *) GetDlgItem(IDC_CHOICES);
		pLB3->DeleteString(current);
	}
	if ((pLB->GetCount()) > 0)
		pLB->SetCurSel(pLB->GetCount()- 1);
}

void CTgr2shpDlg::OnEdit() 
{
	//need to add a function to pop window for setting properties
	
	CListBox* pLB = (CListBox *) GetDlgItem(IDC_FILELIST);
	int current = pLB->GetCurSel();	
	
	if (current >= 0)
	{
		Options1 dlg;
		Options2 dlg2;
		CListBox* pLB3 = (CListBox *) GetDlgItem(IDC_CHOICES);
		pLB3->GetText(current,CurrentOptions);
		switch (CurrentOptions[53])
		{
		case '0':		
			CurrentVersion = 94;
			break;
		case '1':
			CurrentVersion = 95;
			break;
		case '2':
			CurrentVersion = 97;
			break;
		case '3':
			CurrentVersion = 98;
			break;
		case '4':
			CurrentVersion = 99; //really 2000 DR
			break;
		case '5':
			CurrentVersion = 100; //really VTDP
			break;
		case '6':
			CurrentVersion = 101; //tiger 2000
			break;
		case '7':
			CurrentVersion = 102;
			break;
		case '8':			
			CurrentVersion = 103; //tiger 108th			
			break;
		case '9':
			CurrentVersion = 104;
			break; //2002
		case 'a':
			CurrentVersion = 105;			
			break;
		case 'b':
			CurrentVersion = 106;
			break;
		case 'c':
			CurrentVersion = 107;
			break;
		case 'd':
			CurrentVersion = 108;
			break;
		}
		
		if (CurrentVersion <= 103)
			dlg.DoModal();
		else
			dlg2.DoModal();
		pLB3->DeleteString(current);
		pLB3->InsertString(current,CurrentOptions);
	}
	
}
//helper function
CString GetFileDirectory(const CString& path)
{
	ASSERT(path.GetLength());
	int pos = path.ReverseFind('\\');
	if (pos >= 0)
		return path.Left(pos);
	return "";
}

CString GetFileExtension(const CString& path)
{
	ASSERT(path.GetLength());
	int pos = path.ReverseFind('.');
	if (pos >= 0)
		return path.Right(path.GetLength() - pos - 1);
	return "";
}
CString GetFileName(const CString& path)
{
	ASSERT(path.GetLength());
	int pos = path.ReverseFind('\\');
	if (pos >= 0)
		return path.Right(path.GetLength() - pos - 1);
	return "";
}

CString GetFileTitle(const CString& path)
{
	ASSERT(path.GetLength());
	CString strResult = GetFileName(path);
	int pos = strResult.ReverseFind('.');
	if (pos >= 0)
		return strResult.Left(pos);
	return strResult;
}

void CTgr2shpDlg::OnOK() 
{
	CString repval;
	// TODO: Add extra validation here
	CListBox* pLB = (CListBox *) GetDlgItem(IDC_FILELIST);
	CListBox* pLB3 = (CListBox *) GetDlgItem(IDC_CHOICES);
	int n = pLB->GetCount();
	CString strfips, strflags, strout;
	CString extension, originalstrfips;
	CString metfile;

	int isZip;
	int somethingtodo;
	int j;
	int retval;
	
	//build the output file
	CString flags1, flags2;
	AllSame = TRUE;
	if (n > 1)
	{
		pLB3->GetText(0,flags1);
		for (int i = 1; i < n; i++)
		{
			pLB3->GetText(i,flags2);
			if(flags1.GetAt(53) != flags2.GetAt(53))
			{
				AllSame = FALSE;
				break;
			}
		}
	}
	OutputOptions outdlg;
	OutOptionsCanceled = 0;
	outdlg.DoModal();
	
	if (OutOptionsCanceled == 0)
		{	
		for (int i = 0; i < n; i++)
		{
			pLB->SetCurSel(i);
			isZip = 0;
			pLB->GetText(i,strfips);
			strout = CurrentDir;
			_chdir(strout);
			//we must check for zip file, setup the source directory, and unzip the files
			extension = GetFileExtension(strfips);
			extension.MakeUpper();
			CString ftitle = GetFileTitle(strfips);			
			if (extension == "ZIP")
			{//we know it is a zip file, need to unzip it to output directory
				isZip = 1;
				Zipdirectory = strout + "\\unzipped";
				int result = _mkdir(Zipdirectory);
				m_zip.SetExtractDirectory(Zipdirectory);			
				originalstrfips = strfips;
				m_zip.SetZipFileName(originalstrfips);
				while(1)
				{
					m_zip.SetFilesToProcess("*.rt?"); 
					int retval = m_zip.List();
					if (retval != XcdErrorNothingToDo) //tiger 97 or later
					{					
						extension = ".rt1";
						break;
					}
					m_zip.SetFilesToProcess("*.bw?");
					retval = m_zip.List();
					if (retval != XcdErrorNothingToDo) 
					{					
						extension = ".bw1";
						break;
					}
					m_zip.SetFilesToProcess("*.f6?");
					retval = m_zip.List();
					if (retval != XcdErrorNothingToDo) 
					{					
						extension = ".f61";
						break;
					}
					//we should never get here;
					extension = "not";
					break;
				}
				if (extension == "not")
					continue;			
				m_zip.Extract(0);						
				strfips = Zipdirectory+"\\"+ftitle+extension;			
			}
			pLB3->GetText(i,strflags);
			char *fips = (char *)calloc(strlen(strfips)+1,sizeof(char));
			sprintf(fips,"%s",strfips);	
			char vnum;
			vnum = strflags[53];
			//AfxMessageBox(strflags);
			if (vnum <= '8')
			{
				char *flags = (char *)calloc(56,sizeof(char));	
									   //01234567890123456789012345678901234567890123456789012345
					//	strflags = "00000000000000000000000000000000000000100000010010000700";
				
				sprintf(flags,"%s",strflags);
				if ((flags[0] == '1') && (Adsasnum))
					flags[0] = '2';
				char *outdir = (char *)calloc(strlen(strout)+1,sizeof(char));
				sprintf(outdir,"%s",strout);		
				somethingtodo = 0;
				char outopt[] = "0123";
				flags[50] = outopt[ChosenOutputOption];
				if (Pushpins == 1)
					flags[51] = '1';
				else
					flags[51] = '0';
				for (j = 0; j <= 49; j++)
				{
					if (flags[j] != '0')
					{
						somethingtodo = 1;
						break;
					}
				}

				if (somethingtodo == 1)
				{
						retval = Display(fips,outdir, flags, i+1, n);		
					
				}			
				free(flags);			
				free(outdir);
			}
			else //starting 2002
			{		
			
				char *flags = (char *)calloc(86,sizeof(char));	
				sprintf(flags,"%s",strflags);
				if ((flags[0] == '1') && (Adsasnum))
					flags[0] = '2';
				char *outdir = (char *)calloc(strlen(strout)+1,sizeof(char));
				sprintf(outdir,"%s",strout);		
				char outopt[] = "0123";
				flags[79] = outopt[ChosenOutputOption];		
					if (Pushpins == 1)
					flags[81] = '1';
				else
					flags[81] = '0';
				retval = DisplayV2(fips,outdir,flags, i+1, n);			
				free(flags);		
				free(outdir);
			}		
			free(fips);		
			if (isZip)
			{//need to cleanup						
				Unlinkthem = 1;
				Zipdirectory = strout + "\\unzipped";
				m_zip.SetExtractDirectory(Zipdirectory);			
				m_zip.SetZipFileName(originalstrfips);
				m_zip.SetFilesToProcess("*.rt?\r*.bw?\r*.f6?\r*.met\r");
				m_zip.List();
				Unlinkthem = 0;
				
			}
			
		}
	}
	if (OutOptionsCanceled == 0)
		CDialog::OnOK();
	
}

void CTgr2shpDlg::OnCancel() 
{
	// TODO: Add extra cleanup here
	
	CDialog::OnCancel();
}

BEGIN_EVENTSINK_MAP(CTgr2shpDlg, CDialog)
    //{{AFX_EVENTSINK_MAP(CTgr2shpDlg)
	ON_EVENT(CTgr2shpDlg, IDC_XCEEDZIPCTRL1, 6 /* Listing */, OnListingXceedzipctrl1, VTS_PBSTR VTS_I4 VTS_I4 VTS_I4 VTS_I2 VTS_PBSTR VTS_I4 VTS_I2 VTS_I2 VTS_I2 VTS_I2 VTS_I2 VTS_PBSTR)
	//}}AFX_EVENTSINK_MAP
END_EVENTSINK_MAP()


void CTgr2shpDlg::OnListingXceedzipctrl1(BSTR FAR* FileName, long Size, long PSize, long Processed, short FileAttr, BSTR FAR* FTime, long CRC, short Ratio, short Completion, short Method, short Encrypted, short ComLen, BSTR FAR* Comment) 
{
	// TODO: Add your control notification handler code here	
	if (Unlinkthem)
	{
		CString fname,fullname;
		fname = *FileName;
		fullname = Zipdirectory+"\\"+fname;		
		unlink(fullname);
	}
	
}
