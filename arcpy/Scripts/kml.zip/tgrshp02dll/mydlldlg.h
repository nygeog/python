//{{AFX_INCLUDES()
#include "xceedzip.h"
//}}AFX_INCLUDES
#if !defined(AFX_MYDLLDLG_H__8891C5C3_C22D_47B4_AB12_D7A0A37DC085__INCLUDED_)
#define AFX_MYDLLDLG_H__8891C5C3_C22D_47B4_AB12_D7A0A37DC085__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// mydlldlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// mydlldlg dialog

class mydlldlg : public CDialog
{
// Construction
public:
	mydlldlg(CWnd* pParent = NULL);   // standard constructor
	CString InputFileStr; //, OutFilePath, OutFileTitle;
	BOOL IsOn[86];
	void ErrorMessage(CString);
	void ErrorMessageStop(CString);
	void OnGo2(void);
	
// Dialog Data
	//{{AFX_DATA(mydlldlg)
	enum { IDD = IDD_DIALOG1 };
	CProgressCtrl	m_Progress;
	CString	m_strClip;
	CString	m_strFips;
	CString	m_strLayer;
	CString	m_strOutfiles;
	CString	m_strOutoption;
	CString	m_strProcess;
	CString	m_strVersion;
	CXceedZip	m_zip;
	CString	m_strStatus;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(mydlldlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(mydlldlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnListingXceedzipctrl2(BSTR FAR* FileName, long Size, long PSize, long Processed, short FileAttr, BSTR FAR* FTime, long CRC, short Ratio, short Completion, short Method, short Encrypted, short ComLen, BSTR FAR* Comment);
	virtual void OnCancel();
	afx_msg void OnGo();
	DECLARE_EVENTSINK_MAP()
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYDLLDLG_H__8891C5C3_C22D_47B4_AB12_D7A0A37DC085__INCLUDED_)
