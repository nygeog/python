/* 
Written by Bruce Ralston
This file contains the following:
  1. data structures for all record type defs from Chapter 6 of Census Bureau technical documentation
	some structures contain fields I created, such as mycfcc
  2. Index structures for record types A,B,S and E
  3. Boder_Type definitions for all area feature layers
  4. Line type string named Types[]

*/
typedef struct {
	char	RecordType; //1 Record Type
	char	Version[5]; //4 Version Number
	char	Tlid[11]; //10 TIGER/Line� ID, Permanent 1-Cell Number
	char	Side1; //1 Single-Side Source Code
	char	Source; // 1 Linear Segment Source Code
	char	Fedirp[3]; //2 Feature Direction, Prefix
	char	Fename[31]; //30 Feature Name
	char	Fetype[5]; //4 Feature Type
	char	Fedirs[3]; //2 Feature Direction, Suffix
	char	Cfcc[4]; //3 Census Feature Class Code
	char	Fraddl[12]; //11 Start Address, Left
	char	Toaddl[12];// 11 End Address, Left
	char	Fraddr[12];//11 Start Address, Right
	char	Toaddr[12];//11 End Address, Right
	char	Friaddl; //1 Start Imputed Address Flag, Left
	char	Toiaddl;//1 End Imputed Address Flag, Left
	char	Friaddr; //1 Start Imputed Address Flag, Right
	char	Toiaddr; //1 End Imputed Address Flag, Right
	char	Zipl[6]; //5 ZIP Code�, Left
	char	Zipr[6]; //5 ZIP Code�, Right
	char	Aianhhfpl[6];//5 FIPS 55 Code (American Indian/Alaska Native Area/Hawaiian Home Land),2000 Left
	char	Aianhhfpr[6];//5 FIPS 55 Code (American Indian/Alaska Native Area/Hawaiian Home Land),2000 Right
	char	Aihhtlil; //1 American Indian/Hawaiian Home Land Trust Land Indicator, 2000 Left
	char	Aihhtlir;// 1 American Indian/Hawaiian Home Land Trust Land Indicator, 2000 Right
	char	Census1;// 1 Census Use 1
	char	Census2;// 1 Census Use 2
	char	Statel[3];// 2 FIPS State Code, 2000 Left
	char	Stater[3];//2 FIPS State Code, 2000 Right
	char	Countyl[4];// 3 FIPS County Code, 2000 Left
	char	Countyr[4];// 3 FIPS County Code, 2000 Right
	char	Cousubl[6];// 5 FIPS 55 Code (County Subdivision),2000 Left
	char	Cousubr[6];// 5 FIPS 55 Code (County Subdivision),2000 Right
	char	Submcdl[6];// 5 FIPS 55 Code (Subbarrio), 2000 Left
	char	Submcdr[6];// 5 FIPS 55 Code (Subbarrio), 2000 Right
	char	Placel[6];// 5 FIPS 55 Code (Place/CDP), 2000 Left
	char	Placer[6];// 5 FIPS 55 Code (Place/CDP), 2000 Right
	char	Tractl[7];// 6 Census Tract, 2000 Left
	char	Tractr[7];// 6 Census Tract, 2000 Right
	char	Blockl[5];// 4 Census Block Number, 2000 Left
	char	Blockr[5];//4 Census Block Number, 2000 Right
	double	Frlong;// 10 Start Longitude
	double	Frlat; //9 Start Latitude
	double	Tolong;//10 End Longitude
	double	Tolat;//9 End Latitude
	char	MyCfcc;	//keeps track of line types
}RecordType1;
typedef struct{
	double Longitude,Latitude;
}Geographic_Coordinate;
typedef struct { //type 2 records contain shape points in fixed formats
	char	RecordType;
	int 	Version;
	char	Tlid[11];
    char	Rtsq[4]; //sequence number for records with many shape points
    Geographic_Coordinate Point[10];
	//no change in this one
}RecordType2;             
typedef struct{
	//there are no changes
	char	RecordType;
	int		Version;
	char	Tlid[11];
	char	Rtsq[4];
	char	Feat1[9], Feat2[9], Feat3[9], Feat4[9], Feat5[9];
}RecordType4;
typedef struct{
	char	RecordType;
	int		Version; //4 spaces
	char	File[6]; //new in this version
	char	Feat[9];
	char	Fedirp[3];
	char	Fename[31];
	char	Fetype[5];
	char	Fedirs[3];
}RecordType5;
typedef struct{
	//changed imputed flag to char 
	char	RecordType;
	int		Version;
	char	Tlid[11];
	char	Rtsq[4];
	char    Fraddl[12], Toaddl[12], Fraddr[12], Toaddr[12]; //address ranges
	char	Friaddl, Toiaddl, Friaddr, Toiaddr; //imputed range flag
	char	Zipl[6], Zipr[6]; //5 digit zipcodes
}RecordType6;
typedef struct{
	char	RecordType;
	int		Version;
	int		File; //5 File Code
	int		Land; //10 Landmark Identification Number
	char    Source;//Source or First Source Code to Update
	char	Cfcc[4]; //3 Census Feature Class Code
	char	Laname[31]; //30 Landmark Name
	char	Lalong[11];// 10 Longitude
	char    Lalat[10]; //9 Latitude
	char	Filler; //1 Filler (to make even character count)
}RecordType7;
typedef struct{
	char	RecordType;//1
	int		Version;//4
	int		File; //5
	char	Cenid[6];
	char	Polyid[11];
	int		Land;
	char	Filler;
}RecordType8;
typedef struct{
	char	RecordType;//1
	int		Version;//4
	int		File; //5
	char	Cenid[6];//5 Census File Identification Code
	char	Polyid[11];//10 Polygon Identification Code
	char	Statecu[3];// 2 FIPS State Code, Current
	char	Countycu[4];//3 FIPS County Code, Current
	char	Tract[7];// 6 Census Tract, 2000
	char	Block[5];// 4 Census Block Number, 2000
	char	Blocksufcu;//1 Current Suffix for Census 2000 Block Number
	char	RS_A1;// 1 Reserved Space A1
	char	Aianhhfpcu[6];//5 FIPS 55 Code (American Indian/Alaska Native Area/Hawaiian Home Land), Current
	char	Aianhhcu[5];//4 Census Code (American Indian/Alaska Native Area/Hawaiian Home Land), Current
	char	Aihhtlicu;//1 American Indian/Hawaiian Home Land Trust Land Indicator, Current
	char	Anrccu[6];//5 FIPS 55 Code (ANRC), Current 
	char	Aitscecu[4];//3 Census Code (American Indian Tribal Subdivision), Current
	char	Aitscu[6]; // 5 FIPS 55 Code (American Indian Tribal Subdivision), Current
	char	Concitcu[6]; //5 FIPS 55 Code (Consolidated City), Current
	char	Cousubcu[6]; //5 FIPS 55 Code (County Subdivision), Current
	char	Submcdcu[6]; //5 FIPS 55 Code (Subbarrio), Current
	char	Placecu[6]; //5 FIPS 55 Code (Incorporated Place), Current
	char	Sdelmcu[6]; //5 Elementary School District Code, Current
	char	Sdseccu[6]; //5 Secondary School District Code, Current
	char	Sdunicu[6]; //5 Unified School District Code, Current
	char	Msacmsacu[5]; //4 FIPS Consolidated Metropolitan Statistical Area/Metropolitan Statistical Area Code,Current
	char	Pmsacu[5]; //4 FIPS Primary Metropolitan Statistical Area, Current Geography
	char	Necmacu[5]; //4 FIPS New England County Metropolitan Area Code, Current
	char	Cdcu[3]; //2 Congressional District Code, Current (106th)
	char	Zctacu[6]; //RS_A2[6];//5 Reserved Space A2--to be zctacu; read as such
	char	Zcta3cu[4];//3 Reserved Space A3--to be zctacu 3 digit; read as such
	char	RS_A4[7];//6 Reserved Space A4
	char	Slducu[4]; //changed in 2006SE RS_A5[4];//3 Reserved Space A5
	char	Sldlcu[4];//changed in 2006SE3 Reserved Space A6
	char	RS_A7[6];//5 Reserved Space A7
	char	RS_A8[7];//6 Reserved Space A8
	char	RS_A9[7];//6 Reserved Space A9
	/* The following were changed with release 2 of the 2003 techdoc
	char	Cbsafipscu[7];//6 Reserved Space A10--to be cbsa fipscu; read as such
	char	Csafipscu[7];//6 Reserved Space A11--to be combined statistical area fips cu; read as such
	char	Nectacu[7];//6 Reserved Space A12--to be NE City and Town Area (NECTA) cu; ; read as such
	char	Cnectacu[7];//6 Reserved Space A13--to be combined NECTA fips cu; read as such
	char	Mdvfipscu[7];//6 Reserved Space A14--to be Metro Division fips cu; read as such
	*/
	char	RS_A15[6];//5 Reserved Space A15
	char	RS_A16;//1 Reserved Space A16
	char	RS_A17[7];//6 Reserved Space A17
	char	RS_A18[7];//6 Reserved Space A18
	char	RS_A19[12];//11 Reserved Space A19
	//Tiger 2003
	char	Cbsacu[6];//FIPS Core Based Statistical Area Code, Current
	char	Csacu[4];//FIPS Combined Statistical Area Code, Current
	char	Nectacu[6];//FIPS New England City and Town Area Code, Current
	char	Cnectacu[4];//FIPS Combined New England City and Town Area Code, Current
	char	Metdivcu[6];//FIPS Metropolitan Division Code, Current
	char	Nectadivcu[6];//FIPS New England City and Town Area Division Code, Current
	//2004
	char	Uacu[6];  //starts in 2004
	char	Urcu;  //starts in 2004
}RecordTypeA;
typedef struct{
	char	RecordType;//1 Record Type
	int		Version;// 4 Version Number
	int		File; //5 File Code
	char	Cenid[6];//5 Census File Identification Code
	char	Polyid[11];//10 Polygon Identification Code
	char	Statecq[3];//2 FIPS State Code, 2000 CQR
	char	Countycq[4]; //3 FIPS County Code, 2000 CQR
	char	Tractcq[7];//6 Census Tract, 2000 CQR
	char	Blockcq[6];//5 Census Block Number, 2000 CQR
	char	Aianhhfpcq[6]; //5 FIPS 55 Code (American Indian/Alaska Native Area/Hawaiian Home Land),2000 CQR
	char	Aianhhcq[5]; //4 Census Code (American Indian/Alaska Native Area/Hawaiian Home Land),2000 CQR
	char	Aihhtlicq; //1 American Indian/Hawaiian Home Land Trust Land Indicator, 2000 CQR
	char	Aitscecq[4];//3 Census Code (American Indian Tribal Subdivision), 2000 CQR
	char	Aitscq[6]; //5 FIPS 55 Code (American Indian Tribal Subdivision), 2000 CQR
	char	Anrccq[6]; //5 FIPS 55 Code (ANRC), 2000 CQR
	char	Concitcq[6];//5 FIPS 55 Code (Consolidated City), 2000 CQR
	char	Cousubcq[6];//5 FIPS 55 Code (County Subdivision), 2000 CQR
	char	Submcdcq[6];//5 FIPS 55 Code (Subbarrio), 2000 CQR
	char	Placecq[6];//5 FIPS 55 Code (Incorporated Place), 2000 CQR
	char	Uacc[6];//5 Urban Area, 2000 Corrected In TIGER 2004 Second Edition this field is RS_B2
	char	Urcc; //1 Urban/Rural Indicator, 2000 Corrected In TIGER 2004 Second Edition this field is RS_B3
	char	RS_B1[13];//12 Reserved Space B1
}RecordTypeB;
typedef struct{
	char	RecordType;//1 Record Type
	int		Version;//4 Version Number
	char	State[3];//2 FIPS State Code
	char	County[4];//3 FIPS County Code
	char	Datayr[5];//4 FIPS Code, Name, and/or Attribute Data Applicable Year
	char	Fips[6];//5 FIPS PUB 55_3 Code
	char	Fipscc[3];//2 FIPS 55 Class Code
	char	Placedc;//1 Place Description Code
	char	Lsadc[3];//2 Legal/Statistical Area Description Code
	char	Entity;//1 Entity Type Code
	char	Ma[5];//4 Metropolitan Area Code
	char	Sd[6];//5 School District Code
	char	Aianhh[5];//4 Census American Indian/Alaska Native Area/Hawaiian Home Land Code
	char	Vtdtract[7];//6 Census Voting District Code/Census Tract Code
	char	Uauga[6];//5 Urban Area Code/Urban Growth Area Code
	char	Aitsce[4];//3 Census American Indian Tribal Subdivision Code
	char	RS_C1[3];//2 Reserved Space C1
	char	RS_C2[9];//8 Reserved Space C2
	char	Name[61];//60 Name of Geographic Area
	//Tiger 2003
	char	Csacnecta[4]; //Combined Statistical Area/Combined New England City and Town Area Code -renamed CASLD in 2006SE
	char	Cbsanecta[6];//Core Based Statistical Area/New England City and Town Area/Metropolitan Division/New England City and Town Area Division Code
	int 	Commreg; //Commercial Region Code, Economic Census


}RecordTypeC;
typedef struct{
	char	RecordType;//1 Record Type
	int		Version;//4 Version Number
	int		File;//5 File Code
	char	Cenid[6];//5 Census File Identification Code
	char	Polyid[11];//10 Polygon Identification Code
	char	Stateec[3];// 2 FIPS State Code, Economic Census
	char	Countyec[4];//3 FIPS County Code, Economic Census
	char	Placeec[6];//5 FIPS 55 Code (Economic Census Place),Economic Census
/*	The following changed in tiger 2003 from what they were originally supposed to be
	char	Concitec[6];//5 FIPS 55 Code ( Consolidated City), Economic Census
	char	Cousubec[6];//5 FIPS 55 Code (County Subdivision), Economic Census
	char	Placeec[6];//5 FIPS 55 Code (Economic Census Place),Economic Census
	char	Aianhhfpec[6];//5 FIPS 55 Code (American Indian/Alaska Native Area/Hawaiian Home Land), Economic Census
	char	Aianhhec[5];//4 Census Code (American Indian/Alaska Native Area/Hawaiian Home Land), Economic Census
	char	Aianhtliec;//1 American Indian/Hawaiian Home Land Trust Land Indicator, Economic Census
	char	RS_E1[19];//18 Reserved Space E1
	char	RS_E1_20003[18]; //2003 tiger*/
	int 	Comregec; //2003 tiger
}RecordTypeE;
typedef struct{
	char	RecordType;//1 Record Type
	int		Version;//4 Version Number
	int		File;//5 File Code
	char	Tlid[11];//10 TIGER/Line� ID, Permanent 1_Cell Number
	char	Hist;//1 History or Last Source Code to Update
	char	Source;//1 Source or First Source Code to Update
	char	Tlidfr1[11];//10 TIGER/Line� ID, Created From Number 1
	char	Tlidfr2[11];//10 TIGER/Line� ID, Created From Number 2
	char	Tlidto1[11];//10 TIGER/Line� ID, Became Number 1
	char	Tlidto2[11];//10 TIGER/Line� ID, Became Number 2
}RecordTypeH;
typedef struct{
	char	RecordType;//1 Record Type
	int		Version;//4 Version Number
	int		File;//5 File Code
	char	Tlid[11];//10 TIGER/Line� ID, Permanent 1_Cell Number
	char	Tzids[11];//10 TIGER� ID, Start, Permanent Zero_Cell Number
	char	Tzide[11];//10 TIGER� ID, End, Permanent Zero_Cell Number
	char	Cenidl[6];//5 Census File Identification Code, Left
	char	Polyidl[11];//10 Polygon Identification Code, Left
	char	Cenidr[6];//5 Census File Identification Code, Right
	char	Polyidr[11];//10 Polygon Identification Code, Right
	char	Source[11];//10 TIGER� 1_Cell Source Code in TIGER 2004 Second Edition this field is RS_I4
	char	Ftseg[18];//17 FTSeg ID (AAAAA.O.XXXXXXXXX) (Authority_S_ID) FGDC Transportation ID Standard (not filled)
	char	RS_I1[11];//10 Reserved Space I1--to be NHD Com ID
	char	RS_I2[11];//10 Reserved Space I2--to be Local ID
	char	RS_I3[11];//10 Reserved Space I3
	int		Landl, Landr; //to keep track of land polys-come from record type 8
}RecordTypeI;
typedef struct{
	char	RecordType;//1 Record Type
	int		Version;//4 Version Number
	int		File;//5 File Code
	char	Cenid[6];//5 Census File Identification Code
	char	Polyid[11];//10 Polygon Identification Code
	double	Polylong;//10 Polygon Internal Point Longitude
	double	Polylat;//9 Polygon Internal Point Latitude
	int		Water;//1 Perennial/Intermittent Water Flag
}RecordTypeP;
typedef struct{
	char	RecordType;//1 Record Type
	int		Version;//4 Version Number
	int		File;//5 File Code
	char	Cenid[6];//5 Census File Identification Code
	char	Maxid[11];//10 Highest Possible TIGER/Line� ID in range for Census File Identification Code
	char	Minid[11];//10 Lowest Possible TIGER/Line� ID in range for Census File Identification Code
	char	Highid[11];//10 Current High TIGER/Line� ID for Census File Identification Code
	char	Maxzid[11];//10 Highest Possible TIGER� Zero_Cell ID in range for Census File Identification Code
	char	Minzic[11];//10 Lowest Possible TIGER� Zero_Cell ID in range for Census File Identification Code
	char	Highzid[11];//10 Current High TIGER� Zero_Cell ID for Census File Identification Code
	char	Filler;// 1 Filler (to make even character count)
}RecordTypeR;
typedef struct{
	char	RecordType;//1 Record Type
	int		Version;//4 Version Number
	int		File;//5 File Code
	char	Cenid[6];//5 Census File Identification Code
	char	Polyid[11];//10 Polygon Identification Code
	char	State[3];//2 FIPS State Code, 2000
	char	County[4];//3 FIPS County Code, 2000
	char	Tract[7];//6 Census Tract, 2000
	char	Block[5];//4 Census Block Number, 2000
	char	Blkgrp;//1 Census Block Group, 2000
	char	Aianhhfp[6];//5 FIPS 55 Code (American Indian/Alaska Native Area/Hawaiian Home Land), 2000
	char	Aianhh[5];//4 Census Code (American Indian/ Alaska Native Area/Hawaiian Home Land), 2000
	char	Aihhtli;//1 American Indian/Hawaiian Home Land Trust Land Indicator, 2000
	char	Anrc[6];//5 FIPS 55 Code (ANRC), 2000
	char	Aitsce[4];//3 Census Code (American Indian Tribal Subdivision), 2000
	char	Aits[6];//5 FIPS 55 Code (American Indian Tribal Subdivision), 2000
	char	Concit[6];//5 FIPS 55 Code (Consolidated City), 2000
	char	Cousub[6];//5 FIPS 55 Code (County Subdivision), 2000
	char	Submcd[6];//5 FIPS 55 Code (Subbarrio), 2000
	char	Place[6];//5 FIPS 55 Code (Incorporated Place/CDP), 2000
	char	Sdelm[6];//5 Elementary School District Code, 2000
	char	Sdsec[6];//5 Secondary School District Code, 2000
	char	Sduni[6];//5 Unified School District Code, 2000
	char	Msacmsa[5];//4 FIPS Consolidated Metropolitan Statistical Area/Metropolitan Statistical Area Code, 2000
	char	Pmsa[5];//4 FIPS Primary Metropolitan Statistical Area Code, 2000
	char	Necma[5];//4 FIPS New England County Metropolitan Area (NECMA) Code, 2000
	char	Cd106[3];//2 Congressional District Code, 106th
	char	Cd108[3];//2 Congressional District Code, 108th (not filled)
	char	Puma5[6];//5 Public Use Microdata Area 5% File, 2000
	char	Puma1[6];//5 Public Use Microdata Area  1% File, 2000
	char	Zcta5[6];//5_Digit ZIP Code� Tabulation Area, 2000
	char	Zcta3[4];//3 3_Digit ZIP Code� Tabulation Area, 2000
	char	Taz[7];//6 Traffic Analysis Zone Code, 2000
	char	Tazcomb[7];//6 Traffic Analysis Zone Code_State Combined, 2000 (not filled)
	char	Ua[6];//5 Urban Area, 2000
	char	Ur;//1 Urban/Rural Indicator, 2000
	char	Vtd[7];//6 Census Voting District Code, 2000
	char	Sldu[4];//3 State Legislative District Code (Upper Chamber), 2000
	char	Sldl[4];//3 State Legislative District Code (Lower Chamber), 2000
	char	Uga[6];//5 Oregon Urban Growth Area, 2000
}RecordTypeS;
typedef struct{
	char	RecordType;//1 Record Type
	int		Version;//4 Version Number
	int		File;//5 File Code
	char	Tzid[11];//10 TIGER Zero_Cell ID, Permanent Zero_Cell Number
	char	Source[11];//10 TIGER Zero_Cell Source Code (currently blank)
	char	Ftrp[18];//17 FTRP ID (AAAAA.O.XXXXXXXXX) (Authority_P_ID) FGDC Transportation ID Standard (not filled)
}RecordTypeT;
typedef struct{
	char	RecordType;//1 Record Type
	int		Version;//4 Version Number
	int		File;//5 File Code
	char	Tzid[11];//10 TIGER Zero_Cell ID, Permanent Zero_Cell Number
	int		Rtsq;//1 Record Sequence Number
	char	Tlidov1[11];//10 TIGER/Line ID, First Overpass 1_Cell Number
	char	Tlidov2[11];//10 TIGER/Line� ID, Second Overpass 1_Cell Number
	char	Tlidun1[11];//10 TIGER/Line� ID, First Underpass 1_Cell Number
	char	Tlidun2[11];//10 TIGER/Line� ID, Second Underpass 1_Cell Number
	double	Frlong;//10 TZID Longitude
	double	Frlat;//9 TZID Latitude
}RecordTypeU;
typedef struct{
	char	RecordType;//1 Record Type
	int		Version;//4 Version Number
	char	Tlid[11];//10 TIGER/Line� ID, Permanent 1_Cell Number
	char	Rtsq[4];//3 Record Sequence Number
	char	Zip4l[5];//4 +4 Postal Add_On Code, Left
	char	Zip4r[5];//4 +4 Postal Add_On Code, Right
}RecordTypeZ;
//polygons for Type I
typedef struct{			
	char	Countycul[6],Countycur[6];//3 FIPS County Code, Current
	char	Tractcul[12],Tractcur[12];// 6 Census Tract, 2000
	char	Groupcul[13],Groupcur[13];
	char	Blockcul[17],Blockcur[17];// 4 Census Block Number, 2000
	char	Aianhhcul[5],Aianhhcur[5];//4 Census Code (American Indian/Alaska Native Area/Hawaiian Home Land), Current
	char	Aianhhfpcul[6],Aianhhfpcur[6];
	char	Aihhtlicul,Aihhtlicur;
	char	Anrccul[6],Anrccur[6];//5 FIPS 55 Code (ANRC), Current 	
	char	Aitscul[6],Aitscur[6]; // 5 FIPS 55 Code (American Indian Tribal Subdivision), Current
	char	Aitscecul[4],Aitscecur[4];
	char	Concitcul[6],Concitcur[6]; //5 FIPS 55 Code (Consolidated City), Current
	char	Cousubcul[11],Cousubcur[11]; //5 FIPS 55 Code (County Subdivision), Current
	char	Submcdcul[11],Submcdcur[11]; //5 FIPS 55 Code (Subbarrio), Current
	char	Placecul[6],Placecur[6]; //5 FIPS 55 Code (Incorporated Place), Current
	char	Sdelmcul[6],Sdelmcur[6]; //5 Elementary School District Code, Current
	char	Sdseccul[6],Sdseccur[6]; //5 Secondary School District Code, Current
	char	Sdunicul[6],Sdunicur[6]; //5 Unified School District Code, Current
	char	Msacmsacul[5],Msacmsacur[5]; //4 FIPS Consolidated Metropolitan Statistical Area/Metropolitan Statistical Area Code,Current
	char	Pmsacul[5],Pmsacur[5]; //4 FIPS Primary Metropolitan Statistical Area, Current Geography
	char	Necmacul[5],Necmacur[5]; //4 FIPS New England County Metropolitan Area Code, Current
	char	Cdcul[3],Cdcur[3]; //2 Congressional District Code, Current (106th)
	char	Zcta5cul[6],Zcta5cur[6];//5 Reserved Space A2--to be zctacu; read as such
	char	Zcta3cul[4],Zcta3cur[4];//3 Reserved Space A3--to be zctacu 3 digit; read as such
	char	Cbsacul[6], Cbsacur[6];//FIPS Core Based Statistical Area Code, Current
	char	Csacul[4],Csacur[4];//FIPS Combined Statistical Area Code, Current
	char	Nectacul[6],Nectacur[6];//FIPS New England City and Town Area Code, Current
	char	Cnectacul[4],Cnectacur[4];//FIPS Combined New England City and Town Area Code, Current
	char	Metdivcul[6],Metdivcur[6];//FIPS Metropolitan Division Code, Current
	char	Nectadivcul[6],Nectadivcur[6];//FIPS New England City and Town Area Division Code, Current
	char	Slducul[4],Slducur[4]; //2006SE
	char	Sldlcul[4],Sldlcur[4]; //2006SE
	char	Uacul[6],Uacur[6];
	char	Urcul, Urcur;
}RecordTypeIA;
typedef struct{
	int indexl, indexr;
}RecordTypeIAIndex;
typedef struct{ 
	char	Countyl[6];
	char	Tractl[12];//6 Census Tract, 2000
	char	Groupl[13];
	char	Blkgrpl;
	char	Blockl[16];//4 Census Block Number, 2000
	char	Aianhhl[5];//4 Census Code (American Indian/ Alaska Native Area/Hawaiian Home Land), 2000
	char	Aianhhfpl[6];
	char	Aihhtlil;
	char	Anrcl[6];//5 FIPS 55 Code (ANRC), 2000	
	char	Aitsl[6];//5 FIPS 55 Code (American Indian Tribal Subdivision), 2000
	char	Aitscel[4];
	char	Concitl[6];//5 FIPS 55 Code (Consolidated City), 2000
	char	Cousubl[11];//5 FIPS 55 Code (County Subdivision), 2000
	char	Submcdl[11];//5 FIPS 55 Code (Subbarrio), 2000
	char	Placel[6];//5 FIPS 55 Code (Incorporated Place/CDP), 2000
	char	Sdelml[6];//5 Elementary School District Code, 2000
	char	Sdsecl[6];//5 Secondary School District Code, 2000
	char	Sdunil[6];//5 Unified School District Code, 2000
	char	Msacmsal[5];//4 FIPS Consolidated Metropolitan Statistical Area/Metropolitan Statistical Area Code, 2000
	char	Pmsal[5];//4 FIPS Primary Metropolitan Statistical Area Code, 2000
	char	Necmal[5];//4 FIPS New England County Metropolitan Area (NECMA) Code, 2000
	char	Cd106l[3];//2 Congressional District Code, 106th
	char	Cd108l[3];//2 Congressional District Code, 108th NEW IN 2003
	char	Puma5l[6];//5 Public Use Microdata Area 5% File, 2000
	char	Puma1l[6];//5 Public Use Microdata Area  1% File, 2000
	char	Zcta5l[6];//5_Digit ZIP Code� Tabulation Area, 2000
	char	Zcta3l[4];//3 3_Digit ZIP Code� Tabulation Area, 2000
	char	Tazl[7];//6 Traffic Analysis Zone Code, 2000	
	char	Tazcombl[7]; //new in 2003
	char	Ual[6];//5 Urban Area, 2000 --does not include Ur flag
//	char	Url;//1 Urban/Rural Indicator, 2000
	char	Vtdl[7];//6 Census Voting District Code, 2000
	char	Sldul[4];//3 State Legislative District Code (Upper Chamber), 2000
	char	Sldll[4];//3 State Legislative District Code (Lower Chamber), 2000
	char	Ugal[6];//5 Oregon Urban Growth Area, 2000
	int		Waterl;
	char	Countyr[6];
	char	Tractr[12];//6 Census Tract, 2000
	char	Groupr[13];
	char	Blkgrpr;
	char	Blockr[16];//4 Census Block Number, 2000
	//char	Aianhhr[11];//4 Census Code (American Indian/ Alaska Native Area/Hawaiian Home Land), 2000
	char	Aianhhr[5];//4 Census Code (American Indian/ Alaska Native Area/Hawaiian Home Land), 2000
	char	Aianhhfpr[6];
	char	Aihhtlir;	
	char	Anrcr[6];//5 FIPS 55 Code (ANRC), 2000	
	char	Aitsr[6];//5 FIPS 55 Code (American Indian Tribal Subdivision), 2000
	char	Aitscer[4];
	char	Concitr[6];//5 FIPS 55 Code (Consolidated City), 2000
	char	Cousubr[11];//5 FIPS 55 Code (County Subdivision), 2000
	char	Submcdr[11];//5 FIPS 55 Code (Subbarrio), 2000
	char	Placer[6];//5 FIPS 55 Code (Incorporated Place/CDP), 2000
	char	Sdelmr[6];//5 Elementary School District Code, 2000
	char	Sdsecr[6];//5 Secondary School District Code, 2000
	char	Sdunir[6];//5 Unified School District Code, 2000
	char	Msacmsar[5];//4 FIPS Consolidated Metropolitan Statistical Area/Metropolitan Statistical Area Code, 2000
	char	Pmsar[5];//4 FIPS Primary Metropolitan Statistical Area Code, 2000
	char	Necmar[5];//4 FIPS New England County Metropolitan Area (NECMA) Code, 2000
	char	Cd106r[3];//2 Congressional District Code, 106th
	char	Cd108r[3];//2 Congressional District Code, 108th new in 2003
	char	Puma5r[6];//5 Public Use Microdata Area 5% File, 2000
	char	Puma1r[6];//5 Public Use Microdata Area  1% File, 2000
	char	Zcta5r[6];//5_Digit ZIP Code� Tabulation Area, 2000
	char	Zcta3r[4];//3 3_Digit ZIP Code� Tabulation Area, 2000
	char	Tazr[7];//6 Traffic Analysis Zone Code, 2000	
	char	Tazcombr[7]; //new in 2003
	char	Uar[6];//5 Urban Area, does not include 2000
//	char	Urr;//1 Urban/Rural Indicator, 2000
	char	Vtdr[7];//6 Census Voting District Code, 2000
	char	Sldur[4];//3 State Legislative District Code (Upper Chamber), 2000
	char	Sldlr[4];//3 State Legislative District Code (Lower Chamber), 2000
	char	Ugar[6];//5 Oregon Urban Growth Area, 2000
	int		Waterr;
}RecordTypeIS;
typedef struct{
	int indexl, indexr;
}RecordTypeISIndex;
typedef struct{
//	char	Statecql[3];//2 FIPS State Code, 2000 CQR
	char	Countycql[6]; //3 FIPS County Code, 2000 CQR
	char	Tractcql[7];//6 Census Tract, 2000 CQR
	char	Blockcql[6];//5 Census Block Number, 2000 CQR
	char	Aianhhfpcql[6]; //5 FIPS 55 Code (American Indian/Alaska Native Area/Hawaiian Home Land),2000 CQR
	char	Aianhhcql[5]; //4 Census Code (American Indian/Alaska Native Area/Hawaiian Home Land),2000 CQR
	char	Aihhtlicql; //1 American Indian/Hawaiian Home Land Trust Land Indicator, 2000 CQR
	char	Aitscecql[4];//3 Census Code (American Indian Tribal Subdivision), 2000 CQR
	char	Aitscql[6]; //5 FIPS 55 Code (American Indian Tribal Subdivision), 2000 CQR
	char	Anrccql[6]; //5 FIPS 55 Code (ANRC), 2000 CQR
	char	Concitcql[6];//5 FIPS 55 Code (Consolidated City), 2000 CQR
	char	Cousubcql[6];//5 FIPS 55 Code (County Subdivision), 2000 CQR
	char	Submcdcql[6];//5 FIPS 55 Code (Subbarrio), 2000 CQR
	char	Placecql[6];//5 FIPS 55 Code (Incorporated Place), 2000 CQR
	char	Uaccl[6];//5 Urban Area, 2000 Corrected In TIGER 2004 Second Edition this field is RS_B2
	char	Urccl; //1 Urban/Rural Indicator, 2000 Corrected In TIGER 2004 Second Edition this field is RS_B3
//	char	RS_B1[13];//12 Reserved Space B1
//	char	Statecqr[3];//2 FIPS State Code, 2000 CQR
	char	Countycqr[6]; //3 FIPS County Code, 2000 CQR
	char	Tractcqr[7];//6 Census Tract, 2000 CQR
	char	Blockcqr[6];//5 Census Block Number, 2000 CQR
	char	Aianhhfpcqr[6]; //5 FIPS 55 Code (American Indian/Alaska Native Area/Hawaiian Home Land),2000 CQR
	char	Aianhhcqr[5]; //4 Census Code (American Indian/Alaska Native Area/Hawaiian Home Land),2000 CQR
	char	Aihhtlicqr; //1 American Indian/Hawaiian Home Land Trust Land Indicator, 2000 CQR
	char	Aitscecqr[4];//3 Census Code (American Indian Tribal Subdivision), 2000 CQR
	char	Aitscqr[6]; //5 FIPS 55 Code (American Indian Tribal Subdivision), 2000 CQR
	char	Anrccqr[6]; //5 FIPS 55 Code (ANRC), 2000 CQR
	char	Concitcqr[6];//5 FIPS 55 Code (Consolidated City), 2000 CQR
	char	Cousubcqr[6];//5 FIPS 55 Code (County Subdivision), 2000 CQR
	char	Submcdcqr[6];//5 FIPS 55 Code (Subbarrio), 2000 CQR
	char	Placecqr[6];//5 FIPS 55 Code (Incorporated Place), 2000 CQR
	char	Uaccr[6];//5 Urban Area, 2000 Corrected In TIGER 2004 Second Edition this field is RS_B2
	char	Urccr; //1 Urban/Rural Indicator, 2000 Corrected In TIGER 2004 Second Edition this field is RS_B3
//	char	RS_B1[13];//12 Reserved Space B1

}RecordTypeIB;
typedef struct{
	char	Countyecl[6];
	char	Placeecl[6];
	int		Comregecl;
	char	Countyecr[6];
	char	Placeecr[6];
	int 	Comregecr;
}RecordTypeIE;
typedef struct{
	int indexl, indexr;
}RecordTypeIEIndex;
typedef struct{
	int indexl, indexr;
}RecordTypeIBIndex;
//2004
typedef struct{
	char	RecordType; //1 Record Type
	char	Version[5]; //4 Version Number
	char	Tlid[11]; //10 TIGER/Line� ID, Permanent 1-Cell Number
	char	Rtsq[4]; //sequence number for records with many sources
	char	Sourceid[11]; // TIGER 1-Cell Source Code
	char    Id[19]; //Identification Code
	char	Idflag; //Identification Code Flag
}RecordTypeM;

char Types[] = "ABCDEFHX";
typedef struct{ //A
    char  Id[6];
    char  Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int   Chosen, Flip;    
	//long  Seqnum;
}County_Border_Type;
typedef struct{ //A     
	char  Id[12];    
    char  Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int   Chosen, Flip;    
    //long  Seqnum;
}Tract_Border_Type;
typedef struct{
	char  Id[13];
    char  Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int   Chosen, Flip;    
    //long  Seqnum;
}BlockGroup_Border_Type;
typedef struct{
	char  Id[17];
	char  Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int   Chosen, Flip;    
    //long  Seqnum;
}Blockcu_Border_Type;       
typedef struct{
	char County[6];	
	char Id2[6]; //aianhhfp
	char Id[5]; //aianhh	
	char Tli; //aihhtli
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int   Chosen, Flip;    
}Aianhhcu_Border_Type;
typedef struct{
	char County[6];
	char Id[6];
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int   Chosen, Flip;    
}Anrc_Border_Type;
typedef struct{
	char County[6];
	char Id[6];
	char Id2[4];
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int   Chosen, Flip;    
}Aits_Border_Type;
typedef struct{
	char County[6];
	char Id[6];
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int   Chosen, Flip;    
}Concit_Border_Type;
typedef struct{
	char County[6];
	char Id[6];
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int   Chosen, Flip;    
}Cousub_Border_Type;
typedef struct{
	char County[6];
	char Id[6];
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int   Chosen, Flip;    
}Submcd_Border_Type;
typedef struct{
	char County[6];
	char Id[6];
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int   Chosen, Flip;    
}Place_Border_Type;
typedef struct{
	char County[6];
	char Id[6];
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int Chosen, Flip;
}Elementary_Border_Type;
typedef struct{
	char County[6];
	char Id[6];
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int Chosen, Flip;
}Secondary_Border_Type;
typedef struct{
	char County[6];
	char Id[6];
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int Chosen, Flip;
}Unified_Border_Type;
typedef struct{
	char County[6];
	char Id[5];
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int Chosen, Flip;
}Msacmsa_Border_Type;
typedef struct{  //although it is possible to use structures of identical layout, it is easier to maintain each layers struct
	char County[6];
	char Id[5];
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int Chosen, Flip;
}Pmsa_Border_Type;
typedef struct{  //although it is possible to use structures of identical layout, it is easier to maintain each layers struct
	char County[6];
	char Id[5];
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int Chosen, Flip;
}Necma_Border_Type;
typedef struct{
	char County[6];
	char Cdcu[3];
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int Chosen, Flip;
}Cdcu_Border_Type;
typedef struct{
	char County[6];
	char Id[6];
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int   Chosen, Flip;    
}Zcta5_Border_Type;
typedef struct{
	char County[6];
	char Id[4];
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int   Chosen, Flip;    
}Zcta3_Border_Type;
typedef struct{
	char  Id[16];
	char  Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int   Chosen, Flip;    
    //long  Seqnum;
}Block00_Border_Type;       
typedef struct{
	char County[6];
	char Puma[6];
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int Chosen, Flip;
}Puma_Border_Type;
typedef struct{
	char County[6];
	char Taz[7];
	char Ua[6];
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int Chosen, Flip;
}Taz_Border_Type;
typedef struct{
	char County[6];
	char Uacode[6];
//	char Urbflag;
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int Chosen, Flip;
}Urban_Border_Type;
typedef struct{
	char County[6];
	char Id[7];
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int   Chosen, Flip;    
}Vote2000_Border_Type;
typedef struct{
	char County[6];
	char Sld[4];
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int Chosen, Flip;
}Sld_Border_Type;
/*typedef struct{
	char County[6];
	char Uacode[7]; //include flag
//	char Urbflag;
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int Chosen, Flip;
}Urbancq_Border_Type;*/
typedef struct{
	double Latitude, Longitude;
}Landmark_Node_Type;
typedef struct{
	char County[6];
	int Polyid;
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int	 Chosen, Flip;
}Land_Border_Type;
typedef struct{
	char County[6];
//	char Water[6];
//	int Polyid;	
	char Water[34];
	char Waterplus[50];
	int	 Flag;
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int Chosen, Flip;
}Water_Border_Type;
typedef struct{
	char	Polyid[11];
	char	Cenid[6];
	char	Statecu[3];// 2 FIPS State Code, Current
	char	Countycu[4];//3 FIPS County Code, Current
	char	Tractcu[7];// 6 Census Tract, 2000
	char	Blockcu[5];// 4 Census Block Number, 2000
	char	Blocksufcu;//1 Current Suffix for Census 2000 Block Number
	char	Aianhhfpcu[6];//5 FIPS 55 Code (American Indian/Alaska Native Area/Hawaiian Home Land), Current
	char	Aianhhcu[5];//4 Census Code (American Indian/Alaska Native Area/Hawaiian Home Land), Current
	char	Aihhtlicu;//1 American Indian/Hawaiian Home Land Trust Land Indicator, Current
	char	Anrccu[6];//5 FIPS 55 Code (ANRC), Current 
	char	Aitscecu[4];//3 Census Code (American Indian Tribal Subdivision), Current
	char	Aitscu[6]; // 5 FIPS 55 Code (American Indian Tribal Subdivision), Current
	char	Concitcu[6]; //5 FIPS 55 Code (Consolidated City), Current
	char	Cousubcu[6]; //5 FIPS 55 Code (County Subdivision), Current
	char	Submcdcu[6]; //5 FIPS 55 Code (Subbarrio), Current
	char	Placecu[6]; //5 FIPS 55 Code (Incorporated Place), Current
	char	Sdelmcu[6]; //5 Elementary School District Code, Current
	char	Sdseccu[6]; //5 Secondary School District Code, Current
	char	Sdunicu[6]; //5 Unified School District Code, Current
	char	Msacmsacu[5]; //4 FIPS Consolidated Metropolitan Statistical Area/Metropolitan Statistical Area Code,Current
	char	Pmsacu[5]; //4 FIPS Primary Metropolitan Statistical Area, Current Geography
	char	Necmacu[5]; //4 FIPS New England County Metropolitan Area Code, Current
	char	Cdcu[3]; //2 Congressional District Code, Current (106th)
	char	Zctacu[6]; //RS_A2[6];//5 Reserved Space A2--to be zctacu; read as such
	char	Zcta3cu[4];//3 Reserved Space A3--to be zctacu 3 digit; read as such
	char	State00[3];//2 FIPS State Code, 2000
	char	County00[4];//3 FIPS County Code, 2000
	char	Tract00[7];//6 Census Tract, 2000
	char	Block00[5];//4 Census Block Number, 2000
	char	Blkgrp00;//1 Census Block Group, 2000
	char	Aianhhfp00[6];//5 FIPS 55 Code (American Indian/Alaska Native Area/Hawaiian Home Land), 2000
	char	Aianhh00[5];//4 Census Code (American Indian/ Alaska Native Area/Hawaiian Home Land), 2000
	char	Aihhtli00;//1 American Indian/Hawaiian Home Land Trust Land Indicator, 2000
	char	Anrc00[6];//5 FIPS 55 Code (ANRC), 2000
	char	Aitsce00[4];//3 Census Code (American Indian Tribal Subdivision), 2000
	char	Aits00[6];//5 FIPS 55 Code (American Indian Tribal Subdivision), 2000
	char	Concit00[6];//5 FIPS 55 Code (Consolidated City), 2000
	char	Cousub00[6];//5 FIPS 55 Code (County Subdivision), 2000
	char	Submcd00[6];//5 FIPS 55 Code (Subbarrio), 2000
	char	Place00[6];//5 FIPS 55 Code (Incorporated Place/CDP), 2000
	char	Sdelm00[6];//5 Elementary School District Code, 2000
	char	Sdsec00[6];//5 Secondary School District Code, 2000
	char	Sduni00[6];//5 Unified School District Code, 2000
	char	Msacmsa00[5];//4 FIPS Consolidated Metropolitan Statistical Area/Metropolitan Statistical Area Code, 2000
	char	Pmsa00[5];//4 FIPS Primary Metropolitan Statistical Area Code, 2000
	char	Necma00[5];//4 FIPS New England County Metropolitan Area (NECMA) Code, 2000
	char	Cd106[3];//2 Congressional District Code, 106th	
	char	Puma5[6];//5 Public Use Microdata Area 5% File, 2000
	char	Puma1[6];//5 Public Use Microdata Area  1% File, 2000
	char	Zcta00[6];//5_Digit ZIP Code� Tabulation Area, 2000
	char	Zcta300[4];//3 3_Digit ZIP Code� Tabulation Area, 2000
	char	Taz[7];//6 Traffic Analysis Zone Code, 2000
	char	Ua[6];//5 Urban Area, 2000
	char	Ur;//1 Urban/Rural Indicator, 2000
	char	Vtd[7];//6 Census Voting District Code, 2000
	char	Sldu[4];//3 State Legislative District Code (Upper Chamber), 2000
	char	Sldl[4];//3 State Legislative District Code (Lower Chamber), 2000
	char	Uga[6];//5 Oregon Urban Growth Area, 2000
	int		Water;
	char	Statecq[3];//2 FIPS State Code, 2000 CQR
	char	Countycq[4]; //3 FIPS County Code, 2000 CQR
	char	Tractcq[7];//6 Census Tract, 2000 CQR
	char	Blockcq[6];//5 Census Block Number, 2000 CQR
	char	Aianhhfpcq[6]; //5 FIPS 55 Code (American Indian/Alaska Native Area/Hawaiian Home Land),2000 CQR
	char	Aianhhcq[5]; //4 Census Code (American Indian/Alaska Native Area/Hawaiian Home Land),2000 CQR
	char	Aihhtlicq; //1 American Indian/Hawaiian Home Land Trust Land Indicator, 2000 CQR
	char	Aitscecq[4];//3 Census Code (American Indian Tribal Subdivision), 2000 CQR
	char	Aitscq[6]; //5 FIPS 55 Code (American Indian Tribal Subdivision), 2000 CQR
	char	Anrccq[6]; //5 FIPS 55 Code (ANRC), 2000 CQR
	char	Concitcq[6];//5 FIPS 55 Code (Consolidated City), 2000 CQR
	char	Cousubcq[6];//5 FIPS 55 Code (County Subdivision), 2000 CQR
	char	Submcdcq[6];//5 FIPS 55 Code (Subbarrio), 2000 CQR
	char	Placecq[6];//5 FIPS 55 Code (Incorporated Place), 2000 CQR
	char	Uacc[6];//5 Urban Area, 2000 Corrected In TIGER 2004 Second Edition this field is RS_B2
	char	Urcc; //1 Urban/Rural Indicator, 2000 Corrected In TIGER 2004 Second Edition this field is RS_B2
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int Chosen, Flip;
}Poly_Border_TypeAll;
typedef struct{
	char	Polyid[11];
	char	Cenid[6];
	char	Statecu[3];// 2 FIPS State Code, Current
	char	Countycu[4];//3 FIPS County Code, Current
	char	Tractcu[7];// 6 Census Tract, 2000
	char	Blockcu[5];// 4 Census Block Number, 2000
	char	Blocksufcu;//1 Current Suffix for Census 2000 Block Number
	char	Aianhhfpcu[6];//5 FIPS 55 Code (American Indian/Alaska Native Area/Hawaiian Home Land), Current
	char	Aianhhcu[5];//4 Census Code (American Indian/Alaska Native Area/Hawaiian Home Land), Current
	char	Aihhtlicu;//1 American Indian/Hawaiian Home Land Trust Land Indicator, Current
	char	Anrccu[6];//5 FIPS 55 Code (ANRC), Current 
	char	Aitscecu[4];//3 Census Code (American Indian Tribal Subdivision), Current
	char	Aitscu[6]; // 5 FIPS 55 Code (American Indian Tribal Subdivision), Current
	char	Concitcu[6]; //5 FIPS 55 Code (Consolidated City), Current
	char	Cousubcu[6]; //5 FIPS 55 Code (County Subdivision), Current
	char	Submcdcu[6]; //5 FIPS 55 Code (Subbarrio), Current
	char	Placecu[6]; //5 FIPS 55 Code (Incorporated Place), Current
	char	Sdelmcu[6]; //5 Elementary School District Code, Current
	char	Sdseccu[6]; //5 Secondary School District Code, Current
	char	Sdunicu[6]; //5 Unified School District Code, Current
	char	Cdcu[3]; //2 Congressional District Code, Current (106th)
	char	Zctacu[6]; //RS_A2[6];//5 Reserved Space A2--to be zctacu; read as such
	char	Zcta3cu[4];//3 Reserved Space A3--to be zctacu 3 digit; read as such
	char	Cbsacu[6]; //2003
	char	Csacu[4]; //2003
	char	Nectacu[6]; //2003
	char	Cnectacu[4]; //2003
	char	Metdivcu[6]; //2003
	char	Nectadivcu[6]; //2003
	char	State00[3];//2 FIPS State Code, 2000
	char	County00[4];//3 FIPS County Code, 2000
	char	Tract00[7];//6 Census Tract, 2000
	char	Block00[5];//4 Census Block Number, 2000
	char	Blkgrp00;//1 Census Block Group, 2000
	char	Aianhhfp00[6];//5 FIPS 55 Code (American Indian/Alaska Native Area/Hawaiian Home Land), 2000
	char	Aianhh00[5];//4 Census Code (American Indian/ Alaska Native Area/Hawaiian Home Land), 2000
	char	Aihhtli00;//1 American Indian/Hawaiian Home Land Trust Land Indicator, 2000
	char	Anrc00[6];//5 FIPS 55 Code (ANRC), 2000
	char	Aitsce00[4];//3 Census Code (American Indian Tribal Subdivision), 2000
	char	Aits00[6];//5 FIPS 55 Code (American Indian Tribal Subdivision), 2000
	char	Concit00[6];//5 FIPS 55 Code (Consolidated City), 2000
	char	Cousub00[6];//5 FIPS 55 Code (County Subdivision), 2000
	char	Submcd00[6];//5 FIPS 55 Code (Subbarrio), 2000
	char	Place00[6];//5 FIPS 55 Code (Incorporated Place/CDP), 2000
	char	Sdelm00[6];//5 Elementary School District Code, 2000
	char	Sdsec00[6];//5 Secondary School District Code, 2000
	char	Sduni00[6];//5 Unified School District Code, 2000
	char	Msacmsa00[5];//4 FIPS Consolidated Metropolitan Statistical Area/Metropolitan Statistical Area Code, 2000
	char	Pmsa00[5];//4 FIPS Primary Metropolitan Statistical Area Code, 2000
	char	Necma00[5];//4 FIPS New England County Metropolitan Area (NECMA) Code, 2000
	char	Cd106[3];//2 Congressional District Code, 106th	
	char	Cd108[3]; //2003
	char	Puma5[6];//5 Public Use Microdata Area 5% File, 2000
	char	Puma1[6];//5 Public Use Microdata Area  1% File, 2000
	char	Zcta00[6];//5_Digit ZIP Code� Tabulation Area, 2000
	char	Zcta300[4];//3 3_Digit ZIP Code� Tabulation Area, 2000
	char	Taz[7];//6 Traffic Analysis Zone Code, 2000
	char	Tazcomb[7]; //2003
	char	Ua[6];//5 Urban Area, 2000
	char	Ur;//1 Urban/Rural Indicator, 2000
	char	Vtd[7];//6 Census Voting District Code, 2000
	char	Sldu[4];//3 State Legislative District Code (Upper Chamber), 2000
	char	Sldl[4];//3 State Legislative District Code (Lower Chamber), 2000
	char	Uga[6];//5 Oregon Urban Growth Area, 2000
	int		Water;
	char	Statecq[3];//2 FIPS State Code, 2000 CQR
	char	Countycq[4]; //3 FIPS County Code, 2000 CQR
	char	Tractcq[7];//6 Census Tract, 2000 CQR
	char	Blockcq[6];//5 Census Block Number, 2000 CQR
	char	Aianhhfpcq[6]; //5 FIPS 55 Code (American Indian/Alaska Native Area/Hawaiian Home Land),2000 CQR
	char	Aianhhcq[5]; //4 Census Code (American Indian/Alaska Native Area/Hawaiian Home Land),2000 CQR
	char	Aihhtlicq; //1 American Indian/Hawaiian Home Land Trust Land Indicator, 2000 CQR
	char	Aitscecq[4];//3 Census Code (American Indian Tribal Subdivision), 2000 CQR
	char	Aitscq[6]; //5 FIPS 55 Code (American Indian Tribal Subdivision), 2000 CQR
	char	Anrccq[6]; //5 FIPS 55 Code (ANRC), 2000 CQR
	char	Concitcq[6];//5 FIPS 55 Code (Consolidated City), 2000 CQR
	char	Cousubcq[6];//5 FIPS 55 Code (County Subdivision), 2000 CQR
	char	Submcdcq[6];//5 FIPS 55 Code (Subbarrio), 2000 CQR
	char	Placecq[6];//5 FIPS 55 Code (Incorporated Place), 2000 CQR
	char	Uacc[6];//5 Urban Area, 2000 Corrected
	char	Urcc; //1 Urban/Rural Indicator, 2000 Corrected
	char	Stateec[3]; //2003 type e
	char	Countyec[4]; //2003
	char	Placeec[6]; //2003
	int 	Comregec;
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int Chosen, Flip;
}Poly_Border_TypeAll03;
typedef struct{
	char	Polyid[11];
	char	Cenid[6];
	char	Statecu[3];// 2 FIPS State Code, Current
	char	Countycu[4];//3 FIPS County Code, Current
	char	Tractcu[7];// 6 Census Tract, 2000
	char	Blockcu[5];// 4 Census Block Number, 2000
	char	Blocksufcu;//1 Current Suffix for Census 2000 Block Number
	char	Aianhhfpcu[6];//5 FIPS 55 Code (American Indian/Alaska Native Area/Hawaiian Home Land), Current
	char	Aianhhcu[5];//4 Census Code (American Indian/Alaska Native Area/Hawaiian Home Land), Current
	char	Aihhtlicu;//1 American Indian/Hawaiian Home Land Trust Land Indicator, Current
	char	Anrccu[6];//5 FIPS 55 Code (ANRC), Current 
	char	Aitscecu[4];//3 Census Code (American Indian Tribal Subdivision), Current
	char	Aitscu[6]; // 5 FIPS 55 Code (American Indian Tribal Subdivision), Current
	char	Concitcu[6]; //5 FIPS 55 Code (Consolidated City), Current
	char	Cousubcu[6]; //5 FIPS 55 Code (County Subdivision), Current
	char	Submcdcu[6]; //5 FIPS 55 Code (Subbarrio), Current
	char	Placecu[6]; //5 FIPS 55 Code (Incorporated Place), Current
	char	Sdelmcu[6]; //5 Elementary School District Code, Current
	char	Sdseccu[6]; //5 Secondary School District Code, Current
	char	Sdunicu[6]; //5 Unified School District Code, Current
	char	Cdcu[3]; //2 Congressional District Code, Current (106th)
	char	Zctacu[6]; //RS_A2[6];//5 Reserved Space A2--to be zctacu; read as such
	char	Zcta3cu[4];//3 Reserved Space A3--to be zctacu 3 digit; read as such
	char	Slducu[4];
	char	Sldlcu[4];
	char	Cbsacu[6]; //2003
	char	Csacu[4]; //2003
	char	Nectacu[6]; //2003
	char	Cnectacu[4]; //2003
	char	Metdivcu[6]; //2003
	char	Nectadivcu[6]; //2003
	char	Uacu[6];
	char	Urcu;
	char	State00[3];//2 FIPS State Code, 2000
	char	County00[4];//3 FIPS County Code, 2000
	char	Tract00[7];//6 Census Tract, 2000
	char	Block00[5];//4 Census Block Number, 2000
	char	Blkgrp00;//1 Census Block Group, 2000
	char	Aianhhfp00[6];//5 FIPS 55 Code (American Indian/Alaska Native Area/Hawaiian Home Land), 2000
	char	Aianhh00[5];//4 Census Code (American Indian/ Alaska Native Area/Hawaiian Home Land), 2000
	char	Aihhtli00;//1 American Indian/Hawaiian Home Land Trust Land Indicator, 2000
	char	Anrc00[6];//5 FIPS 55 Code (ANRC), 2000
	char	Aitsce00[4];//3 Census Code (American Indian Tribal Subdivision), 2000
	char	Aits00[6];//5 FIPS 55 Code (American Indian Tribal Subdivision), 2000
	char	Concit00[6];//5 FIPS 55 Code (Consolidated City), 2000
	char	Cousub00[6];//5 FIPS 55 Code (County Subdivision), 2000
	char	Submcd00[6];//5 FIPS 55 Code (Subbarrio), 2000
	char	Place00[6];//5 FIPS 55 Code (Incorporated Place/CDP), 2000
	char	Sdelm00[6];//5 Elementary School District Code, 2000
	char	Sdsec00[6];//5 Secondary School District Code, 2000
	char	Sduni00[6];//5 Unified School District Code, 2000
	char	Msacmsa00[5];//4 FIPS Consolidated Metropolitan Statistical Area/Metropolitan Statistical Area Code, 2000
	char	Pmsa00[5];//4 FIPS Primary Metropolitan Statistical Area Code, 2000
	char	Necma00[5];//4 FIPS New England County Metropolitan Area (NECMA) Code, 2000
	char	Cd106[3];//2 Congressional District Code, 106th	
	char	Cd108[3]; //2003
	char	Puma5[6];//5 Public Use Microdata Area 5% File, 2000
	char	Puma1[6];//5 Public Use Microdata Area  1% File, 2000
	char	Zcta00[6];//5_Digit ZIP Code� Tabulation Area, 2000
	char	Zcta300[4];//3 3_Digit ZIP Code� Tabulation Area, 2000
	char	Taz[7];//6 Traffic Analysis Zone Code, 2000
	char	Tazcomb[7]; //2003
	char	Ua[6];//5 Urban Area, 2000
	char	Ur;//1 Urban/Rural Indicator, 2000
	char	Vtd[7];//6 Census Voting District Code, 2000
	char	Sldu[4];//3 State Legislative District Code (Upper Chamber), 2000
	char	Sldl[4];//3 State Legislative District Code (Lower Chamber), 2000
	char	Uga[6];//5 Oregon Urban Growth Area, 2000
	int		Water;
	char	Statecq[3];//2 FIPS State Code, 2000 CQR
	char	Countycq[4]; //3 FIPS County Code, 2000 CQR
	char	Tractcq[7];//6 Census Tract, 2000 CQR
	char	Blockcq[6];//5 Census Block Number, 2000 CQR
	char	Aianhhfpcq[6]; //5 FIPS 55 Code (American Indian/Alaska Native Area/Hawaiian Home Land),2000 CQR
	char	Aianhhcq[5]; //4 Census Code (American Indian/Alaska Native Area/Hawaiian Home Land),2000 CQR
	char	Aihhtlicq; //1 American Indian/Hawaiian Home Land Trust Land Indicator, 2000 CQR
	char	Aitscecq[4];//3 Census Code (American Indian Tribal Subdivision), 2000 CQR
	char	Aitscq[6]; //5 FIPS 55 Code (American Indian Tribal Subdivision), 2000 CQR
	char	Anrccq[6]; //5 FIPS 55 Code (ANRC), 2000 CQR
	char	Concitcq[6];//5 FIPS 55 Code (Consolidated City), 2000 CQR
	char	Cousubcq[6];//5 FIPS 55 Code (County Subdivision), 2000 CQR
	char	Submcdcq[6];//5 FIPS 55 Code (Subbarrio), 2000 CQR
	char	Placecq[6];//5 FIPS 55 Code (Incorporated Place), 2000 CQR
	char	Uacc[6];//5 Urban Area, 2000 Corrected
	char	Urcc; //1 Urban/Rural Indicator, 2000 Corrected
	char	Stateec[3]; //2003 type e
	char	Countyec[4]; //2003
	char	Placeec[6]; //2003
	int 	Comregec;
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int Chosen, Flip;
}Poly_Border_TypeAll06se;
typedef struct{
	char	Id[16];
	char	Polyid[11];
	char	Cenid[6];
	char	Statecq[3];//2 FIPS State Code, 2000 CQR
	char	Countycq[4]; //3 FIPS County Code, 2000 CQR
	char	Tractcq[7];//6 Census Tract, 2000 CQR
	char	Blockcq[6];//5 Census Block Number, 2000 CQR
	char	Aianhhfpcq[6]; //5 FIPS 55 Code (American Indian/Alaska Native Area/Hawaiian Home Land),2000 CQR
	char	Aianhhcq[5]; //4 Census Code (American Indian/Alaska Native Area/Hawaiian Home Land),2000 CQR
	char	Aihhtlicq; //1 American Indian/Hawaiian Home Land Trust Land Indicator, 2000 CQR
	char	Aitscecq[4];//3 Census Code (American Indian Tribal Subdivision), 2000 CQR
	char	Aitscq[6]; //5 FIPS 55 Code (American Indian Tribal Subdivision), 2000 CQR
	char	Anrccq[6]; //5 FIPS 55 Code (ANRC), 2000 CQR
	char	Concitcq[6];//5 FIPS 55 Code (Consolidated City), 2000 CQR
	char	Cousubcq[6];//5 FIPS 55 Code (County Subdivision), 2000 CQR
	char	Submcdcq[6];//5 FIPS 55 Code (Subbarrio), 2000 CQR
	char	Placecq[6];//5 FIPS 55 Code (Incorporated Place), 2000 CQR
	char	Uacc[6];//5 Urban Area, 2000 Corrected In TIGER 2004 Second Edition this field is RS_B2
	char	Urcc; //1 Urban/Rural Indicator, 2000 Corrected In TIGER 2004 Second Edition this field is RS_B3
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int Chosen, Flip;
}Cq_Border_Type;
typedef struct{
	char	Tzid[11];
	int		Cfcount[8];
	double	lat, lng;
	int		fileid;
}Node_Type;
//new for type E
typedef struct{
char County[6];
	char Id[6];
	int Polyid;
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int	 Chosen, Flip;	
}TypeE_Border_Type;
typedef struct{
	char County[6];
	int Id;
	int Polyid;
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int	 Chosen, Flip;	
}Comreg_Border_Type;
typedef struct{
	char County[6];
	char Id[6];;
	int Polyid;
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int	 Chosen, Flip;	
}Cbsacu_Border_Type;
typedef struct{
	char County[6];
	char Id[4];;
	int Polyid;
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int	 Chosen, Flip;	
}Csacu_Border_Type;
typedef struct{
	char County[6];
	char Id[6];;
	int Polyid;
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int	 Chosen, Flip;	
}Metdivcu_Border_Type;
typedef struct{
	char County[6];
	char Id[6];;
	int Polyid;
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int	 Chosen, Flip;	
}Nectacu_Border_Type;
typedef struct{
	char County[6];
	char Id[4];;
	int Polyid;
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int	 Chosen, Flip;	
}Cnectacu_Border_Type;
typedef struct{
	char County[6];
	char Id[6];;
	int Polyid;
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int	 Chosen, Flip;	
}Nectadivcu_Border_Type;
