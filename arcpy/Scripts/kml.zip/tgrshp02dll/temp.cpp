{
	//buiding urbancu from placecu
	int polyid, found, i, nparts, ptcount;
	long num, n, written, curcase;
	Place_Border_Type *place; //can use place since the same size
	double  curX, curY;	
    FILE  *dbftmp, *ptstemp, *headtemp, *partstemp, *boxtemp, *shxtemp; 
	CString info, fname;	
	char placerecord[86];  //since urban and place have same size can use existing structures
	int steppos;
	char *placename;
	int doleft, doright;
	CString errmsg;
	int bval;
	int curpolys;
	char entity, pdc, lsadc[3], fipscc[3];
	if (APolycounts[28] == 0)
	{
		fprintf(LOG,"There are no Urban Current records\n");
		return;
	}
	Ptrdlg->m_strProcess.Format("");		
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	Ptrdlg->m_Progress.SetPos(0);		
	Ptrdlg->m_strLayer.Format("Urban Current");		
	Ptrdlg->SetDlgItemText(IDC_LAYER,Ptrdlg->m_strLayer);
	
	dbftmp = fopen("dbf.tmp","wb");
	if (dbftmp == NULL)
	{
		errmsg.Format("Could not open file dbf.tmp");
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}

	ptstemp = fopen("pts.tmp","wb");
	if (ptstemp == NULL)
	{
		errmsg.Format("Could not open file pts.tmp");
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	headtemp = fopen("head.tmp","wb");
	if (headtemp == NULL)
	{
		errmsg.Format("Could not open file head.tmp");
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	boxtemp = fopen("box.tmp","wb");
	if (boxtemp == NULL)
	{
		errmsg.Format("Could not open file box.tmp");
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	partstemp = fopen("parts.tmp","wb");
	if (partstemp == NULL)
	{
		errmsg.Format("Could not open file parts.tmp");
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	place = (Urban_Border_Type *)calloc(APolycounts[28]+Watercut*SPolycounts[0],sizeof(Urban_Border_Type));
	written = 0;
	int aindexl, aindexr, sindexl, sindexr;
	for (num = 0; num < CountI; num++)
	{
		steppos = (int) (num * 100/CountI);
		Ptrdlg->m_Progress.SetPos(steppos);		

		strcpy(TypeIAs.Countycul,"     ");
		strcpy(TypeIAs.Countycur,"     ");		
		strcpy(TypeIAs.Uacul,"     ");
		strcpy(TypeIAs.Uacur,"     ");
		TypeISs.Waterl = 0;
		TypeISs.Waterr = 0;
		aindexl = TypeIAIndex[num].indexl;
		aindexr = TypeIAIndex[num].indexr;
		sindexl = TypeISIndex[num].indexl;
		sindexr = TypeISIndex[num].indexr;	
		if (aindexl >= 0)
		{
			fseek(atemp,(long)aindexl*sizeof(RecordTypeA),0);
			if (fread(&TypeAs,sizeof(RecordTypeA),1,atemp) != 1)
				{
					errmsg.Format("\nCannot read from temp file");
					Ptrdlg->ErrorMessage(errmsg);
					MissingFile = -1; return;			
				} 
			sprintf(TypeIAs.Countycul,"%2s%3s",TypeAs.Statecu,TypeAs.Countycu);			
			sprintf(TypeIAs.Uacul,"%5s",TypeAs.Uacu);
		}
		if (aindexr >= 0)
		{
			fseek(atemp,(long)aindexr*sizeof(RecordTypeA),0);
			if (fread(&TypeAs,sizeof(RecordTypeA),1,atemp) != 1)
				{
					errmsg.Format("\nCannot read from temp file");
					Ptrdlg->ErrorMessage(errmsg);
					MissingFile = -1; return;			
				}
			sprintf(TypeIAs.Countycur,"%2s%3s",TypeAs.Statecu,TypeAs.Countycu);
			sprintf(TypeIAs.Uacur,"%5s",TypeAs.Uacu);
		
		}
		if (sindexl >= 0)
			TypeISs.Waterl = TypePs[Get_PIndex(TypeIs[num].Cenidl, TypeIs[num].Polyidl)].Water;		
		if (sindexr >= 0)
			TypeISs.Waterr = TypePs[Get_PIndex(TypeIs[num].Cenidr, TypeIs[num].Polyidr)].Water;		

		if (strcmp(TypeIAs.Placecul,TypeIAs.Placecur) == 0)
		{
			if (Watercut)
			{

				if (TypeISs.Waterl == TypeISs.Waterr)
					continue;
				if (abs(TypeISs.Waterl - TypeISs.Waterr) > 1)
					continue;
			}
			else
				continue;		
		}
		doleft = 0;
			
		if ((strcmp(TypeIAs.Uacul,"     ") != 0) &&
			((sindexl >= 0) || (aindexl >= 0)))
		{//left case
			if (Watercut)
			{
				if(TypeISs.Waterl != 1)
					doleft = 1;
			}
			else
				doleft = 1;
			if (doleft)
			{	
				sprintf(place[written].County,"%s",TypeIAs.Countycul);
				sprintf(place[written].Id,"%s",TypeIAs.Uacul);
				sprintf(place[written].Tlid,"%s",TypeIs[num].Tlid);
				place[written].Frlong = Type1s[num].Frlong;
				place[written].Frlat = Type1s[num].Frlat;
				place[written].Tolong = Type1s[num].Tolong;
				place[written].Tolat = Type1s[num].Tolat;
				place[written].Chosen = 0;
				place[written].Flip = 1;
				written++;
			}
		}
		doright = 0;

		if ((strcmp(TypeIAs.Uacur,"     ") != 0) &&
			((sindexr >= 0) || (aindexr >= 0)))
		{
			if (Watercut)
			{
				if(TypeISs.Waterr != 1)
					doright = 1;
			}
			else
				doright = 1;
			if (doright)
			{
				sprintf(place[written].County,"%s",TypeIAs.Countycur);
				sprintf(place[written].Id,"%s",TypeIAs.Uacur);
				sprintf(place[written].Tlid,"%s",TypeIs[num].Tlid);
				place[written].Frlong = Type1s[num].Frlong;
				place[written].Frlat = Type1s[num].Frlat;
				place[written].Tolong = Type1s[num].Tolong;
				place[written].Tolat = Type1s[num].Tolat;
				place[written].Chosen = 0;
				place[written].Flip = 0;
				written++;
			}
		}
		
		if (written > APolycounts[28]+Watercut*SPolycounts[0])
		{
			Ptrdlg->ErrorMessage("the number of Place border lines exceeds the count");				
			MissingFile = -1;
			return;
		}
	}
	if (written == 0)
	{
		if (!Watercut)
			fprintf(LOG,"There are no Urban Current border lines\n");
		else
		{			
			fprintf(LOG,"Try turning off the water polygon clipping option before extracting Urban Current\n");
		}
		fclose(boxtemp);
		fclose(ptstemp);
		fclose(headtemp);
		fclose(partstemp);	
		fclose(dbftmp);
		unlink("box.tmp");
		unlink("pts.tmp");
		unlink("head.tmp");
		unlink("parts.tmp");
		unlink("dbf.tmp");
		return;
	}
	//time to chain	
	Ptrdlg->m_strProcess.Format("Gathering Urban Current Boundary Lines");
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	qsort((void *)place,written,sizeof(Place_Border_Type),(compfn)ComparePlacecu);
	FileMinX = FileMinY = LARGE;
	FileMaxX = FileMaxY = -LARGE;
	CurrentMinX = CurrentMinY = LARGE;
	CurrentMaxX = CurrentMaxY = -LARGE;
	//start version 4.1 insert
	CurNumElements = 0;
	char tempchar;
	CString type, type2;
	type = "urbcu";
	type2 = "urban";

	switch (OutOption)
	{
	case '0': //by county
	case '1': //all in one
		//as is
		Curfilepath = Outfilepath;
		Curfilepolyname.Format("%s%s",Outfiletitle,type);			
		break;
	case '2': //by theme
		Curdirname = type2; 
		Curfilepath.Format("%s%s\\",Outfilepath,Curdirname); 
		result = _mkdir(Curfilepath);
		if (result == 0)
			fprintf(LOG,"directory %s created\n",Curfilepath);
		else
			fprintf(LOG,"directory %s not created\n", Curfilepath);		
		Curfilepolyname.Format("%s%s",Outfiletitle,type);			
		break;
	case '3':
		Curdirname = type2; 
		Curfilepath.Format("%s%s\\",Outfilepath,Curdirname); 
		result = _mkdir(Curfilepath);
		if (result == 0)
			fprintf(LOG,"directory %s created\n",Curfilepath);
		else
			fprintf(LOG,"directory %s not created\n", Curfilepath);
		Curfilepolyname = type; 			
		result = _mkdir(Curfilepath);
		if (result == 0)
			fprintf(LOG,"directory %s created\n",Curfilepath);
		else
			fprintf(LOG,"directory %s not created\n", Curfilepath);	
		fname.Format("%s%s.shx",Curfilepath, Curfilepolyname); 		
		shxtemp = fopen(fname,"r+b");
		if (shxtemp != NULL)
		{
			rewind(shxtemp);
			if (fread(&tempchar,sizeof(char),1,shxtemp) == 1)	
			{			
				GetFileStats(shxtemp); //this will rest fileminx, miny etc.										
				if (MissingFile == -1) return;
				fclose(shxtemp);
			}
		}
		break;
	}
	curpolys = CurNumElements;
	//end version 4.1 reading insert

	curcase = 0;
	polyid = 1;
	Npts = 0; 
	nparts = 1;
	ptcount = 0;
	
	uanum = -1;
	placename = Get_TypeC_Name2(7,place[curcase].Id,"",DATAYR);
    if (uanum < 0)
	{
		pdc = ' ';
		entity = ' ';
		strncpy(lsadc,"  ",2);
		strncpy(fipscc,"  ",2);
	}
	else
	{
		pdc = TypeCs[uanum].Placedc;
		entity = TypeCs[uanum].Entity;
		strncpy(lsadc,TypeCs[uanum].Lsadc,2);
		strncpy(fipscc,TypeCs[uanum].Fipscc,2);
	}
	sprintf(placerecord," %8d",polyid+curpolys);
	sprintf(&placerecord[9],"%-5s",place[curcase].County);
	sprintf(&placerecord[14],"%-5s",place[curcase].Id);
	sprintf(&placerecord[19],"%-60s",placename);	
	sprintf(&placerecord[79],"%-2s",lsadc);
	sprintf(&placerecord[81],"%c",entity);
	sprintf(&placerecord[82],"%-2s",fipscc);
	sprintf(&placerecord[84],"%c",pdc);
	fwrite(&placerecord,sizeof(placerecord)-1,1,dbftmp);
	if (place[0].Flip == 0)
	{
		curX = place[0].Tolong;
		curY = place[0].Tolat;		
		Pts[Npts].Longitude = place[curcase].Frlong;
		Pts[Npts].Latitude = place[curcase].Frlat;
		Npts++;
		Get_Shape_Points(place[curcase].Tlid, place[curcase].Flip);
		Pts[Npts].Longitude = place[curcase].Tolong;
		Pts[Npts].Latitude = place[curcase].Tolat;
		Npts++;
		place[curcase].Chosen = 1;		
	}
	else
	{
		curX = place[0].Frlong;
		curY = place[0].Frlat;		
		Pts[Npts].Longitude = place[curcase].Tolong;
		Pts[Npts].Latitude = place[curcase].Tolat;
		Npts++;
		Get_Shape_Points(place[curcase].Tlid, place[curcase].Flip);
		Pts[Npts].Longitude = place[curcase].Frlong;
		Pts[Npts].Latitude = place[curcase].Frlat;
		Npts++;
		place[curcase].Chosen = 1;		
	}
	ptcount += Npts;
	
    fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
	
	if (Pts[0].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < CurrentMinY)
		CurrentMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[0].Latitude;	
	if (Pts[0].Longitude < FileMinX)
		FileMinX = Pts[0].Longitude;
	if (Pts[0].Longitude > FileMaxX)
		FileMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < FileMinY)
		FileMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > FileMaxY)
		FileMaxY = Pts[0].Latitude;

	if (Pts[Npts-1].Longitude < CurrentMinX)
		CurrentMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < CurrentMinY)
		CurrentMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[Npts-1].Latitude;	
	if (Pts[Npts-1].Longitude < FileMinX)
		FileMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > FileMaxX)
		FileMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < FileMinY)
		FileMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > FileMaxY)
		FileMaxY = Pts[Npts-1].Latitude;		
	n = 1;
	steppos = (int)(n*100/written);	
	Ptrdlg->m_Progress.SetPos(steppos);
	bval = 1;
    while (n < written)
	{
		steppos = (int)(n*100/written);	
		Ptrdlg->m_Progress.SetPos(steppos);
		
		found = 0;
		while (bval > 1)
		{
			if (strcmp(place[bval].Id, place[curcase].Id) >= 0)
				bval--;
			else
				break;			
		}
		for (i = bval; i < written; i++)
         {
			Npts = 0;
			if (place[i].Chosen != 0)
				continue;
			if (strcmp(place[i].Id,place[curcase].Id) > 0)
			{
				bval = i;
				break;
			}
			if (strcmp(place[i].Id,place[curcase].Id) != 0)
				continue;	            
			if (place[i].Flip == 0)
			{
				if ((place[i].Frlong == curX) && (place[i].Frlat == curY))
				{                          
		
					Get_Shape_Points(place[i].Tlid,place[i].Flip);
					Pts[Npts].Longitude = place[i].Tolong;
					Pts[Npts].Latitude = place[i].Tolat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					place[i].Chosen = 1;            
					found = 1;                      
					curX = place[i].Tolong;
					curY = place[i].Tolat;                
					curcase = i;
					break;
				}
			}
			else
			{
				if ((place[i].Tolong == curX) && (place[i].Tolat == curY))
				{
					Get_Shape_Points(place[i].Tlid,place[i].Flip);
					Pts[Npts].Longitude = place[i].Frlong;
					Pts[Npts].Latitude = place[i].Frlat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = place[i].Frlong;
					curY = place[i].Frlat;                        
					place[i].Chosen = 1;	
					found = 1;          
					curcase = i;
					break;
				}
			}
        }//close for loop
		if (found == 0) //initialize new case, eg, new ring or new poly
		{			
			fwrite(&ptcount,sizeof(int),1,headtemp);
			ptcount = 0;
			while (bval > 1)
			{
				if (strcmp(place[bval].Id, place[curcase].Id) >= 0)
					bval--;
				else
					break;			
			}
			for (i = bval; i < written; i++) //check for new ring in poly
            {                    
         		if (place[i].Chosen != 0)
					continue;             		
				if (strcmp(place[i].Id, place[curcase].Id) > 0)
					break;
				if (strcmp(place[i].Id, place[curcase].Id) != 0)
					continue;
				//if we get here it is a new ring in current poly
				found = 1;
				nparts++;
				Npts = 0;
				if (place[i].Flip == 0)
				{
					Pts[Npts].Longitude = place[i].Frlong;
					Pts[Npts].Latitude = place[i].Frlat;
					Npts++;
					Get_Shape_Points(place[i].Tlid,place[i].Flip);
					Pts[Npts].Longitude = place[i].Tolong;
					Pts[Npts].Latitude = place[i].Tolat;
					Npts++;			
    				n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					place[i].Chosen = 1;
    		   		curX = place[i].Tolong;
    				curY = place[i].Tolat;
					curcase = i;
					break;
				}
				else
				{
					Pts[Npts].Longitude = place[i].Tolong;
					Pts[Npts].Latitude = place[i].Tolat;
					Npts++;
					Get_Shape_Points(place[i].Tlid,place[i].Flip);
					Pts[Npts].Longitude = place[i].Frlong;
					Pts[Npts].Latitude = place[i].Frlat;
					Npts++;			
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					place[i].Chosen = 1;
    		   		curX = place[i].Frlong;
    				curY = place[i].Frlat;
					curcase = i;
					break;
				}
    		}
    	}
		if (found == 0) // new poly, first ring
		{
			
			fwrite(&nparts,sizeof(int),1,partstemp);
			nparts = 1;
			fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
			CurrentMinX = CurrentMinY = LARGE;
			CurrentMaxX = CurrentMaxY = -LARGE;
			while (bval > 1)
			{
				if (strcmp(place[bval].Id, place[curcase].Id) >= 0)
					bval--;
				else
					break;			
			}
			for (i = bval; i < written; i++)//first check for new ring in current poly
            {                    
         		if (place[i].Chosen != 0)
					continue;             
				polyid++;
				uanum = -1;
				placename = Get_TypeC_Name2(7,place[i].Id,"",DATAYR);
				if (uanum < 0)
				{
					pdc = ' ';
					entity = ' ';
					strncpy(lsadc,"  ",2);
					strncpy(fipscc,"  ",2);
				}
				else
				{					
					entity = TypeCs[uanum].Entity;
					strncpy(lsadc,TypeCs[uanum].Lsadc,2);
					strncpy(fipscc,TypeCs[uanum].Fipscc,2);
					pdc = TypeCs[uanum].Placedc;
				}
				sprintf(placerecord," %8d",polyid+curpolys);
				sprintf(&placerecord[9],"%-5s",place[i].County);
				sprintf(&placerecord[14],"%-5s",place[i].Id);
				sprintf(&placerecord[19],"%-60s",placename);				
				sprintf(&placerecord[79],"%-2s",lsadc);
				sprintf(&placerecord[81],"%c",entity);
				sprintf(&placerecord[82],"%-2s",fipscc);
				sprintf(&placerecord[84],"%c",pdc);
	
				fwrite(&placerecord,sizeof(placerecord)-1,1,dbftmp);    		
				Npts = 0;
				if (place[i].Flip == 0)
				{
					Pts[Npts].Longitude = place[i].Frlong;
					Pts[Npts].Latitude = place[i].Frlat;
					Npts++;
					Get_Shape_Points(place[i].Tlid,place[i].Flip);
					Pts[Npts].Longitude = place[i].Tolong;
					Pts[Npts].Latitude = place[i].Tolat;
					Npts++;					
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					place[i].Chosen = 1;            
					found = 1;                      
					curX = place[i].Tolong;
					curY = place[i].Tolat;                
					curcase = i;
					break;					
				}
				else
				{
					Pts[Npts].Longitude = place[i].Tolong;
					Pts[Npts].Latitude = place[i].Tolat;
					Npts++;
					Get_Shape_Points(place[i].Tlid,place[i].Flip);
					Pts[Npts].Longitude = place[i].Frlong;
					Pts[Npts].Latitude = place[i].Frlat;
					Npts++;				
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = place[i].Frlong;
					curY = place[i].Frlat;                        
					place[i].Chosen = 1;		
					found = 1;          
					curcase = i;	
					break;					
				}	
			}
		}
		//by now found should be 1
		if (found == 0)
		{
			info.Format("ERROR - found is zero");
			Ptrdlg->ErrorMessage(info);									
			MissingFile = -1;
			return;
		}
		ptcount += Npts;
		fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
		if (Pts[0].Longitude < CurrentMinX)
			CurrentMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < CurrentMinY)
			CurrentMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[0].Latitude;	
		if (Pts[0].Longitude < FileMinX)
			FileMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > FileMaxX)
			FileMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < FileMinY)
			FileMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > FileMaxY)
			FileMaxY = Pts[0].Latitude;

		if (Pts[Npts-1].Longitude < CurrentMinX)
			CurrentMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < CurrentMinY)
			CurrentMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[Npts-1].Latitude;	
		if (Pts[Npts-1].Longitude < FileMinX)
			FileMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > FileMaxX)
			FileMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < FileMinY)
			FileMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > FileMaxY)
			FileMaxY = Pts[Npts-1].Latitude;		
	}//close while loop
	fwrite(&ptcount,sizeof(int),1,headtemp);
	fwrite(&nparts,sizeof(int),1,partstemp);
	fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
	fclose(boxtemp);
	fclose(headtemp);
	fclose(ptstemp);
	fclose(partstemp);
	fclose(dbftmp);
	
	polyid = Build_Poly_Shape2("urbcu",dbUrb00,sizeof(placerecord)-1);
	free(place);
	
	Ptrdlg->m_strProcess.Format("");		
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	Ptrdlg->m_Progress.SetPos(0);		
	Ptrdlg->m_strLayer.Format("");		
	Ptrdlg->SetDlgItemText(IDC_LAYER,Ptrdlg->m_strLayer);
}


--------cut from old
----
{
	int polyid, found, i, nparts, ptcount;
	long num, n, written, curcase;
	Urban_Border_Type *urb;
	double  curX, curY;	
    FILE  *dbftmp, *ptstemp, *headtemp, *partstemp, *boxtemp, *shxtemp; 
	FILE *checkit;
	CString info, fname, errmsg, trimname, urbtype;	
	char urbrecord[86]; //size of dbrecord + 2
	int steppos;
	char * urbname; 
	int doleft, doright;
	int bval;
	int curpolys;
	CString leftval, rightval;
	int test;
	char pdc, entity, fipscc[3],lsadc[3];
	if (APolycounts[28] == 0)
	{
		fprintf(LOG,"There are no UA Current records\n");
		return;
	}
	Ptrdlg->m_strProcess.Format("");		
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	Ptrdlg->m_Progress.SetPos(0);		
	Ptrdlg->m_strLayer.Format("");		
	Ptrdlg->SetDlgItemText(IDC_LAYER,Ptrdlg->m_strLayer);
	checkit=fopen("case.txt","w");
	dbftmp = fopen("dbf.tmp","wb");
	if (dbftmp == NULL)
	{
		errmsg.Format("Could not open file dbf.tmp");
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}

	ptstemp = fopen("pts.tmp","wb");
	if (ptstemp == NULL)
	{
		errmsg.Format("Could not open file pts.tmp");
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	headtemp = fopen("head.tmp","wb");
	if (headtemp == NULL)
	{
		errmsg.Format("Could not open file head.tmp");
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	boxtemp = fopen("box.tmp","wb");
	if (boxtemp == NULL)
	{
		errmsg.Format("Could not open file box.tmp");
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	partstemp = fopen("parts.tmp","wb");
	if (partstemp == NULL)
	{
		errmsg.Format("Could not open file parts.tmp");
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	urb = (Urban_Border_Type *)calloc(APolycounts[28]+Watercut*SPolycounts[0],sizeof(Urban_Border_Type));	
//	urb = (Urban_Border_Type *)calloc(AllACount+Watercut*SPolycounts[0],sizeof(Urban_Border_Type));	
	written = 0;
	Ptrdlg->m_strLayer.Format("Urban Areas Current");
	Ptrdlg->SetDlgItemText(IDC_LAYER,Ptrdlg->m_strLayer);
	int aindexl, aindexr, sindexl, sindexr;
	
	for (num = 0; num < CountI; num++)
	{
	
		steppos = (int) (num * 100/CountI);
		Ptrdlg->m_Progress.SetPos(steppos);		

		strcpy(TypeIAs.Uacul,"     ");
		strcpy(TypeIAs.Uacur,"     ");
		strcpy(TypeIAs.Countycul,"     ");
		strcpy(TypeIAs.Countycur,"     ");
		TypeISs.Waterl = 0;
		TypeISs.Waterr = 0;
		sindexl = TypeISIndex[num].indexl;
		sindexr = TypeISIndex[num].indexr;
		aindexl = TypeIAIndex[num].indexl;
		aindexr = TypeIAIndex[num].indexr;
		rightval = leftval = "";
		
		test = 0;
		if (aindexl >= 0)
		{
			fseek(atemp,(long)aindexl*sizeof(RecordTypeA),0);
			if (fread(&TypeAs,sizeof(RecordTypeA),1,atemp) != 1)
				{
					errmsg.Format("\nCannot read from temp file");
					Ptrdlg->ErrorMessage(errmsg);
					MissingFile = -1; return;			
				}
			sprintf(TypeIAs.Uacul,"%5s",TypeAs.Uacu);
			sprintf(TypeIAs.Countycul,"%2s%3s",TypeAs.Statecu,TypeAs.Countycu);
			leftval.Format("%s%s",TypeIAs.Countycul, TypeIAs.Uacul);
		}
		if (aindexr >= 0)
		{
			fseek(atemp,(long)aindexr*sizeof(RecordTypeA),0);
			if (fread(&TypeAs,sizeof(RecordTypeA),1,atemp) != 1)
				{
					errmsg.Format("\nCannot read from temp file");
					Ptrdlg->ErrorMessage(errmsg);
					MissingFile = -1; return;			
				} 
			sprintf(TypeIAs.Uacur,"%5s",TypeAs.Uacu);		
			sprintf(TypeIAs.Countycur,"%2s%3s",TypeAs.Statecu,TypeAs.Countycu);
			rightval.Format("%s%s",TypeIAs.Countycur, TypeIAs.Uacur);
		}
/*	if (aindexl == 2041)
	{
		test = 1;
		AfxMessageBox(leftval);
		AfxMessageBox(rightval);
	}*/
		if (sindexl >= 0)
			TypeISs.Waterl = TypePs[Get_PIndex(TypeIs[num].Cenidl, TypeIs[num].Polyidl)].Water;		
		if (sindexr >= 0)
			TypeISs.Waterr = TypePs[Get_PIndex(TypeIs[num].Cenidr, TypeIs[num].Polyidr)].Water;	
		/*if (strcmp(TypeIs[num].Tlid,"  42609693") == 0)
		{
			AfxMessageBox(TypeIAs.Uacul);
			AfxMessageBox(TypeIAs.Uacur);
			AfxMessageBox(TypeIAs.Countycul);
			AfxMessageBox(TypeIAs.Countycur);
			AfxMessageBox(Type1s[num].Countyl);
			AfxMessageBox(Type1s[num].Countyr);
			CString rep;
			rep.Format("left = %d, right = %d",aindexl, aindexr);
			AfxMessageBox(rep);
			AfxMessageBox(leftval);
			AfxMessageBox(rightval);
			test = 1;
		}
*/
		//if (strcmp(TypeIAs.Uacul,TypeIAs.Uacur)== 0)
		if (leftval == rightval)
		{
			if (Watercut)
			{

				if (TypeISs.Waterl == TypeISs.Waterr)
					continue;
				if (abs(TypeISs.Waterl - TypeISs.Waterr) > 1)
					continue;
			}
			else
				continue;		
		}
		doleft = 0;	
		if ((strcmp(TypeIAs.Uacul,"     ") != 0) &&
		//if (leftval != rightval) &&
		((sindexl >= 0) || (aindexl >= 0)))
		{//left case	
			if (Watercut)
			{

				if(TypeISs.Waterl != 1)
					doleft = 1;
			}
			else
				doleft = 1;
			if (doleft)
			{
			/*	if (test == 1)
				{
					AfxMessageBox("writing case");
					
				}*/
				sprintf(urb[written].County,"%s",TypeIAs.Countycul);
				sprintf(urb[written].Uacode,"%-5s",TypeIAs.Uacul);				
				sprintf(urb[written].Tlid,"%s",TypeIs[num].Tlid);
				urb[written].Frlong = Type1s[num].Frlong;
				urb[written].Frlat = Type1s[num].Frlat;
				urb[written].Tolong = Type1s[num].Tolong;
				urb[written].Tolat = Type1s[num].Tolat;
				urb[written].Chosen = 0;
				urb[written].Flip = 1;
			/*	if (test == 1)
				{
					fprintf(checkit,"%d %s\n",written, urb[written].Tlid);
					test = 0;
				}*/
				written++;
			}
		}
		doright = 0;			
		if ((strcmp(TypeIAs.Uacur, "     ") != 0) &&
			((sindexr >= 0) || (aindexr >= 0)))
		{//rightcase 
			
			if (Watercut)
			{
				if(TypeISs.Waterr != 1)
					doright = 1;
			}
			else
				doright = 1;
			if (doright)
			{
				sprintf(urb[written].County,"%s",TypeIAs.Countycur);				
				sprintf(urb[written].Uacode,"%-5s",TypeIAs.Uacur);				
				sprintf(urb[written].Tlid,"%s",TypeIs[num].Tlid);				
				urb[written].Frlong = Type1s[num].Frlong;
				urb[written].Frlat = Type1s[num].Frlat;
				urb[written].Tolong = Type1s[num].Tolong;
				urb[written].Tolat = Type1s[num].Tolat;
				urb[written].Chosen = 0;
				urb[written].Flip = 0;
				//fprintf(checkit,"%d %s\n",written, urb[written].Tlid);
				written++;

			}
		}
	}	
	if (written >= APolycounts[28]+Watercut*SPolycounts[0])
	{
		Ptrdlg->ErrorMessage("the number of Urban Current border lines exceeds the count");				
		MissingFile = -1;
		return;
	}
	
	if (written == 0)
	{
		if (!Watercut)
			fprintf(LOG,"There are no lines for Urban Current polygons\n");
		else
		{
			fprintf(LOG,"All Urban Current polygons for this county coincide with water polygons\n");
			fprintf(LOG,"Try turning off the water polygon clipping option\n");
		}
		
		fclose(boxtemp);
		fclose(ptstemp);
		fclose(headtemp);
		fclose(partstemp);	
		fclose(dbftmp);
		unlink("box.tmp");
		unlink("pts.tmp");
		unlink("head.tmp");
		unlink("parts.tmp");
		unlink("dbf.tmp");
		return;
	}
	
	//time to chain		
	Ptrdlg->m_strProcess.Format("Gathering Current Urban Boundary Lines");
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	qsort((void *)urb,written,sizeof(Urban_Border_Type),(compfn)CompareUrb);	
	FileMinX = FileMinY = LARGE;
	FileMaxX = FileMaxY = -LARGE;
	CurrentMinX = CurrentMinY = LARGE;
	CurrentMaxX = CurrentMaxY = -LARGE;
		//start version 4.1 insert
	CurNumElements = 0;
	char tempchar;
	CString type, type2;
	CString curval, testval;
	type = "urbcu";
	type2 = "urban";
	
	switch (OutOption)
	{
	case '0': //by county
	case '1': //all in one
		//as is
		Curfilepath = Outfilepath;
		Curfilepolyname.Format("%s%s",Outfiletitle,type);			
		break;
	case '2': //by theme
		Curdirname = type2; 
		Curfilepath.Format("%s%s\\",Outfilepath,Curdirname); 
		result = _mkdir(Curfilepath);
		if (result == 0)
			fprintf(LOG,"directory %s created\n",Curfilepath);
		else
			fprintf(LOG,"directory %s not created\n", Curfilepath);		
		Curfilepolyname.Format("%s%s",Outfiletitle,type);			
		break;
	case '3':
		Curdirname = type2; 
		Curfilepath.Format("%s%s\\",Outfilepath,Curdirname); 
		result = _mkdir(Curfilepath);
		if (result == 0)
			fprintf(LOG,"directory %s created\n",Curfilepath);
		else
			fprintf(LOG,"directory %s not created\n", Curfilepath);
		Curfilepolyname = type; 			
		result = _mkdir(Curfilepath);
		if (result == 0)
			fprintf(LOG,"directory %s created\n",Curfilepath);
		else
			fprintf(LOG,"directory %s not created\n", Curfilepath);	
		fname.Format("%s%s.shx",Curfilepath, Curfilepolyname); 		
		shxtemp = fopen(fname,"r+b");
		if (shxtemp != NULL)
		{
			rewind(shxtemp);
			if (fread(&tempchar,sizeof(char),1,shxtemp) == 1)	
			{			
				GetFileStats(shxtemp); //this will rest fileminx, miny etc.										
				if (MissingFile == -1) return;
				fclose(shxtemp);
			}
		}
		break;
	}
	curpolys = CurNumElements;
	//end version 4.1 reading insert

	curcase = 0;
	polyid = 1;
	Npts = 0; 
	nparts = 1;
	ptcount = 0;
	sprintf(urbrecord," %8d",polyid+curpolys);
	sprintf(&urbrecord[9],"%-5s",urb[curcase].County);
	sprintf(&urbrecord[14],"%-5s",urb[curcase].Uacode);
	uanum = -1;
	urbname = Get_TypeC_Name2(7,urb[curcase].Uacode,"", DATAYR);
	if (uanum < 0)
	{
		pdc = ' ';
		entity = ' ';
		strncpy(lsadc,"  ",2);
		strncpy(fipscc,"  ",2);
	}
	else
	{
		pdc = TypeCs[uanum].Placedc;
		entity = TypeCs[uanum].Entity;
		strncpy(lsadc,TypeCs[uanum].Lsadc,2);
		strncpy(fipscc,TypeCs[uanum].Fipscc,2);
	}
	
	trimname.Format("%s",urbname);
	trimname.TrimRight();
	sprintf(&urbrecord[19],"%-60s",trimname);
	sprintf(&urbrecord[79],"%2s",lsadc);
	sprintf(&urbrecord[81],"%c",entity);
	sprintf(&urbrecord[82],"%2s",fipscc);
	sprintf(&urbrecord[84],"%c",pdc);
	fwrite(&urbrecord,sizeof(urbrecord)-1,1,dbftmp);
	if (urb[0].Flip == 0)
	{
		curX = urb[0].Tolong;
		curY = urb[0].Tolat;		
		Pts[Npts].Longitude = urb[curcase].Frlong;
		Pts[Npts].Latitude = urb[curcase].Frlat;
		Npts++;
		Get_Shape_Points(urb[curcase].Tlid, urb[curcase].Flip);
		Pts[Npts].Longitude = urb[curcase].Tolong;
		Pts[Npts].Latitude = urb[curcase].Tolat;
		Npts++;
		urb[curcase].Chosen = 1;		
	}
	else
	{
		curX = urb[0].Frlong;
		curY = urb[0].Frlat;		
		Pts[Npts].Longitude = urb[curcase].Tolong;
		Pts[Npts].Latitude = urb[curcase].Tolat;
		Npts++;
		Get_Shape_Points(urb[curcase].Tlid, urb[curcase].Flip);
		Pts[Npts].Longitude = urb[curcase].Frlong;
		Pts[Npts].Latitude = urb[curcase].Frlat;
		Npts++;
		urb[curcase].Chosen = 1;		
	}
	ptcount += Npts;
/*		AfxMessageBox("writing");
	fprintf(checkit,"%s\n %.6lf %.6lf\n %.6lf %.6lf\n",
		urb[curcase].Tlid, Pts[0].Longitude, Pts[0].Latitude,Pts[Npts-1].Longitude, Pts[Npts-1].Latitude);
 */
   fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);

	if (Pts[0].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < CurrentMinY)
		CurrentMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[0].Latitude;	
	if (Pts[0].Longitude < FileMinX)
		FileMinX = Pts[0].Longitude;
	if (Pts[0].Longitude > FileMaxX)
		FileMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < FileMinY)
		FileMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > FileMaxY)
		FileMaxY = Pts[0].Latitude;

	if (Pts[Npts-1].Longitude < CurrentMinX)
		CurrentMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < CurrentMinY)
		CurrentMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[Npts-1].Latitude;	
	if (Pts[Npts-1].Longitude < FileMinX)
		FileMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > FileMaxX)
		FileMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < FileMinY)
		FileMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > FileMaxY)
		FileMaxY = Pts[Npts-1].Latitude;		
	n = 1;
	steppos = (int)(n*100/written);	
	Ptrdlg->m_Progress.SetPos(steppos);
	bval = 1;
    while (n < written)
		{		
		found = 0;
		curval.Format("%5s%5s",urb[curcase].County, urb[curcase].Uacode);
		while (bval > 1)
		{
		testval.Format(	"%5s%5s",urb[bval].County, urb[bval].Uacode);
		//if (strcmp(urb[bval].Uacode,urb[curcase].Uacode) >= 0)
		if (testval > curval)
				bval--;
			else
				break;			
		}
		for (i = bval; i < written; i++)
         {
			Npts = 0;
			if (urb[i].Chosen != 0)
				continue;
			testval.Format(	"%5s%5s",urb[i].County, urb[i].Uacode);
			//if (strcmp(urb[i].Uacode,urb[curcase].Uacode) > 0)
			if (testval > curval)
			{
				bval = i;
				break;
			}
			//if (strcmp(urb[i].Uacode,urb[curcase].Uacode) != 0)
			if (testval != curval)
				continue;	            
			if (urb[i].Flip == 0)
			{
				if ((urb[i].Frlong == curX) && (urb[i].Frlat == curY))
				{                          
					if (strcmp(urb[i].Uacode,urb[curcase].Uacode) != 0)
						continue;	            
					Get_Shape_Points(urb[i].Tlid,urb[i].Flip);
					Pts[Npts].Longitude = urb[i].Tolong;
					Pts[Npts].Latitude = urb[i].Tolat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					urb[i].Chosen = 1;            
					found = 1;                      
					curX = urb[i].Tolong;
					curY = urb[i].Tolat;                
					curcase = i;
					break;
				}
			}
			else
			{
				if ((urb[i].Tolong == curX) && (urb[i].Tolat == curY))
				{
					Get_Shape_Points(urb[i].Tlid,urb[i].Flip);
					Pts[Npts].Longitude = urb[i].Frlong;
					Pts[Npts].Latitude = urb[i].Frlat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = urb[i].Frlong;
					curY = urb[i].Frlat;                        
					urb[i].Chosen = 1;	
					found = 1;          
					curcase = i;
					break;
				}
			}
        }//close for loop
		if (found == 0) //initialize new case, eg, new ring or new poly
		{			
			fwrite(&ptcount,sizeof(int),1,headtemp);
			ptcount = 0;
			while (bval > 1)
			{
				testval.Format("%5s%5s", urb[bval].County,urb[bval].Uacode);
			//if (strcmp(urb[bval].Uacode,urb[curcase].Uacode) >= 0)
				if (testval >= curval)
					bval--;
				else
					break;			
			}
			for (i = bval; i < written; i++) //check for new ring in poly
            {                    
         		if (urb[i].Chosen != 0)
					continue;    
				testval.Format("%5s%5s", urb[i].County,urb[i].Uacode);
				//if (strcmp(urb[i].Uacode,urb[curcase].Uacode) > 0)
				if (testval > curval)
					break;
				//if (strcmp(urb[i].Uacode,urb[curcase].Uacode) != 0)
				if (testval != curval)
					continue;	            
				//if we get here it is a new ring in current poly
				found = 1;
				nparts++;
				Npts = 0;
				if (urb[i].Flip == 0)
				{
					Pts[Npts].Longitude = urb[i].Frlong;
					Pts[Npts].Latitude = urb[i].Frlat;
					Npts++;
					Get_Shape_Points(urb[i].Tlid,urb[i].Flip);
					Pts[Npts].Longitude = urb[i].Tolong;
					Pts[Npts].Latitude = urb[i].Tolat;
					Npts++;			
    				n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					urb[i].Chosen = 1;
    		   		curX = urb[i].Tolong;
    				curY = urb[i].Tolat;
					curcase = i;
					break;
				}
				else
				{
					Pts[Npts].Longitude = urb[i].Tolong;
					Pts[Npts].Latitude = urb[i].Tolat;
					Npts++;
					Get_Shape_Points(urb[i].Tlid,urb[i].Flip);
					Pts[Npts].Longitude = urb[i].Frlong;
					Pts[Npts].Latitude = urb[i].Frlat;
					Npts++;			
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					urb[i].Chosen = 1;
    		   		curX = urb[i].Frlong;
    				curY = urb[i].Frlat;
					curcase = i;
					break;
				}
    		}
    	}
		if (found == 0) // new poly, first ring
		{
			
			fwrite(&nparts,sizeof(int),1,partstemp);
			nparts = 1;
			fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
			CurrentMinX = CurrentMinY = LARGE;
			CurrentMaxX = CurrentMaxY = -LARGE;
			while (bval > 1)
			{
				testval.Format("%5s%5s",urb[bval].County, urb[bval].Uacode);				
				if (testval >= curval)
				//if (strcmp(urb[bval].Uacode,urb[curcase].Uacode) >= 0)
					bval--;
				else
					break;			
			}
			for (i = bval; i < written; i++)//first check for new ring in current poly
            {                    
         		if (urb[i].Chosen != 0)
					continue;             
				polyid++;
				sprintf(urbrecord," %8d",polyid+curpolys);
				sprintf(&urbrecord[9],"%-5s",urb[i].County);
				sprintf(&urbrecord[14],"%-5s",urb[i].Uacode);
				uanum = -1;
				urbname = Get_TypeC_Name2(7,urb[i].Uacode,"",DATAYR);				
				if (uanum < 0)
				{
					pdc = ' ';
					entity = ' ';
					strncpy(lsadc,"  ",2);
					strncpy(fipscc,"  ",2);
				}
				else
				{
					pdc = TypeCs[uanum].Placedc;
					entity = TypeCs[uanum].Entity;
					strncpy(lsadc,TypeCs[uanum].Lsadc,2);
					strncpy(fipscc,TypeCs[uanum].Fipscc,2);
				}
	
				trimname.Format("%s",urbname);
				trimname.TrimRight();
				sprintf(&urbrecord[19],"%-60s",trimname);
				sprintf(&urbrecord[79],"%2s",lsadc);
				sprintf(&urbrecord[81],"%c",entity);
				sprintf(&urbrecord[82],"%2s",fipscc);
				sprintf(&urbrecord[84],"%c",pdc);
				fwrite(&urbrecord,sizeof(urbrecord)-1,1,dbftmp);    		
				Npts = 0;
				if (urb[i].Flip == 0)
				{
					Pts[Npts].Longitude = urb[i].Frlong;
					Pts[Npts].Latitude = urb[i].Frlat;
					Npts++;
					Get_Shape_Points(urb[i].Tlid,urb[i].Flip);
					Pts[Npts].Longitude = urb[i].Tolong;
					Pts[Npts].Latitude = urb[i].Tolat;
					Npts++;					
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					urb[i].Chosen = 1;            
					found = 1;                      
					curX = urb[i].Tolong;
					curY = urb[i].Tolat;                
					curcase = i;
					break;					
				}
				else
				{
					Pts[Npts].Longitude = urb[i].Tolong;
					Pts[Npts].Latitude = urb[i].Tolat;
					Npts++;
					Get_Shape_Points(urb[i].Tlid,urb[i].Flip);
					Pts[Npts].Longitude = urb[i].Frlong;
					Pts[Npts].Latitude = urb[i].Frlat;
					Npts++;				
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = urb[i].Frlong;
					curY = urb[i].Frlat;                        
					urb[i].Chosen = 1;		
					found = 1;          
					curcase = i;	
					break;					
				}	
			}
		}
		//by now found should be 1
		if (found == 0)
		{
			info.Format("ERROR - found is zero");
			Ptrdlg->ErrorMessage(info);									
			MissingFile = -1;
			return;
		}
		ptcount += Npts;
		fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
		/*fprintf(checkit,"%s\n %lf %lf\n %lf %lf\n",
			urb[curcase].Tlid, Pts[0].Longitude, Pts[0].Latitude,Pts[Npts-1].Longitude, Pts[Npts-1].Latitude);*/
		if (Pts[0].Longitude < CurrentMinX)
			CurrentMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < CurrentMinY)
			CurrentMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[0].Latitude;	
		if (Pts[0].Longitude < FileMinX)
			FileMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > FileMaxX)
			FileMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < FileMinY)
			FileMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > FileMaxY)
			FileMaxY = Pts[0].Latitude;

		if (Pts[Npts-1].Longitude < CurrentMinX)
			CurrentMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < CurrentMinY)
			CurrentMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[Npts-1].Latitude;	
		if (Pts[Npts-1].Longitude < FileMinX)
			FileMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > FileMaxX)
			FileMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < FileMinY)
			FileMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > FileMaxY)
			FileMaxY = Pts[Npts-1].Latitude;		
	}
	//close while loop
	fwrite(&ptcount,sizeof(int),1,headtemp);
	fwrite(&nparts,sizeof(int),1,partstemp);
	fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
	fclose(boxtemp);
	fclose(headtemp);
	fclose(ptstemp);
	fclose(partstemp);
	fclose(dbftmp);
	//fclose(checkit);
	polyid = Build_Poly_Shape2("urbcu",dbUrb00,sizeof(urbrecord)-1);
	free(urb);	
	
	Ptrdlg->m_strProcess.Format("");		
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	Ptrdlg->m_Progress.SetPos(0);		
	Ptrdlg->m_strLayer.Format("");		
	Ptrdlg->SetDlgItemText(IDC_LAYER,Ptrdlg->m_strLayer);
}
-----
