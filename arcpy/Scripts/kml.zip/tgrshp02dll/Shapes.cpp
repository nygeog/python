/* shapes.cpp
This file was written with the help of Dr. Cheng Liu 
*/
#include <math.h>
#include <limits.h>
#include <malloc.h>
#include <stdlib.h>
#include <string.h>
#include "StdAfx.h"
#include "tgrshp2.h"
#include "mydlldlg.h"
#include "shape.h"
#include "msg.h"

char                  buf[1024];
int Position,IPosition;
int Size;

typedef unsigned char uchar;

#if UINT_MAX == 65535
typedef long          int32;
#else
typedef int           int32;
#endif

#ifndef FALSE
#  define FALSE         0
#  define TRUE          1
#endif

#define ByteCopy( a, b, c )     memcpy( b, a, c )
#ifndef MAX
#  define MIN(a,b)      ((a<b) ? a : b)
#  define MAX(a,b)      ((a>b) ? a : b)
#endif

int Debug = 0;



static int      BigEndian = 0; /*was 1*/
/*static int
SHP_Dump_Record_In_Hex (
	void*                   rec,
	int                     len);
*/

static void Memory_N_Copy (char*, char*, int, int);
void* SHP_Prepare_Header (shape_header_t*);
int SHP_Write_Header (FILE*, shape_header_t*);
void* SHP_Prepare_Record_Header (shape_record_header_t*);
static void* SHP_Prepare_Arc (shape_arc_t* );
int SHP_Write_Arc(FILE*,shape_arc_t *);
int SHP_Calculate_Record_Size (int shapeType,void* );
static void* SHP_Prepare_Index (shape_index_record_t* );
int SHP_Write_Index(FILE*, shape_index_record_t* );
shape_header_t * Create_Shape_Header(int);
int SHP_Write_Record_Header (FILE* , shape_record_header_t* );
//void Error_Message(char *);
int SHP_Write_Point(FILE *, shape_point_t *);
static void * SHP_Prepare_Point(shape_point_t *);
static void * SHP_Prepare_Poly(shape_poly_t *);
int SHP_Write_Poly(FILE *, shape_poly_t *);

void* SHP_Prepare_Header (shape_header_t* h)
{
	void*                   rec;
	if (h == NULL)
		return ((void*) NULL);

	if ((rec = (void*) calloc (1, SHPHEADERSIZE)) == NULL)
	{
		ErrorMessage ("Error: malloc Header (SHP_Prepare_Header)\n");
		return ((void*) NULL);
	}
	h->fileLen /= 2;
	Memory_N_Copy (&((char *) rec)[0],  (char *) &h->fileCode, 4, BIG);
	Memory_N_Copy (&((char *) rec)[24], (char *) &h->fileLen, 4, BIG);
	Memory_N_Copy (&((char *) rec)[28], (char *) &h->version, 4, LITTLE);
	Memory_N_Copy (&((char *) rec)[32], (char *) &h->shapeType, 4, LITTLE);

	Memory_N_Copy (&((char *) rec)[36], (char *) &h->xMin, 8, LITTLE);
	Memory_N_Copy (&((char *) rec)[44], (char *) &h->yMin, 8, LITTLE);
	Memory_N_Copy (&((char *) rec)[52], (char *) &h->xMax, 8, LITTLE);
	Memory_N_Copy (&((char *) rec)[60], (char *) &h->yMax, 8, LITTLE);

	return (rec);
}

int SHP_Write_Header (FILE* fp, shape_header_t* h)
{
	void*                   rec;
	int                     numWritten;
	int                     rtnCode;

	rec = SHP_Prepare_Header (h);

	if (Debug)
	{
		ErrorMessage("ERROR in Write header record\n");
		/*SHP_Dump_Record_In_Hex (rec, SHPHEADERSIZE);*/
	}
	if ((rtnCode = fseek (fp, 0L, 0)) != 0)
	{
		sprintf (buf, "ERROR: rtnCode = %d (SHP_Write_Header)\n", rtnCode);
		ErrorMessageStop (buf);
		return (-1);
	}
	numWritten = fwrite ( (char *) rec, SHPHEADERSIZE, 1, fp );
	if (numWritten != 1)
	{
		sprintf (buf, "Error: numWritten = %d\n", numWritten);
		ErrorMessageStop (buf);
		return (-1);
	}
	free (rec);
	return (0);
}
static void Memory_N_Copy (char* to,char* from,int length,int order)
{
	int             i;
	uchar           temp;

	memcpy (to, from, length);
	if (BigEndian != order)
	{
		for ( i = 0; i < length / 2; i++ )
		{
			temp = ((uchar *) to)[i];
			((uchar *) to)[i] = ((uchar *) to)[length-i-1];
			((uchar *) to)[length-i-1] = temp;
		}
	}
}
/*void Error_Message(char * buffer)
{
  //printf("\n ERROR");
  //printf("%s",buffer);
}
*/
int SHP_Write_Record_Header (FILE* fp, shape_record_header_t* h)
{
	void*                   rec;
	int                     numWritten;
//	int                     rtnCode;

	rec = SHP_Prepare_Record_Header (h);
	numWritten = fwrite ( (char *) rec, SHPRECHEADERSIZE, 1, fp );
	if (numWritten != 1)
	{
		sprintf (buf, "Error: numWritten in record header is = %d\n", numWritten);
		ErrorMessageStop (buf);
		return (-1);
	}
	free (rec);
	return (0);


}
void* SHP_Prepare_Record_Header (
	shape_record_header_t* h)
{
	void*                   rec;

	if (h == NULL)
		return ((void*) NULL);

	if ((rec = (void *) malloc (SHPRECHEADERSIZE)) == NULL)
	{
		ErrorMessageStop ("Error: malloc rec (SHP_Prepare_Record_Header)\n");
		return ((void*) NULL);
	}
	h->length /= 2;
	Memory_N_Copy (&((char*) rec)[0], (char *) &h->num,    4, BIG);
	Memory_N_Copy (&((char*) rec)[4], (char *) &h->length, 4, BIG);
	return (rec);
}
int SHP_Write_Arc(FILE* fp, shape_arc_t* h)
{
	void*                   rec;
	int                     numWritten;
//	int                     rtnCode;
//	int                     i;


	rec = SHP_Prepare_Arc(h);
	numWritten = fwrite ( (char *) rec, sizeof(char), Size, fp );
	Position = ftell(fp);
	if (numWritten != Size)
	{
		sprintf (buf, "Error: numWritten in record header is = %d\n", numWritten);
		ErrorMessageStop (buf);
		return (-1);
	}
	free (rec);
	return (0);


}
static void* SHP_Prepare_Arc (shape_arc_t* a)
{
	void*                   rec;
	int                     i;
	int                     pos;
	int                     recSize;


	if (a == NULL)
		return ((void*) NULL);

	Size = recSize = SHP_Calculate_Record_Size (SHP_ARC, a);
	if ((rec = (void *) malloc (recSize)) == NULL)
	{
		ErrorMessageStop ("Error: malloc arc (SHP_Prepare_Arc)\n");
		return ((void*) NULL);
	}
	Memory_N_Copy (&((char *) rec)[0],  (char *) &a->shapeType, 4, LITTLE);
	Memory_N_Copy (&((char *) rec)[4],  (char *) &a->xMin,      8, LITTLE);
	Memory_N_Copy (&((char *) rec)[12], (char *) &a->yMin,      8, LITTLE);
	Memory_N_Copy (&((char *) rec)[20], (char *) &a->xMax,      8, LITTLE);
	Memory_N_Copy (&((char *) rec)[28], (char *) &a->yMax,      8, LITTLE);
	Memory_N_Copy (&((char *) rec)[36], (char *) &a->numParts,  4, LITTLE);
	Memory_N_Copy (&((char *) rec)[40], (char *) &a->numPoints, 4, LITTLE);
	for (i = 0; i < a->numParts; i++)
	{
		Memory_N_Copy (&((char *) rec)[44 + i * 4],  (char *) &a->parts[i], 4, LITTLE);
	}
	for (i = 0; i < a->numPoints; i++)
	{
		pos = 44 + a->numParts * 4 + i * 16;		
		Memory_N_Copy (&((char *) rec)[pos],      (char *) &a->points[i].x, 8, LITTLE);
		Memory_N_Copy (&((char *) rec)[pos + 8],  (char *) &a->points[i].y, 8, LITTLE);
	}
	return (rec);
}

int SHP_Calculate_Record_Size (int shapeType,void* p)
{
	int             recSize;

	switch (shapeType)
	{
		case SHP_POINT:
			return (SHPPOINTSIZE);
		case SHP_ARC:
			recSize = sizeof (int) + sizeof (double) * 4 + sizeof (int) * 2 +
				  sizeof (int) * ((shape_arc_t*) p)->numParts +
				  sizeof (double) * 2 * ((shape_arc_t*) p)->numPoints;
			return (recSize);
		case SHP_POLYGON:
				recSize = sizeof (int) + sizeof (double) * 4 + sizeof (int) * 2 +
				  sizeof (int) * ((shape_poly_t*) p)->numParts +
				  sizeof (double) * 2 * ((shape_poly_t*) p)->numPoints;
				/*printf("calc size is %d, with %d pts and %d parts", recSize,
					((shape_poly_t *) p)->numPoints, ((shape_poly_t *)p)->numParts);*/
				return(recSize);				
		case SHP_MULTIPOINT:
			//Error_Message ("Not implement yet\n");
			return (1);
		default:
			sprintf (buf,"Unknown shapeType = %d\n", shapeType);
			ErrorMessage (buf);
			return (1);
	}
}
/*Index functions start here*/
int SHP_Write_Index(FILE* fp, shape_index_record_t* h)
{
	void*                   rec;
	int                     numWritten;
//	int                     rtnCode;

	rec = SHP_Prepare_Index(h);

	numWritten = fwrite ( (char *) rec, SHPINDEXSIZE, 1, fp );
	IPosition = ftell(fp);
	if (numWritten != 1)
	{
		sprintf (buf, "Error: numWritten in shp index is = %d\n", numWritten);
		ErrorMessage (buf);
		return (-1);
	}
	free (rec);

	return (0);


}

static void* SHP_Prepare_Index (shape_index_record_t*   x)
{
	void*           rec;

	if (x == NULL)
		return ((void*) NULL);

	if ((rec = (void *) malloc (SHPINDEXSIZE)) == NULL)
	{
		ErrorMessageStop ("Error: malloc point (SHP_Prepare_Index)\n");
		return ((void*) NULL);
	}
	x->offset /= 2;
	x->length /= 2;
	Memory_N_Copy (&((char *) rec)[0], (char *) &x->offset, 4, BIG);
	Memory_N_Copy (&((char *) rec)[4], (char *) &x->length, 4, BIG);
	return (rec);
}

shape_header_t * Create_Shape_Header(int type)
{
	shape_header_t *header;

	header = (shape_header_t *)calloc(1,sizeof(shape_header_t));
	header->fileCode = 9994;
	header->fileLen = 100;
	header->version = 1000;
	header->shapeType = type; 
	header->xMin = 0;
	header->xMax = 0;
	header->yMin = 0;
	header->yMax = 0;
	header->unUsed1 = header->unUsed2 = header->unUsed3 = header->unUsed4 =
	header->unUsed5 = header->unUsed6 = header->unUsed7 = header->unUsed8 =
	header->unUsed9 = header->unUsed10 = header->unUsed11 = header->unUsed12 =
	0;

	return(header);

}
/*point shapes */
static void* SHP_Prepare_Point (shape_point_t* p)
{
	void*                   rec;

	if (p == NULL)
		return ((void*) NULL);

	if ((rec = (void *) malloc (SHPPOINTSIZE)) == NULL)
	{
		ErrorMessageStop ("Error: malloc rec (SHP_Prepare_Point)\n");
		return ((void*) NULL);
	}
	Memory_N_Copy (&((char *) rec)[0],  (char *) &p->shapeType, 4, LITTLE);
	Memory_N_Copy (&((char *) rec)[4],  (char *) &p->x,         8, LITTLE);
	Memory_N_Copy (&((char *) rec)[12], (char *) &p->y,         8, LITTLE);
	return (rec);
}
int SHP_Write_Point(FILE* fp, shape_point_t* h)
{
	void*                   rec;
	int                     numWritten;
//	int                     rtnCode;
//	int                     i;

	Size = SHPPOINTSIZE;
	rec = SHP_Prepare_Point(h);
	numWritten = fwrite ( (char *) rec, sizeof(char), Size, fp );
	Position = ftell(fp);
	if (numWritten != Size)
	{
		sprintf (buf, "Error: numWritten in record header is = %d\n", numWritten);
		ErrorMessageStop (buf);
		return (-1);
	}
	free (rec);
	return (0);


}


int SHP_Write_Poly(FILE* fp, shape_poly_t* h)
{
	void*                   rec;
	int                     numWritten;
//	int                     rtnCode;
//	int                     i;


	rec = SHP_Prepare_Poly(h);
	numWritten = fwrite ( (char *) rec, sizeof(char), Size, fp );
	Position = ftell(fp);
	if (numWritten != Size)
	{
		sprintf (buf, "Error: numWritten in record header is = %d\n", numWritten);
		ErrorMessageStop (buf);
		return (-1);
	}
	free (rec);
	return (0);


}

static void* SHP_Prepare_Poly (shape_poly_t* a)
{
	void*                   rec;
	int                     i;
	int                     pos;
	int                     recSize;


	if (a == NULL)
		return ((void*) NULL);

	Size = recSize = SHP_Calculate_Record_Size (SHP_POLYGON, a);
	if ((rec = (void *) malloc (recSize)) == NULL)
	{
		ErrorMessageStop ("Error: malloc arc (SHP_Prepare_Poly)\n");
		return ((void*) NULL);
	}
	Memory_N_Copy (&((char *) rec)[0],  (char *) &a->shapeType, 4, LITTLE);
	Memory_N_Copy (&((char *) rec)[4],  (char *) &a->xMin,      8, LITTLE);
	Memory_N_Copy (&((char *) rec)[12], (char *) &a->yMin,      8, LITTLE);
	Memory_N_Copy (&((char *) rec)[20], (char *) &a->xMax,      8, LITTLE);
	Memory_N_Copy (&((char *) rec)[28], (char *) &a->yMax,      8, LITTLE);
	Memory_N_Copy (&((char *) rec)[36], (char *) &a->numParts,  4, LITTLE);
	Memory_N_Copy (&((char *) rec)[40], (char *) &a->numPoints, 4, LITTLE);
	for (i = 0; i < a->numParts; i++)
	{
		Memory_N_Copy (&((char *) rec)[44 + i * 4],  (char *) &a->parts[i], 4, LITTLE);
	}
	for (i = 0; i < a->numPoints; i++)
	{
		pos = 44 + a->numParts * 4 + i * 16;		
		Memory_N_Copy (&((char *) rec)[pos],      (char *) &a->points[i].x, 8, LITTLE);
		Memory_N_Copy (&((char *) rec)[pos + 8],  (char *) &a->points[i].y, 8, LITTLE);
	}
	return (rec);
}
void ErrorMessage(char *s)
{
	AfxMessageBox(s);
}
void ErrorMessageStop(char *s)
{
	AfxMessageBox(s);
	abort();
	//return(1);
}
