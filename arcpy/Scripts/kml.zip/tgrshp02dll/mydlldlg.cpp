/* mydlldlg.cpp : implementation file
Written by Bruce Ralston
This file manages the only dialog in the dll
*/

#include "stdafx.h"
#include "tgrshp2.h"
#include "mydlldlg.h"
#include <direct.h>
#include <windows.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#define XcdErrorNothingToDo 140
extern FILE *LOG;
//variable declarations
extern int TigerVersion;

extern CString Outfiletitle;
extern CString Outdir;
extern void ProcessTiger(mydlldlg *);
CString Zipdirectory;
int Unlinkthem;
extern int IsZip;
CString Originalinputfilestr;

/////////////////////////////////////////////////////////////////////////////
// mydlldlg dialog


mydlldlg::mydlldlg(CWnd* pParent /*=NULL*/)
	: CDialog(mydlldlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(mydlldlg)
	m_strClip = _T("");
	m_strFips = _T("");
	m_strLayer = _T("");
	m_strOutfiles = _T("");
	m_strOutoption = _T("");
	m_strProcess = _T("");
	m_strVersion = _T("");
	m_strStatus = _T("");
	//}}AFX_DATA_INIT
}


void mydlldlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(mydlldlg)
	DDX_Control(pDX, IDC_PROGRESS1, m_Progress);
	DDX_Text(pDX, IDC_CLIP, m_strClip);
	DDX_Text(pDX, IDC_FIPS, m_strFips);
	DDX_Text(pDX, IDC_LAYER, m_strLayer);
	DDX_Text(pDX, IDC_OUTFILES, m_strOutfiles);
	DDX_Text(pDX, IDC_OUTOPTION, m_strOutoption);
	DDX_Text(pDX, IDC_PROCESS, m_strProcess);
	DDX_Text(pDX, IDC_VERSION, m_strVersion);
	DDX_Control(pDX, IDC_XCEEDZIPCTRL2, m_zip);
	DDX_Text(pDX, IDC_STATUS, m_strStatus);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(mydlldlg, CDialog)
	//{{AFX_MSG_MAP(mydlldlg)
	ON_BN_CLICKED(IDOK, OnGo)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// mydlldlg message handlers

BEGIN_EVENTSINK_MAP(mydlldlg, CDialog)
    //{{AFX_EVENTSINK_MAP(mydlldlg)
	ON_EVENT(mydlldlg, IDC_XCEEDZIPCTRL2, 6 /* Listing */, OnListingXceedzipctrl2, VTS_PBSTR VTS_I4 VTS_I4 VTS_I4 VTS_I2 VTS_PBSTR VTS_I4 VTS_I2 VTS_I2 VTS_I2 VTS_I2 VTS_I2 VTS_PBSTR)
	//}}AFX_EVENTSINK_MAP
END_EVENTSINK_MAP()

BOOL mydlldlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	CString titlestring;
	titlestring = "TGR2KML";
	SetWindowText(titlestring);
	CString extension;
	
	if (IsZip == 1)
	{
		Zipdirectory = Outdir + "\\unzipped";	
		int result = _mkdir(Zipdirectory);
		m_zip.SetExtractDirectory(Zipdirectory);							
		m_zip.SetZipFileName(InputFileStr);		
		m_zip.SetFilesToProcess("*.rt?\r*.bw?\r*.f6?");				
		int retval = m_zip.List();
		if (retval == XcdErrorNothingToDo) //tiger 97
		{					
			AfxMessageBox("cound not find files to unzip");
		}
		m_zip.Extract(0);				
		switch (TigerVersion)
		{
/*		case 94:
			extension = ".f61";
			break;
		case 95:
			extension = ".bw1";
			break;
*/		
		case 103:
		default:
			extension = ".rt1";
			break;
		}
		Originalinputfilestr = InputFileStr;
		InputFileStr = Zipdirectory+"\\"+Outfiletitle+extension;					
	}
	UpdateData(FALSE);
	
		
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void mydlldlg::OnListingXceedzipctrl2(BSTR FAR* FileName, long Size, long PSize, long Processed, short FileAttr, BSTR FAR* FTime, long CRC, short Ratio, short Completion, short Method, short Encrypted, short ComLen, BSTR FAR* Comment) 
{
if (Unlinkthem)
	{
		CString fname,fullname;
		fname = *FileName;
		fullname = Zipdirectory+"\\"+fname;		
		unlink(fullname);
	}	
}

void mydlldlg::OnCancel() 
{
	// TODO: Add extra cleanup here
	fclose(LOG);
	CDialog::OnCancel();
}

void mydlldlg::OnGo() 
{
	// TODO: Add your control notification handler code here
	ProcessTiger(this);	
/*	if (IsZip == 1) //need to clean up
	{
		Unlinkthem = 1;
		m_zip.SetZipFileName(Originalinputfilestr);
		m_zip.SetFilesToProcess("*.rt?\r*.bw?\r*.f6?");
		m_zip.List();
		Unlinkthem = 0;
	}
	*/
	CDialog::OnOK();
}
void mydlldlg::OnGo2()
{
	OnGo();
}
void mydlldlg::ErrorMessage(CString s)
{
	fprintf(LOG,"%s\n",s);
}
void mydlldlg::ErrorMessageStop(CString s)
{
	fprintf(LOG,"%s\n",s);

	OnCancel();
}
