/*written with the help of Dr. Cheng Liu
*/
#ifndef _SHAPE_H_
#define _SHAPE_H_

#define PC

#include <stdio.h>

#define SHPHEADERSIZE			100
#define SHPRECHEADERSIZE		8
#define SHPPOINTSIZE			20
#define SHPINDEXSIZE			8
#define SHPRECHEADERSIZE		8
#define SHPARCHEADERSIZE		44
#define LARGE					1.0e99
#define READONLY				"rb"
#define WRITEONLY				"wb"
#define READUPDATE			"rb+"
#define WRITEUPDATE			"wb+"

#ifdef PC
	#define APPEND				"rb+"
#else
	#define APPEND				"ab+"
#endif

typedef struct SHAPEINDEXRECORD
{
	int	offset;
	int	length;
} shape_index_record_t;

typedef struct SHAPERECHEADER
{
	int	num;
	int	length;
} shape_record_header_t;

typedef	struct SHAPE
{
	char*	baseFileName;
	char*	indexFileName;
	char*	shapeFileName;
    FILE        *shpFp;
    FILE	*shxFp;
    int         numRecords;
    int		nMaxRecords;
	int	fileCode;
	int	version;
	int	shpFileLen;
	int	shxFileLen;
	int	shapeType;
	int	recLen;
	double	xMin;
	double	yMin;
	double	xMax;
	double	yMax;
    int		*panRecOffset;
    int		*panRecSize;
    double	adBoundsMin[2];
    double	adBoundsMax[2];
    int		bUpdated;
} shape_t;

typedef struct SHAPEHEADER
{
	int		fileCode;
	int		unUsed1;
	int		unUsed2;
	int		unUsed3;
	int		unUsed4;
	int		unUsed5;
	int		fileLen;
	int		version;
	int		shapeType;
	double		xMin;
	double		xMax;
	double		yMin;
	double		yMax;
	int		unUsed6;
	int		unUsed7;
	int		unUsed8;
	int		unUsed9;
	int		unUsed10;
	int		unUsed11;
	int		unUsed12;
} shape_header_t;

typedef struct SHPPOINT
{
	int		shapeType;
	double		x;
	double		y;
} shape_point_t;

typedef struct SHAPEPOINTRECORD
{
	int		num;
	int		len;
	shape_point_t*	point;
} shape_point_record_t;

typedef struct MYPOINT
{
	double		x;
	double		y;
} point_t;

typedef struct MYRECT
{
	double		xMin;
	double		yMin;
	double		xMax;
	double		yMax;
} rect_t;

typedef struct SHPARC
{
	int		shapeType;
	double		xMin;
	double		yMin;
	double		xMax;
	double		yMax;
	int		numParts;
	int		numPoints;
	int*            parts;
	point_t*        points;
} shape_arc_t;

typedef struct SHPPOLY
{
	int		shapeType;
	double		xMin;
	double		yMin;
	double		xMax;
	double		yMax;
	int		numParts;
	int		numPoints;
	int*            parts;
	point_t*        points;
}shape_poly_t;
/*
typedef struct SHPARCRECORD
{
	rect_t		r;
	int		numParts;
	int		numPoints;
	int*		parts;
	point_t*	points;		
} shape_arc_record_t;
*/
typedef shape_t * SHPHandle;

enum {SHP_NULL = 0, SHP_POINT = 1, SHP_ARC = 3, SHP_POLYGON = 5, SHP_MULTIPOINT = 8};

enum {LITTLE = 0, BIG = 1};
/*
#define SHPT_POINT	1
#define SHPT_ARC	3
#define SHPT_POLYGON	5
#define SHPT_MULTIPOINT	8
*/
//int Position,IPosition;
//int Size;
static void Memory_N_Copy (char*, char*, int, int);
int			SHP_Add_Record (shape_t*, void*);
shape_t		     *	SHP_Read_Headers (shape_t *);
shape_header_t	     *	SHP_Read_Header  (FILE* fp);
shape_point_record_t *	SHP_Read_Record  (shape_t *);
shape_t		     *  SHP_Create_File (const char *, const char *, int);
int			SHP_Close_Files (shape_t *);
int 		      	SHP_Write_New_Headers  (shape_t *);
void		     *	SHP_Next_Record  (shape_t *);
shape_t*		SHP_Open_Files (const char *, const char *);
shape_t*		SHP_Open_Files_For_Read (const char *, const char *);
shape_t*		SHP_Open_Files_For_Write (const char *, const char *, int);
shape_t*		SHP_Reopen_Files_For_Append (shape_t* s, const char *);
int			SHP_Dump_Header (shape_header_t *);
int			SHP_Dump_Shape (shape_t *);
int			SHP_Dump_Point_Record (shape_point_record_t *);
shape_arc_t	     *	SHP_Compose_Arc (int, char**);
shape_point_t	     *	SHP_Compose_Point (double, double);
void			Check_Byte_Order (void);
int			SHP_Dump_Record (void* rec, int shapeType);
int			SHP_Dump_Index_File (shape_t*);
int			SHP_Dump_Shape_File (shape_t*);
int			Check_File_Shape_Type (char *);
#endif
