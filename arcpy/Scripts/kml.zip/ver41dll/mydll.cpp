// mydll.cpp : Defines the initialization routines for the DLL.
//
/*Written by Bruce Ralston
*/

#include "stdafx.h"
#include "mydll.h"
#include "mydlldlg.h"
#include "direct.h"
#include <windows.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
extern "C" __declspec(dllexport) int Display(char *, char *, char *, int, int);
int __stdcall Display2(char *, char *, char *, int, int);
CString GetFileTitle(const CString&);
CString GetFileName(const CString&);
CString GetFilePath(const CString&);
CString  Fipval;
static CString  DefaultOut;
CString Outfiletitle;
CString Outfilepath;
CString Outdir;
CString Flags;
FILE *LOG;
int TigerVersion;
int Watercut;
int IsZip;
int AllLines;
char OutOption;
int Pushpins;
#define XcdErrorNothingToDo 140
BOOLEAN Adsasnums;

//
//	Note!
//
//		If this DLL is dynamically linked against the MFC
//		DLLs, any functions exported from this DLL which
//		call into MFC must have the AFX_MANAGE_STATE macro
//		added at the very beginning of the function.
//
//		For example:
//
//		extern "C" BOOL PASCAL EXPORT ExportedFunction()
//		{
//			AFX_MANAGE_STATE(AfxGetStaticModuleState());
//			// normal function body here
//		}
//
//		It is very important that this macro appear in each
//		function, prior to any calls into MFC.  This means that
//		it must appear as the first statement within the 
//		function, even before any object variable declarations
//		as their constructors may generate calls into the MFC
//		DLL.
//
//		Please see MFC Technical Notes 33 and 58 for additional
//		details.
//

/////////////////////////////////////////////////////////////////////////////
// CMydllApp

BEGIN_MESSAGE_MAP(CMydllApp, CWinApp)
	//{{AFX_MSG_MAP(CMydllApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMydllApp construction

CMydllApp::CMydllApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CMydllApp object

CMydllApp theApp;
int __stdcall Display2(char *s, char *out, char *flags, int cur, int total)
{
	return Display(s, out, flags, cur, total);
}
extern "C" __declspec(dllexport) int Display(char * s, char *out, char *flags, int cur, int total)
{
	
	AFX_MANAGE_STATE (AfxGetStaticModuleState());
	
	mydlldlg dlg;
	CString repval;
	for (int i = 0; i < 55; i++)
	{
		if (flags[i] == '0')
			dlg.IsOn[i] = false;
		else
			dlg.IsOn[i] = true;
		
	}
	if (flags[0] == '2')
		Adsasnums = TRUE;
	else
		Adsasnums = FALSE;
	AllLines = 0;
	int location;
	
	Flags.Format("%s",flags);
	location = strlen(s)-9;
	dlg.InputFileStr = s;
	CString verstring;
	CString statstring;
	statstring.Format("Processing county %d of %d",cur, total);
	dlg.m_strStatus = statstring;
	
	switch(flags[53])
	{
	case '0':
		TigerVersion = 94;
		verstring.Format("TIGER %d",TigerVersion);		
		break;
	case '1':
		TigerVersion = 95;
		verstring.Format("TIGER %d",TigerVersion);		
		break;
	case '2':
		TigerVersion = 97;
		verstring.Format("TIGER %d",TigerVersion);		
		break;
	case '3':
		TigerVersion = 98;
		verstring.Format("TIGER 98");	
		break;
	case '4':
		TigerVersion = 99; //2000 Dress Rehersal
		verstring.Format("2000 Dress Rehersal",TigerVersion);		
		break;
	case '5':
		TigerVersion = 100; //vtdp
		verstring.Format("TIGER 99");
		break;
	case '6':
		TigerVersion = 101;
		verstring.Format("TIGER 2000");
		break;
	case '7':
		TigerVersion = 102;
		verstring.Format("TIGER 2000 Urban Areas");
		break;
	case '8':
		TigerVersion = 103;
		verstring.Format("TIGER 2000 CD108");
		
		break;
	default:
		TigerVersion = 97;
		verstring.Format("TIGER %d",TigerVersion);		
		break;
	}
	
	dlg.m_strVersion = verstring;
	if (dlg.IsOn[54])
	{
		dlg.m_strClip = "Yes";
		Watercut = 1;
		
	}
	else
	{
		dlg.m_strClip = "No";
				Pushpins = 0;		
	}
	if (dlg.IsOn[51])
		Pushpins = 1;
	else
		Pushpins = 0;
	CString filetitle = GetFileTitle(dlg.InputFileStr);
	CString extension;
	extension = dlg.InputFileStr.Right(3);
	if (filetitle.GetLength() > 8)
	{
		CString filetitle2;
		filetitle2 = filetitle.Left(3);	
		filetitle2 = filetitle2 + filetitle.Right(5);	
		filetitle = filetitle2;
		CString filepath;
		filepath = GetFilePath(dlg.InputFileStr);	
		dlg.InputFileStr = filepath + filetitle + "." + extension;
		location = dlg.InputFileStr.GetLength()-9;
	}
	extension.MakeUpper();
	Fipval  = dlg.InputFileStr.Mid(location,5); 
	dlg.m_strFips = Fipval;
	Outdir = out;	
	CString logname;	
	logname = Outdir + "\\" + filetitle + ".log";
	LOG = fopen(logname,"a");
	//write the time processing started
	struct tm *newtime;
	time_t longtime;	
	time(&longtime);
	newtime = localtime(&longtime);
	fprintf(LOG,"New Process started on %d/%d at %d:%02d\n",newtime->tm_mon+1,
		newtime->tm_mday, newtime->tm_hour, newtime->tm_min);	
	fprintf(LOG,verstring);
	fprintf(LOG,"\n");
	int strlength = Outdir.GetLength();
	if (Outdir.GetAt(strlength - 1) == '\\')
		Outdir = Outdir.Left(strlength - 1);
	
	if (extension == "ZIP")
		IsZip = 1;
	else
		IsZip = 0;
	int result;
	CString outdirectory; 
	OutOption = flags[50];
	switch (flags[50])
	{
	case '0':
		outdirectory = Outdir + "\\" + filetitle;	
		result = _mkdir(outdirectory);
		dlg.m_strOption = "Organize by county";
		if (result == 0)
			fprintf(LOG,"directory %s created\n",outdirectory);
		else
			fprintf(LOG,"directory %s not created\n", outdirectory);
		break;
	case '1':
		outdirectory = Outdir + "\\tigershapes";
		result = _mkdir(outdirectory);
		dlg.m_strOption = "All shapes in one directory";
		if (result == 0)
			fprintf(LOG,"directory %s created\n",outdirectory);
		else
			fprintf(LOG,"directory %s not created\n", outdirectory);
		break;
	case '2':
		outdirectory = Outdir;
		dlg.m_strOption = "Organize by Theme";
		break;
	case '3':
		outdirectory = Outdir;
		dlg.m_strOption = "Organize by Theme and Merge";
	default: 
		outdirectory = Outdir;
		break;
	}
	
	Outfilepath = outdirectory + "\\";
	Outfiletitle = filetitle;
	
	dlg.m_strOutFiles = outdirectory;
	
	dlg.Create(IDD_DIALOG1,NULL);
	
	dlg.ShowWindow(SW_SHOW);
	
	dlg.UpdateWindow();
	
	dlg.OnGo2();


	time(&longtime);
	newtime = localtime(&longtime);
	fprintf(LOG,"Process ended on %d/%d at %d:%02d\n\n\n",newtime->tm_mon+1,
		newtime->tm_mday, newtime->tm_hour, newtime->tm_min);	
	fclose(LOG);
	
	return 0;
}
//helpers
CString GetFileName(const CString& path)
{
	ASSERT(path.GetLength());
	int pos = path.ReverseFind('\\');
	if (pos >= 0)
		return path.Right(path.GetLength() - pos - 1);
	return "";
}
CString GetFilePath(const CString& path)
{
	ASSERT(path.GetLength());
	int pos = path.ReverseFind('\\');
	if (pos >= 0)
		return path.Left(pos + 1);
		//return path.Left(path.GetLength() - pos + 1);	
	return "";
}
CString GetFileTitle(const CString& path)
{
	ASSERT(path.GetLength());
	CString strResult = GetFileName(path);
	int pos = strResult.ReverseFind('.');
	if (pos >= 0)
		return strResult.Left(pos);
	return strResult;
}

BOOL CMydllApp::InitInstance() 
{
	// TODO: Add your specialized code here and/or call the base class

	COleObjectFactory::RegisterAll();
	AfxEnableControlContainer();
	return CWinApp::InitInstance();
}
/////////////////////////////////////////////////////////////////////////////
// Special entry points required for inproc servers

STDAPI DllGetClassObject(REFCLSID rclsid, REFIID riid, LPVOID* ppv)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	return AfxDllGetClassObject(rclsid, riid, ppv);
}

STDAPI DllCanUnloadNow(void)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	return AfxDllCanUnloadNow();
}

// by exporting DllRegisterServer, you can use regsvr.exe
STDAPI DllRegisterServer(void)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	COleObjectFactory::UpdateRegistryAll();
	return S_OK;
}
