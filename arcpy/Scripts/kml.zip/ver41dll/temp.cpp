	
//sprintf(watrecord," %-8d%-5s",polyid,county[curcase].Waterplus);
	fwrite(&watrecord,sizeof(watrecord)-1,1,dbftmp);
	//fprintf(LOG,"%d %s %s\n",polyid,wat[curcase].Waterplus,ctyname);
	if (wat[0].Flip == 0)
	{
		curX = wat[curcase].Tolong;
		curY = wat[curcase].Tolat;
		Pts[Npts].Longitude = wat[curcase].Frlong;
		Pts[Npts].Latitude = wat[curcase].Frlat;
		Npts++;
		Get_Shape_Points(wat[curcase].Tlid,wat[curcase].Flip);
		Pts[Npts].Longitude = wat[curcase].Tolong;
		Pts[Npts].Latitude = wat[curcase].Tolat;
		Npts++;
		wat[curcase].Chosen = 1;	
	}
	else
	{
		curX = wat[curcase].Frlong;
		curY = wat[curcase].Frlat;
		Pts[Npts].Longitude = wat[0].Tolong;
		Pts[Npts].Latitude = wat[0].Tolat;
		Npts++;
		Get_Shape_Points(wat[curcase].Tlid,wat[curcase].Flip);
		Pts[Npts].Longitude = wat[curcase].Frlong;
		Pts[Npts].Latitude = wat[curcase].Frlat;
		Npts++;
		wat[curcase].Chosen = 1;	
	}
	ptcount += Npts;	
	fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
	//fprintf(LOG,"tlid %s\n",wat[curcase].Tlid);
	if (Pts[0].Longitude < CurrentMinX)
		CurrentMinX = Pts[0].Longitude;
	if (Pts[0].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < CurrentMinY)
		CurrentMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[0].Latitude;	
	if (Pts[0].Longitude < FileMinX)
		FileMinX = Pts[0].Longitude;
	if (Pts[0].Longitude > FileMaxX)
		FileMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < FileMinY)
		FileMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > FileMaxY)
		FileMaxY = Pts[0].Latitude;

	if (Pts[Npts-1].Longitude < CurrentMinX)
		CurrentMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < CurrentMinY)
		CurrentMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[Npts-1].Latitude;	
	if (Pts[Npts-1].Longitude < FileMinX)
		FileMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > FileMaxX)
		FileMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < FileMinY)
		FileMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > FileMaxY)
		FileMaxY = Pts[Npts-1].Latitude;
	n = 1;
	steppos = (int)(n*100/written);
	//Ptrdlg->m_Progress.StepIt();
	Ptrdlg->m_Progress.SetPos(steppos);
	bval = 1;
    while (n < written)
	
		{//printf("\n Have written %ld of %ld county boundary lines",n, written);
		found = 0;
		while (bval > 1)
		{
			if (strcmp(wat[bval].Waterplus, wat[curcase].Waterplus) >= 0)
				bval--;
			else
				break;
		}

		for (i = bval; i < written; i++)
        {
			Npts = 0;
			if (wat[i].Chosen != 0)
				continue;
			if (strcmp(wat[i].Waterplus,wat[curcase].Waterplus) > 0)
			{
				bval = i;
				break;
			}
			if (strcmp(wat[i].Waterplus,wat[curcase].Waterplus) != 0)
				  continue;
			if (wat[i].Flip == 0)
			{
				 if ((wat[i].Frlong == curX) && (wat[i].Frlat == curY))
					{                          
					
					Get_Shape_Points(wat[i].Tlid,wat[i].Flip);
					Pts[Npts].Longitude = wat[i].Tolong;
					Pts[Npts].Latitude = wat[i].Tolat;
					Npts++;
					n++;
					steppos = (int) (n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					//Ptrdlg->m_Progress.StepIt();
					wat[i].Chosen = 1;            
					found = 1;                      
					curX = wat[i].Tolong;
					curY = wat[i].Tolat;                
					curcase = i;
					break;
					}
			}
			else
			{
				if ((wat[i].Tolong == curX) && (wat[i].Tolat == curY))
					{
					//if (strcmp(wat[i].Waterplus,wat[curcase].Waterplus) != 0)
					 // continue;	            
					Get_Shape_Points(wat[i].Tlid,wat[i].Flip);
					Pts[Npts].Longitude = wat[i].Frlong;
					Pts[Npts].Latitude = wat[i].Frlat;
					Npts++;				
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					//Ptrdlg->m_Progress.StepIt();
					curX = wat[i].Frlong;
					curY = wat[i].Frlat;                        
					wat[i].Chosen = 1;		
					found = 1;          
					curcase = i;
					break;
					}
			}
        }//close for loop
		
		if (found == 0) //initialize new case, eg, new ring in current poly
			// or new polyid
        {
			fwrite(&ptcount,sizeof(int),1,headtemp);
			ptcount = 0;
			while (bval > 1)
			{
				if (strcmp(wat[bval].Waterplus, wat[curcase].Waterplus) >= 0)
					bval--;
				else
					break;
			}

			for (i = bval; i < written; i++)//first check for new ring in current poly
            {                    
         		if (wat[i].Chosen != 0)
					continue;             
				if (strcmp(wat[i].Waterplus, wat[curcase].Waterplus) > 0)
					break;
				if (strcmp(wat[i].Waterplus,wat[curcase].Waterplus) != 0)
					continue;
				//if we get here we have a new ring of the current polygon
				found = 1;
				nparts++;				
				Npts = 0;				
				if (wat[i].Flip == 0)
				{
					Pts[Npts].Longitude = wat[i].Frlong;
					Pts[Npts].Latitude = wat[i].Frlat;
					Npts++;
					Get_Shape_Points(wat[i].Tlid,wat[i].Flip);
					Pts[Npts].Longitude = wat[i].Tolong;
					Pts[Npts].Latitude = wat[i].Tolat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					//Ptrdlg->m_Progress.StepIt();
					wat[i].Chosen = 1;            
					found = 1;                      
					curX = wat[i].Tolong;
					curY = wat[i].Tolat;                
					curcase = i;
					break;					
				}
				else
				{
					Pts[Npts].Longitude = wat[i].Tolong;
					Pts[Npts].Latitude = wat[i].Tolat;
					Npts++;
					Get_Shape_Points(wat[i].Tlid,wat[i].Flip);
					Pts[Npts].Longitude = wat[i].Frlong;
					Pts[Npts].Latitude = wat[i].Frlat;
					Npts++;				
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					//Ptrdlg->m_Progress.StepIt();
					curX = wat[i].Frlong;
					curY = wat[i].Frlat;                        
					wat[i].Chosen = 1;		
					found = 1;          
					curcase = i;
					break;					
				}	
			}//close on for loop on i
		}//close one if on found
        if (found == 0) // new polygon, first ring
		{
			fwrite(&nparts,sizeof(int),1,partstemp);
			//fwrite(&ptcount,sizeof(int),1,headtemp);
			nparts = 1;
			fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
			CurrentMinX = CurrentMinY = LARGE;
			CurrentMaxX = CurrentMaxY = -LARGE;
			while (bval > 1)
			{
				if (strcmp(wat[bval].Waterplus, wat[curcase].Waterplus) >= 0)
					bval--;
				else
					break;
			}

			for (i = bval; i < written; i++)//first check for new ring in current poly
            {                    
         		if (wat[i].Chosen != 0)
					continue;             
				polyid++;
				sprintf(watrecord," %8d", polyid+curpolys);
				sprintf(&watrecord[9],"%-5s",wat[i].County);
				sprintf(&watrecord[14],"%-33s",wat[i].Water);
				sprintf(&watrecord[47],"%1d",wat[i].Flag);
				//sprintf(watrecord," %-8d%-5s",polyid,county[i].Waterplus);
				fwrite(&watrecord,sizeof(watrecord)-1,1,dbftmp);
				//fprintf(LOG,"%d %s %s\n",polyid,wat[i],ctyname);
				Npts = 0;
				if (wat[i].Flip == 0)
				{
					Pts[Npts].Longitude = wat[i].Frlong;
					Pts[Npts].Latitude = wat[i].Frlat;
					Npts++;
					Get_Shape_Points(wat[i].Tlid,wat[i].Flip);
					Pts[Npts].Longitude = wat[i].Tolong;
					Pts[Npts].Latitude = wat[i].Tolat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					//Ptrdlg->m_Progress.StepIt();
					wat[i].Chosen = 1;            
					found = 1;                      
					curX = wat[i].Tolong;
					curY = wat[i].Tolat;                
					curcase = i;
					break;					
				}
				else
				{
					Pts[Npts].Longitude = wat[i].Tolong;
					Pts[Npts].Latitude = wat[i].Tolat;
					Npts++;
					Get_Shape_Points(wat[i].Tlid,wat[i].Flip);
					Pts[Npts].Longitude = wat[i].Frlong;
					Pts[Npts].Latitude = wat[i].Frlat;
					Npts++;				
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					//Ptrdlg->m_Progress.StepIt();
					curX = wat[i].Frlong;
					curY = wat[i].Frlat;                        
					wat[i].Chosen = 1;		
					found = 1;          
					curcase = i;	
					break;					
				}	
			}
		}
		//by now found should be 1
		if (found == 0)
		{
			info.Format("ERROR - found is zero");
			Ptrdlg->ErrorMessage(info);			
			MissingFile = -1;
			return;
		}
		ptcount += Npts;
		fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
		//fprintf(LOG,"tlid %s\n",wat[i].Tlid);
		if (Pts[0].Longitude < CurrentMinX)
		CurrentMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < CurrentMinY)
			CurrentMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[0].Latitude;	
		if (Pts[0].Longitude < FileMinX)
			FileMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > FileMaxX)
			FileMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < FileMinY)
			FileMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > FileMaxY)
			FileMaxY = Pts[0].Latitude;

		if (Pts[Npts-1].Longitude < CurrentMinX)
			CurrentMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < CurrentMinY)
			CurrentMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[Npts-1].Latitude;	
		if (Pts[Npts-1].Longitude < FileMinX)
			FileMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > FileMaxX)
			FileMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < FileMinY)
			FileMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > FileMaxY)
			FileMaxY = Pts[Npts-1].Latitude;		
	}

-----------original below
	n = 1;
	steppos = (int)(n*100/written);
	//Ptrdlg->m_Progress.StepIt();
	Ptrdlg->m_Progress.SetPos(steppos);
	bval = 1;
    while (n < written)
	
		{//printf("\n Have written %ld of %ld county boundary lines",n, written);
		found = 0;
		while (bval > 1)
		{
			if (strcmp(wat[bval].Waterplus, wat[curcase].Waterplus) >= 0)
				bval--;
			else
				break;
		}

		for (i = bval; i < written; i++)
        {
			Npts = 0;
			if (wat[i].Chosen != 0)
				continue;
			if (strcmp(wat[i].Waterplus,wat[curcase].Waterplus) > 0)
			{
				bval = i;
				break;
			}
			if (strcmp(wat[i].Waterplus,wat[curcase].Waterplus) != 0)
				  continue;
			if (wat[i].Flip == 0)
			{
				 if ((wat[i].Frlong == curX) && (wat[i].Frlat == curY))
					{                          
					
					Get_Shape_Points(wat[i].Tlid,wat[i].Flip);
					Pts[Npts].Longitude = wat[i].Tolong;
					Pts[Npts].Latitude = wat[i].Tolat;
					Npts++;
					n++;
					steppos = (int) (n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					//Ptrdlg->m_Progress.StepIt();
					wat[i].Chosen = 1;            
					found = 1;                      
					curX = wat[i].Tolong;
					curY = wat[i].Tolat;                
					curcase = i;
					break;
					}
			}
			else
			{
				if ((wat[i].Tolong == curX) && (wat[i].Tolat == curY))
					{
					//if (strcmp(wat[i].Waterplus,wat[curcase].Waterplus) != 0)
					 // continue;	            
					Get_Shape_Points(wat[i].Tlid,wat[i].Flip);
					Pts[Npts].Longitude = wat[i].Frlong;
					Pts[Npts].Latitude = wat[i].Frlat;
					Npts++;				
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					//Ptrdlg->m_Progress.StepIt();
					curX = wat[i].Frlong;
					curY = wat[i].Frlat;                        
					wat[i].Chosen = 1;		
					found = 1;          
					curcase = i;
					break;
					}
			}
        }//close for loop
		
		if (found == 0) //initialize new case, eg, new ring in current poly
			// or new polyid
        {
			fwrite(&ptcount,sizeof(int),1,headtemp);
			ptcount = 0;
			while (bval > 1)
			{
				if (strcmp(wat[bval].Waterplus, wat[curcase].Waterplus) >= 0)
					bval--;
				else
					break;
			}

			for (i = bval; i < written; i++)//first check for new ring in current poly
            {                    
         		if (wat[i].Chosen != 0)
					continue;             
				if (strcmp(wat[i].Waterplus, wat[curcase].Waterplus) > 0)
					break;
				if (strcmp(wat[i].Waterplus,wat[curcase].Waterplus) != 0)
					continue;
				//if we get here we have a new ring of the current polygon
				found = 1;
				nparts++;				
				Npts = 0;				
				if (wat[i].Flip == 0)
				{
					Pts[Npts].Longitude = wat[i].Frlong;
					Pts[Npts].Latitude = wat[i].Frlat;
					Npts++;
					Get_Shape_Points(wat[i].Tlid,wat[i].Flip);
					Pts[Npts].Longitude = wat[i].Tolong;
					Pts[Npts].Latitude = wat[i].Tolat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					//Ptrdlg->m_Progress.StepIt();
					wat[i].Chosen = 1;            
					found = 1;                      
					curX = wat[i].Tolong;
					curY = wat[i].Tolat;                
					curcase = i;
					break;					
				}
				else
				{
					Pts[Npts].Longitude = wat[i].Tolong;
					Pts[Npts].Latitude = wat[i].Tolat;
					Npts++;
					Get_Shape_Points(wat[i].Tlid,wat[i].Flip);
					Pts[Npts].Longitude = wat[i].Frlong;
					Pts[Npts].Latitude = wat[i].Frlat;
					Npts++;				
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					//Ptrdlg->m_Progress.StepIt();
					curX = wat[i].Frlong;
					curY = wat[i].Frlat;                        
					wat[i].Chosen = 1;		
					found = 1;          
					curcase = i;
					break;					
				}	
			}//close on for loop on i
		}//close one if on found
        if (found == 0) // new polygon, first ring
		{
			fwrite(&nparts,sizeof(int),1,partstemp);
			//fwrite(&ptcount,sizeof(int),1,headtemp);
			nparts = 1;
			fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
			CurrentMinX = CurrentMinY = LARGE;
			CurrentMaxX = CurrentMaxY = -LARGE;
			while (bval > 1)
			{
				if (strcmp(wat[bval].Waterplus, wat[curcase].Waterplus) >= 0)
					bval--;
				else
					break;
			}

			for (i = bval; i < written; i++)//first check for new ring in current poly
            {                    
         		if (wat[i].Chosen != 0)
					continue;             
				polyid++;
				sprintf(watrecord," %8d", polyid+curpolys);
				sprintf(&watrecord[9],"%-5s",wat[i].County);
				sprintf(&watrecord[14],"%-33s",wat[i].Water);
				sprintf(&watrecord[47],"%1d",wat[i].Flag);
				//sprintf(watrecord," %-8d%-5s",polyid,county[i].Waterplus);
				fwrite(&watrecord,sizeof(watrecord)-1,1,dbftmp);
				//fprintf(LOG,"%d %s %s\n",polyid,wat[i],ctyname);
				Npts = 0;
				if (wat[i].Flip == 0)
				{
					Pts[Npts].Longitude = wat[i].Frlong;
					Pts[Npts].Latitude = wat[i].Frlat;
					Npts++;
					Get_Shape_Points(wat[i].Tlid,wat[i].Flip);
					Pts[Npts].Longitude = wat[i].Tolong;
					Pts[Npts].Latitude = wat[i].Tolat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					//Ptrdlg->m_Progress.StepIt();
					wat[i].Chosen = 1;            
					found = 1;                      
					curX = wat[i].Tolong;
					curY = wat[i].Tolat;                
					curcase = i;
					break;					
				}
				else
				{
					Pts[Npts].Longitude = wat[i].Tolong;
					Pts[Npts].Latitude = wat[i].Tolat;
					Npts++;
					Get_Shape_Points(wat[i].Tlid,wat[i].Flip);
					Pts[Npts].Longitude = wat[i].Frlong;
					Pts[Npts].Latitude = wat[i].Frlat;
					Npts++;				
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					//Ptrdlg->m_Progress.StepIt();
					curX = wat[i].Frlong;
					curY = wat[i].Frlat;                        
					wat[i].Chosen = 1;		
					found = 1;          
					curcase = i;	
					break;					
				}	
			}
		}
		//by now found should be 1
		if (found == 0)
		{
			info.Format("ERROR - found is zero");
			Ptrdlg->ErrorMessage(info);			
			MissingFile = -1;
			return;
		}
		ptcount += Npts;
		fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
		//fprintf(LOG,"tlid %s\n",wat[i].Tlid);
		if (Pts[0].Longitude < CurrentMinX)
		CurrentMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < CurrentMinY)
			CurrentMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[0].Latitude;	
		if (Pts[0].Longitude < FileMinX)
			FileMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > FileMaxX)
			FileMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < FileMinY)
			FileMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > FileMaxY)
			FileMaxY = Pts[0].Latitude;

		if (Pts[Npts-1].Longitude < CurrentMinX)
			CurrentMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < CurrentMinY)
			CurrentMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[Npts-1].Latitude;	
		if (Pts[Npts-1].Longitude < FileMinX)
			FileMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > FileMaxX)
			FileMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < FileMinY)
			FileMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > FileMaxY)
			FileMaxY = Pts[Npts-1].Latitude;		
	}


