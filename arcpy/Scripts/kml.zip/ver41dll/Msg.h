#ifndef _MSG_H_
#define _MSG_H_


void ErrorMessageStop (char *msg);
void ErrorMessage (char *msg);

#endif
