/* 	translation program for converting tiger files to
	shape files for use in ITRAF

	This is the header file trg2shp.h



	
*/

// starting with record type 1

typedef struct {//commented out items are not read or used
//	char   RecordType; //not really used by these programs
//	int   Version; //must be tiger 95 or later
	
	char    Tlid[11]; //unique string identifer
//	int		Side1; //single side code 1 = county boundry; one side blank;
			// blank = not a county boundary
	char	Source;
	char    Fedirp[3]; //Feature direction prefix
	char	Fename[31]; //Feature name
	char	Fetype[5]; //Feature type
	char	Fedirs[3]; //Feature direction suffix
	char    Cfcc[4]; //Census feature classification code A = road
	char    Fraddl[12], Toaddl[12], Fraddr[12], Toaddr[12]; //address ranges
	int		Friaddl, Toiaddl, Friaddr, Toiaddr; //imputed range flag
	char	Zipl[6], Zipr[6]; //5 digit zipcodes
//	char	Fairl[6], Fairr[6]; // Fips 55 code left and right
//	char	Trustl, Trustr; //American indian trust land flag
	char	Census1, Census2; //reserved census flags
	char    Statel[3], Stater[3]; //fipscode of state left/right
	char	Countyl[4], Countyr[4]; //fipscode of county left/right
	char	Fmcdl[6],Fmcdr[6]; //fips 55 code left/right for MCD/CCD
	char	Fsmcdl[6],Fsmcdr[6]; //fips 55 code left/right for sub-MCD
	char 	Fpll[6],Fplr[6]; //fips 55 code left/right for place/CDP
	char    Ctbnal[7], Ctbnar[7]; //census tract/bna code left and right
	char    Blkl[5],Blkr[5]; //Bolock numbers left/right
	double	Frlong, Frlat, Tolong, Tolat; //start and end longitude and latitude
	char	MyCfcc;	 // new for Tiger 99+
//there are no differences between versions 94, 94, 97 or LUCA
}RecordType1;
typedef struct{
	double Longitude,Latitude;
}Geographic_Coordinate;
typedef struct { //type 2 records contain shape points in fixed formats

 //   char	RecordType;
 //   int 	Version;
    char	Tlid[11];
    char	Rtsq[4]; //sequence number for records with many shape points
    Geographic_Coordinate Point[10];
	//there are no differences between versions 94, 94, 97 or LUCA
}RecordType2;             
typedef struct{ //structure of type 3 records relating polys to arcs
//	char	RecordType;
  //  int 	Version;
    char	Tlid[11];       
    char	State90l[3],State90r[3];
    char	Coun90l[4],Coun90r[4];
    /*char    Fmcd90l[6],Fmcd90r[6];
    char    Fpl90l[6],Fpl90r[6];
    char	Ctbnal[7],Ctbnar[7];
	char	Air90l[5],Air90r[5]; //luca
	char	Trust90l, Trust90r; //luca
    char 	Rs1[3]; 
//	char	Rs2[4],Rs3[4],Rs4[4]; // not in luca
    char	Blk90l[5], Blk90r[5];
    char	Aircul[5], Aircur[5];
    char	Rs5[4],Rs6[4]; // not in luca
    char	Anrcl[6],Anrcr[6]; //luca
	char	Census3[4], Census4[4]; //luca
    char	Rs2[3];
//	char    Rs7[5],Rs8[5]; //not in luca
*/
    char	Vtd90l[5],Vtd90r[5]; //luca
	int     BorderType[2]; // I added this field to track different border types
	//on 19 June, we no long use BorderType[8] anrc.
	//the following are for standard tiger 97
//	char	Rs2_97[6],Rs3_97[6],Rs4_97[4],Rs5_97[4],Rs6_97[3]; //for standard tiger 97
	//the following are for tiger 94 and 95
//	char	Rs1_95[4],Rs2_95[4],Rs3_95[4],Rs4_95[4], Rs5_95[4],Rs6_95[4],Rs7_95[4],Rs8_95[4];
	//on Feb 19 2000, we added the following for TIGER 99
	char	Aihhtli90l, Aihhtli90r;  //formal name is Aihhtl90 l and r
	char	Aianhhcecul[5], Aianhhcecur[5];
	char	Anrccul[6], Anrccur[6];
	char	Aitscel[4], Aitscer[4];
	char	Aitsl[6], Aitsr[6];
}RecordType3;    
typedef struct{ //type C records, names of census polys
//	char	RecordType;
//    int 	Version; //length 4
	char	State[3];
	char	County[4];
	char	Fipsyr[5];
//	char	Datayr[5]; //in 99	
	char	Fips[6]; 
	char	Fipscc[3]; //in 99
	int		Pdc; //in 99 - Census entity description code
	char	Lasad[3];
	char	Entity;  //not in 94, 95
	char	Ma[5]; //not in 95, 95
	char	Sd[6]; //luca - school district code--currently empty -not in 94, 95
	char	Air[5]; //called AIANHHCE in 99
	char	Vtd[7]; //called VTD Tract in 99
	char	Ua[6]; //luca - new length - called UAUGA in 99 UA 2000
	char	Anrc[3];// in different location in Luca - not in 99
	char	Census5[4]; //luca
	char	Aitse[4]; //99
	char	Name[67]; //luca has 8 extra blank spaces
	//Tiger97
	char	Fipsyr97[3]; //in 94, 95, 97
	//char	Ua97[5]; //in 94, 95, 97
	//char	Name97[67]; //in 94, 95, 97
	//Tiger94-95
	char	Cmsamsa[5]; // not in luca
	char	Pmsa[5]; //not in luca
}RecordTypeC;
typedef struct{ //type 9 records, names of kgls
	//there are no differences from 94 to luca
	//char	RecordType;
    //int 	Version;
	//char	State[3];
	//char	County[4];
	char	Cenid[6];
	char 	Polyid[11];
	//char	Source;
	char	Cfcc[4];
	char	Kglname[31];
	char	Kgladd[12];
	char	Kglzip[6];
	char	Kglzip4[5];
	char	Feat[9];
	//char	Filler;
}RecordType9;
typedef struct{ //type I records
//	char	RecordType;
//	int		Version;
	char	Tlid[11];
	char	State[3];
	char	County[4];
	char	Rtlink;
	char	Cenidl[6];
	char 	Polyidl[11];
	char	Cenidr[6];
	char 	Polyidr[11];
	char	Filler;
	int		Kgll, Kglr; //i added to keep track of kgl polys
	int		Landl, Landr; //to keep track of land polys
	
}RecordTypeI;
typedef struct{
	char	Countycul[6], Countycur[6]; //A
	char	County90l[6], County90r[6]; //A
	char	Tract90l[12], Tract90r[12];//A
	char	Group90l[13],Group90r[13];//A
	char	Block90l[16], Block90r[16];//A
	char	Fpl90l[6], Fpl90r[6];//A
	char	Fmcd90l[6], Fmcd90r[6];//A
	char	Air90l[5], Air90r[5];//A
	char	Tazl[11],Tazr[11]; //A to keep track of taz and ctpp poly	
	char    Urb90l[6],Urb90r[6];//A
	char    Elml[6],Elmr[6];	//A
	char    Secl[6],Secr[6];//A
	char    Unil[6],Unir[6];//A
	char	Fair90l[6],Fair90r[6];//A
	char	Ctbna90l[7],Ctbna90r[7];//A
	char	Blk90l[5],Blk90r[5];//A
	char	Cd106l[3],Cd106r[3];//A
	char	Cd108l[3],Cd108r[3];//A
	char	Urbflagl,Urbflagr;//A
	char    Midl[6],Midr[6]; //A Tiger 94/94
	char	Urb00l[6],Urb00r[6]; //Tiger 2000 Urban
	char	Puma5l[6],Puma5r[6]; //Tiger 2000 Urban
}RecordTypeIA;
typedef struct{
	int indexl, indexr;
}RecordTypeIAIndex;
typedef struct{
	char	Countyl[6],Countyr[6];  //from columns 6-10
	int     Waterl, Waterr;//S
	char    Msal[5],Msar[5];//S
	char    Pmsl[5],Pmsr[5];//S
	char	Cdcul[3],Cdcur[3];//S
	char	Countycul[6],Countycur[6]; //can store 2000
	//char	House97l[7],House97r[7];
	//char	Senate97l[7],Senate97r[7];
	char	Housel[7],Houser[7];//S
	char	Senatel[7],Senater[7];//S
	char	Anrcl[3],Anrcr[3];//S

	//start DR
	char	Ctbna00l[7],Ctbna00r[7];
	char	Blk00l[5],Blk00r[5];
	char	Vtd00l[7],Vtd00r[7];
	char	Zctal[6],Zctar[6];
	//End DR
	char	Fplcul[6],Fplcur[6]; //S//luca
	char	Fmcdcul[6],Fmcdcur[6]; //S//luca
	
	char	Aircul[5],Aircur[5]; //S//luca
	char	Colblkl[18],Colblkr[18]; //S luca
	
	//Colblk will be StateCol(2),CountyCol(3),BlockCol(5),Blksufcol(1),Tea(1),Zcta(5) = 17 spaces
	char	Faircul[6],Faircur[6];//S
	char	Trustl, Trustr;//S
	char	Fccityl[6],Fccityr[6];//S
	char	Fsmcdcul[6],Fsmcdcur[6];//S
	char	Census6l[6], Census6r[6];//S
//Tiger 99 (TigerVersion == 100)
	char	Blkgrpl, Blkgrpr;
	char	Ugal[6],Ugar[6];	
	char	Cityl[6],Cityr[6];
	//Tiger 2000 Urban
	char	Urb00l, Urb00r;
	char	Urb90l, Urb90r;
	//tiger cd 108 march 03
	char	Ua00Corl[6],Ua00Corr[6];
	char	Ua90Redl[6],Ua90Redr[6];
	char	Ur90Redl,Ur90Redr;
}RecordTypeIS;
typedef struct{
	int indexl, indexr;
}RecordTypeISIndex;
typedef struct{
	//there are no differences between 94 to luca
	//char	RecordType;	
	//char	State[3];
	//char	County[4];
	char	Feat[9];
	char	Fedirp[3];
	char	Fename[31];
	char	Fetype[5];
	char	Fedirs[3];
}RecordType5;
typedef struct{
	//there are no differences from 94 to luca
	//char	RecordType;
	//int		Version;
	//char	State[3];
	//char	County[4];
	int		Land;
	char	Source;
	char	Cfcc[4];
	char	Laname[31];
	char	Lalong[11];
	char	Lalat[10];
	//char	Filler;
}RecordType7;
typedef struct{
	//there are no difference from 94 to luca
	//char	RecordType;
	//int		Version;
	//char	State[3];
	//char	County[4];
	char	Cenid[6];
	char	Polyid[11];
	int		Land;
	//char	Filler;
}RecordType8;
typedef struct{
	//char	RecordType;
	//int		Version;
 	 char	State[3];
	 char	County[4];
	 char	Cenid[6];
	 char	Polyid[11];
	 char	Fair[6];
	 char	Fmcd[6];
	 char	Fpl[6];
	 char	Ctbna90[7];
	 char	Blk90[5];
	 char    Cd106[3];
	 char	Cd108[3];
	 char	Sdelm[6];
	//char	Ua00[6]; //luca empty
	// luca char	Sdmid[6];
	 char	Sdsec[6];
	 char	Sduni[6];
	 char	Taz[7];
	 char	Ua90[6]; //moved in 2000 urban
	 char	Urbflag; //not in 2000 urban
	 char	Ctpp[5];
	// luca char	Rs9[10];
	 char	State90[3];  //not in 94-95
	 char	County90[4]; //not in 94-95
	 char	Air90[5]; //not in 94-95
	//tiger 94-95
	 char	Sdmid[6];
	 //UA 2000 create fields for PUMA[6], UA2000[6], UA1990[5]
	 char	Puma5[6]; //new in 2000 urban
	 char	Ua[6]; //new in 2000 urban

}RecordTypeA;	
typedef struct{
	//there are no differences between 94 to luca
//	char	RecordType;
//	int		Version;
	char	Tlid[11];
	char	Rtsq[4];
	char	Feat1[9], Feat2[9], Feat3[9], Feat4[9], Feat5[9];
}RecordType4;
typedef struct{
	//there are no differences from 94 to luca 
	//char	RecordType;
	//int		Version;
	char	Tlid[11];
	char	Rtsq[4];
	char    Fraddl[12], Toaddl[12], Fraddr[12], Toaddr[12]; //address ranges
	int		Friaddl, Toiaddl, Friaddr, Toiaddr; //imputed range flag
	char	Zipl[6], Zipr[6]; //5 digit zipcodes
}RecordType6;
typedef struct{
	//char	RecordType;
	//int		Version;
	char	State[3]; //not in 99
	char	County[4]; //not in 99
	 char	Cenid[6];
	 char	Polyid[11];
	 int 	Water;
	 char	Cmsamsa[5]; 
	 char	Pmsa[5];
	 char	Fair[6]; //AIANHH in 99
	 char	Air[5]; //AIANHHCE in 99
	 char	Trust; //AIHHTLI in 99
	 char	Anrc[3]; //not in 99
	 char	Statecu[3];
	 char	Countycu[4];
	 char	Fccity[6]; //CONCIT in 99
	 char	Fmcd[6]; //COUSUB in 99
	 char	Fsmcd[6]; //SUBMCD in 99
	 char	Fpl[6]; //PLACE IN 99
	//char	Ctbna90[7]; //luca
	//char	Blk90[7]; //luca
	 char	Tea;
	//char	Rs10; //not in luca
	 char	Cdcu[3];
	//char	Stsenate[7]; length changed in luca
	//char	Sthouse[7]; length changed in luca
	 char	Stsenate[7]; //luca
	 char	Sthouse[7]; //luca
	 char	Census6[6]; //luca
	//char	Rs4;	
	 char	Statecol[3]; //luca and Dress Rehersal
	 char	Councol[4]; // luca and DR
	 char	Blkcol[6]; // luca and DR
	 char	Blksufcol; //luca and DR
	 char	Zcta[6]; // DR
	//char	Rs5[3];
	//from here are are for non-luca versions
	char	Ctbna00[7]; // Dress Rehersal and 99
	char	Blk00[5]; //Dress Rehersal and 99
	//char	Stsenate97[7]; //tiger 94-97
	//char	Sthouse97[7]; //tiger 94-97
	char	Vtd00[7];  //tiger 94-97 - empty
	//char	Rs11[7]; //tiger 94-97
	//char	Rs12; //tiger 94-97
	//char	Rs13[6]; //tiger 94-97
	//char	Rs14[6]; //tiger 94-97
	//char	Filler; //tiger 94-97
	//char	Sldu[4]; //new in 99 replaces Stsenate
	//char	Sldl[4]; //new in 99 replaces Sthouse
	char	Uga[6];
	char	Blkgrp; //new in 99

	//UA 2000 add URBFLAG00 and URBFLAG90 single chars
	char	Ur, Ur90;
	//tiger cd 108 march 03
	char	Ua00Cor[6];
	char	Ua90Red[6];
	char	Ur90Red;
}RecordTypeS;
typedef struct{
	//char	RecordType;
	//int		Version;
	char	Tlid[11];
	char	Rtsq[4];
	char	Zip4l[5];
	char	Zip4r[5];
}RecordTypeZ;
typedef struct{
	char	Cenid[6];
	char	Polyid[11];
	Geographic_Coordinate Centroid;
}RecordTypeP;
typedef struct{
	double  Longitude, Latitude;
	char    Tlid[11];
	int     Toflag; //0 = from node, 1 = to node    
}Node_type;             
typedef struct{
    char  Id[6];
    char  Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int   Chosen, Flip;    
	//long  Seqnum;
}County_Border_Type;
typedef struct{      
	char  Id[12];    
    char  Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int   Chosen, Flip;    
    //long  Seqnum;
}Tract_Border_Type;
typedef struct{
	char  Id[13];
    char  Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int   Chosen, Flip;    
    //long  Seqnum;
}BlockGroup_Border_Type;
typedef struct{
	char  Id[16];
	char  Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int   Chosen, Flip;    
    //long  Seqnum;
}Block_Border_Type;       
typedef struct{
	char County[6];
	char Id[6];	
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int   Chosen, Flip;    
}Fmcd_Border_Type;
typedef struct{
	char County[6];
	char Id[6];	
	char Id2[6];
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int   Chosen, Flip;    
}Fmcd_Fsmcd_Border_Type;

typedef struct{
	char County[6];
	char Id[6];
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int   Chosen, Flip;    
}Fpl_Border_Type;
typedef struct{
	char County[6];
	char Id[5]; //air
	char Id2[6]; //fair
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int   Chosen, Flip;    
}Air_Border_Type;
typedef struct{
	char County[6];
	char Id[5]; //air
	char Id2[6]; //fair
	char Trust;	
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int   Chosen, Flip;    
}Air00_Border_Type;
typedef struct{
	char County[6];
	char Id[4]; //aitsce
	char Id2[6]; //aits
	char Trust;	
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int   Chosen, Flip;    
}TribalSubDiv_Border_type;
typedef struct{
	char County[6];
	char Id[5];
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int   Chosen, Flip;    
}Vote_Border_Type;
typedef struct{
	char County[6];
	char Id[7];
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int   Chosen, Flip;    
}Vote2000_Border_Type;
typedef struct{
	char County[6];
	char Id[3];
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int   Chosen, Flip;    
}Anrc_Border_Type;
typedef struct{
	char County[6];
	char Id[6];
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int   Chosen, Flip;    
}Anrc_Type3_Border_Type;
typedef struct{
	char County[6];
	char Id[6];
	char Id2[4];
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int   Chosen, Flip;    
}Aits_Border_Type;

typedef struct{
	char County[6];
	int Polyid;
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int	 Chosen, Flip;
}Kgl_Border_Type;
typedef struct{
	char County[6];
	int Polyid;
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int	 Chosen, Flip;
}Land_Border_Type;
typedef struct{
	double Latitude, Longitude;
}Landmark_Node_Type;
typedef struct{
	char County[6];
	char Taz[7];
	char Ctpp[5];
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int Chosen, Flip;
}Taz_Border_Type;
typedef struct{
	char County[6];
	char Uacode[6];
//	char Urbflag;
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int Chosen, Flip;
}Urban_Border_Type;
typedef struct{
	char County[6];
//	char Water[6];
	int Polyid;
	char Water[34];
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int Chosen, Flip;
}Water_Border_Type;
typedef struct{
	char County[6];
	char Cmsamsa[5];
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int Chosen, Flip;
}Cmsamsa_Border_Type;
typedef struct{
	char County[6];
	char Pmsa[5];
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int Chosen, Flip;
}Pmsa_Border_Type;
typedef struct{
	char County[5];
	char Cdcu[3];
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int Chosen, Flip;
}Cdcu_Border_Type;
typedef struct{
	char County[5];
	char Elementary[6];
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int Chosen, Flip;
}Elementary_Border_Type;
typedef struct{
	char County[5];
	char Middle[6];
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int Chosen, Flip;
}Middle_Border_Type;
typedef struct{
	char County[5];
	char Secondary[6];
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int Chosen, Flip;
}Secondary_Border_Type;
typedef struct{
	char County[5];
	char Unified[6];
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int Chosen, Flip;
}Unified_Border_Type;
typedef struct{
	char County[5];
	char House[7];
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int Chosen, Flip;
}State_House_Border_Type;
typedef struct{
	char County[5];
	char Senate[7];
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int Chosen, Flip;
}State_Senate_Border_Type;
typedef struct{      
	char  Id[12];    
    char  Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int   Chosen, Flip;    
    //long  Seqnum;
}Tract00_Border_Type;
typedef struct{
	char  Id[16];
	char  Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int   Chosen, Flip;    
    //long  Seqnum;
}Block00_Border_Type;       
typedef struct{
	char Id[18];
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int   Chosen, Flip;    
}CollectionBlock_Border_Type;
typedef struct{
	char County[5];
	char Id[6];
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int   Chosen, Flip;    
}Zcta_Border_Type;
typedef struct{
	char County[5];
	char Id[6];
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int   Chosen, Flip;    
}UA00Cor_Border_Type; //tiger cd 108 march 03
typedef struct{
	char County[5];
	char Id[6];
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int   Chosen, Flip;    
}UA90Red_Border_Type; //tiger cd 108 march 03

/*typedef struct {
    char  Tlid[11];
    double Frlong, Frlat, Tolong, Tolat;
    int   Chosen, Flip;
}Border_Type;*/
typedef struct{	
	char 	Polyid[11];
	char	Cenid[6];	
	char	State[3];
	char	County[4];
	int 	Waterflag;
	char	Cmsamsa[5];
	char	Pmsa[5];
	char	Fair[6];
	char	Air[6];
	char	Trust;
	char	Anrc[3];
	char	Fccity[6];
	char	Fmcd[6];
	char	Fsmcd[6];
	char	Fpl[6];
	char	Tea;
	char	Cdcu[3];
	char	Stsenate[7];
	char	Sthouse[7];
	char	Census6[6];
	char	Vtd90[7];
	char	Statecol[3];
	char	Councol[4];
	char	Blkcol[6];
	char	Blksufcol;
	char	Zcta[6];
	char	Fair90[6];
	char	Fmcd90[6];
	char	Fpl90[6];
	char	Ctbna90[7];
	char	Blk90[5];
	char	Cd106[3];
	char	Cd108[3];
	char	Sdelm[6];
	char	Ua[6];
	char	Sdsec[6];	
	char	Sduni[6];
	char	Taz[7];
	char	Ua90[5];
	char	Urbflag;
	char	Ctpp[5];
	char	State90[3];
	char	Coun90[4];
	char	Air90[5];
	char	Vote[5];
	char	Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int   Chosen, Flip;    
}Poly_Border_Type;
typedef struct{	
	char 	Polyid[11];
	char	Cenid[6];	
	char	State[3];
	char	County[4];
	int 	Waterflag;
	char	Cmsamsa[5];
	char	Pmsa[5];
	char	Fair[6];
	char	Air[6];
	char	Trust;
	char	Anrc[3];
	char	Fccity[6];
	char	Fmcd[6];
	char	Fsmcd[6];
	char	Fpl[6];
	//char	Tea;
	char	Cdcu[3];
	char	Stsenate[7];
	char	Sthouse[7];
	char	Census7[6];
	char	Vtd90[7];
	char	Statecol[3];
	char	Councol[4];
	char	Blkcol[6];
	char	Blksufcol;
	char	Census6;
	char	Zcta[6];
	char	Fair90[6];
	char	Fmcd90[6];
	char	Fpl90[6];
	char	Ctbna90[7];
	char	Blk90[5];
	char	Cd106[3];
	char	Cd108[3];
	char	Sdelm[6];
	char	Ua[6];
	char	Sdsec[6];	
	char	Sduni[6];
	char	Taz[7];
	char	Ua90[5];
	char	Urbflag;
	char	Ctpp[5];
	char	State90[3];
	char	Coun90[4];
	char	Air90[5];
	char	Vote[5];
	char	Tlid[11];
	char    Ctbna00[7];
	char    Blk00[5];
	char    Vtd00[7];
	double Frlong, Frlat, Tolong, Tolat;
	int   Chosen, Flip;    
}Poly_Border_Type00;

typedef struct{	
	char 	Polyid[11];
	char	Cenid[6];	
	char	State[3];
	char	County[4];
	int 	Waterflag;
	char	Cmsamsa[5];
	char	Pmsa[5];
	char	Fair[6];
	char	Air[6];
	char	Trust;
	char	Anrc[3];
	char	Fccity[6];
	char	Fmcd[6];
	char	Fsmcd[6];
	char	Fpl[6];	
	char	Cdcu[3];
	char	Stsenate[7];
	char	Sthouse[7];
	char	Fair90[6];
	char	Fmcd90[6];
	char	Fpl90[6];
	char	Ctbna90[7];
	char	Blk90[5];
	char	Cd106[3];
	char	Cd108[3];
	char	Sdelm[6];
	char	Sdmid[6];
	char	Sdsec[6];	
	char	Sduni[6];
	char	Taz[7];
	char	Ua90[5];
	char	Urbflag;
	char	Ctpp[5];
	char	State90[3];
	char	Coun90[4];	
	char	Air90[5];
	char	Vote90[5];
	char	Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int   Chosen, Flip;    
}Poly_Border_Type97;
typedef struct{	//structure is type S codes, type A codes, type 3 codes
	char 	Polyid[11];
	char	Cenid[6];	
	char	StateFile[3];//start typeSs
	char	CountyFile[4]; 
	int 	Waterflag;  
	char	Cmsamsa[5];
	char	Pmsa[5];
	char	AIANHH[6];
	char	AIANHHCE[6];
	char	Trust;
	char	State00[3];
	char	County00[4];
	char	Concit[6];
	char	Cousub[6];
	char	Submcd[6];
	char	Place[6];
	char	Tract[7];
	char	Block[5];
	char	Cdcu[3];
	char	Sldu[7]; //leave long for backward compatibility
	char	Sldl[7];
	char	Uga[6];
	char	Blkgrp;
	char	Vtd[7];
	char	Statecol[3];
	char	Councol[4];
	char	Blkcol[6];
	char	Blksufcol;	
	char	Zcta[6];  //end type S
	char	AIANHH90[6]; //start type A
	char	Cousub90[6];
	char	Place90[6];
	char	Tract90[7];
	char	Block90[5];
	char	Cd106[3];
	char	Cd108[3];
	char	Sdelm[6];
	char	Sdsec[6];	
	char	Sduni[6];
	char	Taz[7];
	char	Ua90[6];
	char	UR90;
	char	State90[3];
	char	Coun90[4];
	char	AIANHHCE90[5]; //end type A
	char	Anrccu[6];  //start type 3
	char	Aitsce[4];
	char	Aits[6]; //end type 3
	char	Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;	
	int   Chosen, Flip;    
}Poly_Border_Type100;
//2000 urban starts here
typedef struct{
	char County[6];
	char Puma[6];
	char Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;
	int Chosen, Flip;
}Puma_Border_Type;
//ua00 uses urb 
typedef struct{	//structure is type S codes, type A codes, type 3 codes
	char 	Polyid[11];
	char	Cenid[6];
	char	StateFile[3];//start typeSs
	char	CountyFile[4]; 
	int 	Waterflag;  
	char	Cmsamsa[5];
	char	Pmsa[5];
	char	AIANHH[6];
	char	AIANHHCE[5];
	char	Trust;
//	char	State00[3];
//	char	County00[4];
	char	Concit[6];
	char	Cousub[6];
	char	Submcd[6];
	char	Place[6];
	char	Tract[7];
	char	Block[5];
	char	Cdcu[3];
	char	Sldu[7]; //leave long for backward compatibility
	char	Sldl[7];
	char	Uga[6];
	char	Blkgrp;
	char	Vtd[7];
	char	Statecol[3];
	char	Councol[4];
	char	Blkcol[6];
	char	Blksufcol;	
	char	Zcta[6];
	char	Ur;
	char	Ur90; //end type S
	char	AIANHH90[6]; //start type A
	char	Cousub90[6];	
	char	Place90[6];
	char	Tract90[7];
	char	Block90[5];
	char	Cd106[3];
	char	Cd108[3];
	char	Sdelm[6];
	char	Puma[6];	
	char	Sduni[6];
	char	Taz[7];
	char	Ua[6];
	char	Ua90[6];
	char	State90[3];
	char	Coun90[4];
	char	AIANHHCE90[5]; //end type A
	char	Anrc[6];  //start type 3
	char	Aitsce[4];
	char	Aits[6]; //end type 3
	char	Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;	
	int   Chosen, Flip;    
}Poly_Border_TypeUrban;

typedef struct{	//structure is type S codes, type A codes, type 3 codes
	char 	Polyid[11];
	char	Cenid[6];
	char	StateFile[3];//start typeSs
	char	CountyFile[4]; 
	int 	Waterflag;  
	char	Cmsamsa[5];
	char	Pmsa[5];
	char	AIANHH[6];
	char	AIANHHCE[5];
	char	Trust;
//	char	State00[3];
//	char	County00[4];
	char	Concit[6];
	char	Cousub[6];
	char	Submcd[6];
	char	Place[6];
	char	Tract[7];
	char	Block[5];
	char	Cdcu[3];
	char	Sldu[7]; //leave long for backward compatibility
	char	Sldl[7];
	char	Uga[6];
	char	Blkgrp;
	char	Vtd[7];
	char	UA00Cor[6];
	char	UA90Red[6];
	char	Ur90Red;	
	char	Zcta[6];
	char	Ur;
	char	Ur90; //end type S
	char	AIANHH90[6]; //start type A
	char	Cousub90[6];	
	char	Place90[6];
	char	Tract90[7];
	char	Block90[5];
	char	Cd106[3];
	char	Cd108[3];
	char	Sdelm[6];
	char	Puma[6];	
	char	Sduni[6];
	char	Taz[7];
	char	Ua[6];
	char	Ua90[6];
	char	State90[3];
	char	Coun90[4];
	char	AIANHHCE90[5]; //end type A
	char	Anrc[6];  //start type 3
	char	Aitsce[4];
	char	Aits[6]; //end type 3
	char	Tlid[11];
	double Frlong, Frlat, Tolong, Tolat;	
	int   Chosen, Flip;    
}Poly_Border_TypeCD108;

char Types[] = "ABCDEFHX";


	
