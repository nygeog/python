/* mydlldlg.cpp : implementation file
Written by Bruce Ralston
This file manages the only dialog in the dll
*/

#include "xceedzip.h"
#include <stdlib.h>

#include "stdafx.h"
#include <direct.h>
#include "mydll.h"
#include "mydlldlg.h"



#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#define XcdErrorNothingToDo 140
extern FILE *LOG;
//variable declarations
extern int TigerVersion;

extern CString Outfiletitle;
//extern CString Outfilepath;
extern CString Outdir;
//extern functions
extern void ProcessTiger(mydlldlg *);
CString Zipdirectory;
int Unlinkthem;
extern int IsZip;
CString Originalinputfilestr;
/////////////////////////////////////////////////////////////////////////////
// mydlldlg dialog


mydlldlg::mydlldlg(CWnd* pParent /*=NULL*/)
	: CDialog(mydlldlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(mydlldlg)
	m_strProcess = _T("");
	m_strVersion = _T("");
	m_strOutFiles = _T("");
	m_strClip = _T("");
	m_strLayer = _T("");
	m_strFips = _T("");
	m_strOption = _T("");
	m_strStatus = _T("");
	//}}AFX_DATA_INIT
}


void mydlldlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(mydlldlg)
	DDX_Control(pDX, IDC_PROGRESS1, m_Progress);
	DDX_Text(pDX, IDC_PROCESS, m_strProcess);
	DDX_Control(pDX, IDC_XCEEDZIPCTRL1, m_zip);
	DDX_Text(pDX, IDC_VERSION, m_strVersion);
	DDX_Text(pDX, IDC_OUTFILES, m_strOutFiles);
	DDX_Text(pDX, IDC_CLIP, m_strClip);
	DDX_Text(pDX, IDC_LAYER, m_strLayer);
	DDX_Text(pDX, IDC_FIPS, m_strFips);
	DDX_Text(pDX, IDC_OUTOPTION, m_strOption);
	DDX_Text(pDX, IDC_STATUS, m_strStatus);
	//}}AFX_DATA_MAP
	
}


BEGIN_MESSAGE_MAP(mydlldlg, CDialog)
	//{{AFX_MSG_MAP(mydlldlg)
	ON_BN_CLICKED(IDC_GO, OnGo)
	ON_BN_CLICKED(IDC_CANCEL, OnCancel)
	ON_BN_CLICKED(IDC_VERSION, OnVersion)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// mydlldlg message handlers
void mydlldlg::OnCancel() 
{
	fclose(LOG);
	CDialog::OnCancel();
}

void mydlldlg::ErrorMessage(CString s)
{
	fprintf(LOG,"%s\n",s);
}
void mydlldlg::ErrorMessageStop(CString s)
{
	fprintf(LOG,"%s\n",s);

	OnCancel();
}

BOOL mydlldlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	CString titlestring;
	titlestring = "TGR2SHP from GIS Tools";
	SetWindowText(titlestring);
	CString extension;
	if (IsZip == 1)
	{
		Zipdirectory = Outdir + "\\unzipped";	
		int result = _mkdir(Zipdirectory);
		m_zip.SetExtractDirectory(Zipdirectory);							
		m_zip.SetZipFileName(InputFileStr);		
		m_zip.SetFilesToProcess("*.rt?\r*.bw?\r*.f6?");				
		int retval = m_zip.List();
		if (retval == XcdErrorNothingToDo) //tiger 97
		{					
			AfxMessageBox("cound not find files to unzip");
		}
		m_zip.Extract(0);				
		switch (TigerVersion)
		{
		case 94:
			extension = ".f61";
			break;
		case 95:
			extension = ".bw1";
			break;
		default:
			extension = ".rt1";
			break;
		}
		Originalinputfilestr = InputFileStr;
		InputFileStr = Zipdirectory+"\\"+Outfiletitle+extension;					
	}
	UpdateData(FALSE);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void mydlldlg::OnGo() 
{
	// TODO: Add your control notification handler code here
	ProcessTiger(this);	
	if (IsZip == 1) //need to clean up
	{
		Unlinkthem = 1;
		m_zip.SetZipFileName(Originalinputfilestr);
		m_zip.SetFilesToProcess("*.rt?\r*.bw?\r*.f6?");
		m_zip.List();
		Unlinkthem = 0;
	}
	CDialog::OnOK();
}

void mydlldlg::OnGo2()
{
	OnGo();
}










BEGIN_EVENTSINK_MAP(mydlldlg, CDialog)
    //{{AFX_EVENTSINK_MAP(mydlldlg)
	ON_EVENT(mydlldlg, IDC_XCEEDZIPCTRL1, 6 /* Listing */, OnListingXceedzipctrl1, VTS_PBSTR VTS_I4 VTS_I4 VTS_I4 VTS_I2 VTS_PBSTR VTS_I4 VTS_I2 VTS_I2 VTS_I2 VTS_I2 VTS_I2 VTS_PBSTR)
	//}}AFX_EVENTSINK_MAP
END_EVENTSINK_MAP()


void mydlldlg::OnListingXceedzipctrl1(BSTR FAR* FileName, long Size, long PSize, long Processed, short FileAttr, BSTR FAR* FTime, long CRC, short Ratio, short Completion, short Method, short Encrypted, short ComLen, BSTR FAR* Comment) 
{
	// TODO: Add your control notification handler code here
if (Unlinkthem)
	{
		CString fname,fullname;
		fname = *FileName;
		fullname = Zipdirectory+"\\"+fname;
		unlink(fullname);
	}	
}

void mydlldlg::OnVersion() 
{
	// TODO: Add your control notification handler code here
	
}
