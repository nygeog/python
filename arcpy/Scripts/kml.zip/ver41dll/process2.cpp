#include "stdafx.h"
#include <math.h>
#include <stdlib.h>
#include <malloc.h>
#include <string.h>


#include "mydll.h"
#include "mydlldlg.h"
#include "dbase.h"
#include "shape.h"
#include "Tgr2shp.h"



#define BUFFLEN 250                     
#define PI				3.1415926535
#define RAD				6367650.0
#define RADIAN(x)			(((x) * PI / 180.0))
#define STATUS_MILE			1609.344
#define METERPERMILE			STATUS_MILE

extern int TigerVersion;
extern int Position, IPosition;
extern int Size;
extern CString Outfiletitle;
extern CString Outfilepath;

extern CString Fipval;
extern FILE * LOG;
extern int	 Watercut;
mydlldlg * Ptrdlg;
char Fipscode[6];
CString Curcounty;
CString Curstate;
RecordType1  *Type1s;
RecordType2  *Type2s;
RecordType3  *Type3s;
RecordTypeC	 *TypeCs;
RecordType9  *Type9s;
RecordTypeI	 *TypeIs;
RecordType5	 *Type5s;
RecordType7	 *Type7s;
RecordType8	 *Type8s;
RecordTypeA  *TypeAs;
RecordType4  *Type4s;
RecordType6	 *Type6s;
RecordTypeZ  *TypeZs;
RecordTypeS  *TypeSs;
//Node_type *Nodes;	
FILE *in;
long Count1, Count2, Count3, CountC, Count9, CountI, Count5, Count7, Count8, 
   CountA, Count4, Count6, CountZ, CountS;
long Counts[8], Polycounts[1], APolycounts[14], SPolycounts[13], AllACount, AllSCount;
int	 MissingFile;

char	Record[BUFFLEN];
long num;
int MaxShapeRecords;
double CurrentMinX,CurrentMinY,CurrentMaxX,CurrentMaxY;
double FileMinX,FileMinY,FileMaxX,FileMaxY;
int Npts;
char MsgA[60],MsgB[60],MsgC[60],MsgD[60],MsgE[60],MsgF[60],MsgH[60],MsgX[60];
Geographic_Coordinate *Pts;
void Parse_Type1_Record(long);
void Parse_Type2_Record(long);
void Parse_Type3_Record(long);
void Parse_TypeC_Record(long);
void Parse_TypeI_Record(long);
void Parse_Type9_Record(long);
void Parse_Type5_Record(long);
void Parse_Type7_Record(long);
void Parse_Type8_Record(long);
void Parse_TypeA_Record(long);
void Parse_Type4_Record(long);
void Parse_Type6_Record(long);
void Parse_TypeZ_Record(long);
void Parse_TypeS_Record(long);
void Nscanf(char *, int, const char *, void *);
void Ascanf(char *, int, char *);
typedef int (*compfn)(const void*, const void*);
int  Compare1(RecordType1 *, RecordType1 *);
int  Compare1A(RecordType1 *, RecordType1 *);
int  Compare2(RecordType2 *, RecordType2 *);
int  CompareNodes(Node_type *, Node_type *);
int  Compare3(RecordType3 *, RecordType3 *);
int  CompareI(RecordTypeI *, RecordTypeI *);
int	 Compare9(RecordType9 *, RecordType9 *);
int  Compare5(RecordType5 *, RecordType5 *);
int  Compare7(RecordType7 *, RecordType7 *);
int  Compare8(RecordType8 *, RecordType8 *);
int  CompareA(RecordTypeA *, RecordTypeA *);
int  Compare4(RecordType4 *, RecordType4 *);
int  Compare6(RecordType6 *, RecordType6 *);
int  CompareZ(RecordTypeZ *, RecordTypeZ *);
int  CompareS(RecordTypeS *, RecordTypeS *);
int	 CompareCounty(County_Border_Type *, County_Border_Type *);
int  CompareTract(Tract_Border_Type *, Tract_Border_Type *);
int  CompareGroup(BlockGroup_Border_Type *, BlockGroup_Border_Type *);
int  CompareBlock(Block_Border_Type *, Block_Border_Type *);
int  CompareFmcd(Fmcd_Border_Type *, Fmcd_Border_Type *);
int  CompareFpl(Fpl_Border_Type *, Fpl_Border_Type *);
int  CompareAir(Air_Border_Type *, Air_Border_Type *);
int  CompareVote(Vote_Border_Type *, Vote_Border_Type *);
int  CompareAnrc(Anrc_Border_Type *, Anrc_Border_Type *);
int  CompareKgl(Kgl_Border_Type *, Kgl_Border_Type *);
int  CompareLand(Land_Border_Type *, Land_Border_Type *);
int  CompareTaz(Taz_Border_Type *, Taz_Border_Type *);
int  CompareUrb(Urban_Border_Type *, Urban_Border_Type *);
int  CompareWat(Water_Border_Type *, Water_Border_Type *);
int  CompareElementary(Elementary_Border_Type *, Elementary_Border_Type *);
int  CompareMiddle(Middle_Border_Type *, Middle_Border_Type *);
int  CompareSecondary(Secondary_Border_Type *, Secondary_Border_Type *);
int  CompareUnified(Unified_Border_Type *, Unified_Border_Type *);
int  CompareMsa(Cmsamsa_Border_Type *, Cmsamsa_Border_Type *);
int  ComparePmsa(Pmsa_Border_Type *, Pmsa_Border_Type *);
int  CompareCdcu(Cdcu_Border_Type *, Cdcu_Border_Type *);
int  CompareHouse(State_House_Border_Type *, State_House_Border_Type *);
int  CompareSenate(State_Senate_Border_Type *, State_Senate_Border_Type *);
int  CompareCollectionBlock(CollectionBlock_Border_Type *, CollectionBlock_Border_Type *);
int ComparePoly(Poly_Border_Type *, Poly_Border_Type * );
int ComparePoly97(Poly_Border_Type97 *, Poly_Border_Type97 *);
//void main(void);
void Get_Type1(void);
void Get_Type2(void);
void Get_Type3(void);
void Get_TypeC(void);
void Get_Type9(void);
void Get_TypeI(void);
void Get_Type5(void);
void Get_Type7(void);
void Get_Type8(void);
void Get_TypeA(void);
void Get_Type4(void);
void Get_Type6(void);
void Get_TypeZ(void);
void Get_TypeS(void);
void Build_Lines_And_Nodes(void);
void Get_Shape_Points(char *, int);
void Match_Poly_Lines_County90(void);
void Match_Poly_Lines_Countycu(void);
void Match_Poly_Lines_Tract90(void);
void Match_Poly_Lines_Group90(void);
void Match_Poly_Lines_Block90(void);
void Match_Poly_Lines_Fmcd90(void);
void Match_Poly_Lines_Fmcdcu(void);
void Match_Poly_Lines_Fpl90(void);
void Match_Poly_Lines_Fplcu(void);
void Match_Poly_Lines_Air90(void);
void Match_Poly_Lines_Aircu(void);
void Match_Poly_Lines_Vote(void);
void Match_Poly_Lines_Anrc(void);
void Match_Poly_Lines_Kgl(void);
void Match_Poly_Lines_Land(void);
void Match_Poly_Lines_Taz(void);
void Match_Poly_Lines_Urban90(void);
void Match_Poly_Lines_Water(void);
void Match_Poly_Lines_Cmsamsa(void);
void Match_Poly_Lines_Pmsa(void);
void Match_Poly_Lines_Cdcu(void);
void Match_Poly_Lines_Elementary(void);
void Match_Poly_Lines_Middle(void);
void Match_Poly_Lines_Secondary(void);
void Match_Poly_Lines_Unified(void);
void Match_Poly_Lines_House(void);
void Match_Poly_Lines_Senate(void);
void Match_Poly_Lines_Collection2000(void);			
void Match_Poly_Lines_All(void);
void Match_Poly_Lines_All97(void);
//void Match_Poly_Lines_Tract2000(void);
//void Match_Poly_Lines_Block2000(void);
void Build_Poly_Shape(char *);
void KglAdd(void);
void Write_Alternate_Fenames(void);
void Write_Additional_Addresses(void);
void Write_Additional_Zips(void);
void ProcessTiger(mydlldlg *);
void Write_Line_Update(int, int, int);
double Great_Circle_Distance(Geographic_Coordinate *, Geographic_Coordinate *);
extern shape_header_t * Create_Shape_Header(int);
extern int SHP_Write_Header(FILE*, shape_header_t*);
extern int SHP_Write_Record_Header(FILE* , shape_record_header_t* );
extern int SHP_Write_Arc(FILE*,shape_arc_t *);
extern int SHP_Write_Index(FILE*, shape_index_record_t* );
extern int SHP_Write_Point(FILE*, shape_point_t *);
extern int SHP_Write_Poly(FILE *, shape_poly_t *);
char * Get_TypeC_Name(int, char *, char *);
void Build_TypeI_Borders(int);
void Build_Landmark_Nodes(void);
int Get_Kgl(char *, char *);
int Get_Feature(char *);
int Get_Land(char *, char *);
int Get_Land7(int);
int Get_Taz(char *, char *);
int Get_Water(char *, char *);


void ProcessTiger(mydlldlg* ptrdlg)
{
	int loc, dopolys;
	CString fname;
	CString msg;
	int lineson;
	
	Ptrdlg = ptrdlg;	
	
	MissingFile = 0;
	//initialize count variables and pointers
	Count1 = Count2 = Count3 = CountC = Count9 = CountI = Count5 = 0L;
	Count7 = Count8 = CountA = Count4 = Count6 = CountZ = CountS = 0L;
	Type1s = NULL;
	Type2s = NULL;
	Type3s = NULL;
	Type4s = NULL;
	Type5s = NULL;
	Type6s = NULL;
	Type7s = NULL;
	Type8s = NULL;
	Type9s = NULL;
	TypeAs = NULL;
	TypeCs = NULL;
	TypeIs = NULL;
	TypeSs = NULL;
	TypeZs = NULL;
	AllACount = 0;
	AllSCount = 0;

	int typeSon = 0;
	while (1)
	{
		in = fopen(ptrdlg->InputFileStr,"r");		
		if (in == NULL)
		{
			msg.Format("Could not open file %s. Program will terminate",ptrdlg->InputFileStr);
			ptrdlg->ErrorMessage(msg);
			break;
	
		}
		//for (int i = 0; i < 9; i++)
		//	Polycounts[i] = 0;
		Get_Type1();
		
		if (MissingFile == -1)
			break;
		loc = Ptrdlg->InputFileStr.ReverseFind('.');
		fname = Ptrdlg->InputFileStr.Left(loc + 1);
		switch (TigerVersion)
		{
		case 95:
			fname = fname + "bw2";	
			break;
		case 94:
			fname = fname + "f62";
			break;
		case 97:
			fname = fname + "rt2";
			break;
		case 98: //luca
			fname = fname + "rt2";
			break;
		default:
			msg.Format("Unrecongnized TIGER version. Program will terminate");
			MissingFile = -1;
			break;
		}
		if (MissingFile == -1)
			break;
		in = fopen(fname,"r");		
		if (in == NULL)
		{
			ptrdlg->ErrorMessage("Could not open Type 2 file. Processing for this county will terminate");
			break;
		}
		Get_Type2();
		
		if (MissingFile == -1)
			break;
		Pts = (Geographic_Coordinate *)calloc(MaxShapeRecords*10+2,sizeof(Geographic_Coordinate));	
		Build_Lines_And_Nodes();
		if (MissingFile == -1)
			break;
		lineson = 0;
		for (int i = 0; i < 8; i++)
		{
			if (Ptrdlg->IsOn[i])
				lineson = 1;
			break;
		}
		if (lineson)
		{
			loc = Ptrdlg->InputFileStr.ReverseFind('.');
			fname = Ptrdlg->InputFileStr.Left(loc + 1);
			switch (TigerVersion)
			{
			case 95:
				fname = fname + "bw4";	
				break;
			case 94:
				fname = fname + "f64";
				break;
			case 97:
				fname = fname + "rt4";
				break;
			case 98: //luca
				fname = fname + "rt4";
			break;
			default:
				msg.Format("Unrecongnized TIGER version. Program will terminate");
				MissingFile = -1;
				break;
			}
			if (MissingFile == -1)
				break;
			in = fopen(fname,"r");			
			if (in == NULL)
			{
				ptrdlg->ErrorMessage("Could not open Type 4 file. No alternative feature names will be generated.");
				MissingFile = 2;
			}				
			if (MissingFile == 2)
				Count4 = 0;
			else
				Get_Type4();
			
			if ((MissingFile != -1)	&& (MissingFile != 2))
			{
				loc = Ptrdlg->InputFileStr.ReverseFind('.');
				fname = Ptrdlg->InputFileStr.Left(loc + 1);
				switch (TigerVersion)
				{
				case 95:
					fname = fname + "bw5";	
					break;
				case 94:
					fname = fname + "f65";
					break;
				case 97:
					fname = fname + "rt5";
					break;
				case 98: //luca
					fname = fname + "rt5";
					break;
				default:
					msg.Format("Unrecongnized TIGER version. Program will terminate");
					MissingFile = -1;
					break;
				}
				in = fopen(fname,"r");				
				if (in == NULL)
				{		
					ptrdlg->ErrorMessage("Could not open Type 5 file. No alternative feature names will be generated.");
					MissingFile = 3;
				}				
				if (MissingFile != 3)
					Get_Type5();
				else
					Count5 = 0;					
				if ((Count4 > 0) && (Count5 > 0))
				{
					Ptrdlg->m_strProcess = "Building Alternate Names File";
					Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
					Write_Alternate_Fenames();
					free(Type4s);
					if (!Ptrdlg->IsOn[22])
						free(Type5s);
				}
			}
		}
		if (MissingFile > 0) //if type 4 or 5 missing, we can still continue
			MissingFile = 0;
		if (MissingFile == -1)
			break;
		if (Ptrdlg->IsOn[0]) //roads are on
		{
			loc = Ptrdlg->InputFileStr.ReverseFind('.');
			fname = Ptrdlg->InputFileStr.Left(loc + 1);
			switch (TigerVersion)
			{
			case 95:
				fname = fname + "bw6";	
				break;
			case 94:
				fname = fname + "f66";
				break;
			case 97:
				fname = fname + "rt6";
				break;
			case 98:
				fname = fname + "rt6";
				break;
			default:
				msg.Format("Unrecongnized TIGER version. Program will terminate");
				MissingFile = -1;
				break;
			}
			if (MissingFile == -1)
				break;
			in = fopen(fname,"r");
			if (in == NULL)
			{
				ptrdlg->ErrorMessage("Could not open Type 6 file. No additional address ranges and zip codes will be processed.");
				MissingFile = 2;
			}				
			if (MissingFile == 2)
				Count6 = 0;
			else
				Get_Type6();
			
			if ((MissingFile != -1)	&& (MissingFile != 2))
			{
				loc = Ptrdlg->InputFileStr.ReverseFind('.');
				fname = Ptrdlg->InputFileStr.Left(loc + 1);
				switch (TigerVersion)
				{
				case 95:
					fname = fname + "bwz";	
					break;
				case 94:
					fname = fname + "f6z";
					break;
				case 97:
					fname = fname + "rtz";
					break;
				case 98: //luca
					fname = fname + "rtz";
					break;
				default:
					msg.Format("Unrecongnized TIGER version. Program will terminate");
					MissingFile = -1;
					break;
				}
				if (MissingFile == -1)
					break;
				in = fopen(fname,"r");
				
				if (in == NULL)
				{
					ptrdlg->ErrorMessage("Could not open Type z file. No zip+4 information will be generated.");
					MissingFile = 3;
				}				
				if (MissingFile != 3)			
					Get_TypeZ();
				else
					CountZ = 0;					
				if (Count6 > 0)// && (CountZ > 0))
				{
					Ptrdlg->m_strProcess = "Building Additional Address Info File";
					Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
					Write_Additional_Addresses();					
					free(Type6s);
				}
				if (CountZ > 0)
				{
					Ptrdlg->m_strProcess = "Building Zip+4 Info File";
					Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);					
					Write_Additional_Zips();
					free(TypeZs);
				}
			}
		}

		if (MissingFile > 0) //if type 6 or Z are messed up, we can still continue
			MissingFile = 0;
		if (MissingFile == -1)
			break;
		//this finishes the line sections.  Now it is time to do polys
		//first we will resort the type1 records
		while (MissingFile == 0)
		{
			dopolys = 0;
			for (i = 8; i < 39; i++) // all polys might use type c, so check first
			{
				if (Ptrdlg->IsOn[i])
				{
					dopolys = 1;
					break;
				}
			}
			if (dopolys == 0) //no polygons so quit
			{
				fprintf(LOG,"Finished\n");
				return;
			}	
			//if any ploys then get type A and type S
			Ptrdlg->m_Progress.SetPos(0);
			Ptrdlg->m_strProcess.Format("Sorting");
			Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);	
			qsort((void *)Type1s,Count1,sizeof(RecordType1),(compfn)Compare1);
			loc = Ptrdlg->InputFileStr.ReverseFind('.');
			fname = Ptrdlg->InputFileStr.Left(loc + 1);
			switch (TigerVersion)
			{
			case 95:
				fname = fname + "bwc";	
				break;
			case 94:
				fname = fname + "f6c";
				break;
			case 97:
				fname = fname + "rtc";
				break;
			case 98: //luca
				fname = fname + "rtc";
				break;
			default:
				msg.Format("Unrecongnized TIGER version. Program will terminate");
				MissingFile = -1;
				break;
			}
			if (MissingFile == -1)
				break;
			in = fopen(fname,"r");
				
			if (in == NULL)
			{				
				ptrdlg->ErrorMessage("Could not open Type c file. No polygon names will be generated");					
				MissingFile = 1;
			}	
			if (MissingFile == 0)
				Get_TypeC();
			else
				CountC == 0;
			if (MissingFile == -1)
				break;
			if ((Ptrdlg->IsOn[17]) || (TigerVersion < 97) || (Ptrdlg->IsOn[38])) // voting districts)
			{
				
				//now get type3 records
				loc = Ptrdlg->InputFileStr.ReverseFind('.');
				fname = Ptrdlg->InputFileStr.Left(loc + 1);
				switch (TigerVersion)
				{
				case 95:
					fname = fname + "bw3";	
					break;
				case 94:
					fname = fname + "f63";
					break;
				case 97:
					fname = fname + "rt3";
					break;
				case 98: //luca
					fname = fname + "rt3";
					break;
				default:
					msg.Format("Unrecongnized TIGER version. Program will terminate");
					MissingFile = -1;
					break;
				}
				if (MissingFile == -1)
					break;
				in = fopen(fname,"r");
				
				if (in == NULL)
				{			
					ptrdlg->ErrorMessage("Could not open Type 3 file. No Voting Districts 90 will be generated");
					MissingFile++;
					break;
				}
				Get_Type3();
			
				if (MissingFile == -1)
					break;			
			}
			if (MissingFile == -1)
				break;
			Curcounty = Fipval.Right(3);
			Curstate = Fipval.Left(2);
			/*
			Match_Poly_Lines_Vote();
			free(Type3s);			
			//break;
		
		
			if (MissingFile == -1)
				break;
		*/
			if (dopolys)
			{
				loc = Ptrdlg->InputFileStr.ReverseFind('.');
				fname = Ptrdlg->InputFileStr.Left(loc + 1);
				switch (TigerVersion)
				{
				case 95:
					fname = fname + "bwi";	
					break;
				case 94:
					fname = fname + "f6i";
					break;
				case 97:
					fname = fname + "rti";
					break;
				case 98: //luca
					fname = fname + "rti";
					break;
				default:
					msg.Format("Unrecongnized TIGER version. Program will terminate");
					MissingFile = -1;
					break;
				}
				if (MissingFile == -1)
					break;
				
				in = fopen(fname,"r");
				if (in == NULL)
				{			
					ptrdlg->ErrorMessage("Could not open Type i file. No KGLs,Landmark,Type A nor Type S polygons will be generated");
					break;

				}		
				
				Get_TypeI();			
			
				if (MissingFile == -1)
					break;
				//moved typeS and typeA here 12/19
				loc = Ptrdlg->InputFileStr.ReverseFind('.');
				fname = Ptrdlg->InputFileStr.Left(loc + 1);
				switch (TigerVersion)
				{
				case 95:
					fname = fname + "bwa";	
					break;
				case 94:
					fname = fname + "f6a";
					break;
				case 97:
					fname = fname + "rta";
					break;
				case 98: //luca
					fname = fname + "rta";
					break;
				default:
					msg.Format("Unrecongnized TIGER version. Program will terminate");
					MissingFile = -1;
					break;
				}
				if (MissingFile == -1)
					break;
				in = fopen(fname,"r");
				if (in == NULL)
				{			
					ptrdlg->ErrorMessage("Could not open Type a file. No Type A polygons will be generated");
					MissingFile = 6;
				}				
				if (MissingFile != 6)
					Get_TypeA();	
				else
					break;
				if (MissingFile == -1)
					break;						
				Build_TypeI_Borders(2);				
			
				loc = Ptrdlg->InputFileStr.ReverseFind('.');
				fname = Ptrdlg->InputFileStr.Left(loc + 1);
				switch (TigerVersion)
				{
				case 95:
					fname = fname + "bws";	
					break;
				case 94:
					fname = fname + "f6s";
					break;
				case 97:
					fname = fname + "rts";
					break;
				case 98: //luca
					fname = fname + "rts";
					break;
				default:
					msg.Format("Unrecongnized TIGER version. Program will terminate");
					MissingFile = -1;
					break;
				}
				if (MissingFile == -1)
					break;
				in = fopen(fname,"r");
				if (in == NULL)
				{			
					ptrdlg->ErrorMessage("Could not open Type s file. No Type S polygons will be generated");
					MissingFile = 7;
				}				
				if (MissingFile != 7)
					Get_TypeS();	
				else
					break;
				if (MissingFile == -1)
					break;		
				Build_TypeI_Borders(3); //TYPE S POLYS		
			
			}
			if (MissingFile == -1)
				break;
			if (Ptrdlg->IsOn[17])
				Match_Poly_Lines_Vote();
			//if (Count3 > 0)
			//	free(Type3s);			
			
			if (MissingFile == -1)
				break;
		//
		//check if Kgl, landmarks, or water is on
			if ((Ptrdlg->IsOn[22]) || (Ptrdlg->IsOn[23]) || (Ptrdlg->IsOn[31]))
			{
				if (Ptrdlg->IsOn[22])
				{				
					loc = Ptrdlg->InputFileStr.ReverseFind('.');
					fname = Ptrdlg->InputFileStr.Left(loc + 1);
					switch (TigerVersion)
					{
					case 95:
						fname = fname + "bw9";	
						break;
					case 94:
						fname = fname + "f69";
						break;
					case 97:
						fname = fname + "rt9";
						break;
					case 98: //luca
						fname = fname + "rt9";
						break;
					default:
						msg.Format("Unrecongnized TIGER version. Program will terminate");
						MissingFile = -1;
						break;
					}
					if (MissingFile == -1)
						break;
					in = fopen(fname,"r");
					if (in == NULL)
					{
						ptrdlg->ErrorMessage("Could not open Type 9 file. No KGL names will be generated");
						MissingFile = 2;
					}				
					
					if (MissingFile != 2)			
						Get_Type9();	
					else
						Count9 = 0;
					
					if (MissingFile == -1)
						break;				
					if (!lineson)
					{
						loc = Ptrdlg->InputFileStr.ReverseFind('.');
						fname = Ptrdlg->InputFileStr.Left(loc + 1);
						switch (TigerVersion)
						{
						case 95:
							fname = fname + "bw5";	
							break;
						case 94:
							fname = fname + "f65";
							break;
						case 97:
							fname = fname + "rt5";
							break;
						case 98: //luca
							fname = fname + "rt5";
							break;
						default:
							msg.Format("Unrecongnized TIGER version. Program will terminate");
							MissingFile = -1;
							break;
						}
						if (MissingFile == -1)
							break;
						in = fopen(fname,"r");
						if (in == NULL)
						{				
							ptrdlg->ErrorMessage("Could not open Type 5 file. No KGL addresses will be generated.");
							MissingFile = 3;
						}				
						if (MissingFile != 3)
							Get_Type5();
						else
							Count5 = 0;
					}
					if (MissingFile == -1)
						break;
				}
				if (MissingFile == -1)
					break;
				Build_TypeI_Borders(0);
			
				if (MissingFile == -1)
					break;
				if (Ptrdlg->IsOn[22])
				{
					Match_Poly_Lines_Kgl();
					if (MissingFile == -1)
						break;				
					if (Count9 > 0)
					{
						KglAdd();
						free(Type9s);
					}
					if (Count5 > 0)
						free(Type5s);
				}
			
				if ((Ptrdlg->IsOn[23]) || (Ptrdlg->IsOn[31]))
				{
					loc = Ptrdlg->InputFileStr.ReverseFind('.');
					fname = Ptrdlg->InputFileStr.Left(loc + 1);
					switch (TigerVersion)
					{
					case 95:
						fname = fname + "bw7";	
						break;
					case 94:
						fname = fname + "f67";
						break;
					case 97:
						fname = fname + "rt7";
						break;
					case 98: //luca
						fname = fname + "rt7";
						break;
					default:
						msg.Format("Unrecongnized TIGER version. Program will terminate");
						MissingFile = -1;
						break;
					}
					if (MissingFile == -1)
						break;
					in = fopen(fname,"r");
					if (in == NULL)
					{				
						ptrdlg->ErrorMessage("Could not open Type 7 file. No Landmark points or polys will be generated");
						MissingFile = 4;				
					}	
					if (MissingFile != 4)
					{	
					
						Get_Type7();
			
						if (MissingFile == -1)
							break;
						loc = Ptrdlg->InputFileStr.ReverseFind('.');
						fname = Ptrdlg->InputFileStr.Left(loc + 1);
						switch (TigerVersion)
						{
						case 95:
							fname = fname + "bw8";	
							break;
						case 94:
							fname = fname + "f68";
							break;
						case 97:
							fname = fname + "rt8";
							break;
						case 98: //luca
							fname = fname + "rt8";
							break;
						default:
							msg.Format("Unrecongnized TIGER version. Program will terminate");
							MissingFile = -1;
							break;
						}
						if (MissingFile == -1)
							break;
						in = fopen(fname,"r");
						if (in == NULL)
						{						
							ptrdlg->ErrorMessage("Could not open Type 8 file. No Landmark polys will be generated");
							MissingFile = 5;					
						}	
						if (MissingFile != 5)
						{
							Get_Type8();
			
							if (MissingFile == -1)
								break;
						
							Build_TypeI_Borders(1);
			
							if (MissingFile == -1)
								break;
							if (Ptrdlg->IsOn[23])
								Match_Poly_Lines_Land();
							if (MissingFile == -1)
								break;
						}
						if (Ptrdlg->IsOn[23])
							Build_Landmark_Nodes();
						if (MissingFile == -1)
							break;
					}
					if (!Ptrdlg->IsOn[31]) 
					{
						if (Count7 > 0)
							free(Type7s);
						if (Count8 > 0)
							free(Type8s);
					}
					if (MissingFile == -1)
						break;
				}
		
			}
			if (MissingFile == -1)
				break;
		/* moved this to dopolys 12/19
		//need the if for typeA polys
		int typeAon = 0;
		for (i = 8; i < 19; i++)
		{
			if (i == 13) 
				continue;
			if (i == 15)
		 		continue;
			if (i == 17) 
				continue;			
			if (Ptrdlg->IsOn[i])
			{
				typeAon = 1;
				break;
			}
		}
		if (!typeAon) //keep looking
		{
			for (i = 23; i < 29; i++)
			{
				if (i == 25)
					continue;
				if (Ptrdlg->IsOn[i])
				{
					typeAon = 1;
					break;
				}
			}
		}
		
		if (typeAon)			
		{				
			loc = Ptrdlg->InputFileStr.ReverseFind('.');
			fname = Ptrdlg->InputFileStr.Left(loc + 1);
			switch (TigerVersion)
			{
			case 95:
				fname = fname + "bwa";	
				break;
			case 94:
				fname = fname + "f6a";
				break;
			case 97:
				fname = fname + "rta";
				break;
			default:
				msg.Format("Unrecongnized TIGER version. Program will terminate");
				MissingFile = -1;
				break;
			}
			if (MissingFile == -1)
				break;
			in = fopen(fname,"r");
			if (in == NULL)
			{			
				ptrdlg->ErrorMessage("Could not open Type a file. No Type A polygons will be generated");
				MissingFile = 6;
			}				
			if (MissingFile != 6)
				Get_TypeA();	
			else
				break;
			if (MissingFile == -1)
				break;						
			Build_TypeI_Borders(2);				
			
			
		}*/
			if (Ptrdlg->IsOn[8])
			{		
				Match_Poly_Lines_County90();				
				if (MissingFile == -1)
					break;				
			}
			if (Ptrdlg->IsOn[9])
			{		
				Match_Poly_Lines_Countycu();				
				if (MissingFile == -1)
					break;				
			}
			if (Ptrdlg->IsOn[10])
			{
				Match_Poly_Lines_Tract90();				
				if (MissingFile == -1)
					break;				
			}
			if (Ptrdlg->IsOn[11])
			{
				Match_Poly_Lines_Group90();				
				if (MissingFile == -1)
					break;				
			}
			if (Ptrdlg->IsOn[12])
			{
				Match_Poly_Lines_Block90();				
				if (MissingFile == -1)
					break;				
			}
			if (Ptrdlg->IsOn[13])
			{
				Match_Poly_Lines_Fpl90();
				if (MissingFile == -1)
					break;
			}
			if (Ptrdlg->IsOn[15])
			{
				Match_Poly_Lines_Fmcd90();
				if (MissingFile == -1)
					break;
			}
			if (Ptrdlg->IsOn[19])
			{
				if (TigerVersion >= 97)
				{
					Match_Poly_Lines_Air90();
					if (MissingFile == -1)
						break;
				}
			}			
			if (Ptrdlg->IsOn[24])
			{
				Match_Poly_Lines_Taz();				
				if (MissingFile == -1)
					break;				
			}
			if (Ptrdlg->IsOn[25])
			{
				Match_Poly_Lines_Urban90();
				if (MissingFile == -1)
					break;
			}
			if (Ptrdlg->IsOn[26])
			{
				Match_Poly_Lines_Elementary();
				if (MissingFile == -1)
					break;
			}
			if (Ptrdlg->IsOn[28])
			{
				Match_Poly_Lines_Middle();
				if (MissingFile == -1)
					break;
			}
			if (Ptrdlg->IsOn[29])
			{
				Match_Poly_Lines_Secondary();
				if (MissingFile == -1)
					break;
			}
			if (Ptrdlg->IsOn[30])
			{
				Match_Poly_Lines_Unified();			
				if (MissingFile == -1)
					break;
			}
		
			if (CountA > 0)
				free(TypeAs);
		
/*		int typeSon = 0;
		if ((Ptrdlg->IsOn[13]) || (Ptrdlg->IsOn[15]) || (Ptrdlg->IsOn[19])|| (Ptrdlg->IsOn[20]))
			typeSon = 1;
		if (!typeSon)
		{
			for (i = 29; i < 36; i++)
			{
				//AfxMessageBox("here");
				if (Ptrdlg->IsOn[i])
				{				 
					typeSon = 1;
					break;
				}
			}
		}
		if (typeSon)
		{				
			loc = Ptrdlg->InputFileStr.ReverseFind('.');
			fname = Ptrdlg->InputFileStr.Left(loc + 1);
			switch (TigerVersion)
			{
			case 95:
				fname = fname + "bws";	
				break;
			case 94:
				fname = fname + "f6s";
				break;
			case 97:
				fname = fname + "rts";
				break;
			default:
				msg.Format("Unrecongnized TIGER version. Program will terminate");
				MissingFile = -1;
				break;
			}
			if (MissingFile == -1)
				break;
			in = fopen(fname,"r");
			if (in == NULL)
			{			
				ptrdlg->ErrorMessage("Could not open Type s file. No Type S polygons will be generated");
				MissingFile = 7;
			}				
			if (MissingFile != 7)
				Get_TypeS();	
			else
				break;
			if (MissingFile == -1)
				break;		
			Build_TypeI_Borders(3); //TYPE S POLYS
			if (MissingFile == -1)
				break;
*/			/*
			//new for 2000 entities - oct 4

			if (Ptrdlg->IsOn[9])
				Match_Poly_Lines_Tract2000();
			
			if (Ptrdlg->IsOn[11])
				Match_Poly_Lines_Block2000();
			//moved here because of TIGER 97- june 19
			*/
			if (Ptrdlg->IsOn[14])
			{
				Match_Poly_Lines_Fplcu();
				if (MissingFile == -1)
					break;
			}
			if (Ptrdlg->IsOn[16])
			{
				Match_Poly_Lines_Fmcdcu();
				if (MissingFile == -1)
					break;
			}
			if (Ptrdlg->IsOn[20])
			{
				Match_Poly_Lines_Aircu();
				if (MissingFile == -1)
					break;
			}
			if (Ptrdlg->IsOn[21])
			{
				Match_Poly_Lines_Anrc();
				if (MissingFile == -1)
					break;
			}
			if (Ptrdlg->IsOn[31])
			{			
				Match_Poly_Lines_Water();				
				if (Count7 > 0)
					free(Type7s);
				if (Count8 > 0)
					free(Type8s);	
				if (MissingFile == -1)
					break;
			}
			if (Ptrdlg->IsOn[32])
			{
				Match_Poly_Lines_Cmsamsa();
				if (MissingFile == -1)
					break;
			}
			if (Ptrdlg->IsOn[33])
			{
				Match_Poly_Lines_Pmsa();
				if (MissingFile == -1)
					break;
			}
			if (Ptrdlg->IsOn[34])
			{
				Match_Poly_Lines_Cdcu();
				if (MissingFile == -1)
					break;
			}
			if (Ptrdlg->IsOn[35])
			{
				Match_Poly_Lines_House();
				if (MissingFile == -1)
					break;
			}
			if (Ptrdlg->IsOn[36])
			{
				Match_Poly_Lines_Senate();
				if (MissingFile == -1)
					break;
			}
			if (Ptrdlg->IsOn[37])
			{
				Match_Poly_Lines_Collection2000();			
				if (MissingFile == -1)
					break;
			}
			if (Ptrdlg->IsOn[38])
			{
				if (TigerVersion == 98)
					Match_Poly_Lines_All();
				if (TigerVersion == 97)
					Match_Poly_Lines_All97();
			}

		//}
		//put tract2000, block2000, and voting district 2000 here.
		if (CountS > 0)
			free(TypeSs);
		break;
		}
	if (CountC > 0)
		free(TypeCs);
	
	Ptrdlg->m_strProcess = "";
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	if (Count1 > 0)
		free(Type1s);
	if (Count2 > 0)
		free(Type2s);
	if (Count3 > 0)
		free(Type3s);			
			
	if (CountI > 0)
		free(TypeIs);
	break; //while(1);
	}
	//put landmark points here. if (MissingFile != 4) && (MissingFile != 1)
	// if (Ptrdlg->IsOn[18]) do landmark points
	fprintf(LOG,"Finished\n");
	//AfxMessageBox("finished");
	return;

}
void Get_Type1()
{
	int i;
	CString info;
	
/*This sections reads and sorts all type 1 records.  
The records are sorted on Cfcc type (primary key) and Tlid (secondary key).
After the records are sorted, we move to record type2*/
	
	Count1 = 0;
	//if (Ptrdlg->m_nQuiet == 1)
	//	AfxMessageBox("Scanning record type 1 file");
	Ptrdlg->m_strProcess = "Reading";
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);//"Reading");
	
	while (fgets(Record, (BUFFLEN - 1), in) != NULL)
		{
		Count1++;
		}
	/*if (Ptrdlg->m_nQuiet == 1)
	{
		info.Format("Read %ld Type 1 Records", Count1);
		AfxMessageBox(info);
	}
	*/
	Type1s = (RecordType1 *)calloc(Count1, sizeof(RecordType1));
	if (Type1s == NULL)
	{
		Ptrdlg->ErrorMessage("MEMORY ALLOCATION ERROR");		
		MissingFile = -1; return;
	}
	rewind(in);
	for (i = 0; i < 8; i++)
		Counts[i] = 0L;		
    for (num = 0; num < Count1; num++)
	{
		if (fgets(Record, (BUFFLEN - 1), in) == NULL)
		{
			Ptrdlg->ErrorMessage("\nERROR reading type 1 records");			
			MissingFile = -1; return;
		}
		Parse_Type1_Record(num);
		switch(Type1s[num].Cfcc[0])
		{
		case 'A':
			Counts[0]++;
			break;
		case 'B':
			Counts[1]++;
			break;
		case 'C':
			Counts[2]++;
			break;
		case 'D':
			Counts[3]++;
			break;
		case 'E':
			Counts[4]++;
			break;
		case 'F':
			Counts[5]++;
			break;
		case 'H':
			Counts[6]++;
			break;
		case 'X':
			Counts[7]++;
			break;
		default:	
			break;
		}				
	}	
	fclose(in);
	
	Ptrdlg->m_strProcess = "Sorting";
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	qsort((void *)Type1s,Count1,sizeof(RecordType1),(compfn)Compare1A);	
	return;	
}
void Get_Type2()
{
/*This section reads and sorts type 2 reocrds. The sort is on Tlid
(primary key) and Rtsq (seondary key)
*/
	CString info;
	
    Count2 = 0;
	Ptrdlg->m_strProcess = "Reading";
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	
	
	while (fgets(Record, (BUFFLEN - 1), in) != NULL)
	{                       
		Count2++;
	}
	rewind(in);
	/*&if (Ptrdlg->m_nQuiet == 1)
	{
		info.Format("Read %ld Type 2 records",Count2);
		AfxMessageBox(info);
	}*/
	Type2s = (RecordType2 *)calloc(Count2, sizeof(RecordType2));
	if (Type2s == NULL)
	{
		Ptrdlg->ErrorMessage("MEMORY ALLOCATION ERROR");		
		MissingFile = -1; return;
	}
	MaxShapeRecords = 0;
	for (num = 0; num < Count2; num++)
	{
		if (fgets(Record, (BUFFLEN - 1), in) == NULL)
		{
			Ptrdlg->ErrorMessage("ERROR reading type 2 records");			
			MissingFile = -1; return;
		}
       Parse_Type2_Record(num);
	   if (atoi(Type2s[num].Rtsq) > MaxShapeRecords)
		   MaxShapeRecords = atoi(Type2s[num].Rtsq);
    }  
    fclose(in);
	
	/*if (Ptrdlg->m_nQuiet == 1)
	//{
		info.Format("Max Shape Records is %d",MaxShapeRecords);	
		//AfxMessageBox(info);
	//}
	*/
	Ptrdlg->m_strProcess = "Sorting";
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
   	qsort((void *)Type2s,Count2,sizeof(RecordType2),(compfn)Compare2);
	return;
}
void Get_Type3()
{
/*This sections reads and sorts all type 3 records.  
The records are sorted on Tlid */
//	int i;
		
	Count3 = 0;
	Ptrdlg->m_strProcess = "Reading";
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	while (fgets(Record, (BUFFLEN - 1), in) != NULL)
		{
		Count3++;
		}
	if (Count3 != Count1)
	{
		Ptrdlg->ErrorMessage("TIGER ERROR-There is not a one-to one correspondence between type 1 records and type 3 records.  This is an error in TIGER");
		MissingFile = -1; return;
	}
	Type3s = (RecordType3 *)calloc(Count3, sizeof(RecordType3));
	if (Type3s == NULL)
	{
		Ptrdlg->ErrorMessage("\nMEMORY ALLOCATION ERROR");
		MissingFile = -1; return;
	}
	rewind(in);
	CString repval;
	Polycounts[0] = 0;
	for (num = 0; num < Count3; num++)
	{
		if (fgets(Record, (BUFFLEN - 1), in) == NULL)
		{
			Ptrdlg->ErrorMessage("ERROR reading type 3 records");			
			MissingFile = -1; return;
		}		
		Parse_Type3_Record(num);
		Type3s[num].BorderType = 0;
		//only poly in luca from type 3.
		  
		   if (strcmp(Type3s[num].Vtd90l,Type3s[num].Vtd90r) != 0)
	       {
			Type3s[num].BorderType = 1;
			Polycounts[0]++;	
			if ((strcmp(Type3s[num].Vtd90l,"    ") != 0) && (strcmp(Type3s[num].Vtd90r,"    ") != 0))
				Polycounts[0]++;
	       }		
	}
	fclose(in);
	
	Ptrdlg->m_strProcess = "Sorting";
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
   	qsort((void *)Type3s,Count3,sizeof(RecordType3),(compfn)Compare3);
	/*for (num = 0; num < Count3; num++)
		printf("\n%ld %s %s",num, Type1s[num].Tlid, Type3s[num].Tlid);	
	*/
	
	return;
}
void Get_TypeC()
{
/*This sections reads and sorts all type 3 records.  
The records are sorted on Tlid */

	
	CountC = 0;
	Ptrdlg->m_strProcess = "Reading";
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	while (fgets(Record, (BUFFLEN - 1), in) != NULL)
		{
		CountC++;
		}
	TypeCs = (RecordTypeC *)calloc(CountC, sizeof(RecordTypeC));
	if (TypeCs == NULL)
	{
		Ptrdlg->ErrorMessage("\nMEMORY ALLOCATION ERROR");
		MissingFile = -1; return;
	}
	rewind(in);
	for (num = 0; num < CountC; num++)
	{
		if (fgets(Record, (BUFFLEN - 1), in) == NULL)
		{
			Ptrdlg->ErrorMessage("ERROR reading type C records");			
			MissingFile = -1; return;
		}	
		Parse_TypeC_Record(num);
	}
	fclose(in);
	
}
void Get_TypeI()
{
/*This sections reads and sorts all type I records.  
The records are sorted on Tlid */

	
	CountI = 0;
	Ptrdlg->m_strProcess = "Reading";
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	while (fgets(Record, (BUFFLEN - 1), in) != NULL)
		{
		CountI++;
		}
	if (CountI != Count1)
	{
		Ptrdlg->ErrorMessage("\nTIGER ERROR-The number of Type I records does not equal the number of Type 1 Records");
		MissingFile = -1; return;
	}
	TypeIs = (RecordTypeI *)calloc(CountI, sizeof(RecordTypeI));
	if (TypeIs == NULL)
	{
		Ptrdlg->ErrorMessage("\nMEMORY ALLOCATION ERROR");
		MissingFile = -1; return;
	}
	rewind(in);
	for (num = 0; num < CountI; num++)
	{
		if (fgets(Record, (BUFFLEN - 1), in) == NULL)
		{
			Ptrdlg->ErrorMessage("ERROR reading type I records");			
			MissingFile = -1; return;
		}	
		Parse_TypeI_Record(num);
	}
	fclose(in);
	Ptrdlg->m_strProcess = "Sorting";
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
   	qsort((void *)TypeIs,CountI,sizeof(RecordTypeI),(compfn)CompareI);
}
void Get_Type9()
{
/*This sections reads all type 9 records.  */

	Count9 = 0;
	Ptrdlg->m_strProcess = "Reading";
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	while (fgets(Record, (BUFFLEN - 1), in) != NULL)
		{
		Count9++;
		}
	Type9s = (RecordType9 *)calloc(Count9, sizeof(RecordType9));
	if (Type9s == NULL)
	{
		Ptrdlg->ErrorMessage("\nMEMORY ALLOCATION ERROR");
		MissingFile = -1; return;
	}
	rewind(in);		
	for (num = 0; num < Count9; num++)
	{
		if (fgets(Record, (BUFFLEN - 1), in) == NULL)
		{
			Ptrdlg->ErrorMessage("ERROR reading type 9 records");			
			MissingFile = -1; return;
		}			
		Parse_Type9_Record(num);
	}
	fclose(in);
	Ptrdlg->m_strProcess = "Sorting";
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
   	qsort((void *)Type9s,Count9,sizeof(RecordType9),(compfn)Compare9);
	/*CString vals;
	for (num = 0; num < Count9; num++)
	{
		vals.Format("num:%d\nvalue:%s",num, Type9s[num].Polyid);
		AfxMessageBox(vals);
	}
*/
	
}
void Get_Type5()
{
/*This sections reads all type 5 records.  */

	Count5 = 0;
	Ptrdlg->m_strProcess = "Reading";
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	while (fgets(Record, (BUFFLEN - 1), in) != NULL)
		{
		Count5++;
		}
	Type5s = (RecordType5 *)calloc(Count5, sizeof(RecordType5));
	if (Type5s == NULL)
	{
		Ptrdlg->ErrorMessage("\nMEMORY ALLOCATION ERROR");
		MissingFile = -1; return;
	}
	rewind(in);		
	for (num = 0; num < Count5; num++)
	{
		if (fgets(Record, (BUFFLEN - 1), in) == NULL)
		{
			Ptrdlg->ErrorMessage("ERROR reading type 5 records");			
			MissingFile = -1; return;
		}			
		Parse_Type5_Record(num);
	}
	fclose(in);
	
	Ptrdlg->m_strProcess = "Sorting";
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
   	qsort((void *)Type5s,Count5,sizeof(RecordType5),(compfn)Compare5);
	/*CString vals;
	for (num = 0; num < Count9; num++)
	{
		vals.Format("num:%d\nvalue:%s",num, Type9s[num].Polyid);
		AfxMessageBox(vals);
	}
*/
	
}
void Get_Type4()
{

	Count4 = 0;
	Ptrdlg->m_strProcess = "Reading";
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	while (fgets(Record, (BUFFLEN - 1), in) != NULL)
		{
		Count4++;
		}
	Type4s = (RecordType4 *)calloc(Count4, sizeof(RecordType4));
	if (Type4s == NULL)
	{
		Ptrdlg->ErrorMessage("\nMEMORY ALLOCATION ERROR");
		MissingFile = -1; return;
	}
	rewind(in);		
	for (num = 0; num < Count4; num++)
	{
		if (fgets(Record, (BUFFLEN - 1), in) == NULL)
		{
			Ptrdlg->ErrorMessage("ERROR reading type 4 records");			
			MissingFile = -1; return;
		}			
		Parse_Type4_Record(num);
	}
	fclose(in);
	
	Ptrdlg->m_strProcess = "Sorting";
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
   	qsort((void *)Type4s,Count4,sizeof(RecordType4),(compfn)Compare4);
}
void Get_Type6()
{
	Count6 = 0;
	Ptrdlg->m_strProcess = "Reading";
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	while (fgets(Record, (BUFFLEN - 1), in) != NULL)
		{
		Count6++;
		}
	Type6s = (RecordType6 *)calloc(Count6, sizeof(RecordType6));
	if (Type6s == NULL)
	{
		Ptrdlg->ErrorMessage("\nMEMORY ALLOCATION ERROR");
		MissingFile = -1; return;
	}
	rewind(in);		
	for (num = 0; num < Count6; num++)
	{
		if (fgets(Record, (BUFFLEN - 1), in) == NULL)
		{
			Ptrdlg->ErrorMessage("ERROR reading type 6 records");			
			MissingFile = -1; return;
		}			
		Parse_Type6_Record(num);
	}
	fclose(in);
	
	Ptrdlg->m_strProcess = "Sorting";
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
   	qsort((void *)Type6s,Count6,sizeof(RecordType6),(compfn)Compare6);	
}
void Get_TypeZ()
{
	CountZ = 0;
	Ptrdlg->m_strProcess = "Reading";
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	while (fgets(Record, (BUFFLEN - 1), in) != NULL)
		{
		CountZ++;
		}
	TypeZs = (RecordTypeZ *)calloc(CountZ, sizeof(RecordTypeZ));
	if (TypeZs == NULL)
	{
		Ptrdlg->ErrorMessage("\nMEMORY ALLOCATION ERROR");
		MissingFile = -1; return;
	}
	rewind(in);		
	for (num = 0; num < CountZ; num++)
	{
		if (fgets(Record, (BUFFLEN - 1), in) == NULL)
		{
			Ptrdlg->ErrorMessage("ERROR reading type Z records");			
			MissingFile = -1; return;
		}			
		Parse_TypeZ_Record(num);
	}
	fclose(in);
	
	Ptrdlg->m_strProcess = "Sorting";
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
   	qsort((void *)TypeZs,CountZ,sizeof(RecordTypeZ),(compfn)CompareZ);	
}
void Get_TypeS()
{
	CountS = 0;
	Ptrdlg->m_strProcess = "Reading";
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	while (fgets(Record, (BUFFLEN - 1), in) != NULL)
		{
		CountS++;
		}
	TypeSs = (RecordTypeS *)calloc(CountS, sizeof(RecordTypeS));
	if (TypeSs == NULL)
	{
		Ptrdlg->ErrorMessage("\nMEMORY ALLOCATION ERROR");
		MissingFile = -1; return;
	}
	rewind(in);		
	for (num = 0; num < CountS; num++)
	{
		if (fgets(Record, (BUFFLEN - 1), in) == NULL)
		{
			Ptrdlg->ErrorMessage("ERROR reading type S records");			
			MissingFile = -1; return;
		}			
		Parse_TypeS_Record(num);
	}
	fclose(in);
	Ptrdlg->m_strProcess = "Sorting";
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
   	qsort((void *)TypeSs,CountS,sizeof(RecordTypeS),(compfn)CompareS);	
	
}

void Get_Type7()
{
/*This sections reads all type 7 records.  */
//	char msg[50];
	Count7 = 0;
	Ptrdlg->m_strProcess = "Reading";
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	while (fgets(Record, (BUFFLEN - 1), in) != NULL)
		{
		Count7++;
		}
	Type7s = (RecordType7 *)calloc(Count7, sizeof(RecordType7));
	if (Type7s == NULL)
	{
		Ptrdlg->ErrorMessage("\nMEMORY ALLOCATION ERROR");
		MissingFile = -1; return;
	}
	rewind(in);		
	for (num = 0; num < Count7; num++)
	{
		if (fgets(Record, (BUFFLEN - 1), in) == NULL)
		{
			Ptrdlg->ErrorMessage("ERROR reading type 7 records");			
			MissingFile = -1; return;
		}			
		Parse_Type7_Record(num);
	}
	fclose(in);
	Ptrdlg->m_strProcess = "Sorting";
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
   	qsort((void *)Type7s,Count7,sizeof(RecordType7),(compfn)Compare7);
	
}
void Get_Type8()
{
/*This sections reads all type 7 records.  */
//	char msg[50];
	Count8 = 0;
	Ptrdlg->m_strProcess = "Reading";
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	while (fgets(Record, (BUFFLEN - 1), in) != NULL)
		{
		Count8++;
		}
	Type8s = (RecordType8 *)calloc(Count8, sizeof(RecordType8));
	if (Type8s == NULL)
	{
		Ptrdlg->ErrorMessage("\nMEMORY ALLOCATION ERROR");
		MissingFile = -1; return;
	}
	rewind(in);		
	for (num = 0; num < Count8; num++)
	{
		if (fgets(Record, (BUFFLEN - 1), in) == NULL)
		{
			Ptrdlg->ErrorMessage("ERROR reading type 8 records");			
			MissingFile = -1; return;
		}			
		Parse_Type8_Record(num);
	}
	fclose(in);
	Ptrdlg->m_strProcess = "Sorting";
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
   	qsort((void *)Type8s,Count8,sizeof(RecordType8),(compfn)Compare8);
	
}
void Get_TypeA()
{
	/*This sections reads all type 7 records.  */
//	char msg[50];
	CountA = 0;
	Ptrdlg->m_strProcess = "Reading";
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	while (fgets(Record, (BUFFLEN - 1), in) != NULL)
		{
		CountA++;
		}
	TypeAs = (RecordTypeA *)calloc(CountA, sizeof(RecordTypeA));
	if (TypeAs == NULL)
	{
		Ptrdlg->ErrorMessage("\nMEMORY ALLOCATION ERROR");
		MissingFile = -1; return;
	}
	rewind(in);		
	for (num = 0; num < CountA; num++)
	{
		if (fgets(Record, (BUFFLEN - 1), in) == NULL)
		{
			Ptrdlg->ErrorMessage("ERROR reading type A records");			
			MissingFile = -1; return;
		}			
		Parse_TypeA_Record(num);
	}
	fclose(in);
	Ptrdlg->m_strProcess = "Sorting";
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
   	qsort((void *)TypeAs,CountA,sizeof(RecordTypeA),(compfn)CompareA);
	
}
void Build_TypeI_Borders(int type)
{ 
	int num, steppos;
	int indexl, indexr;
//	char msg[50];
	for (int j = 0; j < 14; j++)
	{
		if (type < 2)
		{
			Polycounts[j] = 0;
			break;
		}
		if (type == 2)
			APolycounts[j] = 0;
		if ((type == 3)&&(j < 13))
			SPolycounts[j] = 0;
	}
	Ptrdlg->m_strProcess = "Determining Polygon Borders";
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	Ptrdlg->m_Progress.SetPos(0);
		CString repval;
	//repval.Format("build type %d", type);
	//AfxMessageBox(repval);
	for(num = 0; num < CountI; num++)
	{
		steppos = (int) (num * 100/CountI);
			//Ptrdlg->m_Progress.StepIt();
		Ptrdlg->m_Progress.SetPos(steppos);
		if (type == 0) //type 9 polys
		{
			TypeIs[num].Kgll = Get_Kgl(TypeIs[num].Cenidl, TypeIs[num].Polyidl);			
			TypeIs[num].Kglr = Get_Kgl(TypeIs[num].Cenidr, TypeIs[num].Polyidr);
			
			if (TypeIs[num].Kgll != TypeIs[num].Kglr)
			{				
				Polycounts[0]++;
				if ((TypeIs[num].Kgll >= 0) && (TypeIs[num].Kglr >= 0))
					Polycounts[0]++;
			}
		}
		if (type == 1) //type 8 polys		
		{
			TypeIs[num].Landl = Get_Land(TypeIs[num].Cenidl,TypeIs[num].Polyidl);//returns seqnum of type 8 record.
			TypeIs[num].Landr = Get_Land(TypeIs[num].Cenidr,TypeIs[num].Polyidr);
			if (TypeIs[num].Landl != TypeIs[num].Landr)
			{
				Polycounts[0]++;
				if ((TypeIs[num].Landl >= 0) && (TypeIs[num].Landr >= 0))
					Polycounts[0]++;
			}
		}
		if (type == 2)//type A polys
		{//the function Get_Taz returns the index of the polyid--this will work for other typeA features
			indexl = Get_Taz(TypeIs[num].Cenidl,TypeIs[num].Polyidl);			
			indexr = Get_Taz(TypeIs[num].Cenidr,TypeIs[num].Polyidr);
			if (indexl >= 0)
			{				
				if (TigerVersion >= 97)
					sprintf(TypeIs[num].County90l,"%2s%3s",TypeAs[indexl].State90,TypeAs[indexl].County90);
				else
					sprintf(TypeIs[num].County90l,"%2s%3s",Type3s[num].State90l,Type3s[num].Coun90l);
				sprintf(TypeIs[num].Tract90l,"%5s%6s",TypeIs[num].County90l,TypeAs[indexl].Ctbna90);
				sprintf(TypeIs[num].Group90l,"%11s%c",TypeIs[num].Tract90l,TypeAs[indexl].Blk90[0]);
				sprintf(TypeIs[num].Block90l,"%11s%4s",TypeIs[num].Tract90l,TypeAs[indexl].Blk90);
				sprintf(TypeIs[num].Fpl90l,"%5s",TypeAs[indexl].Fpl);
				sprintf(TypeIs[num].Fmcd90l,"%5s",TypeAs[indexl].Fmcd);
				if (TigerVersion >= 97)
					sprintf(TypeIs[num].Air90l,"%4s",TypeAs[indexl].Air90);
				sprintf(TypeIs[num].Tazl,"%6s%4s",TypeAs[indexl].Taz,TypeAs[indexl].Ctpp);
				sprintf(TypeIs[num].Urb90l,"%-5s",TypeAs[indexl].Ua90);
				sprintf(TypeIs[num].Elml,"%5s",TypeAs[indexl].Sdelm);
				if (TigerVersion < 97)
					sprintf(TypeIs[num].Midl,"%5s",TypeAs[indexl].Sdmid);
				sprintf(TypeIs[num].Secl,"%5s",TypeAs[indexl].Sdsec);
				sprintf(TypeIs[num].Unil,"%5s",TypeAs[indexl].Sduni);				
			//	if (TigerVersion >= 97)
					sprintf(TypeIs[num].Countycul,"%2s%3s",TypeAs[indexl].State,TypeAs[indexl].County);
				//the following items are needed for the all polys option
			//	if (TigerVersion == 98)
			//	{
					TypeIs[num].Urbflagl = TypeAs[indexl].Urbflag;
					sprintf(TypeIs[num].Fair90l,"%5s",TypeAs[indexl].Fair);
					sprintf(TypeIs[num].Ctbna90l,"%6s",TypeAs[indexl].Ctbna90);
					sprintf(TypeIs[num].Blk90l,"%4s",TypeAs[indexl].Blk90);
					sprintf(TypeIs[num].Cd106l,"%2s",TypeAs[indexl].Cd106);
					sprintf(TypeIs[num].Cd108l,"%2s",TypeAs[indexl].Cd108);
			//	}

			}
			else
			{			
				sprintf(TypeIs[num].County90l,"     ");
				sprintf(TypeIs[num].Tract90l,"           ");
				sprintf(TypeIs[num].Group90l,"            ");
				sprintf(TypeIs[num].Block90l,"               ");
				sprintf(TypeIs[num].Fpl90l,"     ");
				sprintf(TypeIs[num].Fmcd90l,"     ");
				if (TigerVersion >= 97)
					sprintf(TypeIs[num].Air90l,"    ");
				sprintf(TypeIs[num].Tazl,"          ");
				sprintf(TypeIs[num].Urb90l,"     ");
				sprintf(TypeIs[num].Elml,"     ");
				if (TigerVersion < 97)
				    sprintf(TypeIs[num].Midl,"     ");
				sprintf(TypeIs[num].Secl,"     ");
				sprintf(TypeIs[num].Unil,"     ");
				//if (TigerVersion >= 97)
					sprintf(TypeIs[num].Countycul,"     ");
				TypeIs[num].Urbflagl = ' ';
				sprintf(TypeIs[num].Fair90l,"     ");
				sprintf(TypeIs[num].Ctbna90l,"      ");
				sprintf(TypeIs[num].Blk90l,"    ");
				sprintf(TypeIs[num].Cd106l,"  ");
				sprintf(TypeIs[num].Cd108l,"  ");
			}
			if (indexr >= 0)
			{			
				if (TigerVersion >= 97)
					sprintf(TypeIs[num].County90r,"%2s%3s",TypeAs[indexr].State90,TypeAs[indexr].County90);
				else
					sprintf(TypeIs[num].County90r,"%2s%3s",Type3s[num].State90r,Type3s[num].Coun90r);
				sprintf(TypeIs[num].Tract90r,"%5s%6s",TypeIs[num].County90r,TypeAs[indexr].Ctbna90);
				sprintf(TypeIs[num].Group90r,"%11s%c",TypeIs[num].Tract90r,TypeAs[indexr].Blk90[0]);
				sprintf(TypeIs[num].Block90r,"%11s%4s",TypeIs[num].Tract90r,TypeAs[indexr].Blk90);
				sprintf(TypeIs[num].Fpl90r,"%5s",TypeAs[indexr].Fpl);
				sprintf(TypeIs[num].Fmcd90r,"%5s",TypeAs[indexr].Fmcd);
				if (TigerVersion >= 97)
					sprintf(TypeIs[num].Air90r,"%4s",TypeAs[indexr].Air90);				
				sprintf(TypeIs[num].Tazr,"%6s%4s",TypeAs[indexr].Taz,TypeAs[indexr].Ctpp);
				sprintf(TypeIs[num].Urb90r,"%-5s",TypeAs[indexr].Ua90); //,TypeAs[indexr].Urbflag);
				sprintf(TypeIs[num].Elmr,"%5s",TypeAs[indexr].Sdelm);
				if (TigerVersion < 97)
					sprintf(TypeIs[num].Midr,"%5s",TypeAs[indexr].Sdmid);
				sprintf(TypeIs[num].Secr,"%5s",TypeAs[indexr].Sdsec);
				sprintf(TypeIs[num].Unir,"%5s",TypeAs[indexr].Sduni);
				TypeIs[num].Urbflagr = TypeAs[indexr].Urbflag;
				//if (TigerVersion >= 97)
					sprintf(TypeIs[num].Countycur,"%2s%3s",TypeAs[indexr].State,TypeAs[indexr].County);
				//if (TigerVersion == 98)
				//{
					TypeIs[num].Urbflagr = TypeAs[indexr].Urbflag;
					sprintf(TypeIs[num].Fair90r,"%5s",TypeAs[indexr].Fair);
					sprintf(TypeIs[num].Ctbna90r,"%6s",TypeAs[indexr].Ctbna90);
					sprintf(TypeIs[num].Blk90r,"%4s",TypeAs[indexr].Blk90);
					sprintf(TypeIs[num].Cd106r,"%2s",TypeAs[indexr].Cd106);
					sprintf(TypeIs[num].Cd108r,"%2s",TypeAs[indexr].Cd108);
				//}
			}
			else
			{
				sprintf(TypeIs[num].County90r,"     ");
				sprintf(TypeIs[num].Tract90r,"           ");
				sprintf(TypeIs[num].Group90r,"            ");
				sprintf(TypeIs[num].Block90r,"               ");
				sprintf(TypeIs[num].Fpl90r,"     ");
				sprintf(TypeIs[num].Fmcd90r,"     ");
				if (TigerVersion >= 97)
					sprintf(TypeIs[num].Air90r,"    ");				
				sprintf(TypeIs[num].Tazr,"          ");
				sprintf(TypeIs[num].Urb90r,"     ");
				sprintf(TypeIs[num].Elmr,"     ");
				if (TigerVersion < 97)
					sprintf(TypeIs[num].Midr,"     ");
				sprintf(TypeIs[num].Secr,"     ");
				sprintf(TypeIs[num].Unir,"     ");
				//if (TigerVersion >= 97)
					sprintf(TypeIs[num].Countycur,"     ");
				TypeIs[num].Urbflagr = ' ';
				sprintf(TypeIs[num].Fair90r,"     ");
				sprintf(TypeIs[num].Ctbna90r,"      ");
				sprintf(TypeIs[num].Blk90r,"    ");
				sprintf(TypeIs[num].Cd106r,"  ");
				sprintf(TypeIs[num].Cd108r,"  ");
			}
			if (strcmp(TypeIs[num].County90l,TypeIs[num].County90r) != 0)
			{
				APolycounts[0]++;
				if ((strcmp(TypeIs[num].County90l,"     ") != 0) &&
					(strcmp(TypeIs[num].County90r,"     ") != 0))
					APolycounts[0]++;
			}
			if (strcmp(TypeIs[num].Countycul,TypeIs[num].Countycur) != 0)
			{
				APolycounts[13]++;
				if ((strcmp(TypeIs[num].Countycul,"     ") != 0) &&
					(strcmp(TypeIs[num].Countycur,"     ") != 0))
					APolycounts[13]++;
			}
			if (strcmp(TypeIs[num].Tract90l,TypeIs[num].Tract90r) != 0)
			{
				APolycounts[1]++;
				if ((strcmp(TypeIs[num].Tract90l,"           ") != 0) &&
					(strcmp(TypeIs[num].Tract90r,"           ") != 0))
					APolycounts[1]++;
			}
			if (strcmp(TypeIs[num].Group90l,TypeIs[num].Group90r) != 0)
			{
				APolycounts[2]++;
				if ((strcmp(TypeIs[num].Group90l,"            ") != 0) &&
					(strcmp(TypeIs[num].Group90r,"            ") != 0))
					APolycounts[2]++;
			}
			if (strcmp(TypeIs[num].Block90l,TypeIs[num].Block90r) != 0)
			{
				APolycounts[3]++;
				if ((strcmp(TypeIs[num].Block90l,"               ") != 0) &&
					(strcmp(TypeIs[num].Block90r,"               ") != 0))
					APolycounts[3]++;
			}
			if (strcmp(TypeIs[num].Fpl90l,TypeIs[num].Fpl90r) != 0)
			{
				APolycounts[4]++;
				if ((strcmp(TypeIs[num].Fpl90l,"     ") != 0) &&
					(strcmp(TypeIs[num].Fpl90r,"     ") != 0))
					APolycounts[4]++;
			}
			if (strcmp(TypeIs[num].Fmcd90l,TypeIs[num].Fmcd90r) != 0)
			{
				APolycounts[5]++;
				if ((strcmp(TypeIs[num].Fmcd90l,"     ") != 0) &&
					(strcmp(TypeIs[num].Fmcd90r,"     ") != 0))
					APolycounts[5]++;
			}
			if (TigerVersion >= 97)
			{
				if (strcmp(TypeIs[num].Air90l,TypeIs[num].Air90r) != 0)
				{
					APolycounts[6]++;
					if ((strcmp(TypeIs[num].Air90l,"    ") != 0) &&
						(strcmp(TypeIs[num].Air90r,"    ") != 0))
						APolycounts[6]++;
				}
			}
			if (strcmp(TypeIs[num].Tazl,TypeIs[num].Tazr) != 0)
			{
				APolycounts[7]++;
				if ((strcmp(TypeIs[num].Tazl,"          ") != 0) && 
					(strcmp(TypeIs[num].Tazr,"          ") != 0))
					APolycounts[7]++;
			}
			if (strcmp(TypeIs[num].Urb90l,TypeIs[num].Urb90r) != 0)
			{
				APolycounts[8]++;
				if ((strcmp(TypeIs[num].Urb90l,"    ") != 0) && 
					(strcmp(TypeIs[num].Urb90r,"    ") != 0))
					APolycounts[8]++;
			}
			
			if (strcmp(TypeIs[num].Elml,TypeIs[num].Elmr) != 0)
			{
				APolycounts[9]++;
				if ((strcmp(TypeIs[num].Elml,"     ") != 0) &&
					(strcmp(TypeIs[num].Elmr,"     ") != 0))
					APolycounts[9]++;
			}
			if (TigerVersion < 97)
			{
				if (strcmp(TypeIs[num].Midl,TypeIs[num].Midr) != 0)
				{
					APolycounts[12]++;
					if ((strcmp(TypeIs[num].Midl,"     ") != 0) &&
						(strcmp(TypeIs[num].Midr,"     ") != 0))
						APolycounts[12]++;
				}
			}
			if (strcmp(TypeIs[num].Secl,TypeIs[num].Secr) != 0)
			{
				APolycounts[10]++;
				if ((strcmp(TypeIs[num].Secl,"     ") != 0) &&
					(strcmp(TypeIs[num].Secr,"     ") != 0))
					APolycounts[10]++;
			}
			if (strcmp(TypeIs[num].Unil,TypeIs[num].Unir) != 0)
			{
				APolycounts[11]++;
				if ((strcmp(TypeIs[num].Unil,"     ") != 0) &&
					(strcmp(TypeIs[num].Unir,"     ") != 0))
					APolycounts[11]++;
			}
			if (indexl != indexr)
			{
				AllACount++;
				if ((indexl >= 0) && (indexr >= 0))
					AllACount++;
			}
		}		
		if (type == 3) //type s
		{
			indexl = Get_Water(TypeIs[num].Cenidl, TypeIs[num].Polyidl);			
			indexr = Get_Water(TypeIs[num].Cenidr, TypeIs[num].Polyidr);
			if (indexl >= 0)
			{
				TypeIs[num].Waterl = TypeSs[indexl].Water;
				sprintf(TypeIs[num].Msal,"%4s",TypeSs[indexl].Cmsamsa);
				sprintf(TypeIs[num].Pmsl,"%4s",TypeSs[indexl].Pmsa);
				sprintf(TypeIs[num].Cdcul,"%2s",TypeSs[indexl].Cdcu);
				/*if (TigerVersion > 97)
				{
					sprintf(TypeIs[num].Housel,"%3s",TypeSs[indexl].Sthouse);
					sprintf(TypeIs[num].Senatel,"%3s",TypeSs[indexl].Stsenate);
				}
				else
				{
					sprintf(TypeIs[num].House97l,"%6s",TypeSs[indexl].Sthouse97);
					sprintf(TypeIs[num].Senate97l,"%6s",TypeSs[indexl].Stsenate97);
				}*/
				sprintf(TypeIs[num].Housel,"%6s",TypeSs[indexl].Sthouse);
				sprintf(TypeIs[num].Senatel,"%6s",TypeSs[indexl].Stsenate);
				sprintf(TypeIs[num].Anrcl,"%2s",TypeSs[indexl].Anrc);
				//sprintf(TypeIs[num].Ctbna00l,"%6s",TypeSs[indexl].Ctbna00);
				//sprintf(TypeIs[num].Blk00l,"%4s",TypeSs[indexl].Blk00);
				//sprintf(TypeIs[num].Vtd00l,"%6s",TypeSs[indexl].Vtd00);
				sprintf(TypeIs[num].Fplcul,"%5s",TypeSs[indexl].Fpl);
				sprintf(TypeIs[num].Fmcdcul,"%5s",TypeSs[indexl].Fmcd);
				sprintf(TypeIs[num].Aircul,"%4s",TypeSs[indexl].Air);
				//new
				sprintf(TypeIs[num].Faircul,"%5s",TypeSs[indexl].Fair);
				TypeIs[num].Trustl = TypeSs[indexl].Trust;
				sprintf(TypeIs[num].Fccityl,"%5s",TypeSs[indexl].Fccity);
				sprintf(TypeIs[num].Fsmcdcul,"%5s",TypeSs[indexl].Fsmcd);
		
				if (TigerVersion > 97)
				{
					sprintf(TypeIs[num].Colblkl,"%2s%3s%5s%c%c%5s",TypeSs[indexl].Statecol,
						TypeSs[indexl].Councol,TypeSs[indexl].Blkcol,TypeSs[indexl].Blksufcol,
						TypeSs[indexl].Tea,TypeSs[indexl].Zcta);
					//new
					sprintf(TypeIs[num].Census6l,"%5s",TypeSs[indexl].Census6);	
				}
				//sprintf(TypeIs[num].Countyl,"%s%s",TypeSs[indexl].State, TypeSs[indexl].County);
			}
			else
			{
				TypeIs[num].Waterl = 0;
				sprintf(TypeIs[num].Msal,"    ");
				sprintf(TypeIs[num].Pmsl,"    ");
				sprintf(TypeIs[num].Cdcul,"  ");
				/*
				if (TigerVersion > 97)
				{
					sprintf(TypeIs[num].Housel,"   ");
					sprintf(TypeIs[num].Senatel,"   ");
				}
				else
				{
					sprintf(TypeIs[num].House97l,"      ");
					sprintf(TypeIs[num].Senate97l,"      ");
				}*/
				sprintf(TypeIs[num].Housel,"      ");
				sprintf(TypeIs[num].Senatel,"      ");
				sprintf(TypeIs[num].Anrcl,"  ");
				/*sprintf(TypeIs[num].Ctbna00l,"      ");
				sprintf(TypeIs[num].Blk00l,"    ");
				sprintf(TypeIs[num].Vtd00l,"      ");*/
				sprintf(TypeIs[num].Fplcul,"     ");
				sprintf(TypeIs[num].Fmcdcul,"     ");
				sprintf(TypeIs[num].Aircul,"    ");
				sprintf(TypeIs[num].Faircul,"     ");
				TypeIs[num].Trustl = ' ';
				sprintf(TypeIs[num].Fccityl,"     ");
				sprintf(TypeIs[num].Fsmcdcul,"     ");
		
				if (TigerVersion > 97)
				{
					sprintf(TypeIs[num].Colblkl,"                 ");
					sprintf(TypeIs[num].Census6l,"     ");
				}
				//sprintf(TypeIs[num].Countyl,"     ");
			}
			if (indexr >= 0)
			{
				TypeIs[num].Waterr = TypeSs[indexr].Water;
				sprintf(TypeIs[num].Msar,"%4s",TypeSs[indexr].Cmsamsa);
				sprintf(TypeIs[num].Pmsr,"%4s",TypeSs[indexr].Pmsa);
				sprintf(TypeIs[num].Cdcur,"%2s",TypeSs[indexr].Cdcu);
				/*if (TigerVersion > 97)
				{
					sprintf(TypeIs[num].Houser,"%3s",TypeSs[indexr].Sthouse);
					sprintf(TypeIs[num].Senater,"%3s",TypeSs[indexr].Stsenate);
				}				
				else
				{
					sprintf(TypeIs[num].Houser,"%6s",TypeSs[indexr].Sthouse97);
					sprintf(TypeIs[num].Senater,"%6s",TypeSs[indexr].Stsenate97);
				}*/
				sprintf(TypeIs[num].Houser,"%6s",TypeSs[indexr].Sthouse);
				sprintf(TypeIs[num].Senater,"%6s",TypeSs[indexr].Stsenate);
				sprintf(TypeIs[num].Anrcr,"%2s",TypeSs[indexr].Anrc);
				//sprintf(TypeIs[num].Ctbna00r,"%6s",TypeSs[indexr].Ctbna00);
				//sprintf(TypeIs[num].Blk00r,"%4s",TypeSs[indexr].Blk00);
				//sprintf(TypeIs[num].Vtd00r,"%6s",TypeSs[indexr].Vtd00);
				sprintf(TypeIs[num].Fplcur,"%5s",TypeSs[indexr].Fpl);
				sprintf(TypeIs[num].Fmcdcur,"%5s",TypeSs[indexr].Fmcd);
				sprintf(TypeIs[num].Aircur,"%4s",TypeSs[indexr].Air);
				sprintf(TypeIs[num].Faircur,"%5s",TypeSs[indexr].Fair);
				TypeIs[num].Trustr = TypeSs[indexr].Trust;
				sprintf(TypeIs[num].Fccityr,"%5s",TypeSs[indexr].Fccity);
				sprintf(TypeIs[num].Fsmcdcur,"%5s",TypeSs[indexr].Fsmcd);
		
				if (TigerVersion > 97)
				{
					sprintf(TypeIs[num].Colblkr,"%2s%3s%5s%c%c%5s",TypeSs[indexr].Statecol,
						TypeSs[indexr].Councol,TypeSs[indexr].Blkcol,TypeSs[indexr].Blksufcol,
						TypeSs[indexr].Tea,TypeSs[indexr].Zcta);
					sprintf(TypeIs[num].Census6r,"%5s",TypeSs[indexr].Census6);	
				}
				//sprintf(TypeIs[num].Countyr,"%s%s",TypeSs[indexr].State, TypeSs[indexr].County);
	
			}
			else
			{
				TypeIs[num].Waterr = 0;
				sprintf(TypeIs[num].Msar,"    ");
				sprintf(TypeIs[num].Pmsr,"    ");
				sprintf(TypeIs[num].Cdcur,"  ");
				/*
				if (TigerVersion > 97)
				{
					sprintf(TypeIs[num].Senater,"   ");
					sprintf(TypeIs[num].Houser,"   ");
				}
				else
				{
					sprintf(TypeIs[num].Senate97r,"      ");
					sprintf(TypeIs[num].House97r,"      ");
				}
				*/
				sprintf(TypeIs[num].Senater,"      ");
				sprintf(TypeIs[num].Houser,"      ");
				sprintf(TypeIs[num].Anrcr,"  ");
				//sprintf(TypeIs[num].Ctbna00r,"      ");
				//sprintf(TypeIs[num].Blk00r,"    ");
				//sprintf(TypeIs[num].Vtd00r,"      ");
				sprintf(TypeIs[num].Fplcur,"     ");
				sprintf(TypeIs[num].Fmcdcur,"     ");
				sprintf(TypeIs[num].Aircur,"    ");
				sprintf(TypeIs[num].Faircur,"     ");
				TypeIs[num].Trustr = ' ';
				sprintf(TypeIs[num].Fccityr,"     ");
				sprintf(TypeIs[num].Fsmcdcur,"     ");
				sprintf(TypeIs[num].Faircur,"     ");
				TypeIs[num].Trustr = ' ';
				sprintf(TypeIs[num].Fccityr,"     ");
				sprintf(TypeIs[num].Fsmcdcur,"     ");
				if (TigerVersion > 97)
				{
					sprintf(TypeIs[num].Colblkr,"                 ");
					sprintf(TypeIs[num].Census6r,"     ");
				}
				//sprintf(TypeIs[num].Countyr,"     ");
			}
			//if (TypeIs[num].Waterl != TypeIs[num].Waterr)
			if (TypeIs[num].Waterl == 1)
			{		
				SPolycounts[0]++;
				//if ((TypeIs[num].Waterl >= 0) && (TypeIs[num].Waterr >= 0))
				//	Polycounts[0]++;
			}
			//new
			if (TypeIs[num].Waterr == 1)
				SPolycounts[0]++;
			if (strcmp(TypeIs[num].Msal,TypeIs[num].Msar) != 0)
			{
				SPolycounts[1]++;
				if ((strcmp(TypeIs[num].Msal,"    ") != 0) && 
					(strcmp(TypeIs[num].Msar,"    ") != 0))
					SPolycounts[1]++;
			}
			if (strcmp(TypeIs[num].Pmsl,TypeIs[num].Pmsr) != 0)
			{
				SPolycounts[2]++;
				if ((strcmp(TypeIs[num].Pmsl,"    ") != 0) && 
					(strcmp(TypeIs[num].Pmsr,"    ") != 0))
					SPolycounts[2]++;
			}
			if (strcmp(TypeIs[num].Cdcul,TypeIs[num].Cdcur) != 0)
			{
				SPolycounts[3]++;
				if ((strcmp(TypeIs[num].Cdcul,"  ") != 0) &&
					(strcmp(TypeIs[num].Cdcur,"  ") != 0))
					SPolycounts[3]++;
			}
			/*if (TigerVersion > 97)
			{
				if (strcmp(TypeIs[num].Housel,TypeIs[num].Houser) != 0)
				{
					SPolycounts[4]++;
					if ((strcmp(TypeIs[num].Housel,"   ") != 0) &&
						(strcmp(TypeIs[num].Houser,"   ") != 0))
						SPolycounts[4]++;
				}
				if (strcmp(TypeIs[num].Senatel,TypeIs[num].Senater) != 0)
				{
					SPolycounts[5]++;
					if ((strcmp(TypeIs[num].Senatel,"   ") != 0) &&
						(strcmp(TypeIs[num].Senater,"   ") != 0))
						SPolycounts[5]++;
				}
			}
			else
			{*/
				if (strcmp(TypeIs[num].Housel,TypeIs[num].Houser) != 0)
				{
					SPolycounts[4]++;
					if ((strcmp(TypeIs[num].Housel,"      ") != 0) &&
						(strcmp(TypeIs[num].Houser,"      ") != 0))
						SPolycounts[4]++;
				}
				if (strcmp(TypeIs[num].Senatel,TypeIs[num].Senater) != 0)
				{
					SPolycounts[5]++;
					if ((strcmp(TypeIs[num].Senatel,"      ") != 0) &&
						(strcmp(TypeIs[num].Senater,"      ") != 0))
						SPolycounts[5]++;
				}
			//}
			if (strcmp(TypeIs[num].Anrcl, TypeIs[num].Anrcr) != 0)
			{
				SPolycounts[6]++;
				if ((strcmp(TypeIs[num].Anrcl,"  ") != 0) &&
					(strcmp(TypeIs[num].Anrcr,"  ") != 0))
					SPolycounts[6]++;
			}
			/*if (strcmp(TypeIs[num].Ctbna00l, TypeIs[num].Ctbna00r) != 0)
			{
				Polycounts[7]++;
				if ((strcmp(TypeIs[num].Ctbna00l,"      ") != 0) &&
					(strcmp(TypeIs[num].Ctbna00r,"      ") != 0))
					Polycounts[7]++;
			}
			if ((strcmp(TypeIs[num].Blk00l, TypeIs[num].Blk00r) != 0) ||
				(strcmp(TypeIs[num].Ctbna00l, TypeIs[num].Ctbna00r) != 0))

			{
				Polycounts[8]++;
				if ((strcmp(TypeIs[num].Blk00l,"    ") != 0) &&
					(strcmp(TypeIs[num].Blk00r,"    ") != 0))
					Polycounts[8]++;
			}
			if (strcmp(TypeIs[num].Vtd00l, TypeIs[num].Vtd00r) != 0)
			{
				Polycounts[9]++;
				if ((strcmp(TypeIs[num].Vtd00l,"      ") != 0) &&
					(strcmp(TypeIs[num].Vtd00r,"      ") != 0))
					Polycounts[9]++;
			}*/
			if (strcmp(TypeIs[num].Fplcul, TypeIs[num].Fplcur) != 0)
			{
				SPolycounts[7]++;
				if ((strcmp(TypeIs[num].Fplcul,"     ") != 0) &&
					(strcmp(TypeIs[num].Fplcur,"     ") != 0))
					SPolycounts[7]++;
			}
			if (strcmp(TypeIs[num].Fmcdcul, TypeIs[num].Fmcdcur) != 0)
			{
				SPolycounts[8]++;
				if ((strcmp(TypeIs[num].Fmcdcul,"     ") != 0) &&
					(strcmp(TypeIs[num].Fmcdcur,"     ") != 0))
					SPolycounts[8]++;
			}
			if (strcmp(TypeIs[num].Aircul, TypeIs[num].Aircur) != 0)
			{
				SPolycounts[9]++;
				if ((strcmp(TypeIs[num].Aircul,"    ") != 0) &&
					(strcmp(TypeIs[num].Aircur,"    ") != 0))
					SPolycounts[9]++;
			}
			if (strcmp(TypeIs[num].Colblkl, TypeIs[num].Colblkr) != 0)
			{
				SPolycounts[10]++;
				if ((strcmp(TypeIs[num].Colblkl,"                 ") != 0) &&
					(strcmp(TypeIs[num].Colblkr,"                 ") != 0))
					SPolycounts[10]++;
			}
			if (indexl != indexr)
			{
				AllSCount++;
				if ((indexl >= 0) && (indexr >= 0))
					AllSCount++;
			}		
		}			
		
	}
	//AfxMessageBox("finished");
}


void Build_Lines_And_Nodes()
{
/*This section builds a node list for each node used of a given type
After the node list is built, it is sorted and packed, then used to 
write the line type files*/

	int i, found, m, steppos;
	long num, base, j, numunique, k;
	long upper, lower, halfway, idnum;
	CString fname, info;
//	char msg[50];
	char noderec[10]; //9 is size of a node record
	char linkrec[135]; //134 is size of a link record
	FILE  *linkndes, *ndeatt;
	//shape stuff
	FILE *linkshp, *linkshx, *nodeshp, *nodeshx;
	shape_header_t *arcshphead, *nodeshphead;
	shape_record_header_t *rechead;
	shape_arc_t *curarc;
	shape_point_t *curnode;
	int nparts; //always is one
	int oldposition;
	shape_index_record_t *curindex;
	double distance;
	CString errmsg;
	
	Node_type *packed, *nodes;
    
	base = 0L;
	for (i = 0; i < 8; i++)
	{
		//AfxMessageBox("here top of loop");
		if (i == 0)
			base = 0;
		else
			base += Counts[i-1];
		if (!Ptrdlg->IsOn[i])
			continue;
		if (Counts[i] == 0)
		{  //cannot use write_line_update because of pagefault problem
			//Write_Line_Update(i,-1,-1);		
			switch (i)
			{
			case 0:
				Ptrdlg->SetDlgItemText(IDC_TYPEA,"No Such Cases");			
				break;
			case 1:
				Ptrdlg->SetDlgItemText(IDC_TYPEB,"No Such Cases");			
				break;
			case 2:
				Ptrdlg->SetDlgItemText(IDC_TYPEC,"No Such Cases");			
				break;
			case 3:
				Ptrdlg->SetDlgItemText(IDC_TYPED,"No Such Cases");			
				break;
			case 4:
				Ptrdlg->SetDlgItemText(IDC_TYPEE,"No Such Cases");			
				break;
			case 5:
				Ptrdlg->SetDlgItemText(IDC_TYPEF,"No Such Cases");			
				break;
			case 6:
				Ptrdlg->SetDlgItemText(IDC_TYPEH,"No Such Cases");			
				break;
			case 7:
				Ptrdlg->SetDlgItemText(IDC_TYPEX,"No Such Cases");			
				break;
			default:
				break;
			}
			continue;
		}		
		nodes = (Node_type *)calloc(Counts[i]*2,sizeof(Node_type));
		packed = (Node_type *)calloc(Counts[i]*2,sizeof(Node_type));
		num = 0;
		Ptrdlg->m_strProcess.Format("Building Nodes of Type %c",Types[i]);
		Ptrdlg->m_Progress.SetPos(0);
		Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
		//create an array of nodes for the current line type
		for (j = base; j < base + Counts[i]; j++)
		{
			nodes[num].Longitude = Type1s[j].Frlong;
			nodes[num].Latitude = Type1s[j].Frlat;
			strcpy(nodes[num].Tlid,Type1s[j].Tlid);
			nodes[num].Toflag = 0;
			packed[num] = nodes[num];			
			num++;
   			nodes[num].Longitude = Type1s[j].Tolong;
			nodes[num].Latitude = Type1s[j].Tolat;
			strcpy(nodes[num].Tlid,Type1s[j].Tlid);
			nodes[num].Toflag = 1;
			packed[num] = nodes[num];			
			num++;
		}					
		qsort((void *)packed,2*Counts[i],sizeof(Node_type),(compfn)CompareNodes);		
		fname.Format("%s%slk%c.shp",Outfilepath,Outfiletitle,Types[i]);		
		linkshp = fopen(fname,"wb");
		
		if (linkshp == NULL)
		{
			errmsg.Format("Could not open file %s",fname);
			Ptrdlg->ErrorMessage(errmsg);
			MissingFile = -1; return;
		}
		fname.Format("%s%slk%c.shx",Outfilepath,Outfiletitle,Types[i]);				
		linkshx = fopen(fname,"wb");
		
		if (linkshx == NULL)
		{
			errmsg.Format("Could not open file %s",fname);
			Ptrdlg->ErrorMessage(errmsg);
			MissingFile = -1; return;
		}
		fname.Format("%s%slk%c.dbf",Outfilepath,Outfiletitle,Types[i]);				
		linkndes = fopen(fname,"wb");		
		
		if (linkndes == NULL)
		{
			errmsg.Format("Could not open file %s",fname);
			Ptrdlg->ErrorMessage(errmsg);
			MissingFile = -1; return;
		}
		fname.Format("%s%snd%c.dbf",Outfilepath,Outfiletitle,Types[i]);				
		ndeatt = fopen(fname,"wb");	
		
		if (ndeatt == NULL)
		{
			errmsg.Format("Could not open file %s",fname);
			Ptrdlg->ErrorMessage(errmsg);
			MissingFile = -1; return;
		}
		fname.Format("%s%snd%c.shp",Outfilepath,Outfiletitle,Types[i]);				
		nodeshp = fopen(fname,"wb");
		
		if (nodeshp == NULL)
		{
			errmsg.Format("Could not open file %s",fname);
			Ptrdlg->ErrorMessage(errmsg);
			MissingFile = -1; return;
		}
		fname.Format("%s%snd%c.shx",Outfilepath,Outfiletitle,Types[i]);				
		nodeshx = fopen(fname,"wb");
		
		if (nodeshx == NULL)
		{
			errmsg.Format("Could not open file %s",fname);
			Ptrdlg->ErrorMessage(errmsg);
			MissingFile = -1; return;
		}
		Build_db_Header(ndeatt,0L,dbNodes);
		Build_db_FieldHeaders(ndeatt,dbNodes);
		nodeshphead = Create_Shape_Header(SHP_POINT);
	    SHP_Write_Header(nodeshp,nodeshphead);
        SHP_Write_Header(nodeshx,nodeshphead); 
		Position = 100; 
		oldposition = Position;
		FileMinX = FileMinY = LARGE;
		FileMaxX = FileMaxY = -LARGE;
		Build_db_Header(linkndes,Counts[i],dbLinks);
		Build_db_FieldHeaders(linkndes,dbLinks);
		numunique = 0;
		curnode = (shape_point_t *)calloc(1,sizeof(shape_point_t));
		curnode->shapeType = 1;
		curnode->x = packed[numunique].Longitude;
		curnode->y = packed[numunique].Latitude;
		rechead =(shape_record_header_t *)calloc(1,sizeof(shape_record_header_t));
		rechead->num = numunique+1;
		rechead->length = SHPPOINTSIZE/2;
		SHP_Write_Record_Header(nodeshp,rechead);
		free(rechead);
		SHP_Write_Point(nodeshp,curnode);
		curindex = (shape_index_record_t *)calloc(1,sizeof(shape_index_record_t));
		curindex->offset = oldposition;
		curindex->length = Size;
		SHP_Write_Index(nodeshx,curindex);
		free(curindex);
		oldposition = Position;
		if (packed[numunique].Longitude < FileMinX)
			FileMinX = packed[numunique].Longitude;
		if (packed[numunique].Longitude > FileMaxX)
			FileMaxX = packed[numunique].Longitude;
		if (packed[numunique].Latitude < FileMinY)
			FileMinY = packed[numunique].Latitude;
		if (packed[numunique].Latitude > FileMaxY)
			FileMaxY = packed[numunique].Latitude;
		sprintf(noderec," %-8ld",numunique+1);
		fwrite(noderec,sizeof(noderec)-1,1,ndeatt);
		numunique++;
		//Write_Line_Update(i,numunique,-1);
		switch (i)
		{
		case 0:
			sprintf(MsgA,"%d Nodes",numunique);
			Ptrdlg->SetDlgItemText(IDC_TYPEA,MsgA);								
			break;
		case 1:
			sprintf(MsgB,"%d Nodes",numunique);
			Ptrdlg->SetDlgItemText(IDC_TYPEB,MsgB);				
			break;
		case 2:
			sprintf(MsgC,"%d Nodes",numunique);
			Ptrdlg->SetDlgItemText(IDC_TYPEC,MsgC);				
			break;
		case 3:
			sprintf(MsgD,"%d Nodes",numunique);
			Ptrdlg->SetDlgItemText(IDC_TYPED,MsgD);				
			break;
		case 4:
			sprintf(MsgE,"%d Nodes",numunique);
			Ptrdlg->SetDlgItemText(IDC_TYPEE,MsgE);				
			break;
		case 5:
			sprintf(MsgF,"%d Nodes",numunique);
			Ptrdlg->SetDlgItemText(IDC_TYPEF,MsgF);				
			break;
		case 6:
			sprintf(MsgH,"%d Nodes",numunique);
			Ptrdlg->SetDlgItemText(IDC_TYPEH,MsgH);				
			break;
		case 7:
			sprintf(MsgX,"%d Nodes",numunique);
			Ptrdlg->SetDlgItemText(IDC_TYPEX,MsgX);				
			break;
		default:
			break;
		}

		//restructure array so first numunique elements are unique
		for (j = 1; j < num; j++)
		{
			if ((packed[j-1].Longitude == packed[j].Longitude) && 
				(packed[j-1].Latitude == packed[j].Latitude))
				continue;
			//if we get here we have a unique case
			packed[numunique] = packed[j];
			sprintf(noderec," %-8ld",numunique+1);
			fwrite(noderec,sizeof(noderec)-1,1,ndeatt);
			curnode->x = packed[numunique].Longitude;
			curnode->y = packed[numunique].Latitude;
			rechead =(shape_record_header_t *)calloc(1,sizeof(shape_record_header_t));
			rechead->num = numunique+1;
			rechead->length = SHPPOINTSIZE/2;
			SHP_Write_Record_Header(nodeshp,rechead);
			free(rechead);
			SHP_Write_Point(nodeshp,curnode);
			curindex = (shape_index_record_t *)calloc(1,sizeof(shape_index_record_t));
			curindex->offset = oldposition;
			curindex->length = Size;
			SHP_Write_Index(nodeshx,curindex);
			free(curindex);
			oldposition = Position;
			if (packed[numunique].Longitude < FileMinX)
			FileMinX = packed[numunique].Longitude;
			if (packed[numunique].Longitude > FileMaxX)
				FileMaxX = packed[numunique].Longitude;
			if (packed[numunique].Latitude < FileMinY)
				FileMinY = packed[numunique].Latitude;
			if (packed[numunique].Latitude > FileMaxY)
				FileMaxY = packed[numunique].Latitude;
			numunique++;		
			//Write_Line_Update(i,numunique,-1);
			switch (i)
			{
			case 0:
				sprintf(MsgA,"%d Nodes",numunique);
				Ptrdlg->SetDlgItemText(IDC_TYPEA,MsgA);								
				break;
			case 1:
				sprintf(MsgB,"%d Nodes",numunique);
				Ptrdlg->SetDlgItemText(IDC_TYPEB,MsgB);				
				break;
			case 2:
				sprintf(MsgC,"%d Nodes",numunique);
				Ptrdlg->SetDlgItemText(IDC_TYPEC,MsgC);				
				break;
			case 3:
				sprintf(MsgD,"%d Nodes",numunique);
				Ptrdlg->SetDlgItemText(IDC_TYPED,MsgD);				
				break;
			case 4:
				sprintf(MsgE,"%d Nodes",numunique);
				Ptrdlg->SetDlgItemText(IDC_TYPEE,MsgE);				
				break;
			case 5:
				sprintf(MsgF,"%d Nodes",numunique);
				Ptrdlg->SetDlgItemText(IDC_TYPEF,MsgF);				
				break;
			case 6:
				sprintf(MsgH,"%d Nodes",numunique);
				Ptrdlg->SetDlgItemText(IDC_TYPEH,MsgH);				
				break;
			case 7:
				sprintf(MsgX,"%d Nodes",numunique);
				Ptrdlg->SetDlgItemText(IDC_TYPEX,MsgX);				
				break;
			default:
				break;
			}

		}
		
		fprintf(LOG,"Wrote %d Type %c nodes to shape %s%snd%c \n", numunique, Types[i],
			Outfilepath,Outfiletitle,Types[i]);		
		free(curnode);		
		write_eof(ndeatt);
		//rewind and rewrite node shape header, and index file
		rewind(nodeshp);
		nodeshphead->fileLen = Position;
		nodeshphead->xMin = FileMinX;
		nodeshphead->yMin = FileMinY;
		nodeshphead->xMax = FileMaxX;
		nodeshphead->yMax = FileMaxY;		
		//AfxMessageBox("here1");
		SHP_Write_Header(nodeshp,nodeshphead);
		nodeshphead->fileLen = IPosition;
		rewind(nodeshx);
		SHP_Write_Header(nodeshx,nodeshphead);
		free(nodeshphead);
		fclose(nodeshx);
		
		fclose(nodeshp);        
		
		rewind(ndeatt);
		Build_db_Header(ndeatt,numunique,dbNodes);
		//match node and links
		//AfxMessageBox("here2");
		FileMinX = FileMinY = LARGE;
		FileMaxX = FileMaxY = -LARGE;
		arcshphead = Create_Shape_Header(SHP_ARC);
	    SHP_Write_Header(linkshp,arcshphead);
        SHP_Write_Header(linkshx,arcshphead); 
		Position = 100; 
		oldposition = Position;
		Ptrdlg->m_strProcess.Format("Building Lines of Type %c",Types[i]);
		Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
		//Ptrdlg->m_Progress.SetRange(0,Counts[i]);
		//Ptrdlg->m_Progress.SetStep(1);		
		for (j = base; j < base + Counts[i]; j++)
		{
			Npts = 0;
			CurrentMinX = CurrentMinY = LARGE;
			CurrentMaxX = CurrentMaxY = -LARGE;
			for (k = (j-base)*2; k < (j-base)*2 + 2; k++)
			{
				if (strcmp(Type1s[j].Tlid,nodes[k].Tlid) != 0)
				{
					info.Format("ERROR-nonmatching Tlid values in the link file %s and the node file %s",
						Type1s[j].Tlid, nodes[k].Tlid);
					Ptrdlg->ErrorMessage(info);
					info.Format("link number %ld node number %ld",j,k);
					Ptrdlg->ErrorMessage(info);
					MissingFile = -1;
					return;
				}
				upper = numunique - 1;
				lower = 0;
				found = 0;
				if (numunique ==1)
					found = 1;
				while (upper - lower > 0)
				{			
					if (nodes[k].Longitude == packed[lower].Longitude)
					{
						if (nodes[k].Latitude == packed[lower].Latitude)
						{
							//we have a match   
							found = 1;
							idnum = lower+1;
							break;
						}
					}
					if (nodes[k].Longitude == packed[upper].Longitude)
					{
						if (nodes[k].Latitude == packed[upper].Latitude)
						{
							//we have a match   
							found = 1;
							idnum = upper+1;
							break;
						}
					}
					//the following should never happen
					if ((upper - lower) == 1) 
					{//ERROR no match found
						info.Format("ERROR - no match found for %s for direction %d",nodes[k].Tlid, nodes[k].Toflag);
						Ptrdlg->ErrorMessage(info);
						info.Format("search values %lf %lf",nodes[k].Longitude,nodes[k].Latitude);
						Ptrdlg->ErrorMessage(info);
						info.Format("nupper %ld %lf %lf", upper,packed[upper].Longitude, packed[upper].Latitude);
						Ptrdlg->ErrorMessage(info);
						info.Format("lower %ld %lf %lf", lower,packed[lower].Longitude, packed[lower].Latitude);
						Ptrdlg->ErrorMessage(info);						
						MissingFile = -1;
						return;
					}
					halfway = (long)floor((upper + lower) / 2);      
					if (nodes[k].Longitude == packed[halfway].Longitude)
					{
						if (nodes[k].Latitude == packed[halfway].Latitude)
						{
							//we have a match   
							found = 1;
							idnum = halfway+1;
							break;
						}
					}
					if (packed[halfway].Longitude == nodes[k].Longitude)
					{
						if (packed[halfway].Latitude < nodes[k].Latitude)
						{                 
							lower = halfway;  
						}
						else
						{
							upper = halfway;                    
						}
					}                                      
					else 
					{           
						if (packed[halfway].Longitude < nodes[k].Longitude)
						{
							lower = halfway;      
						} 
						else
           				{
							upper = halfway;                            
						}                              
					}
				}//while upper and lower
				//need to check for a found value
				if (found == 0)
				{
					info.Format("ERROR node %lf %lf %s %d was not found",nodes[k].Longitude, nodes[k].Latitude,
						nodes[k].Tlid, nodes[k].Toflag);
					Ptrdlg->ErrorMessage(info);					
					MissingFile = -1;
					return;
				}
				//we have found a case, time to update max and min values

				if (nodes[k].Longitude < CurrentMinX)
					CurrentMinX = nodes[k].Longitude;
				if (nodes[k].Longitude > CurrentMaxX)
					CurrentMaxX = nodes[k].Longitude;
				if (nodes[k].Latitude < CurrentMinY)
					CurrentMinY = nodes[k].Latitude;
				if (nodes[k].Latitude > CurrentMaxY)
					CurrentMaxY = nodes[k].Latitude;
				
				if (nodes[k].Longitude < FileMinX)
					FileMinX = nodes[k].Longitude;
				if (nodes[k].Longitude > FileMaxX)
					FileMaxX = nodes[k].Longitude;
				if (nodes[k].Latitude < FileMinY)
					FileMinY = nodes[k].Latitude;
				if (nodes[k].Latitude > FileMaxY)
					FileMaxY = nodes[k].Latitude;

				//we have found a case, time to write           
				if (nodes[k].Toflag == 0L)
				{
			
					//sprintf(linkrec," %-10s%-8ld",nodes[k].Tlid,idnum);
					sprintf(linkrec," %-10s",nodes[k].Tlid);
					sprintf(&linkrec[11],"%-8ld",idnum);
					Pts[Npts].Longitude = nodes[k].Longitude;
					Pts[Npts].Latitude = nodes[k].Latitude;
					Npts++;
					Get_Shape_Points(nodes[k].Tlid,0);
				}
				else
				{
					/*sprintf(&linkrec[19],"%-8ld%-2s%-30s%-4s%-2s%-3s%-11s%-11s%-11s%-11s%-5s%-5s",
					idnum,Type1s[j].Fedirp,Type1s[j].Fename,Type1s[j].Fetype,
					Type1s[j].Fedirs, Type1s[j].Cfcc,Type1s[j].Fraddl, Type1s[j].Toaddl, Type1s[j].Fraddr, 
					Type1s[j].Toaddr,Type1s[j].Zipl,Type1s[j].Zipr);
					fwrite(&linkrec,sizeof(linkrec)-1,1,linkndes);*/
					Pts[Npts].Longitude = nodes[k].Longitude;
					Pts[Npts].Latitude = nodes[k].Latitude;
					Npts++;
					distance = 0.0;
					for (m = 0; m < Npts -1; m++)
						distance += Great_Circle_Distance(&Pts[m], &Pts[m+1]);

					/*sprintf(&linkrec[19],"%-8ld%-10.5lf%-2s%-30s%-4s%-2s%-3s%-11s%-11s%-11s%-11s%-5s%-5s",
					idnum,distance,Type1s[j].Fedirp,Type1s[j].Fename,Type1s[j].Fetype,
					Type1s[j].Fedirs, Type1s[j].Cfcc,Type1s[j].Fraddl, Type1s[j].Toaddl, Type1s[j].Fraddr, 
					Type1s[j].Toaddr,Type1s[j].Zipl,Type1s[j].Zipr);*/
					sprintf(&linkrec[19],"%-8ld",idnum);
					sprintf(&linkrec[27],"%-10.5f",distance);
					sprintf(&linkrec[37],"%-2s",Type1s[j].Fedirp);
					sprintf(&linkrec[39],"%-30s",Type1s[j].Fename);
					sprintf(&linkrec[69],"%-4s",Type1s[j].Fetype);
					sprintf(&linkrec[73],"%-2s",Type1s[j].Fedirs);
					sprintf(&linkrec[75],"%-3s",Type1s[j].Cfcc);
					sprintf(&linkrec[78],"%-11s",Type1s[j].Fraddl);
					sprintf(&linkrec[89],"%-11s",Type1s[j].Toaddl);
					sprintf(&linkrec[100],"%-11s",Type1s[j].Fraddr);
					sprintf(&linkrec[111],"%-11s",Type1s[j].Toaddr);
					sprintf(&linkrec[122],"%-5s",Type1s[j].Zipl);
					sprintf(&linkrec[127],"%-5s%c%c",Type1s[j].Zipr,Type1s[j].Census1,Type1s[j].Census2);

					fwrite(&linkrec,sizeof(linkrec)-1,1,linkndes);
				}
			}//for on k
			//time to write arc stuff to shape file
			rechead =(shape_record_header_t *)calloc(1,sizeof(shape_record_header_t));
			rechead->num = (int)(j - base + 1);
			//Write_Line_Update(i,numunique,rechead->num);
			switch (i)
			{
			case 0:
				sprintf(MsgA,"%d Nodes, %d Lines", numunique, rechead->num);
				Ptrdlg->SetDlgItemText(IDC_TYPEA,MsgA);			
				break;
			case 1:
				sprintf(MsgB,"%d Nodes, %d Lines", numunique, rechead->num);
				Ptrdlg->SetDlgItemText(IDC_TYPEB,MsgB);			
				break;
			case 2:
				sprintf(MsgC,"%d Nodes, %d Lines", numunique, rechead->num);
				Ptrdlg->SetDlgItemText(IDC_TYPEC,MsgC);			
				break;
			case 3:
				sprintf(MsgD,"%d Nodes, %d Lines", numunique, rechead->num);
				Ptrdlg->SetDlgItemText(IDC_TYPED,MsgD);			
				break;
			case 4:
				sprintf(MsgE,"%d Nodes, %d Lines", numunique, rechead->num);
				Ptrdlg->SetDlgItemText(IDC_TYPEE,MsgE);			
				break;
			case 5:
				sprintf(MsgF,"%d Nodes, %d Lines", numunique, rechead->num);
				Ptrdlg->SetDlgItemText(IDC_TYPEF,MsgF);			
				break;
			case 6:
				sprintf(MsgH,"%d Nodes, %d Lines", numunique, rechead->num);
				Ptrdlg->SetDlgItemText(IDC_TYPEH,MsgH);			
				break;
			case 7:
				sprintf(MsgX,"%d Nodes, %d Lines", numunique, rechead->num);
				Ptrdlg->SetDlgItemText(IDC_TYPEX,MsgX);			
				break;
			default:
				break;
			}
			nparts = 1;
			steppos = (int) (rechead->num * 100/Counts[i]);
			//Ptrdlg->m_Progress.StepIt();
			Ptrdlg->m_Progress.SetPos(steppos);
			rechead->length = (4 + 32 + 4 + 4 + (4 * nparts) + (16 * Npts) );			
			SHP_Write_Record_Header(linkshp,rechead);
			free(rechead);
			curarc = (shape_arc_t *)calloc(1,sizeof(shape_arc_t));
			curarc->shapeType = SHP_ARC;
			curarc->xMin = CurrentMinX;
			curarc->yMin = CurrentMinY;
			curarc->xMax = CurrentMaxX;
			curarc->yMax = CurrentMaxY;
			curarc->numParts = nparts;
			curarc->numPoints = Npts;
			curarc->parts = (int *)calloc(nparts,sizeof(int ));
			curarc->points = (point_t *)calloc(Npts,sizeof(point_t));
			curarc->parts[0] = 0;
			for (m = 0; m < Npts; m++)
			{
				curarc->points[m].x = Pts[m].Longitude;
				curarc->points[m].y = Pts[m].Latitude;
			}		   
			SHP_Write_Arc(linkshp,curarc);
			free(curarc->parts);
			free(curarc->points);
			free(curarc);
			curindex = (shape_index_record_t *)calloc(1,sizeof(shape_index_record_t));
			curindex->offset = oldposition;
			curindex->length = Size;
			SHP_Write_Index(linkshx,curindex);
			free(curindex);
			oldposition = Position;			
		}//for on j
		//time to rewind and rebuild file header
		//sprintf(msg,"rechead->num:%d",rechead->num);
		//AfxMessageBox(msg);
		//Write_Line_Update(i,numunique,Counts[i]); //rechead->num);		
		
		fprintf(LOG,"Wrote %ld Type %c lines to shape %s%slk%c\n",Counts[i],Types[i],
			Outfilepath,Outfiletitle,Types[i]);
		arcshphead->fileLen = Position;
		arcshphead->xMin = FileMinX;
		arcshphead->yMin = FileMinY;
		arcshphead->xMax = FileMaxX;
		arcshphead->yMax = FileMaxY;
		rewind(linkshp);
		SHP_Write_Header(linkshp,arcshphead);
		arcshphead->fileLen = IPosition;
		rewind(linkshx);
		SHP_Write_Header(linkshx,arcshphead);
		free(arcshphead);
		fclose(linkshp);
		
		fclose(linkshx);

		fclose(ndeatt);
		
		write_eof(linkndes);
		fclose(linkndes);
		
		free(nodes);		
		free(packed);
	}//for on i	

}
void Match_Poly_Lines_County90()
{
	int polyid, found, i, nparts, ptcount;
	long num, n, written, curcase;
	County_Border_Type *county;
	double  curX, curY;	
    FILE  *dbfout, *ptstemp, *headtemp, *partstemp, *boxtemp;
	CString fname, info;
	char  ctyrecord[147]; //131]; 
	char  msg[100];
	int  steppos;
	char *ctyname, *statename;
	CString errmsg;

	int doleft, doright;

	
	if (APolycounts[0] == 0)
	{
		Ptrdlg->SetDlgItemText(IDC_COUNTY,"No Such Cases");			
		return;
	}
	
	/*fname.Format("%s%scty.dbf",Outfilepath,Outfiletitle);		
	dbfout = fopen(fname,"wb");
	if (dbfout == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}*/
	ptstemp = fopen("pts.tmp","wb");
	if (ptstemp == NULL)
	{
		errmsg.Format("Could not open file pts.tmp");
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	fname.Format("%s%scty.dbf",Outfilepath,Outfiletitle);		
	dbfout = fopen(fname,"wb");
	if (dbfout == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	headtemp = fopen("head.tmp","wb");
	if (headtemp == NULL)
	{
		errmsg.Format("Could not open file head.tmp");
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	boxtemp = fopen("box.tmp","wb");
	if (boxtemp == NULL)
	{
		errmsg.Format("Could not open file box.tmp");
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	partstemp = fopen("parts.tmp","wb");
	if (partstemp == NULL)
	{
		errmsg.Format("Could not open file parts.tmp");
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	county = (County_Border_Type *)calloc(APolycounts[0]+Watercut*SPolycounts[0],sizeof(County_Border_Type));
	written = 0;
	for (num = 0; num < CountI; num++)
	{
	
		if (strcmp(TypeIs[num].County90l,TypeIs[num].County90r)== 0)
		{
			if (Watercut)
			{
				if (TypeIs[num].Waterl == TypeIs[num].Waterr)
					continue;
			}
			else
				continue;		
		}
		doleft = 0;
		if (strcmp(TypeIs[num].County90l,"     ") != 0)
		{
			if (Watercut)
			{
				if (!TypeIs[num].Waterl)
					doleft = 1;
			}
			else
				doleft = 1;
			if (doleft)
			{//left case
				sprintf(county[written].Id,"%s",TypeIs[num].County90l);
				sprintf(county[written].Tlid,"%s",TypeIs[num].Tlid);
				county[written].Frlong = Type1s[num].Frlong;
				county[written].Frlat = Type1s[num].Frlat;
				county[written].Tolong = Type1s[num].Tolong;
				county[written].Tolat = Type1s[num].Tolat;
				county[written].Chosen = 0;			
				county[written].Flip = 1;
				written++;
			}
		}
		if (written > APolycounts[0]+Watercut*SPolycounts[0])
		{
			Ptrdlg->ErrorMessage("the number of county border lines exceeds the count");			
			MissingFile = -1;
			return;
		}
		doright = 0;
		if (strcmp(TypeIs[num].County90r,"     ") != 0)
		{
			if(Watercut)
			{
				if (!TypeIs[num].Waterr)
					doright = 1;
			}
			else
				doright = 1;
			if (doright)
			{
	
				sprintf(county[written].Id,"%s",TypeIs[num].County90r);
				sprintf(county[written].Tlid,"%s",TypeIs[num].Tlid);
				county[written].Frlong = Type1s[num].Frlong;
				county[written].Frlat = Type1s[num].Frlat;
				county[written].Tolong = Type1s[num].Tolong;
				county[written].Tolat = Type1s[num].Tolat;
				county[written].Chosen = 0;
				county[written].Flip = 0;
				written++;
			}
		}
		if (written > APolycounts[0]+Watercut*SPolycounts[0])
		{
			Ptrdlg->ErrorMessage("the number of county border lines exceeds the count");			
			MissingFile = -1;
			return;
		}
	}	

	
	qsort((void *)county,written,sizeof(County_Border_Type),(compfn)CompareCounty);
	Ptrdlg->m_strProcess.Format("Gathering County Boundary Lines");
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	//Ptrdlg->m_Progress.SetRange(0,written);
	//Ptrdlg->m_Progress.SetStep(1);		
	FileMinX = FileMinY = LARGE;
	FileMaxX = FileMaxY = -LARGE;
	CurrentMinX = CurrentMinY = LARGE;
	CurrentMaxX = CurrentMaxY = -LARGE;
	curcase = 0; // counter on line being processed
	polyid = 1; //counter on polygon being processed
	Npts = 0; //counter on points in poly ring being processed
	nparts = 1; // part of polygon (ring counter) being processed
	ptcount = 0; //counts the points in the current ring
	Build_db_Header(dbfout,0,dbCounty);
	Build_db_FieldHeaders(dbfout,dbCounty);
	statename = Get_TypeC_Name(0,"",county[curcase].Id);
	ctyname = Get_TypeC_Name(1,"",county[curcase].Id);
//	sprintf(ctyrecord," %-8d%-5s%-66s%-66s",polyid,county[curcase].Id,
//		statename,ctyname);
	sprintf(ctyrecord," %-8d",polyid);
	sprintf(&ctyrecord[9],"%-5s",county[curcase].Id);
	sprintf(&ctyrecord[14],"%-66s",statename);
	sprintf(&ctyrecord[80],"%-66s",ctyname);
	//sprintf(ctyrecord," %-8d%-5s",polyid,county[curcase].Id);
	fwrite(&ctyrecord,sizeof(ctyrecord)-1,1,dbfout);
	if (county[0].Flip == 0)
	{
		curX = county[curcase].Tolong;
		curY = county[curcase].Tolat;
		Pts[Npts].Longitude = county[curcase].Frlong;
		Pts[Npts].Latitude = county[curcase].Frlat;
		Npts++;
		Get_Shape_Points(county[curcase].Tlid,county[curcase].Flip);
		Pts[Npts].Longitude = county[curcase].Tolong;
		Pts[Npts].Latitude = county[curcase].Tolat;
		Npts++;
		county[curcase].Chosen = 1;	
	}
	else
	{
		curX = county[curcase].Frlong;
		curY = county[curcase].Frlat;
		Pts[Npts].Longitude = county[0].Tolong;
		Pts[Npts].Latitude = county[0].Tolat;
		Npts++;
		Get_Shape_Points(county[curcase].Tlid,county[curcase].Flip);
		Pts[Npts].Longitude = county[curcase].Frlong;
		Pts[Npts].Latitude = county[curcase].Frlat;
		Npts++;
		county[curcase].Chosen = 1;	
	}
	ptcount += Npts;	
	fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
	if (Pts[0].Longitude < CurrentMinX)
		CurrentMinX = Pts[0].Longitude;
	if (Pts[0].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < CurrentMinY)
		CurrentMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[0].Latitude;	
	if (Pts[0].Longitude < FileMinX)
		FileMinX = Pts[0].Longitude;
	if (Pts[0].Longitude > FileMaxX)
		FileMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < FileMinY)
		FileMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > FileMaxY)
		FileMaxY = Pts[0].Latitude;

	if (Pts[Npts-1].Longitude < CurrentMinX)
		CurrentMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < CurrentMinY)
		CurrentMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[Npts-1].Latitude;	
	if (Pts[Npts-1].Longitude < FileMinX)
		FileMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > FileMaxX)
		FileMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < FileMinY)
		FileMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > FileMaxY)
		FileMaxY = Pts[Npts-1].Latitude;
	n = 1;
	steppos = (int)(n*100/written);
	//Ptrdlg->m_Progress.StepIt();
	Ptrdlg->m_Progress.SetPos(steppos);
    while (n < written)
	{
		
		sprintf(msg,"processed %d of %d records",n,written);
		Ptrdlg->SetDlgItemText(IDC_COUNTY,msg);		

		//printf("\n Have written %ld of %ld county boundary lines",n, written);
		found = 0;
		for (i = 1; i < written; i++)
        {
			Npts = 0;
			if (county[i].Chosen != 0)
				continue;
			if (county[i].Flip == 0)
			{
				 if ((county[i].Frlong == curX) && (county[i].Frlat == curY))
					{                          
					if (strcmp(county[i].Id,county[curcase].Id) != 0)
					  continue;
					Get_Shape_Points(county[i].Tlid,county[i].Flip);
					Pts[Npts].Longitude = county[i].Tolong;
					Pts[Npts].Latitude = county[i].Tolat;
					Npts++;
					n++;
					steppos = (int) (n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					//Ptrdlg->m_Progress.StepIt();
					county[i].Chosen = 1;            
					found = 1;                      
					curX = county[i].Tolong;
					curY = county[i].Tolat;                
					curcase = i;
					break;
					}
			}
			else
			{
				if ((county[i].Tolong == curX) && (county[i].Tolat == curY))
					{
					if (strcmp(county[i].Id,county[curcase].Id) != 0)
					  continue;	            
					Get_Shape_Points(county[i].Tlid,county[i].Flip);
					Pts[Npts].Longitude = county[i].Frlong;
					Pts[Npts].Latitude = county[i].Frlat;
					Npts++;				
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					//Ptrdlg->m_Progress.StepIt();
					curX = county[i].Frlong;
					curY = county[i].Frlat;                        
					county[i].Chosen = 1;		
					found = 1;          
					curcase = i;
					break;
					}
			}
        }//close for loop
		
		if (found == 0) //initialize new case, eg, new ring in current poly
			// or new polyid
        {
	//		if (ptcount > 0)
			fwrite(&ptcount,sizeof(int),1,headtemp);
			ptcount = 0;
			for (i = 0; i < written; i++)//first check for new ring in current poly
            {                    
         		if (county[i].Chosen != 0)
					continue;             
				if (strcmp(county[i].Id,county[curcase].Id) != 0)
					continue;
				//if we get here we have a new ring of the current polygon
				found = 1;
				nparts++;				
				Npts = 0;				
				if (county[i].Flip == 0)
				{
					Pts[Npts].Longitude = county[i].Frlong;
					Pts[Npts].Latitude = county[i].Frlat;
					Npts++;
					Get_Shape_Points(county[i].Tlid,county[i].Flip);
					Pts[Npts].Longitude = county[i].Tolong;
					Pts[Npts].Latitude = county[i].Tolat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					//Ptrdlg->m_Progress.StepIt();
					county[i].Chosen = 1;            
					found = 1;                      
					curX = county[i].Tolong;
					curY = county[i].Tolat;                
					curcase = i;
					break;					
				}
				else
				{
					Pts[Npts].Longitude = county[i].Tolong;
					Pts[Npts].Latitude = county[i].Tolat;
					Npts++;
					Get_Shape_Points(county[i].Tlid,county[i].Flip);
					Pts[Npts].Longitude = county[i].Frlong;
					Pts[Npts].Latitude = county[i].Frlat;
					Npts++;				
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					//Ptrdlg->m_Progress.StepIt();
					curX = county[i].Frlong;
					curY = county[i].Frlat;                        
					county[i].Chosen = 1;		
					found = 1;          
					curcase = i;
					break;					
				}	
			}//close on for loop on i
		}//close one if on found
        if (found == 0) // new polygon, first ring
		{
			fwrite(&nparts,sizeof(int),1,partstemp);
	//		fwrite(&ptcount,sizeof(int),1,headtemp);
			nparts = 1;
			fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
			CurrentMinX = CurrentMinY = LARGE;
			CurrentMaxX = CurrentMaxY = -LARGE;

			for (i = 0; i < written; i++)//first check for new ring in current poly
            {                    
         		if (county[i].Chosen != 0)
					continue;             
				polyid++;
				statename = Get_TypeC_Name(0,"",county[i].Id);
				ctyname = Get_TypeC_Name(1,"",county[i].Id);
				//sprintf(ctyrecord," %-8d%-5s%-66s%-66s",polyid,county[i].Id,statename,
				//	ctyname);	
				sprintf(ctyrecord," %-8d",polyid);
				sprintf(&ctyrecord[9],"%-5s",county[i].Id);
				sprintf(&ctyrecord[14],"%-66s",statename);
				sprintf(&ctyrecord[80],"%-66s",ctyname);
	
				//sprintf(ctyrecord," %-8d%-5s",polyid,county[i].Id);
				fwrite(&ctyrecord,sizeof(ctyrecord)-1,1,dbfout);    		
				Npts = 0;
				if (county[i].Flip == 0)
				{
					Pts[Npts].Longitude = county[i].Frlong;
					Pts[Npts].Latitude = county[i].Frlat;
					Npts++;
					Get_Shape_Points(county[i].Tlid,county[i].Flip);
					Pts[Npts].Longitude = county[i].Tolong;
					Pts[Npts].Latitude = county[i].Tolat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					//Ptrdlg->m_Progress.StepIt();
					county[i].Chosen = 1;            
					found = 1;                      
					curX = county[i].Tolong;
					curY = county[i].Tolat;                
					curcase = i;
					break;					
				}
				else
				{
					Pts[Npts].Longitude = county[i].Tolong;
					Pts[Npts].Latitude = county[i].Tolat;
					Npts++;
					Get_Shape_Points(county[i].Tlid,county[i].Flip);
					Pts[Npts].Longitude = county[i].Frlong;
					Pts[Npts].Latitude = county[i].Frlat;
					Npts++;				
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					//Ptrdlg->m_Progress.StepIt();
					curX = county[i].Frlong;
					curY = county[i].Frlat;                        
					county[i].Chosen = 1;		
					found = 1;          
					curcase = i;	
					break;					
				}	
			}
		}
		//by now found should be 1
		if (found == 0)
		{
			info.Format("ERROR - found is zero");
			Ptrdlg->ErrorMessage(info);			
			MissingFile = -1;
			return;
		}
		ptcount += Npts;
		fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
		if (Pts[0].Longitude < CurrentMinX)
		CurrentMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < CurrentMinY)
			CurrentMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[0].Latitude;	
		if (Pts[0].Longitude < FileMinX)
			FileMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > FileMaxX)
			FileMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < FileMinY)
			FileMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > FileMaxY)
			FileMaxY = Pts[0].Latitude;

		if (Pts[Npts-1].Longitude < CurrentMinX)
			CurrentMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < CurrentMinY)
			CurrentMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[Npts-1].Latitude;	
		if (Pts[Npts-1].Longitude < FileMinX)
			FileMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > FileMaxX)
			FileMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < FileMinY)
			FileMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > FileMaxY)
			FileMaxY = Pts[Npts-1].Latitude;		
	}//close while loop
	fwrite(&ptcount,sizeof(int),1,headtemp);
	fwrite(&nparts,sizeof(int),1,partstemp);
	fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
	fclose(boxtemp);
	fclose(headtemp);
	fclose(ptstemp);
	fclose(partstemp);
	
	sprintf(msg,"processed %d of %d records",n,written);
	Ptrdlg->SetDlgItemText(IDC_COUNTY,msg);		
	write_eof(dbfout);
	rewind(dbfout);
	Build_db_Header(dbfout,polyid,dbCounty);
	fclose(dbfout);
	free(county);
	Build_Poly_Shape("cty");	
	Ptrdlg->m_strCounty.Format("%d County",polyid);
	Ptrdlg->SetDlgItemText(IDC_COUNTY,Ptrdlg->m_strCounty);
	fprintf(LOG,"Wrote %d County polygon to shape %s%scty\n", polyid,Outfilepath,
		Outfiletitle);		
	
}
void Match_Poly_Lines_Countycu()
{
	int polyid, found, i, nparts, ptcount;
	long num, n, written, curcase;
	County_Border_Type *countycu;
	double  curX, curY;	
    FILE  *dbfout, *ptstemp, *headtemp, *partstemp, *boxtemp;
	CString fname, info;
	char  ctyrecord[147]; //131]; 
	char  msg[100];
	int  steppos;
	char *ctyname, *statename;
	CString errmsg;

	int doleft, doright;

	
	if (APolycounts[13] == 0)
	{
		Ptrdlg->SetDlgItemText(IDC_COUNTYCU,"No Such Cases");			
		return;
	}
	
	fname.Format("%s%sctycu.dbf",Outfilepath,Outfiletitle);		
	dbfout = fopen(fname,"wb");
	if (dbfout == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	ptstemp = fopen("pts.tmp","wb");
	if (ptstemp == NULL)
	{
		errmsg.Format("Could not open file pts.tmp");
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	/*fname.Format("%s%scty.dbf",Outfilepath,Outfiletitle);		
	dbfout = fopen(fname,"wb");
	if (dbfout == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}*/
	headtemp = fopen("head.tmp","wb");
	if (headtemp == NULL)
	{
		errmsg.Format("Could not open file head.tmp");
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	boxtemp = fopen("box.tmp","wb");
	if (boxtemp == NULL)
	{
		errmsg.Format("Could not open file box.tmp");
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	partstemp = fopen("parts.tmp","wb");
	if (partstemp == NULL)
	{
		errmsg.Format("Could not open file parts.tmp");
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	countycu = (County_Border_Type *)calloc(APolycounts[13]+Watercut*SPolycounts[0],sizeof(County_Border_Type));
	written = 0;
	for (num = 0; num < CountI; num++)
	{
	
		if (strcmp(TypeIs[num].Countycul,TypeIs[num].Countycur)== 0)
		{
			if (Watercut)
			{
				if (TypeIs[num].Waterl == TypeIs[num].Waterr)
					continue;
			}
			else
				continue;		
		}
		doleft = 0;
		if (strcmp(TypeIs[num].Countycul,"     ") != 0)
		{
			if (Watercut)
			{
				if (!TypeIs[num].Waterl)
					doleft = 1;
			}
			else
				doleft = 1;
			if (doleft)
			{//left case
				sprintf(countycu[written].Id,"%s",TypeIs[num].Countycul);
				sprintf(countycu[written].Tlid,"%s",TypeIs[num].Tlid);
				countycu[written].Frlong = Type1s[num].Frlong;
				countycu[written].Frlat = Type1s[num].Frlat;
				countycu[written].Tolong = Type1s[num].Tolong;
				countycu[written].Tolat = Type1s[num].Tolat;
				countycu[written].Chosen = 0;			
				countycu[written].Flip = 1;
				written++;
			}
		}
		if (written > APolycounts[13]+Watercut*SPolycounts[0])
		{
			Ptrdlg->ErrorMessage("the number of county border lines exceeds the count");			
			MissingFile = -1;
			return;
		}
		doright = 0;
		if (strcmp(TypeIs[num].Countycur,"     ") != 0)
		{
			if(Watercut)
			{
				if (!TypeIs[num].Waterr)
					doright = 1;
			}
			else
				doright = 1;
			if (doright)
			{
	
				sprintf(countycu[written].Id,"%s",TypeIs[num].Countycur);
				sprintf(countycu[written].Tlid,"%s",TypeIs[num].Tlid);
				countycu[written].Frlong = Type1s[num].Frlong;
				countycu[written].Frlat = Type1s[num].Frlat;
				countycu[written].Tolong = Type1s[num].Tolong;
				countycu[written].Tolat = Type1s[num].Tolat;
				countycu[written].Chosen = 0;
				countycu[written].Flip = 0;
				written++;
			}
		}
		if (written > APolycounts[13]+Watercut*SPolycounts[0])
		{
			Ptrdlg->ErrorMessage("the number of county border lines exceeds the count");			
			MissingFile = -1;
			return;
		}
	}	

	
	qsort((void *)countycu,written,sizeof(County_Border_Type),(compfn)CompareCounty);
	Ptrdlg->m_strProcess.Format("Gathering County Boundary Lines");
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	//Ptrdlg->m_Progress.SetRange(0,written);
	//Ptrdlg->m_Progress.SetStep(1);		
	FileMinX = FileMinY = LARGE;
	FileMaxX = FileMaxY = -LARGE;
	CurrentMinX = CurrentMinY = LARGE;
	CurrentMaxX = CurrentMaxY = -LARGE;
	curcase = 0; // counter on line being processed
	polyid = 1; //counter on polygon being processed
	Npts = 0; //counter on points in poly ring being processed
	nparts = 1; // part of polygon (ring counter) being processed
	ptcount = 0; //counts the points in the current ring
	Build_db_Header(dbfout,0,dbCounty);
	Build_db_FieldHeaders(dbfout,dbCounty);
	statename = Get_TypeC_Name(0,"",countycu[curcase].Id);
	ctyname = Get_TypeC_Name(1,"",countycu[curcase].Id);
//	sprintf(ctyrecord," %-8d%-5s%-66s%-66s",polyid,county[curcase].Id,
//		statename,ctyname);
	sprintf(ctyrecord," %-8d",polyid);
	sprintf(&ctyrecord[9],"%-5s",countycu[curcase].Id);
	sprintf(&ctyrecord[14],"%-66s",statename);
	sprintf(&ctyrecord[80],"%-66s",ctyname);
	//sprintf(ctyrecord," %-8d%-5s",polyid,county[curcase].Id);
	fwrite(&ctyrecord,sizeof(ctyrecord)-1,1,dbfout);
	if (countycu[0].Flip == 0)
	{
		curX = countycu[curcase].Tolong;
		curY = countycu[curcase].Tolat;
		Pts[Npts].Longitude = countycu[curcase].Frlong;
		Pts[Npts].Latitude = countycu[curcase].Frlat;
		Npts++;
		Get_Shape_Points(countycu[curcase].Tlid,countycu[curcase].Flip);
		Pts[Npts].Longitude = countycu[curcase].Tolong;
		Pts[Npts].Latitude = countycu[curcase].Tolat;
		Npts++;
		countycu[curcase].Chosen = 1;	
	}
	else
	{
		curX = countycu[curcase].Frlong;
		curY = countycu[curcase].Frlat;
		Pts[Npts].Longitude = countycu[0].Tolong;
		Pts[Npts].Latitude = countycu[0].Tolat;
		Npts++;
		Get_Shape_Points(countycu[curcase].Tlid,countycu[curcase].Flip);
		Pts[Npts].Longitude = countycu[curcase].Frlong;
		Pts[Npts].Latitude = countycu[curcase].Frlat;
		Npts++;
		countycu[curcase].Chosen = 1;	
	}
	ptcount += Npts;	
	fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
	if (Pts[0].Longitude < CurrentMinX)
		CurrentMinX = Pts[0].Longitude;
	if (Pts[0].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < CurrentMinY)
		CurrentMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[0].Latitude;	
	if (Pts[0].Longitude < FileMinX)
		FileMinX = Pts[0].Longitude;
	if (Pts[0].Longitude > FileMaxX)
		FileMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < FileMinY)
		FileMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > FileMaxY)
		FileMaxY = Pts[0].Latitude;

	if (Pts[Npts-1].Longitude < CurrentMinX)
		CurrentMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < CurrentMinY)
		CurrentMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[Npts-1].Latitude;	
	if (Pts[Npts-1].Longitude < FileMinX)
		FileMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > FileMaxX)
		FileMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < FileMinY)
		FileMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > FileMaxY)
		FileMaxY = Pts[Npts-1].Latitude;
	n = 1;
	steppos = (int)(n*100/written);
	//Ptrdlg->m_Progress.StepIt();
	Ptrdlg->m_Progress.SetPos(steppos);
    while (n < written)
	{
		
		sprintf(msg,"processed %d of %d records",n,written);
		Ptrdlg->SetDlgItemText(IDC_COUNTYCU,msg);		

		//printf("\n Have written %ld of %ld county boundary lines",n, written);
		found = 0;
		for (i = 1; i < written; i++)
        {
			Npts = 0;
			if (countycu[i].Chosen != 0)
				continue;
			if (countycu[i].Flip == 0)
			{
				 if ((countycu[i].Frlong == curX) && (countycu[i].Frlat == curY))
					{                          
					if (strcmp(countycu[i].Id,countycu[curcase].Id) != 0)
					  continue;
					Get_Shape_Points(countycu[i].Tlid,countycu[i].Flip);
					Pts[Npts].Longitude = countycu[i].Tolong;
					Pts[Npts].Latitude = countycu[i].Tolat;
					Npts++;
					n++;
					steppos = (int) (n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					//Ptrdlg->m_Progress.StepIt();
					countycu[i].Chosen = 1;            
					found = 1;                      
					curX = countycu[i].Tolong;
					curY = countycu[i].Tolat;                
					curcase = i;
					break;
					}
			}
			else
			{
				if ((countycu[i].Tolong == curX) && (countycu[i].Tolat == curY))
					{
					if (strcmp(countycu[i].Id,countycu[curcase].Id) != 0)
					  continue;	            
					Get_Shape_Points(countycu[i].Tlid,countycu[i].Flip);
					Pts[Npts].Longitude = countycu[i].Frlong;
					Pts[Npts].Latitude = countycu[i].Frlat;
					Npts++;				
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					//Ptrdlg->m_Progress.StepIt();
					curX = countycu[i].Frlong;
					curY = countycu[i].Frlat;                        
					countycu[i].Chosen = 1;		
					found = 1;          
					curcase = i;
					break;
					}
			}
        }//close for loop
		
		if (found == 0) //initialize new case, eg, new ring in current poly
			// or new polyid
        {
			fwrite(&ptcount,sizeof(int),1,headtemp);
			ptcount = 0;
			for (i = 0; i < written; i++)//first check for new ring in current poly
            {                    
         		if (countycu[i].Chosen != 0)
					continue;             
				if (strcmp(countycu[i].Id,countycu[curcase].Id) != 0)
					continue;
				//if we get here we have a new ring of the current polygon
				found = 1;
				nparts++;				
				Npts = 0;				
				if (countycu[i].Flip == 0)
				{
					Pts[Npts].Longitude = countycu[i].Frlong;
					Pts[Npts].Latitude = countycu[i].Frlat;
					Npts++;
					Get_Shape_Points(countycu[i].Tlid,countycu[i].Flip);
					Pts[Npts].Longitude = countycu[i].Tolong;
					Pts[Npts].Latitude = countycu[i].Tolat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					//Ptrdlg->m_Progress.StepIt();
					countycu[i].Chosen = 1;            
					found = 1;                      
					curX = countycu[i].Tolong;
					curY = countycu[i].Tolat;                
					curcase = i;
					break;					
				}
				else
				{
					Pts[Npts].Longitude = countycu[i].Tolong;
					Pts[Npts].Latitude = countycu[i].Tolat;
					Npts++;
					Get_Shape_Points(countycu[i].Tlid,countycu[i].Flip);
					Pts[Npts].Longitude = countycu[i].Frlong;
					Pts[Npts].Latitude = countycu[i].Frlat;
					Npts++;				
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					//Ptrdlg->m_Progress.StepIt();
					curX = countycu[i].Frlong;
					curY = countycu[i].Frlat;                        
					countycu[i].Chosen = 1;		
					found = 1;          
					curcase = i;
					break;					
				}	
			}//close on for loop on i
		}//close one if on found
        if (found == 0) // new polygon, first ring
		{
			fwrite(&nparts,sizeof(int),1,partstemp);
			//fwrite(&ptcount,sizeof(int),1,headtemp);
			nparts = 1;
			fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
			CurrentMinX = CurrentMinY = LARGE;
			CurrentMaxX = CurrentMaxY = -LARGE;

			for (i = 0; i < written; i++)//first check for new ring in current poly
            {                    
         		if (countycu[i].Chosen != 0)
					continue;             
				polyid++;
				statename = Get_TypeC_Name(0,"",countycu[i].Id);
				ctyname = Get_TypeC_Name(1,"",countycu[i].Id);
				//sprintf(ctyrecord," %-8d%-5s%-66s%-66s",polyid,county[i].Id,statename,
				//	ctyname);	
				sprintf(ctyrecord," %-8d",polyid);
				sprintf(&ctyrecord[9],"%-5s",countycu[i].Id);
				sprintf(&ctyrecord[14],"%-66s",statename);
				sprintf(&ctyrecord[80],"%-66s",ctyname);
	
				//sprintf(ctyrecord," %-8d%-5s",polyid,county[i].Id);
				fwrite(&ctyrecord,sizeof(ctyrecord)-1,1,dbfout);    		
				Npts = 0;
				if (countycu[i].Flip == 0)
				{
					Pts[Npts].Longitude = countycu[i].Frlong;
					Pts[Npts].Latitude = countycu[i].Frlat;
					Npts++;
					Get_Shape_Points(countycu[i].Tlid,countycu[i].Flip);
					Pts[Npts].Longitude = countycu[i].Tolong;
					Pts[Npts].Latitude = countycu[i].Tolat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					//Ptrdlg->m_Progress.StepIt();
					countycu[i].Chosen = 1;            
					found = 1;                      
					curX = countycu[i].Tolong;
					curY = countycu[i].Tolat;                
					curcase = i;
					break;					
				}
				else
				{
					Pts[Npts].Longitude = countycu[i].Tolong;
					Pts[Npts].Latitude = countycu[i].Tolat;
					Npts++;
					Get_Shape_Points(countycu[i].Tlid,countycu[i].Flip);
					Pts[Npts].Longitude = countycu[i].Frlong;
					Pts[Npts].Latitude = countycu[i].Frlat;
					Npts++;				
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					//Ptrdlg->m_Progress.StepIt();
					curX = countycu[i].Frlong;
					curY = countycu[i].Frlat;                        
					countycu[i].Chosen = 1;		
					found = 1;          
					curcase = i;	
					break;					
				}	
			}
		}
		//by now found should be 1
		if (found == 0)
		{
			info.Format("ERROR - found is zero");
			Ptrdlg->ErrorMessage(info);			
			MissingFile = -1;
			return;
		}
		ptcount += Npts;
		fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
		if (Pts[0].Longitude < CurrentMinX)
		CurrentMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < CurrentMinY)
			CurrentMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[0].Latitude;	
		if (Pts[0].Longitude < FileMinX)
			FileMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > FileMaxX)
			FileMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < FileMinY)
			FileMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > FileMaxY)
			FileMaxY = Pts[0].Latitude;

		if (Pts[Npts-1].Longitude < CurrentMinX)
			CurrentMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < CurrentMinY)
			CurrentMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[Npts-1].Latitude;	
		if (Pts[Npts-1].Longitude < FileMinX)
			FileMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > FileMaxX)
			FileMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < FileMinY)
			FileMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > FileMaxY)
			FileMaxY = Pts[Npts-1].Latitude;		
	}//close while loop
	fwrite(&ptcount,sizeof(int),1,headtemp);
	fwrite(&nparts,sizeof(int),1,partstemp);
	fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
	fclose(boxtemp);
	fclose(headtemp);
	fclose(ptstemp);
	fclose(partstemp);
	
	sprintf(msg,"processed %d of %d records",n,written);
	Ptrdlg->SetDlgItemText(IDC_COUNTYCU,msg);		
	write_eof(dbfout);
	rewind(dbfout);
	Build_db_Header(dbfout,polyid,dbCounty);
	fclose(dbfout);
	free(countycu);
	Build_Poly_Shape("ctycu");	
	Ptrdlg->m_strCountycu.Format("%d County",polyid);
	Ptrdlg->SetDlgItemText(IDC_COUNTYCU,Ptrdlg->m_strCountycu);
	fprintf(LOG,"Wrote %d County Current polygon to shape %s%sctycu\n", polyid,Outfilepath,
		Outfiletitle);	
}
void  Match_Poly_Lines_Tract90()
{
	int polyid, found, i, nparts, ptcount;
	long num, n, written, curcase;
	Tract_Border_Type *tract;
	double  curX, curY;	
    FILE  *dbfout, *ptstemp, *headtemp, *partstemp, *boxtemp; 
	CString fname, info;
	char trtrecord[32]; //size of tract dbrecord + 1
	char msg[100];
	int steppos;
	CString errmsg;
	CString repval;
	int doleft, doright;
	if (APolycounts[1] == 0)
	{
		Ptrdlg->SetDlgItemText(IDC_TRACT,"No Such Cases");		
		return;
	}
	
	fname.Format("%s%strt.dbf",Outfilepath,Outfiletitle);		
    dbfout = fopen(fname,"wb");
	if (dbfout == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	ptstemp = fopen("pts.tmp","wb");
	if (ptstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	headtemp = fopen("head.tmp","wb");
	if (headtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	boxtemp = fopen("box.tmp","wb");
	if (boxtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	partstemp = fopen("parts.tmp","wb");
	if (partstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	tract = (Tract_Border_Type *)calloc(APolycounts[1]+Watercut*SPolycounts[0],sizeof(Tract_Border_Type));	
	written = 0;

	for (num = 0; num < CountI; num++)
	{
		if (strcmp(TypeIs[num].Tract90l,TypeIs[num].Tract90r)== 0)
		{
			if (Watercut)
			{
				if (TypeIs[num].Waterl == TypeIs[num].Waterr)
					continue;
			}
			else
				continue;		
		}
		doleft = 0;
		if (strcmp(TypeIs[num].Tract90l,"           ") != 0)
		{//left case
			if (Watercut)
			{
				if (!TypeIs[num].Waterl)
					doleft = 1;
			}
			else
				doleft = 1;
			if (doleft)
			{
				sprintf(tract[written].Id,"%11s",TypeIs[num].Tract90l);
				sprintf(tract[written].Tlid,"%s",TypeIs[num].Tlid);
				tract[written].Frlong = Type1s[num].Frlong;
				tract[written].Frlat = Type1s[num].Frlat;
				tract[written].Tolong = Type1s[num].Tolong;
				tract[written].Tolat = Type1s[num].Tolat;
				tract[written].Chosen = 0;
				tract[written].Flip = 1;
				written++;
			}
		}
		if (written > APolycounts[1] + Watercut * SPolycounts[0])
		{
			Ptrdlg->ErrorMessage("the number of tract border lines exceeds the count");			
			MissingFile = -1;
			return;
		}
		doright = 0;
		if (strcmp(TypeIs[num].Tract90r,"           ") != 0)
		{//rightcase of county-tract
			if (Watercut)
			{
				if (!TypeIs[num].Waterr)
					doright = 1;
			}
			else
				doright = 1;
			if (doright)
			{
				sprintf(tract[written].Id,"%11s",TypeIs[num].Tract90r);
				sprintf(tract[written].Tlid,"%s",TypeIs[num].Tlid);
				tract[written].Frlong = Type1s[num].Frlong;
				tract[written].Frlat = Type1s[num].Frlat;
				tract[written].Tolong = Type1s[num].Tolong;
				tract[written].Tolat = Type1s[num].Tolat;
				tract[written].Chosen = 0;
				tract[written].Flip = 0;
				written++;	
			}
		}

		if (written > APolycounts[1] + Watercut * SPolycounts[0])
		{
			Ptrdlg->ErrorMessage("the number of tract border lines exceeds the count");			
			MissingFile = -1;
			return;
		}
	}
//AfxMessageBox("built tract array");
	//time to chain
	Ptrdlg->m_strProcess.Format("Gathering Tract Boundary Lines");
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	//Ptrdlg->m_Progress.SetRange(0,written);
	//Ptrdlg->m_Progress.SetStep(1);		
	//qsort((void *)tract,Polycounts[1],sizeof(Tract_Border_Type),(compfn)CompareTract);
	qsort((void *)tract,written,sizeof(Tract_Border_Type),(compfn)CompareTract);
	FileMinX = FileMinY = LARGE;
	FileMaxX = FileMaxY = -LARGE;
	CurrentMinX = CurrentMinY = LARGE;
	CurrentMaxX = CurrentMaxY = -LARGE;
	curcase = 0;
	polyid = 1;
	Npts = 0; 
	nparts = 1;
	ptcount = 0;
	Build_db_Header(dbfout,0,dbTract);
	Build_db_FieldHeaders(dbfout,dbTract);
	/*
	char *tname;
	tname = (char *)calloc(12,sizeof(char));
	for (i = 0; i < 11; i++)
	{
		if (tract[curcase].Id[i] != ' ')
			tname[i] = tract[curcase].Id[i];
		else
			tname[i] = 0;
	}
	tname[11] = '\0';	*/
	tract[curcase].Id[11] = '\0';
	//sprintf(trtrecord," %-8d%-5s%-6s",polyid,tract[curcase].Id,&tract[curcase].Id[5]);
	//sprintf(&trtrecord[20],"%-11s",tname);
	sprintf(trtrecord," %-8d",polyid);
	sprintf(&trtrecord[9],"%-5s",tract[curcase].Id);
	sprintf(&trtrecord[14],"%-6s",&tract[curcase].Id[5]);
	sprintf(&trtrecord[20],"%-11s",tract[curcase].Id);

	
//	free(tname);
	fwrite(&trtrecord,sizeof(trtrecord)-1,1,dbfout);
	if (tract[0].Flip == 0)
	{
		curX = tract[0].Tolong;
		curY = tract[0].Tolat;		
		Pts[Npts].Longitude = tract[curcase].Frlong;
		Pts[Npts].Latitude = tract[curcase].Frlat;
		Npts++;
		Get_Shape_Points(tract[curcase].Tlid, tract[curcase].Flip);
		Pts[Npts].Longitude = tract[curcase].Tolong;
		Pts[Npts].Latitude = tract[curcase].Tolat;
		Npts++;
		tract[curcase].Chosen = 1;		
	}
	else
	{
		curX = tract[0].Frlong;
		curY = tract[0].Frlat;		
		Pts[Npts].Longitude = tract[curcase].Tolong;
		Pts[Npts].Latitude = tract[curcase].Tolat;
		Npts++;
		Get_Shape_Points(tract[curcase].Tlid, tract[curcase].Flip);
		Pts[Npts].Longitude = tract[curcase].Frlong;
		Pts[Npts].Latitude = tract[curcase].Frlat;
		Npts++;
		tract[curcase].Chosen = 1;		
	}
	ptcount += Npts;
	
    fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
	
	if (Pts[0].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < CurrentMinY)
		CurrentMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[0].Latitude;	
	if (Pts[0].Longitude < FileMinX)
		FileMinX = Pts[0].Longitude;
	if (Pts[0].Longitude > FileMaxX)
		FileMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < FileMinY)
		FileMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > FileMaxY)
		FileMaxY = Pts[0].Latitude;

	if (Pts[Npts-1].Longitude < CurrentMinX)
		CurrentMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < CurrentMinY)
		CurrentMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[Npts-1].Latitude;	
	if (Pts[Npts-1].Longitude < FileMinX)
		FileMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > FileMaxX)
		FileMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < FileMinY)
		FileMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > FileMaxY)
		FileMaxY = Pts[Npts-1].Latitude;		
	n = 1;
	steppos = (int)(n*100/written);	
	Ptrdlg->m_Progress.SetPos(steppos);
	//Ptrdlg->m_Progress.StepIt();
    while (n < written)
	{
		sprintf(msg,"processed %d of %d records",n,written);
		Ptrdlg->SetDlgItemText(IDC_TRACT,msg);		
		//printf("\n Have written %ld of %ld tract boundary lines",n, written);
		found = 0;
		for (i = 1; i < written; i++)
         {
			Npts = 0;
			if (tract[i].Chosen != 0)
				continue;
			if (tract[i].Flip == 0)
			{
				if ((tract[i].Frlong == curX) && (tract[i].Frlat == curY))
				{                          
					if (strcmp(tract[i].Id,tract[curcase].Id) != 0)
						continue;	            
					Get_Shape_Points(tract[i].Tlid,tract[i].Flip);
					Pts[Npts].Longitude = tract[i].Tolong;
					Pts[Npts].Latitude = tract[i].Tolat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);					
					//Ptrdlg->m_Progress.StepIt();
					tract[i].Chosen = 1;            
					found = 1;                      
					curX = tract[i].Tolong;
					curY = tract[i].Tolat;                
					curcase = i;
					break;
				}
			}
			else
			{
				if ((tract[i].Tolong == curX) && (tract[i].Tolat == curY))
				{
					if (strcmp(tract[i].Id,tract[curcase].Id) != 0)
						continue;	            
					Get_Shape_Points(tract[i].Tlid,tract[i].Flip);
					Pts[Npts].Longitude = tract[i].Frlong;
					Pts[Npts].Latitude = tract[i].Frlat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					//Ptrdlg->m_Progress.StepIt();
					curX = tract[i].Frlong;
					curY = tract[i].Frlat;                        
					tract[i].Chosen = 1;	
					found = 1;          
					curcase = i;
					break;
				}
			}
        }//close for loop
		if (found == 0) //initialize new case, eg, new ring or new poly
		{			
			fwrite(&ptcount,sizeof(int),1,headtemp);
			ptcount = 0;
			for (i = 0; i < written; i++) //check for new ring in poly
            {                    
         		if (tract[i].Chosen != 0)
					continue;             		
				if (strcmp(tract[i].Id, tract[curcase].Id) != 0)
					continue;
				//if we get here it is a new ring in current poly
				found = 1;
				nparts++;
				Npts = 0;
				if (tract[i].Flip == 0)
				{
					Pts[Npts].Longitude = tract[i].Frlong;
					Pts[Npts].Latitude = tract[i].Frlat;
					Npts++;
					Get_Shape_Points(tract[i].Tlid,tract[i].Flip);
					Pts[Npts].Longitude = tract[i].Tolong;
					Pts[Npts].Latitude = tract[i].Tolat;
					Npts++;			
    				n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);					
					//Ptrdlg->m_Progress.StepIt();
					tract[i].Chosen = 1;
    		   		curX = tract[i].Tolong;
    				curY = tract[i].Tolat;
					curcase = i;
					break;
				}
				else
				{
					Pts[Npts].Longitude = tract[i].Tolong;
					Pts[Npts].Latitude = tract[i].Tolat;
					Npts++;
					Get_Shape_Points(tract[i].Tlid,tract[i].Flip);
					Pts[Npts].Longitude = tract[i].Frlong;
					Pts[Npts].Latitude = tract[i].Frlat;
					Npts++;			
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					//Ptrdlg->m_Progress.StepIt();
					tract[i].Chosen = 1;
    		   		curX = tract[i].Frlong;
    				curY = tract[i].Frlat;
					curcase = i;
					break;
				}
    		}
    	}
		if (found == 0) // new poly, first ring
		{
			
			fwrite(&nparts,sizeof(int),1,partstemp);
			nparts = 1;
			fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
			CurrentMinX = CurrentMinY = LARGE;
			CurrentMaxX = CurrentMaxY = -LARGE;

			for (i = 0; i < written; i++)//first check for new ring in current poly
            {                    
         		if (tract[i].Chosen != 0)
					continue;             
				polyid++;
				/*tname = (char *)calloc(12,sizeof(char));
				for (int j = 0; j < 11; j++)
				{
					if (tract[i].Id[j] != ' ')
						tname[j] = tract[i].Id[j];
					else
						tname[j] = 0;
				}
				tname[11] = '\0';*/
				tract[i].Id[11] = '\0';
				//sprintf(trtrecord," %-8d%-5s%-6s",polyid,tract[i].Id,&tract[i].Id[5]);
				//sprintf(&trtrecord[20],"%-11s",tract[i].Id);				
				sprintf(trtrecord," %-8d",polyid);
				sprintf(&trtrecord[9],"%-5s",tract[i].Id);
				sprintf(&trtrecord[14],"%-6s",&tract[i].Id[5]);
				sprintf(&trtrecord[20],"%-11s",tract[i].Id);
				fwrite(&trtrecord,sizeof(trtrecord)-1,1,dbfout);    		
//				free(tname);
				Npts = 0;
				if (tract[i].Flip == 0)
				{
					Pts[Npts].Longitude = tract[i].Frlong;
					Pts[Npts].Latitude = tract[i].Frlat;
					Npts++;
					Get_Shape_Points(tract[i].Tlid,tract[i].Flip);
					Pts[Npts].Longitude = tract[i].Tolong;
					Pts[Npts].Latitude = tract[i].Tolat;
					Npts++;					
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					//Ptrdlg->m_Progress.StepIt();
					tract[i].Chosen = 1;            
					found = 1;                      
					curX = tract[i].Tolong;
					curY = tract[i].Tolat;                
					curcase = i;
					break;					
				}
				else
				{
					Pts[Npts].Longitude = tract[i].Tolong;
					Pts[Npts].Latitude = tract[i].Tolat;
					Npts++;
					Get_Shape_Points(tract[i].Tlid,tract[i].Flip);
					Pts[Npts].Longitude = tract[i].Frlong;
					Pts[Npts].Latitude = tract[i].Frlat;
					Npts++;				
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					//Ptrdlg->m_Progress.StepIt();
					curX = tract[i].Frlong;
					curY = tract[i].Frlat;                        
					tract[i].Chosen = 1;		
					found = 1;          
					curcase = i;	
					break;					
				}	
			}
		}
		//by now found should be 1
		if (found == 0)
		{
			info.Format("ERROR - found is zero");
			Ptrdlg->ErrorMessage(info);			
			MissingFile = -1;
			return;
		}
		ptcount += Npts;
		fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
		if (Pts[0].Longitude < CurrentMinX)
			CurrentMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < CurrentMinY)
			CurrentMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[0].Latitude;	
		if (Pts[0].Longitude < FileMinX)
			FileMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > FileMaxX)
			FileMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < FileMinY)
			FileMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > FileMaxY)
			FileMaxY = Pts[0].Latitude;

		if (Pts[Npts-1].Longitude < CurrentMinX)
			CurrentMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < CurrentMinY)
			CurrentMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[Npts-1].Latitude;	
		if (Pts[Npts-1].Longitude < FileMinX)
			FileMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > FileMaxX)
			FileMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < FileMinY)
			FileMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > FileMaxY)
			FileMaxY = Pts[Npts-1].Latitude;		
	}//close while loop
	fwrite(&ptcount,sizeof(int),1,headtemp);
	fwrite(&nparts,sizeof(int),1,partstemp);
	fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
	fclose(boxtemp);
	fclose(headtemp);
	fclose(ptstemp);
	fclose(partstemp);
	sprintf(msg,"processed %d of %d records",n,written);
	Ptrdlg->SetDlgItemText(IDC_TRACT,msg);		
	//printf("\n Have written %ld of %ld tract boundary lines",n, written);
	write_eof(dbfout);
	rewind(dbfout);
	Build_db_Header(dbfout,polyid,dbTract);
	Build_Poly_Shape("trt");
	Ptrdlg->m_strTract.Format("%d Tracts",polyid);
	Ptrdlg->SetDlgItemText(IDC_TRACT,Ptrdlg->m_strTract);	
	fprintf(LOG,"Wrote %d Tract polygons to shape %s%strt\n", polyid, Outfilepath,
		Outfiletitle);		
	fclose(dbfout);
	free(tract);
	//free(tname);
}

void Match_Poly_Lines_Group90()
{
	int polyid, found, i, nparts, ptcount;
	long num, n, written, curcase;
	BlockGroup_Border_Type *group;
	double  curX, curY;	
	int doleft, doright;

    FILE  *dbfout, *ptstemp, *headtemp, *partstemp, *boxtemp;
	CString fname, info;
	char grprecord[34]; //22 is size of group record
	char msg[100];
	int steppos;
	CString errmsg;
	if (APolycounts[2] == 0)
	{
		Ptrdlg->SetDlgItemText(IDC_GROUP,"No Such Cases");		
		return;
	}
	
	fname.Format("%s%sgrp.dbf",Outfilepath,Outfiletitle);		
	dbfout = fopen(fname,"wb");
	if (dbfout == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	ptstemp = fopen("pts.tmp","wb");
	if (ptstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	headtemp = fopen("head.tmp","wb");
	if (headtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	boxtemp = fopen("box.tmp","wb");
	if (boxtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	partstemp = fopen("parts.tmp","wb");
	if (partstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	
	group = (BlockGroup_Border_Type *)calloc(APolycounts[2]+Watercut*SPolycounts[0],sizeof(BlockGroup_Border_Type));
	written = 0;

	for (num = 0; num < CountI; num++)
	{
		if (strcmp(TypeIs[num].Group90l,TypeIs[num].Group90r) == 0)
		{
			if (Watercut)
			{
				if (TypeIs[num].Waterl == TypeIs[num].Waterr)
					continue;
			}
			else
				continue;		
		}
		doleft = 0;
		if (strcmp(TypeIs[num].Group90l,"            ") != 0)
		{//left case
			if (Watercut)
			{
				if (!TypeIs[num].Waterl)
					doleft = 1;
			}
			else
				doleft = 1;
			if (doleft)
			{
				sprintf(group[written].Id,"%12s",TypeIs[num].Group90l);
				sprintf(group[written].Tlid,"%s",TypeIs[num].Tlid);
				group[written].Frlong = Type1s[num].Frlong;
				group[written].Frlat = Type1s[num].Frlat;
				group[written].Tolong = Type1s[num].Tolong;
				group[written].Tolat = Type1s[num].Tolat;
				group[written].Chosen = 0;
				group[written].Flip = 1;
				written++;
			}
		}
		doright = 0;
		if (strcmp(TypeIs[num].Group90r,"            ") != 0)
		{//right case
			if (Watercut)
			{
				if (!TypeIs[num].Waterr)
					doright = 1;
			}
			else
				doright = 1;
			if (doright)
			{
				sprintf(group[written].Id,"%12s",TypeIs[num].Group90r);
				sprintf(group[written].Tlid,"%s",TypeIs[num].Tlid);
				group[written].Frlong = Type1s[num].Frlong;
				group[written].Frlat = Type1s[num].Frlat;
				group[written].Tolong = Type1s[num].Tolong;
				group[written].Tolat = Type1s[num].Tolat;
				group[written].Chosen = 0;
				group[written].Flip = 0;
				written++;
			}
		}
				
	}
	if (written > APolycounts[2]+Watercut*SPolycounts[0])
	{
		Ptrdlg->ErrorMessage("the number of block group border lines exceeds the count");						
		MissingFile = -1;
		return;
	}

	//time to chain
	//printf("\nsorting block group lines by group id");
	Ptrdlg->m_strProcess.Format("Gathering Block Group Boundary Lines");
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	//Ptrdlg->m_Progress.SetRange(0,written);
	//Ptrdlg->m_Progress.SetStep(1);		
	qsort((void *)group,written,sizeof(BlockGroup_Border_Type),(compfn)CompareGroup);
	FileMinX = FileMinY = LARGE;
	FileMaxX = FileMaxY = -LARGE;
	CurrentMinX = CurrentMinY = LARGE;
	CurrentMaxX = CurrentMaxY = -LARGE;
	curcase = 0;
	polyid = 1;
	Npts = 0; 
	nparts = 1;
	ptcount = 0;
	Build_db_Header(dbfout,0,dbGroup);
	Build_db_FieldHeaders(dbfout,dbGroup);
/*	char * gname;
	gname = (char *)calloc(13,sizeof(char));
	int curchar = 0;
	for (int j = 0; j < 12; j++)
	{
		if (group[0].Id[j] == ' ')
			continue;
		gname[curchar] = group[0].Id[j];
		curchar++;
	}
	gname[curchar] = '\0';*/
    //sprintf(grprecord," %-8d%-5s%-6s%s",polyid,group[curcase].Id,&group[curcase].Id[5],&group[curcase].Id[11]);
	//sprintf(&grprecord[21],"%-12s",gname);
	sprintf(grprecord," %-8d",polyid);
	sprintf(&grprecord[9],"%-5s",group[curcase].Id);
	sprintf(&grprecord[14],"%-6s",&group[curcase].Id[5]);
	sprintf(&grprecord[20],"%s",&group[curcase].Id[11]);
	sprintf(&grprecord[21],"%-12s",group[curcase].Id);
	fwrite(&grprecord,sizeof(grprecord)-1,1,dbfout);
	//free(gname);
	if (group[0].Flip == 0)
	{
		curX = group[curcase].Tolong;
		curY = group[curcase].Tolat;
		Pts[Npts].Longitude = group[curcase].Frlong;
		Pts[Npts].Latitude = group[curcase].Frlat;
		Npts++;	
		Get_Shape_Points(group[curcase].Tlid,group[curcase].Flip);
		Pts[Npts].Longitude = group[curcase].Tolong;
		Pts[Npts].Latitude = group[curcase].Tolat;
		Npts++;	
		group[curcase].Chosen = 1;
	}
	else
	{
		curX = group[curcase].Frlong;
		curY = group[curcase].Frlat;
		Pts[Npts].Longitude = group[curcase].Frlong;
		Pts[Npts].Latitude = group[curcase].Frlat;
		Npts++;	
		Get_Shape_Points(group[curcase].Tlid,group[curcase].Flip);
		Pts[Npts].Longitude = group[curcase].Frlong;
		Pts[Npts].Latitude = group[curcase].Frlat;
		Npts++;	
		group[curcase].Chosen = 1;
	}
	ptcount += Npts;
	fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);	
	if (Pts[0].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < CurrentMinY)
		CurrentMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[0].Latitude;	
	if (Pts[0].Longitude < FileMinX)
		FileMinX = Pts[0].Longitude;
	if (Pts[0].Longitude > FileMaxX)
		FileMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < FileMinY)
		FileMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > FileMaxY)
		FileMaxY = Pts[0].Latitude;

	if (Pts[Npts-1].Longitude < CurrentMinX)
		CurrentMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < CurrentMinY)
		CurrentMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[Npts-1].Latitude;	
	if (Pts[Npts-1].Longitude < FileMinX)
		FileMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > FileMaxX)
		FileMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < FileMinY)
		FileMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > FileMaxY)
		FileMaxY = Pts[Npts-1].Latitude;		
	n = 1;
	steppos = (int)(n*100/written);	
	Ptrdlg->m_Progress.SetPos(steppos);
	//Ptrdlg->m_Progress.StepIt();		
    while (n < written)
	{
		sprintf(msg,"processed %d of %d records",n,written);
		Ptrdlg->SetDlgItemText(IDC_GROUP,msg);		
		//printf("\n Have written %ld of %ld block group boundary lines",n, written);
		found = 0;
		for (i = 1; i < written; i++)
			{
			Npts = 0;
			if (group[i].Chosen != 0)
				continue;
			if (group[i].Flip == 0)
			{
				if ((group[i].Frlong == curX) && (group[i].Frlat == curY))
				{                          
					if (strcmp(group[i].Id,group[curcase].Id) != 0)
						continue;	            
					Get_Shape_Points(group[i].Tlid,group[i].Flip);
					Pts[Npts].Longitude = group[i].Tolong;
					Pts[Npts].Latitude = group[i].Tolat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					//Ptrdlg->m_Progress.StepIt();		
					group[i].Chosen = 1;            
					found = 1;                      
					curX = group[i].Tolong;
					curY = group[i].Tolat;                
					curcase = i;
					break;
				}
			}
			else
			{
				if ((group[i].Tolong == curX) && (group[i].Tolat == curY))
				{
					if (strcmp(group[i].Id,group[curcase].Id) != 0)
						continue;	            
					Get_Shape_Points(group[i].Tlid,group[i].Flip);
					Pts[Npts].Longitude = group[i].Frlong;
					Pts[Npts].Latitude = group[i].Frlat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					//Ptrdlg->m_Progress.StepIt();		
					curX = group[i].Frlong;
					curY = group[i].Frlat;                        
					group[i].Chosen = 1;
					found = 1;          
					curcase = i;
					break;
				}
			}
        }//close for loop
		if (found == 0) //initialize new ring or new poly
        {
			fwrite(&ptcount,sizeof(int),1,headtemp);
			ptcount = 0;
			for (i = 0; i < written; i++)
            {                    
	         	if (group[i].Chosen != 0)
		           continue;             		
				if (strcmp(group[i].Id,group[curcase].Id) != 0)
					continue;
				//if we get here we have a new ring in current polygon
			    found = 1;
				nparts++;
				Npts = 0;
				if (group[i].Flip == 0)
				{
					Pts[Npts].Longitude = group[i].Frlong;
					Pts[Npts].Latitude = group[i].Frlat;
					Npts++;
		    		Get_Shape_Points(group[i].Tlid,group[i].Flip);
					Pts[Npts].Longitude = group[i].Tolong;
					Pts[Npts].Latitude = group[i].Tolat;
					Npts++;
    				n++;    
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					//Ptrdlg->m_Progress.StepIt();		
    				group[i].Chosen = 1;
					found = 1;
		    		curX = group[i].Tolong;
    				curY = group[i].Tolat;
					curcase = i;
					break;
				}
				else
				{
					Pts[Npts].Longitude = group[i].Tolong;
					Pts[Npts].Latitude = group[i].Tolat;
					Npts++;
		    		Get_Shape_Points(group[i].Tlid,group[i].Flip);
					Pts[Npts].Longitude = group[i].Frlong;
					Pts[Npts].Latitude = group[i].Frlat;
					Npts++;
    				n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					//Ptrdlg->m_Progress.StepIt();		
    				group[i].Chosen = 1;
					found = 1;
		    		curX = group[i].Frlong;
    				curY = group[i].Frlat;
					curcase = i;
					break;
				}
    		}//close i on for
    	}//close if on found		
		if (found == 0) //new poly, first ring
		{
			fwrite(&nparts,sizeof(int),1,partstemp);
			nparts = 1;
			fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
			CurrentMinX = CurrentMinY = LARGE;
			CurrentMaxX = CurrentMaxY = -LARGE;

			for (i = 0; i < written; i++)
			{
				if (group[i].Chosen != 0)
					continue;
				polyid++;
				/*curchar = 0;
				gname = (char *)calloc(13,sizeof(char));
				for (j = 0; j < 12; j++)
				{
					if (group[i].Id[j] == ' ')
						continue;
					gname[curchar] = group[i].Id[j];
					curchar++;
				}
				gname[curchar] = '\0';*/
				//sprintf(grprecord," %-8d%-5s%-6s%s",polyid,group[i].Id,&group[i].Id[5],&group[i].Id[11]);
				//sprintf(&grprecord[21],"%-12s",gname);
				sprintf(grprecord," %-8d",polyid);
				sprintf(&grprecord[9],"%-5s",group[i].Id);
				sprintf(&grprecord[14],"%-6s",&group[i].Id[5]);
				sprintf(&grprecord[20],"%s",&group[i].Id[11]);
				sprintf(&grprecord[21],"%-12s",group[i].Id);	
				fwrite(&grprecord,sizeof(grprecord)-1,1,dbfout);
				//free(gname);
				Npts = 0;
				if (group[i].Flip == 0)
				{
					Pts[Npts].Longitude = group[i].Frlong;
					Pts[Npts].Latitude = group[i].Frlat;
					Npts++;
		    		Get_Shape_Points(group[i].Tlid,group[i].Flip);
					Pts[Npts].Longitude = group[i].Tolong;
					Pts[Npts].Latitude = group[i].Tolat;
					Npts++;
    				n++;    
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					//Ptrdlg->m_Progress.StepIt();		
    				group[i].Chosen = 1;
					found = 1;
		    		curX = group[i].Tolong;
    				curY = group[i].Tolat;
					curcase = i;
					break;
				}
				else
				{
					Pts[Npts].Longitude = group[i].Tolong;
					Pts[Npts].Latitude = group[i].Tolat;
					Npts++;
		    		Get_Shape_Points(group[i].Tlid,group[i].Flip);
					Pts[Npts].Longitude = group[i].Frlong;
					Pts[Npts].Latitude = group[i].Frlat;
					Npts++;
    				n++;    
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					//Ptrdlg->m_Progress.StepIt();		
    				group[i].Chosen = 1;
					found = 1;
		    		curX = group[i].Frlong;
    				curY = group[i].Frlat;
					curcase = i;
					break;
				}
			}
		}
		//by now found should be 1
		if (found == 0)
		{
			info.Format("ERROR - found is zero");
			Ptrdlg->ErrorMessage(info);						
			MissingFile = -1;
			return;
		}
		ptcount += Npts;
	
		fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
		if (Pts[0].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < CurrentMinY)
			CurrentMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[0].Latitude;	
		if (Pts[0].Longitude < FileMinX)
			FileMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > FileMaxX)
			FileMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < FileMinY)
			FileMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > FileMaxY)
			FileMaxY = Pts[0].Latitude;

		if (Pts[Npts-1].Longitude < CurrentMinX)
			CurrentMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < CurrentMinY)
			CurrentMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[Npts-1].Latitude;	
		if (Pts[Npts-1].Longitude < FileMinX)
			FileMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > FileMaxX)
			FileMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < FileMinY)
			FileMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > FileMaxY)
			FileMaxY = Pts[Npts-1].Latitude;		
	}//close while
	fwrite(&ptcount,sizeof(int),1,headtemp);
	fwrite(&nparts,sizeof(int),1,partstemp);
	fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
	fclose(boxtemp);
	fclose(headtemp);
	fclose(ptstemp);
	fclose(partstemp);
	sprintf(msg,"processed %d of %d records",n,written);
	Ptrdlg->SetDlgItemText(IDC_GROUP,msg);		
	//printf("\n Have written %ld of %ld block group boundary lines",n, written);
	write_eof(dbfout);
	rewind(dbfout);
	Build_db_Header(dbfout,polyid,dbGroup);
    fclose(dbfout);
	free(group);
	Build_Poly_Shape("grp");	
	Ptrdlg->m_strGroup.Format("%d Block Groups",polyid);
	Ptrdlg->SetDlgItemText(IDC_GROUP,Ptrdlg->m_strGroup);
	fprintf(LOG,"Wrote %d Block Group polygons to shape %s%sgrp\n", polyid,Outfilepath,
		Outfiletitle);		
}
void Match_Poly_Lines_Block90()
{
	int polyid, found, i, nparts, ptcount;
	long num, n, written, curcase;
	Block_Border_Type *block;
	double  curX, curY;	
    FILE  *dbfout;
	FILE  *ptstemp, *headtemp, *partstemp, *boxtemp;
	CString fname, info;
	char blkrecord[40];
	char msg[130];
	int steppos;
	CString errmsg;
	int doright, doleft;
	if (APolycounts[3] == 0)
	{
		Ptrdlg->SetDlgItemText(IDC_BLOCK,"No Such Cases");		
		return;
	}
	
	fname.Format("%s%sblk.dbf",Outfilepath,Outfiletitle);	
	dbfout = fopen(fname,"wb");
	if (dbfout == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	ptstemp = fopen("pts.tmp","wb");
	if (ptstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	headtemp = fopen("head.tmp","wb");
	if (headtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	boxtemp = fopen("box.tmp","wb");
	if (boxtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	partstemp = fopen("parts.tmp","wb");
	if (partstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	
    
    block = (Block_Border_Type *)calloc(APolycounts[3]+Watercut*SPolycounts[0],sizeof(Block_Border_Type));
	written = 0;

	for (num = 0; num < CountI; num++)
	{
		if (strcmp(TypeIs[num].Block90l,TypeIs[num].Block90r) == 0)
		{
			if (Watercut)
			{
				if (TypeIs[num].Waterl == TypeIs[num].Waterr)
					continue;
			}
			else
				continue;		
		}
		doleft = 0;	
		if (strcmp(TypeIs[num].Block90l,"               ") != 0)
		{
			if (Watercut)
			{
				if (!TypeIs[num].Waterl)
					doleft = 1;
			}
			else
				doleft = 1;
			if (doleft)
			{
				sprintf(block[written].Id,"%15s",TypeIs[num].Block90l);
				sprintf(block[written].Tlid,"%s",TypeIs[num].Tlid);
				block[written].Frlong = Type1s[num].Frlong;
				block[written].Frlat = Type1s[num].Frlat;
				block[written].Tolong = Type1s[num].Tolong;
				block[written].Tolat = Type1s[num].Tolat;
				block[written].Chosen = 0;
				block[written].Flip = 1;
				written++;
			}
		}
		doright = 0;
		if (strcmp(TypeIs[num].Block90r,"               ") != 0)
		{
			if (Watercut)
			{
				if (!TypeIs[num].Waterr)
					doright = 1;
			}
			else
				doright = 1;
			if (doright)
			{
				sprintf(block[written].Id,"%15s",TypeIs[num].Block90r);
				sprintf(block[written].Tlid,"%s",TypeIs[num].Tlid);
				block[written].Frlong = Type1s[num].Frlong;
				block[written].Frlat = Type1s[num].Frlat;
				block[written].Tolong = Type1s[num].Tolong;
				block[written].Tolat = Type1s[num].Tolat;
				block[written].Chosen = 0;
				block[written].Flip = 0;
				written++;			
			}
		}
		
		if (written > APolycounts[3]+Watercut*SPolycounts[0])
		{
			Ptrdlg->ErrorMessage("the number of block border lines exceeds the count");			
			MissingFile = -1;
			return;
		}
	}
	//printf("\nsorting block  lines by block id");
	Ptrdlg->m_strProcess.Format("Gathering Block Boundary Lines");
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	//Ptrdlg->m_Progress.SetRange(0,written);
	//Ptrdlg->m_Progress.SetStep(1);		
	qsort((void *)block,written,sizeof(Block_Border_Type),(compfn)CompareBlock);
	FileMinX = FileMinY = LARGE;
	FileMaxX = FileMaxY = -LARGE;
	CurrentMinX = CurrentMinY = LARGE;
	CurrentMaxX = CurrentMaxY = -LARGE;
	curcase = 0;
	polyid = 1;
	Npts = 0; 
	nparts = 1;
	ptcount = 0;
	Build_db_Header(dbfout,0,dbBlock);
	Build_db_FieldHeaders(dbfout,dbBlock);
	/*char * bname;
	bname = (char *)calloc(16,sizeof(char));
	int curchar = 0;
	for (int j = 0; j < 15; j++)
	{
		if (block[0].Id[j] == ' ')
			continue;
		bname[curchar] = block[0].Id[j];
		curchar++;
	}
	bname[curchar] = '\0';*/
//    sprintf(blkrecord," %-8d%-5s%-6s%-4s",polyid,block[curcase].Id,&block[curcase].Id[5],
//		&block[curcase].Id[11]);
//	sprintf(&blkrecord[24],"%-15s",bname);
	sprintf(blkrecord," %-8d",polyid);
	sprintf(&blkrecord[9],"%-5s",block[curcase].Id);
	sprintf(&blkrecord[14],"%-6s",&block[curcase].Id[5]);
	sprintf(&blkrecord[20],"%-4s",&block[curcase].Id[11]);
	sprintf(&blkrecord[24],"%-15s",block[curcase].Id);
	//free(bname);
	fwrite(&blkrecord,sizeof(blkrecord)-1,1,dbfout);
	if (block[0].Flip == 0)
	{
		curX = block[0].Tolong;
		curY = block[0].Tolat;
		Pts[Npts].Longitude = block[curcase].Frlong;
		Pts[Npts].Latitude = block[curcase].Frlat;
		Npts++;
		Get_Shape_Points(block[curcase].Tlid,block[curcase].Flip);
		Pts[Npts].Longitude = block[curcase].Tolong;
		Pts[Npts].Latitude = block[curcase].Tolat;
		Npts++;
		block[curcase].Chosen = 1;
	}
	else
	{
		curX = block[0].Frlong;
		curY = block[0].Frlat;
		Pts[Npts].Longitude = block[curcase].Tolong;
		Pts[Npts].Latitude = block[curcase].Tolat;
		Npts++;
		Get_Shape_Points(block[curcase].Tlid,block[curcase].Flip);
		Pts[Npts].Longitude = block[curcase].Frlong;
		Pts[Npts].Latitude = block[curcase].Frlat;
		Npts++;
		block[curcase].Chosen = 1;
	}
	ptcount += Npts;
	fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);	
	if (Pts[0].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < CurrentMinY)
		CurrentMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[0].Latitude;	
	if (Pts[0].Longitude < FileMinX)
		FileMinX = Pts[0].Longitude;
	if (Pts[0].Longitude > FileMaxX)
		FileMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < FileMinY)
		FileMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > FileMaxY)
		FileMaxY = Pts[0].Latitude;

	if (Pts[Npts-1].Longitude < CurrentMinX)
		CurrentMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < CurrentMinY)
		CurrentMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[Npts-1].Latitude;	
	if (Pts[Npts-1].Longitude < FileMinX)
		FileMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > FileMaxX)
		FileMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < FileMinY)
		FileMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > FileMaxY)
		FileMaxY = Pts[Npts-1].Latitude;		
	n = 1;
	steppos = (int)(n*100/written);	
	Ptrdlg->m_Progress.SetPos(steppos);
	//Ptrdlg->m_Progress.StepIt();		
    while (n < written)
	{
		sprintf(msg,"processed %d of %d records",n,written);
		Ptrdlg->SetDlgItemText(IDC_BLOCK,msg);		
		//printf("\n Have written %ld of %ld block boundary lines",n, written);
		found = 0;
		for (i = 1; i < written; i++)
         {
			Npts = 0;
			if (block[i].Chosen != 0)
				continue;
			if (block[i].Flip == 0)
			{
				if ((block[i].Frlong == curX) && (block[i].Frlat == curY))
				{                          
					if (strcmp(block[i].Id,block[curcase].Id) != 0)
						continue;	            
					Get_Shape_Points(block[i].Tlid,block[i].Flip);
					Pts[Npts].Longitude = block[i].Tolong;
					Pts[Npts].Latitude = block[i].Tolat;
					Npts++;		
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					//Ptrdlg->m_Progress.StepIt();		
					block[i].Chosen = 1;            
					found = 1;                      
					curX = block[i].Tolong;
					curY = block[i].Tolat;                
					curcase = i;
					break;
				}
			}
			else
			{
				if ((block[i].Tolong == curX) && (block[i].Tolat == curY))
				{
					if (strcmp(block[i].Id,block[curcase].Id) != 0)
						continue;	       
					Get_Shape_Points(block[i].Tlid,block[i].Flip);
					Pts[Npts].Longitude = block[i].Frlong;
					Pts[Npts].Latitude = block[i].Frlat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					//Ptrdlg->m_Progress.StepIt();		
					curX = block[i].Frlong;
					curY = block[i].Frlat;                        
					block[i].Chosen = 1;
					found = 1;          
					curcase = i;
					break;
				}
			}
		}//close for loop		
		if (found == 0) //initialize new case, eg, new ring or poly
		{
			fwrite(&ptcount,sizeof(int),1,headtemp);
			ptcount = 0;
			for (i = 0; i < written; i++)
            {                    
         		if (block[i].Chosen != 0)
				   continue;           
				if (strcmp(block[i].Id, block[curcase].Id) != 0)
					continue;
				//we have a new ring in current polygon
				found = 1;
				nparts++;
				Npts = 0;
				if (block[i].Flip == 0)
				{
					Pts[Npts].Longitude = block[i].Frlong;
					Pts[Npts].Latitude = block[i].Frlat;
					Npts++;
					Get_Shape_Points(block[i].Tlid,block[i].Flip);
					Pts[Npts].Longitude = block[i].Tolong;
					Pts[Npts].Latitude = block[i].Tolat;
					Npts++;
					n++;                 
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					//Ptrdlg->m_Progress.StepIt();		
					block[i].Chosen = 1;
					found = 1;
    		  		curX = block[i].Tolong;
    				curY = block[i].Tolat;
					curcase = i;
			   		break;
    			}
				else
				{
					Pts[Npts].Longitude = block[i].Tolong;
					Pts[Npts].Latitude = block[i].Tolat;
					Npts++;
					Get_Shape_Points(block[i].Tlid,block[i].Flip);
					Pts[Npts].Longitude = block[i].Frlong;
					Pts[Npts].Latitude = block[i].Frlat;
					Npts++;
					n++;    
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					//Ptrdlg->m_Progress.StepIt();		
					block[i].Chosen = 1;
					found = 1;
    		  		curX = block[i].Frlong;
    				curY = block[i].Frlat;
					curcase = i;
			   		break;
				}
    		}//loop on i
		}//if on found
		if (found == 0) // new poly, first ring
		{
			fwrite(&nparts,sizeof(int),1, partstemp);
			nparts = 1;
			fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
			CurrentMinX = CurrentMinY = LARGE;
			CurrentMaxX = CurrentMaxY = -LARGE;

			for (i = 0; i < written; i++)
			{
				if (block[i].Chosen != 0)
					continue;
				polyid++;
				/*bname = (char *)calloc(16,sizeof(char));
				curchar = 0;
				for (int j = 0; j < 15; j++)
				{
					if (block[i].Id[j] == ' ')
						continue;
					bname[curchar] = block[i].Id[j];
					curchar++;
				}
				bname[curchar] = '\0';*/
				//sprintf(blkrecord," %-8d%-5s%-6s%-4s",polyid,block[i].Id,&block[i].Id[5],
				//	&block[i].Id[11]);
				//sprintf(&blkrecord[24],"%-15s",bname);
				sprintf(blkrecord," %-8d",polyid);
				sprintf(&blkrecord[9],"%-5s",block[i].Id);
				sprintf(&blkrecord[14],"%-6s",&block[i].Id[5]);
				sprintf(&blkrecord[20],"%-4s",&block[i].Id[11]);
				sprintf(&blkrecord[24],"%-15s",block[i].Id);
	
				fwrite(&blkrecord,sizeof(blkrecord)-1,1,dbfout);
				//free(bname);
				Npts = 0;
				if (block[i].Flip == 0)
				{
					Pts[Npts].Longitude = block[i].Frlong;
					Pts[Npts].Latitude = block[i].Frlat;
					Npts++;
					Get_Shape_Points(block[i].Tlid,block[i].Flip);
					Pts[Npts].Longitude = block[i].Tolong;
					Pts[Npts].Latitude = block[i].Tolat;
					Npts++;
					n++;    
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					//Ptrdlg->m_Progress.StepIt();		
					block[i].Chosen = 1;
					found = 1;
    		  		curX = block[i].Tolong;
    				curY = block[i].Tolat;
					curcase = i;
			   		break;
    			}
				else
				{
					Pts[Npts].Longitude = block[i].Tolong;
					Pts[Npts].Latitude = block[i].Tolat;
					Npts++;
					Get_Shape_Points(block[i].Tlid,block[i].Flip);
					Pts[Npts].Longitude = block[i].Frlong;
					Pts[Npts].Latitude = block[i].Frlat;
					Npts++;
					n++;    
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					//Ptrdlg->m_Progress.StepIt();		
					block[i].Chosen = 1;
					found = 1;
    		  		curX = block[i].Frlong;
    				curY = block[i].Frlat;
					curcase = i;
			   		break;
				}
			}
		}
		//by now found should be 1
		if (found == 0)
		{
			Ptrdlg->ErrorMessage("ERROR - found is zero");			
			MissingFile = -1;
			return;
		}
		ptcount += Npts;
		fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
		if (Pts[0].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < CurrentMinY)
			CurrentMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[0].Latitude;	
		if (Pts[0].Longitude < FileMinX)
			FileMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > FileMaxX)
			FileMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < FileMinY)
			FileMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > FileMaxY)
			FileMaxY = Pts[0].Latitude;

		if (Pts[Npts-1].Longitude < CurrentMinX)
			CurrentMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < CurrentMinY)
			CurrentMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[Npts-1].Latitude;	
		if (Pts[Npts-1].Longitude < FileMinX)
			FileMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > FileMaxX)
			FileMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < FileMinY)
			FileMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > FileMaxY)
			FileMaxY = Pts[Npts-1].Latitude;		
	}//close while loop
	fwrite(&ptcount,sizeof(int),1,headtemp);
	fwrite(&nparts,sizeof(int),1,partstemp);
	fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
	fclose(boxtemp);
	fclose(headtemp);
	fclose(ptstemp);
	fclose(partstemp);
	sprintf(msg,"processed %d of %d records",n,written);
	Ptrdlg->SetDlgItemText(IDC_BLOCK,msg);		
	//printf("\n Have written %ld of %ld block boundary lines",n, written);
	write_eof(dbfout);
	rewind(dbfout);
	Build_db_Header(dbfout,polyid,dbBlock);
	fclose(dbfout);
	free(block);
	Build_Poly_Shape("blk");
	Ptrdlg->m_strBlock.Format("%d Blocks",polyid);
	Ptrdlg->SetDlgItemText(IDC_BLOCK,Ptrdlg->m_strBlock);
	fprintf(LOG,"Wrote %d Block polygons to shape %s%sblk\n", polyid, Outfilepath,
		Outfiletitle);		
}
void Match_Poly_Lines_Fmcd90()
{
	int polyid, found, i, nparts, ptcount;
	long num, n, written, curcase;
	Fmcd_Border_Type *fmcd;
	double  curX, curY;	
    FILE  *dbfout, *ptstemp, *headtemp, *partstemp, *boxtemp; 
	CString fname, info;	
	char fmcrecord[86]; //size of fmcd dbrecord + 2
	int steppos;
	char msg[100];
	char *fmcdname;
	CString errmsg;
	int doleft, doright;
	
	if (APolycounts[5] == 0)
	{
		Ptrdlg->SetDlgItemText(IDC_DIVISIONS,"No Such Cases");		
		return;
	}
	fname.Format("%s%sccd.dbf",Outfilepath,Outfiletitle);		
	dbfout = fopen(fname,"wb");
	if (dbfout == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	ptstemp = fopen("pts.tmp","wb");
	if (ptstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	headtemp = fopen("head.tmp","wb");
	if (headtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	boxtemp = fopen("box.tmp","wb");
	if (boxtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	partstemp = fopen("parts.tmp","wb");
	if (partstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	
    
	fmcd = (Fmcd_Border_Type *)calloc(APolycounts[5]+Watercut*SPolycounts[0],sizeof(Fmcd_Border_Type));
	written = 0;
	for (num = 0; num < CountI; num++)
	{
		if (strcmp(TypeIs[num].Fmcd90l,TypeIs[num].Fmcd90r) == 0)
		{
			if (Watercut)
			{

				if (TypeIs[num].Waterl == TypeIs[num].Waterr)
					continue;
			}
			else
				continue;		
		}
		doleft = 0;	
		if (strcmp(TypeIs[num].Fmcd90l,"     ") != 0)
		{//left case
			if (Watercut)
			{

				if (!TypeIs[num].Waterl)
					doleft = 1;
			}
			else
				doleft = 1;
			if (doleft)
			{	
				sprintf(fmcd[written].County,"%s",TypeIs[num].County90l);
				sprintf(fmcd[written].Id,"%s",TypeIs[num].Fmcd90l);
				sprintf(fmcd[written].Tlid,"%s",TypeIs[num].Tlid);
				fmcd[written].Frlong = Type1s[num].Frlong;
				fmcd[written].Frlat = Type1s[num].Frlat;
				fmcd[written].Tolong = Type1s[num].Tolong;
				fmcd[written].Tolat = Type1s[num].Tolat;
				fmcd[written].Chosen = 0;
				fmcd[written].Flip = 1;
				written++;
			}
		}
		doright = 0;
		if (strcmp(TypeIs[num].Fmcd90r,"     ") != 0)
		{//rightcase 
			//printf("\nright case");
			if (Watercut)
			{
				if (!TypeIs[num].Waterr)
					doright = 1;
			}
			else
				doright = 1;
			if (doright)
			{
				sprintf(fmcd[written].County,"%s",TypeIs[num].County90r);
				sprintf(fmcd[written].Id,"%s",TypeIs[num].Fmcd90r);
				//rintf(fmcd[written].Id,"%s%s%s",Type3s[num].State90r,Type3s[num].Coun90r,Type3s[num].Fmcd90r);
				sprintf(fmcd[written].Tlid,"%s",TypeIs[num].Tlid);
				fmcd[written].Frlong = Type1s[num].Frlong;
				fmcd[written].Frlat = Type1s[num].Frlat;
				fmcd[written].Tolong = Type1s[num].Tolong;
				fmcd[written].Tolat = Type1s[num].Tolat;
				fmcd[written].Chosen = 0;
				fmcd[written].Flip = 0;
				written++;
			}
		}
	}
	if (written > APolycounts[5]+Watercut*SPolycounts[0])
	{
		Ptrdlg->ErrorMessage("the number of CCD or MCD border lines exceeds the count");		
		MissingFile = -1;
		return;
	}
	Ptrdlg->m_strProcess.Format("Gathering County Division Boundary Lines");
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	//time to chain	
	qsort((void *)fmcd,written,sizeof(Fmcd_Border_Type),(compfn)CompareFmcd);
	FileMinX = FileMinY = LARGE;
	FileMaxX = FileMaxY = -LARGE;
	CurrentMinX = CurrentMinY = LARGE;
	CurrentMaxX = CurrentMaxY = -LARGE;
	curcase = 0;
	polyid = 1;
	Npts = 0; 
	nparts = 1;
	ptcount = 0;
	Build_db_Header(dbfout,0,dbFmcd);
	Build_db_FieldHeaders(dbfout,dbFmcd);
	fmcdname = Get_TypeC_Name(2,fmcd[curcase].Id, fmcd[curcase].County);
//    sprintf(fmcrecord," %-8d%-5s%-5s%-66s",polyid,fmcd[curcase].County,fmcd[curcase].Id,
//		fmcdname);
	sprintf(fmcrecord," %-8d",polyid);
	sprintf(&fmcrecord[9],"%-5s",fmcd[curcase].County);
	sprintf(&fmcrecord[14],"%-5s",fmcd[curcase].Id);
	sprintf(&fmcrecord[19],"%-66s",fmcdname);
	fwrite(&fmcrecord,sizeof(fmcrecord)-1,1,dbfout);
	if (fmcd[0].Flip == 0)
	{
		curX = fmcd[0].Tolong;
		curY = fmcd[0].Tolat;		
		Pts[Npts].Longitude = fmcd[curcase].Frlong;
		Pts[Npts].Latitude = fmcd[curcase].Frlat;
		Npts++;
		Get_Shape_Points(fmcd[curcase].Tlid, fmcd[curcase].Flip);
		Pts[Npts].Longitude = fmcd[curcase].Tolong;
		Pts[Npts].Latitude = fmcd[curcase].Tolat;
		Npts++;
		fmcd[curcase].Chosen = 1;		
	}
	else
	{
		curX = fmcd[0].Frlong;
		curY = fmcd[0].Frlat;		
		Pts[Npts].Longitude = fmcd[curcase].Tolong;
		Pts[Npts].Latitude = fmcd[curcase].Tolat;
		Npts++;
		Get_Shape_Points(fmcd[curcase].Tlid, fmcd[curcase].Flip);
		Pts[Npts].Longitude = fmcd[curcase].Frlong;
		Pts[Npts].Latitude = fmcd[curcase].Frlat;
		Npts++;
		fmcd[curcase].Chosen = 1;		
	}
	ptcount += Npts;
	
    fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
	
	if (Pts[0].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < CurrentMinY)
		CurrentMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[0].Latitude;	
	if (Pts[0].Longitude < FileMinX)
		FileMinX = Pts[0].Longitude;
	if (Pts[0].Longitude > FileMaxX)
		FileMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < FileMinY)
		FileMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > FileMaxY)
		FileMaxY = Pts[0].Latitude;

	if (Pts[Npts-1].Longitude < CurrentMinX)
		CurrentMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < CurrentMinY)
		CurrentMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[Npts-1].Latitude;	
	if (Pts[Npts-1].Longitude < FileMinX)
		FileMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > FileMaxX)
		FileMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < FileMinY)
		FileMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > FileMaxY)
		FileMaxY = Pts[Npts-1].Latitude;		
	n = 1;
	steppos = (int)(n*100/written);	
	Ptrdlg->m_Progress.SetPos(steppos);
    while (n < written)
	{
		//printf("\n Have written %ld of %ld fmcd boundary lines",n, written);
		sprintf(msg,"processed %d of %d records",n,written);
		Ptrdlg->SetDlgItemText(IDC_DIVISIONS,msg);		
		found = 0;
		for (i = 1; i < written; i++)
         {
			Npts = 0;
			if (fmcd[i].Chosen != 0)
				continue;
			if (fmcd[i].Flip == 0)
			{
				if ((fmcd[i].Frlong == curX) && (fmcd[i].Frlat == curY))
				{                          
					if (strcmp(fmcd[i].Id,fmcd[curcase].Id) != 0)
						continue;	            
					Get_Shape_Points(fmcd[i].Tlid,fmcd[i].Flip);
					Pts[Npts].Longitude = fmcd[i].Tolong;
					Pts[Npts].Latitude = fmcd[i].Tolat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					fmcd[i].Chosen = 1;            
					found = 1;                      
					curX = fmcd[i].Tolong;
					curY = fmcd[i].Tolat;                
					curcase = i;
					break;
				}
			}
			else
			{
				if ((fmcd[i].Tolong == curX) && (fmcd[i].Tolat == curY))
				{
					if (strcmp(fmcd[i].Id,fmcd[curcase].Id) != 0)
						continue;	            
					Get_Shape_Points(fmcd[i].Tlid,fmcd[i].Flip);
					Pts[Npts].Longitude = fmcd[i].Frlong;
					Pts[Npts].Latitude = fmcd[i].Frlat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = fmcd[i].Frlong;
					curY = fmcd[i].Frlat;                        
					fmcd[i].Chosen = 1;	
					found = 1;          
					curcase = i;
					break;
				}
			}
        }//close for loop
		if (found == 0) //initialize new case, eg, new ring or new poly
		{			
			fwrite(&ptcount,sizeof(int),1,headtemp);
			ptcount = 0;
			for (i = 0; i < written; i++) //check for new ring in poly
            {                    
         		if (fmcd[i].Chosen != 0)
					continue;             		
				if (strcmp(fmcd[i].Id, fmcd[curcase].Id) != 0)
					continue;
				//if we get here it is a new ring in current poly
				found = 1;
				nparts++;
				Npts = 0;
				if (fmcd[i].Flip == 0)
				{
					Pts[Npts].Longitude = fmcd[i].Frlong;
					Pts[Npts].Latitude = fmcd[i].Frlat;
					Npts++;
					Get_Shape_Points(fmcd[i].Tlid,fmcd[i].Flip);
					Pts[Npts].Longitude = fmcd[i].Tolong;
					Pts[Npts].Latitude = fmcd[i].Tolat;
					Npts++;			
    				n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					fmcd[i].Chosen = 1;
    		   		curX = fmcd[i].Tolong;
    				curY = fmcd[i].Tolat;
					curcase = i;
					break;
				}
				else
				{
					Pts[Npts].Longitude = fmcd[i].Tolong;
					Pts[Npts].Latitude = fmcd[i].Tolat;
					Npts++;
					Get_Shape_Points(fmcd[i].Tlid,fmcd[i].Flip);
					Pts[Npts].Longitude = fmcd[i].Frlong;
					Pts[Npts].Latitude = fmcd[i].Frlat;
					Npts++;			
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					fmcd[i].Chosen = 1;
    		   		curX = fmcd[i].Frlong;
    				curY = fmcd[i].Frlat;
					curcase = i;
					break;
				}
    		}
    	}
		if (found == 0) // new poly, first ring
		{
			
			fwrite(&nparts,sizeof(int),1,partstemp);
			nparts = 1;
			fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
			CurrentMinX = CurrentMinY = LARGE;
			CurrentMaxX = CurrentMaxY = -LARGE;

			for (i = 0; i < written; i++)//first check for new ring in current poly
            {                    
         		if (fmcd[i].Chosen != 0)
					continue;             
				polyid++;
				fmcdname = Get_TypeC_Name(2,fmcd[i].Id,fmcd[i].County);
			    //sprintf(fmcrecord," %-8d%-5s%-5s%-66s",polyid,fmcd[i].County,fmcd[curcase].Id,
				//fmcdname);
				sprintf(fmcrecord," %-8d",polyid);
				sprintf(&fmcrecord[9],"%-5s",fmcd[i].County);
				sprintf(&fmcrecord[14],"%-5s",fmcd[i].Id);
				sprintf(&fmcrecord[19],"%-66s",fmcdname);
	
				//sprintf(fmcrecord," %-8d%-5s%-5s",polyid,fmcd[i].County,fmcd[i].Id);
				fwrite(&fmcrecord,sizeof(fmcrecord)-1,1,dbfout);    		
				Npts = 0;
				if (fmcd[i].Flip == 0)
				{
					Pts[Npts].Longitude = fmcd[i].Frlong;
					Pts[Npts].Latitude = fmcd[i].Frlat;
					Npts++;
					Get_Shape_Points(fmcd[i].Tlid,fmcd[i].Flip);
					Pts[Npts].Longitude = fmcd[i].Tolong;
					Pts[Npts].Latitude = fmcd[i].Tolat;
					Npts++;					
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					fmcd[i].Chosen = 1;            
					found = 1;                      
					curX = fmcd[i].Tolong;
					curY = fmcd[i].Tolat;                
					curcase = i;
					break;					
				}
				else
				{
					Pts[Npts].Longitude = fmcd[i].Tolong;
					Pts[Npts].Latitude = fmcd[i].Tolat;
					Npts++;
					Get_Shape_Points(fmcd[i].Tlid,fmcd[i].Flip);
					Pts[Npts].Longitude = fmcd[i].Frlong;
					Pts[Npts].Latitude = fmcd[i].Frlat;
					Npts++;				
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = fmcd[i].Frlong;
					curY = fmcd[i].Frlat;                        
					fmcd[i].Chosen = 1;		
					found = 1;          
					curcase = i;	
					break;					
				}	
			}
		}
		//by now found should be 1
		if (found == 0)
		{
			info.Format("ERROR - found is zero");
			Ptrdlg->ErrorMessage(info);						
			MissingFile = -1;
			return;
		}
		ptcount += Npts;
		fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
		if (Pts[0].Longitude < CurrentMinX)
			CurrentMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < CurrentMinY)
			CurrentMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[0].Latitude;	
		if (Pts[0].Longitude < FileMinX)
			FileMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > FileMaxX)
			FileMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < FileMinY)
			FileMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > FileMaxY)
			FileMaxY = Pts[0].Latitude;

		if (Pts[Npts-1].Longitude < CurrentMinX)
			CurrentMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < CurrentMinY)
			CurrentMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[Npts-1].Latitude;	
		if (Pts[Npts-1].Longitude < FileMinX)
			FileMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > FileMaxX)
			FileMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < FileMinY)
			FileMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > FileMaxY)
			FileMaxY = Pts[Npts-1].Latitude;		
	}//close while loop
	fwrite(&ptcount,sizeof(int),1,headtemp);
	fwrite(&nparts,sizeof(int),1,partstemp);
	fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
	fclose(boxtemp);
	fclose(headtemp);
	fclose(ptstemp);
	fclose(partstemp);
	sprintf(msg,"processed %d of %d records",n,written);
	Ptrdlg->SetDlgItemText(IDC_DIVISIONS,msg);		
	//printf("\n Have written %ld of %ld fmcd boundary lines",n, written);
	write_eof(dbfout);
	rewind(dbfout);
	Build_db_Header(dbfout,polyid,dbFmcd);
	Build_Poly_Shape("ccd");
	Ptrdlg->m_strDivisions.Format("%d Divisions",polyid);
	Ptrdlg->SetDlgItemText(IDC_DIVISIONS,Ptrdlg->m_strDivisions);	
    fclose(dbfout);
	free(fmcd);
	fprintf(LOG,"Wrote %d Census County Division polygons to shape %s%sccd\n", polyid,Outfilepath,
		Outfiletitle);		
}
void Match_Poly_Lines_Fmcdcu()
{
	int polyid, found, i, nparts, ptcount;
	long num, n, written, curcase;
	Fmcd_Border_Type *fmcd;
	double  curX, curY;	
    FILE  *dbfout, *ptstemp, *headtemp, *partstemp, *boxtemp; 
	CString fname, info;	
	char fmcrecord[86]; //size of fmcd dbrecord + 2
	int steppos;
	char msg[100];
	char *fmcdname;
	CString errmsg;
	int doleft, doright;
	
	if (SPolycounts[8] == 0)
	{
		Ptrdlg->SetDlgItemText(IDC_DIVISIONSCU,"No Such Cases");		
		return;
	}
	fname.Format("%s%sccdcu.dbf",Outfilepath,Outfiletitle);		
	dbfout = fopen(fname,"wb");
	if (dbfout == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	ptstemp = fopen("pts.tmp","wb");
	if (ptstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	headtemp = fopen("head.tmp","wb");
	if (headtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	boxtemp = fopen("box.tmp","wb");
	if (boxtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	partstemp = fopen("parts.tmp","wb");
	if (partstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	
    
	fmcd = (Fmcd_Border_Type *)calloc(SPolycounts[8]+Watercut*SPolycounts[0],sizeof(Fmcd_Border_Type));
	written = 0;
	for (num = 0; num < CountI; num++)
	{
		if (strcmp(TypeIs[num].Fmcdcul,TypeIs[num].Fmcdcur) == 0)
		{
			if (Watercut)
			{

				if (TypeIs[num].Waterl == TypeIs[num].Waterr)
					continue;
			}
			else
				continue;		
		}
		doleft = 0;
	
		if (strcmp(TypeIs[num].Fmcdcul,"     ") != 0)
		{//left case
			if (Watercut)
			{

				if (!TypeIs[num].Waterl)
					doleft = 1;
			}
			else
				doleft = 1;
			if (doleft)
			{	
				sprintf(fmcd[written].County,"%2s%3s",TypeIs[num].State,TypeIs[num].County);
				sprintf(fmcd[written].Id,"%s",TypeIs[num].Fmcdcul);
				sprintf(fmcd[written].Tlid,"%s",TypeIs[num].Tlid);
				fmcd[written].Frlong = Type1s[num].Frlong;
				fmcd[written].Frlat = Type1s[num].Frlat;
				fmcd[written].Tolong = Type1s[num].Tolong;
				fmcd[written].Tolat = Type1s[num].Tolat;
				fmcd[written].Chosen = 0;
				fmcd[written].Flip = 1;
				written++;
			}
		}
		doright = 0;
		if (strcmp(TypeIs[num].Fmcdcur,"     ") != 0)
		{//rightcase 
			//printf("\nright case");
			if (Watercut)
			{
				if (!TypeIs[num].Waterr)
					doright = 1;
			}
			else
				doright = 1;
			if (doright)
			{
				sprintf(fmcd[written].County,"%2s%3s",TypeIs[num].State,TypeIs[num].County);
				sprintf(fmcd[written].Id,"%s",TypeIs[num].Fmcdcur);
				//rintf(fmcd[written].Id,"%s%s%s",Type3s[num].State90r,Type3s[num].Coun90r,Type3s[num].Fmcdcur);
				sprintf(fmcd[written].Tlid,"%s",TypeIs[num].Tlid);
				fmcd[written].Frlong = Type1s[num].Frlong;
				fmcd[written].Frlat = Type1s[num].Frlat;
				fmcd[written].Tolong = Type1s[num].Tolong;
				fmcd[written].Tolat = Type1s[num].Tolat;
				fmcd[written].Chosen = 0;
				fmcd[written].Flip = 0;
				written++;
			}
		}
	}
	if (written > SPolycounts[8]+Watercut*SPolycounts[0])
	{
		Ptrdlg->ErrorMessage("the number of CCD or MCD current border lines exceeds the count");		
		MissingFile = -1;
		return;
	}
	Ptrdlg->m_strProcess.Format("Gathering County Division Boundary Lines");
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	//time to chain	
	qsort((void *)fmcd,written,sizeof(Fmcd_Border_Type),(compfn)CompareFmcd);
	FileMinX = FileMinY = LARGE;
	FileMaxX = FileMaxY = -LARGE;
	CurrentMinX = CurrentMinY = LARGE;
	CurrentMaxX = CurrentMaxY = -LARGE;
	curcase = 0;
	polyid = 1;
	Npts = 0; 
	nparts = 1;
	ptcount = 0;
	Build_db_Header(dbfout,0,dbFmcdcu);
	Build_db_FieldHeaders(dbfout,dbFmcdcu);
	fmcdname = Get_TypeC_Name(2,fmcd[curcase].Id,fmcd[curcase].County);
//    sprintf(fmcrecord," %-8d%-5s%-5s%-66s",polyid,fmcd[curcase].County,fmcd[curcase].Id,
//		fmcdname);
	sprintf(fmcrecord," %-8d",polyid);
	sprintf(&fmcrecord[9],"%-5s",fmcd[curcase].County);
	sprintf(&fmcrecord[14],"%-5s",fmcd[curcase].Id);
	sprintf(&fmcrecord[19],"%-66s",fmcdname);
	fwrite(&fmcrecord,sizeof(fmcrecord)-1,1,dbfout);
	if (fmcd[0].Flip == 0)
	{
		curX = fmcd[0].Tolong;
		curY = fmcd[0].Tolat;		
		Pts[Npts].Longitude = fmcd[curcase].Frlong;
		Pts[Npts].Latitude = fmcd[curcase].Frlat;
		Npts++;
		Get_Shape_Points(fmcd[curcase].Tlid, fmcd[curcase].Flip);
		Pts[Npts].Longitude = fmcd[curcase].Tolong;
		Pts[Npts].Latitude = fmcd[curcase].Tolat;
		Npts++;
		fmcd[curcase].Chosen = 1;		
	}
	else
	{
		curX = fmcd[0].Frlong;
		curY = fmcd[0].Frlat;		
		Pts[Npts].Longitude = fmcd[curcase].Tolong;
		Pts[Npts].Latitude = fmcd[curcase].Tolat;
		Npts++;
		Get_Shape_Points(fmcd[curcase].Tlid, fmcd[curcase].Flip);
		Pts[Npts].Longitude = fmcd[curcase].Frlong;
		Pts[Npts].Latitude = fmcd[curcase].Frlat;
		Npts++;
		fmcd[curcase].Chosen = 1;		
	}
	ptcount += Npts;
	
    fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
	
	if (Pts[0].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < CurrentMinY)
		CurrentMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[0].Latitude;	
	if (Pts[0].Longitude < FileMinX)
		FileMinX = Pts[0].Longitude;
	if (Pts[0].Longitude > FileMaxX)
		FileMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < FileMinY)
		FileMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > FileMaxY)
		FileMaxY = Pts[0].Latitude;

	if (Pts[Npts-1].Longitude < CurrentMinX)
		CurrentMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < CurrentMinY)
		CurrentMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[Npts-1].Latitude;	
	if (Pts[Npts-1].Longitude < FileMinX)
		FileMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > FileMaxX)
		FileMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < FileMinY)
		FileMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > FileMaxY)
		FileMaxY = Pts[Npts-1].Latitude;		
	n = 1;
	steppos = (int)(n*100/written);	
	Ptrdlg->m_Progress.SetPos(steppos);
    while (n < written)
	{
		//printf("\n Have written %ld of %ld fmcd boundary lines",n, written);
		sprintf(msg,"processed %d of %d records",n,written);
		Ptrdlg->SetDlgItemText(IDC_DIVISIONSCU,msg);		
		found = 0;
		for (i = 1; i < written; i++)
         {
			Npts = 0;
			if (fmcd[i].Chosen != 0)
				continue;
			if (fmcd[i].Flip == 0)
			{
				if ((fmcd[i].Frlong == curX) && (fmcd[i].Frlat == curY))
				{                          
					if (strcmp(fmcd[i].Id,fmcd[curcase].Id) != 0)
						continue;	            
					Get_Shape_Points(fmcd[i].Tlid,fmcd[i].Flip);
					Pts[Npts].Longitude = fmcd[i].Tolong;
					Pts[Npts].Latitude = fmcd[i].Tolat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					fmcd[i].Chosen = 1;            
					found = 1;                      
					curX = fmcd[i].Tolong;
					curY = fmcd[i].Tolat;                
					curcase = i;
					break;
				}
			}
			else
			{
				if ((fmcd[i].Tolong == curX) && (fmcd[i].Tolat == curY))
				{
					if (strcmp(fmcd[i].Id,fmcd[curcase].Id) != 0)
						continue;	            
					Get_Shape_Points(fmcd[i].Tlid,fmcd[i].Flip);
					Pts[Npts].Longitude = fmcd[i].Frlong;
					Pts[Npts].Latitude = fmcd[i].Frlat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = fmcd[i].Frlong;
					curY = fmcd[i].Frlat;                        
					fmcd[i].Chosen = 1;	
					found = 1;          
					curcase = i;
					break;
				}
			}
        }//close for loop
		if (found == 0) //initialize new case, eg, new ring or new poly
		{			
			fwrite(&ptcount,sizeof(int),1,headtemp);
			ptcount = 0;
			for (i = 0; i < written; i++) //check for new ring in poly
            {                    
         		if (fmcd[i].Chosen != 0)
					continue;             		
				if (strcmp(fmcd[i].Id, fmcd[curcase].Id) != 0)
					continue;
				//if we get here it is a new ring in current poly
				found = 1;
				nparts++;
				Npts = 0;
				if (fmcd[i].Flip == 0)
				{
					Pts[Npts].Longitude = fmcd[i].Frlong;
					Pts[Npts].Latitude = fmcd[i].Frlat;
					Npts++;
					Get_Shape_Points(fmcd[i].Tlid,fmcd[i].Flip);
					Pts[Npts].Longitude = fmcd[i].Tolong;
					Pts[Npts].Latitude = fmcd[i].Tolat;
					Npts++;			
    				n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					fmcd[i].Chosen = 1;
    		   		curX = fmcd[i].Tolong;
    				curY = fmcd[i].Tolat;
					curcase = i;
					break;
				}
				else
				{
					Pts[Npts].Longitude = fmcd[i].Tolong;
					Pts[Npts].Latitude = fmcd[i].Tolat;
					Npts++;
					Get_Shape_Points(fmcd[i].Tlid,fmcd[i].Flip);
					Pts[Npts].Longitude = fmcd[i].Frlong;
					Pts[Npts].Latitude = fmcd[i].Frlat;
					Npts++;			
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					fmcd[i].Chosen = 1;
    		   		curX = fmcd[i].Frlong;
    				curY = fmcd[i].Frlat;
					curcase = i;
					break;
				}
    		}
    	}
		if (found == 0) // new poly, first ring
		{
			
			fwrite(&nparts,sizeof(int),1,partstemp);
			nparts = 1;
			fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
			CurrentMinX = CurrentMinY = LARGE;
			CurrentMaxX = CurrentMaxY = -LARGE;

			for (i = 0; i < written; i++)//first check for new ring in current poly
            {                    
         		if (fmcd[i].Chosen != 0)
					continue;             
				polyid++;
				fmcdname = Get_TypeC_Name(2,fmcd[i].Id,fmcd[i].County);
			    //sprintf(fmcrecord," %-8d%-5s%-5s%-66s",polyid,fmcd[i].County,fmcd[curcase].Id,
				//fmcdname);
				sprintf(fmcrecord," %-8d",polyid);
				sprintf(&fmcrecord[9],"%-5s",fmcd[i].County);
				sprintf(&fmcrecord[14],"%-5s",fmcd[i].Id);
				sprintf(&fmcrecord[19],"%-66s",fmcdname);
	
				//sprintf(fmcrecord," %-8d%-5s%-5s",polyid,fmcd[i].County,fmcd[i].Id);
				fwrite(&fmcrecord,sizeof(fmcrecord)-1,1,dbfout);    		
				Npts = 0;
				if (fmcd[i].Flip == 0)
				{
					Pts[Npts].Longitude = fmcd[i].Frlong;
					Pts[Npts].Latitude = fmcd[i].Frlat;
					Npts++;
					Get_Shape_Points(fmcd[i].Tlid,fmcd[i].Flip);
					Pts[Npts].Longitude = fmcd[i].Tolong;
					Pts[Npts].Latitude = fmcd[i].Tolat;
					Npts++;					
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					fmcd[i].Chosen = 1;            
					found = 1;                      
					curX = fmcd[i].Tolong;
					curY = fmcd[i].Tolat;                
					curcase = i;
					break;					
				}
				else
				{
					Pts[Npts].Longitude = fmcd[i].Tolong;
					Pts[Npts].Latitude = fmcd[i].Tolat;
					Npts++;
					Get_Shape_Points(fmcd[i].Tlid,fmcd[i].Flip);
					Pts[Npts].Longitude = fmcd[i].Frlong;
					Pts[Npts].Latitude = fmcd[i].Frlat;
					Npts++;				
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = fmcd[i].Frlong;
					curY = fmcd[i].Frlat;                        
					fmcd[i].Chosen = 1;		
					found = 1;          
					curcase = i;	
					break;					
				}	
			}
		}
		//by now found should be 1
		if (found == 0)
		{
			info.Format("ERROR - found is zero");
			Ptrdlg->ErrorMessage(info);						
			MissingFile = -1;
			return;
		}
		ptcount += Npts;
		fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
		if (Pts[0].Longitude < CurrentMinX)
			CurrentMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < CurrentMinY)
			CurrentMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[0].Latitude;	
		if (Pts[0].Longitude < FileMinX)
			FileMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > FileMaxX)
			FileMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < FileMinY)
			FileMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > FileMaxY)
			FileMaxY = Pts[0].Latitude;

		if (Pts[Npts-1].Longitude < CurrentMinX)
			CurrentMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < CurrentMinY)
			CurrentMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[Npts-1].Latitude;	
		if (Pts[Npts-1].Longitude < FileMinX)
			FileMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > FileMaxX)
			FileMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < FileMinY)
			FileMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > FileMaxY)
			FileMaxY = Pts[Npts-1].Latitude;		
	}//close while loop
	fwrite(&ptcount,sizeof(int),1,headtemp);
	fwrite(&nparts,sizeof(int),1,partstemp);
	fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
	fclose(boxtemp);
	fclose(headtemp);
	fclose(ptstemp);
	fclose(partstemp);
	sprintf(msg,"processed %d of %d records",n,written);
	Ptrdlg->SetDlgItemText(IDC_DIVISIONSCU,msg);		
	//printf("\n Have written %ld of %ld fmcd boundary lines",n, written);
	write_eof(dbfout);
	rewind(dbfout);
	Build_db_Header(dbfout,polyid,dbFmcdcu);
	Build_Poly_Shape("ccdcu");
	Ptrdlg->m_strDivisionscu.Format("%d Divisions",polyid);
	Ptrdlg->SetDlgItemText(IDC_DIVISIONSCU,Ptrdlg->m_strDivisionscu);	
    fclose(dbfout);
	free(fmcd);
	fprintf(LOG,"Wrote %d Census County Division Current polygons to shape %s%sccdcu\n", polyid,
		Outfilepath,Outfiletitle);		
}
void Match_Poly_Lines_Fpl90()
{
	int polyid, found, i, nparts, ptcount;
	long num, n, written, curcase;
	Fpl_Border_Type *fpl;
	double  curX, curY;	
    FILE  *dbfout, *ptstemp, *headtemp, *partstemp, *boxtemp; 
	CString info, fname;	
	char fplrecord[86]; //size of fpl dbrecord + 2
	int steppos;
	char msg[100];
	char *fplname;
	int doleft, doright;
	CString errmsg;
	
	if (APolycounts[4] == 0)
	{
		Ptrdlg->SetDlgItemText(IDC_PLACES,"No Such Cases");		
		return;
	}
	fname.Format("%s%splc.dbf",Outfilepath,Outfiletitle);			
	dbfout = fopen(fname,"wb");
	if (dbfout == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	ptstemp = fopen("pts.tmp","wb");
	if (ptstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	headtemp = fopen("head.tmp","wb");
	if (headtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	boxtemp = fopen("box.tmp","wb");
	if (boxtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	partstemp = fopen("parts.tmp","wb");
	if (partstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	    
	fpl = (Fpl_Border_Type *)calloc(APolycounts[4]+Watercut*SPolycounts[0],sizeof(Fpl_Border_Type));
	written = 0;
	for (num = 0; num < CountI; num++)
	{
		if (strcmp(TypeIs[num].Fpl90l,TypeIs[num].Fpl90r) == 0)
		{
			if (Watercut)
			{

				if (TypeIs[num].Waterl == TypeIs[num].Waterr)
					continue;
			}
			else
				continue;		
		}
		doleft = 0;
			
		if (strcmp(TypeIs[num].Fpl90l,"     ") != 0)
		{//left case
			if (Watercut)
			{
				if (!TypeIs[num].Waterl)
					doleft = 1;
			}
			else
				doleft = 1;
			if (doleft)
			{	
				sprintf(fpl[written].County,"%s",TypeIs[num].County90l);
				sprintf(fpl[written].Id,"%s",TypeIs[num].Fpl90l);
				sprintf(fpl[written].Tlid,"%s",TypeIs[num].Tlid);
				fpl[written].Frlong = Type1s[num].Frlong;
				fpl[written].Frlat = Type1s[num].Frlat;
				fpl[written].Tolong = Type1s[num].Tolong;
				fpl[written].Tolat = Type1s[num].Tolat;
				fpl[written].Chosen = 0;
				fpl[written].Flip = 1;
				written++;
			}
		}
		doright = 0;

		if (strcmp(TypeIs[num].Fpl90r,"     ") != 0)
		{
			if (Watercut)
			{
				if (!TypeIs[num].Waterr)
					doright = 1;
			}
			else
				doright = 1;
			if (doright)
			{
				sprintf(fpl[written].County,"%s",TypeIs[num].County90r);
				sprintf(fpl[written].Id,"%s",TypeIs[num].Fpl90r);
				sprintf(fpl[written].Tlid,"%s",TypeIs[num].Tlid);
				fpl[written].Frlong = Type1s[num].Frlong;
				fpl[written].Frlat = Type1s[num].Frlat;
				fpl[written].Tolong = Type1s[num].Tolong;
				fpl[written].Tolat = Type1s[num].Tolat;
				fpl[written].Chosen = 0;
				fpl[written].Flip = 0;
				written++;
			}
		}
		
		if (written > APolycounts[4]+Watercut*SPolycounts[0])
		{
			Ptrdlg->ErrorMessage("the number of Places 90 border lines exceeds the count");				
			MissingFile = -1;
			return;
		}
	}
	//time to chain	
	Ptrdlg->m_strProcess.Format("Gathering Place Boundary Lines");
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	qsort((void *)fpl,written,sizeof(Fpl_Border_Type),(compfn)CompareFpl);
	FileMinX = FileMinY = LARGE;
	FileMaxX = FileMaxY = -LARGE;
	CurrentMinX = CurrentMinY = LARGE;
	CurrentMaxX = CurrentMaxY = -LARGE;
	curcase = 0;
	polyid = 1;
	Npts = 0; 
	nparts = 1;
	ptcount = 0;
	Build_db_Header(dbfout,0,dbFpl);
	Build_db_FieldHeaders(dbfout,dbFpl);
	fplname = Get_TypeC_Name(3,fpl[curcase].Id,"");
    //sprintf(fplrecord," %-8d%-5s%-5s%-66s",polyid,fpl[curcase].County,
	//	fpl[curcase].Id, fplname);
	sprintf(fplrecord," %-8d",polyid);
	sprintf(&fplrecord[9],"%-5s",fpl[curcase].County);
	sprintf(&fplrecord[14],"%-5s",fpl[curcase].Id);
	sprintf(&fplrecord[19],"%-66s",fplname);
	fwrite(&fplrecord,sizeof(fplrecord)-1,1,dbfout);
	if (fpl[0].Flip == 0)
	{
		curX = fpl[0].Tolong;
		curY = fpl[0].Tolat;		
		Pts[Npts].Longitude = fpl[curcase].Frlong;
		Pts[Npts].Latitude = fpl[curcase].Frlat;
		Npts++;
		Get_Shape_Points(fpl[curcase].Tlid, fpl[curcase].Flip);
		Pts[Npts].Longitude = fpl[curcase].Tolong;
		Pts[Npts].Latitude = fpl[curcase].Tolat;
		Npts++;
		fpl[curcase].Chosen = 1;		
	}
	else
	{
		curX = fpl[0].Frlong;
		curY = fpl[0].Frlat;		
		Pts[Npts].Longitude = fpl[curcase].Tolong;
		Pts[Npts].Latitude = fpl[curcase].Tolat;
		Npts++;
		Get_Shape_Points(fpl[curcase].Tlid, fpl[curcase].Flip);
		Pts[Npts].Longitude = fpl[curcase].Frlong;
		Pts[Npts].Latitude = fpl[curcase].Frlat;
		Npts++;
		fpl[curcase].Chosen = 1;		
	}
	ptcount += Npts;
	
    fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
	
	if (Pts[0].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < CurrentMinY)
		CurrentMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[0].Latitude;	
	if (Pts[0].Longitude < FileMinX)
		FileMinX = Pts[0].Longitude;
	if (Pts[0].Longitude > FileMaxX)
		FileMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < FileMinY)
		FileMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > FileMaxY)
		FileMaxY = Pts[0].Latitude;

	if (Pts[Npts-1].Longitude < CurrentMinX)
		CurrentMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < CurrentMinY)
		CurrentMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[Npts-1].Latitude;	
	if (Pts[Npts-1].Longitude < FileMinX)
		FileMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > FileMaxX)
		FileMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < FileMinY)
		FileMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > FileMaxY)
		FileMaxY = Pts[Npts-1].Latitude;		
	n = 1;
	steppos = (int)(n*100/written);	
	Ptrdlg->m_Progress.SetPos(steppos);
    while (n < written)
	{
		//printf("\n Have written %ld of %ld fpl boundary lines",n, written);
		sprintf(msg,"processed %d of %d records",n,written);
		Ptrdlg->SetDlgItemText(IDC_PLACES,msg);		
		found = 0;
		for (i = 1; i < written; i++)
         {
			Npts = 0;
			if (fpl[i].Chosen != 0)
				continue;
			if (fpl[i].Flip == 0)
			{
				if ((fpl[i].Frlong == curX) && (fpl[i].Frlat == curY))
				{                          
					if (strcmp(fpl[i].Id,fpl[curcase].Id) != 0)
						continue;	            
					Get_Shape_Points(fpl[i].Tlid,fpl[i].Flip);
					Pts[Npts].Longitude = fpl[i].Tolong;
					Pts[Npts].Latitude = fpl[i].Tolat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					fpl[i].Chosen = 1;            
					found = 1;                      
					curX = fpl[i].Tolong;
					curY = fpl[i].Tolat;                
					curcase = i;
					break;
				}
			}
			else
			{
				if ((fpl[i].Tolong == curX) && (fpl[i].Tolat == curY))
				{
					if (strcmp(fpl[i].Id,fpl[curcase].Id) != 0)
						continue;	            
					Get_Shape_Points(fpl[i].Tlid,fpl[i].Flip);
					Pts[Npts].Longitude = fpl[i].Frlong;
					Pts[Npts].Latitude = fpl[i].Frlat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = fpl[i].Frlong;
					curY = fpl[i].Frlat;                        
					fpl[i].Chosen = 1;	
					found = 1;          
					curcase = i;
					break;
				}
			}
        }//close for loop
		if (found == 0) //initialize new case, eg, new ring or new poly
		{			
			fwrite(&ptcount,sizeof(int),1,headtemp);
			ptcount = 0;
			for (i = 0; i < written; i++) //check for new ring in poly
            {                    
         		if (fpl[i].Chosen != 0)
					continue;             		
				if (strcmp(fpl[i].Id, fpl[curcase].Id) != 0)
					continue;
				//if we get here it is a new ring in current poly
				found = 1;
				nparts++;
				Npts = 0;
				if (fpl[i].Flip == 0)
				{
					Pts[Npts].Longitude = fpl[i].Frlong;
					Pts[Npts].Latitude = fpl[i].Frlat;
					Npts++;
					Get_Shape_Points(fpl[i].Tlid,fpl[i].Flip);
					Pts[Npts].Longitude = fpl[i].Tolong;
					Pts[Npts].Latitude = fpl[i].Tolat;
					Npts++;			
    				n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					fpl[i].Chosen = 1;
    		   		curX = fpl[i].Tolong;
    				curY = fpl[i].Tolat;
					curcase = i;
					break;
				}
				else
				{
					Pts[Npts].Longitude = fpl[i].Tolong;
					Pts[Npts].Latitude = fpl[i].Tolat;
					Npts++;
					Get_Shape_Points(fpl[i].Tlid,fpl[i].Flip);
					Pts[Npts].Longitude = fpl[i].Frlong;
					Pts[Npts].Latitude = fpl[i].Frlat;
					Npts++;			
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					fpl[i].Chosen = 1;
    		   		curX = fpl[i].Frlong;
    				curY = fpl[i].Frlat;
					curcase = i;
					break;
				}
    		}
    	}
		if (found == 0) // new poly, first ring
		{
			
			fwrite(&nparts,sizeof(int),1,partstemp);
			nparts = 1;
			fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
			CurrentMinX = CurrentMinY = LARGE;
			CurrentMaxX = CurrentMaxY = -LARGE;

			for (i = 0; i < written; i++)//first check for new ring in current poly
            {                    
         		if (fpl[i].Chosen != 0)
					continue;             
				polyid++;
				fplname = Get_TypeC_Name(3,fpl[i].Id,"");
				//sprintf(fplrecord," %-8d%-5s%-5s%-66s",polyid,fpl[i].County,
				//fpl[i].Id, fplname);
				sprintf(fplrecord," %-8d",polyid);
				sprintf(&fplrecord[9],"%-5s",fpl[i].County);
				sprintf(&fplrecord[14],"%-5s",fpl[i].Id);
				sprintf(&fplrecord[19],"%-66s",fplname);
	
				//sprintf(fplrecord," %-8d%-5s%-5s",polyid,fpl[i].County,fpl[i].Id);
				fwrite(&fplrecord,sizeof(fplrecord)-1,1,dbfout);    		
				Npts = 0;
				if (fpl[i].Flip == 0)
				{
					Pts[Npts].Longitude = fpl[i].Frlong;
					Pts[Npts].Latitude = fpl[i].Frlat;
					Npts++;
					Get_Shape_Points(fpl[i].Tlid,fpl[i].Flip);
					Pts[Npts].Longitude = fpl[i].Tolong;
					Pts[Npts].Latitude = fpl[i].Tolat;
					Npts++;					
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					fpl[i].Chosen = 1;            
					found = 1;                      
					curX = fpl[i].Tolong;
					curY = fpl[i].Tolat;                
					curcase = i;
					break;					
				}
				else
				{
					Pts[Npts].Longitude = fpl[i].Tolong;
					Pts[Npts].Latitude = fpl[i].Tolat;
					Npts++;
					Get_Shape_Points(fpl[i].Tlid,fpl[i].Flip);
					Pts[Npts].Longitude = fpl[i].Frlong;
					Pts[Npts].Latitude = fpl[i].Frlat;
					Npts++;				
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = fpl[i].Frlong;
					curY = fpl[i].Frlat;                        
					fpl[i].Chosen = 1;		
					found = 1;          
					curcase = i;	
					break;					
				}	
			}
		}
		//by now found should be 1
		if (found == 0)
		{
			info.Format("ERROR - found is zero");
			Ptrdlg->ErrorMessage(info);									
			MissingFile = -1;
			return;
		}
		ptcount += Npts;
		fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
		if (Pts[0].Longitude < CurrentMinX)
			CurrentMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < CurrentMinY)
			CurrentMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[0].Latitude;	
		if (Pts[0].Longitude < FileMinX)
			FileMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > FileMaxX)
			FileMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < FileMinY)
			FileMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > FileMaxY)
			FileMaxY = Pts[0].Latitude;

		if (Pts[Npts-1].Longitude < CurrentMinX)
			CurrentMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < CurrentMinY)
			CurrentMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[Npts-1].Latitude;	
		if (Pts[Npts-1].Longitude < FileMinX)
			FileMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > FileMaxX)
			FileMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < FileMinY)
			FileMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > FileMaxY)
			FileMaxY = Pts[Npts-1].Latitude;		
	}//close while loop
	fwrite(&ptcount,sizeof(int),1,headtemp);
	fwrite(&nparts,sizeof(int),1,partstemp);
	fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
	fclose(boxtemp);
	fclose(headtemp);
	fclose(ptstemp);
	fclose(partstemp);
	sprintf(msg,"processed %d of %d records",n,written);
	Ptrdlg->SetDlgItemText(IDC_PLACES,msg);		
	//printf("\n Have written %ld of %ld fpl boundary lines",n, written);
	write_eof(dbfout);
	rewind(dbfout);
	Build_db_Header(dbfout,polyid,dbFpl);
	Build_Poly_Shape("plc");
	Ptrdlg->m_strPlaces.Format("%d Places",polyid);
	Ptrdlg->SetDlgItemText(IDC_PLACES,Ptrdlg->m_strPlaces);	
    fclose(dbfout);
	free(fpl);
	fprintf(LOG,"Wrote %d Place polygons to shape %s%splc\n", polyid,Outfilepath,
		Outfiletitle);		
}
void Match_Poly_Lines_Fplcu()
{
	int polyid, found, i, nparts, ptcount;
	long num, n, written, curcase;
	Fpl_Border_Type *fpl;
	double  curX, curY;	
    FILE  *dbfout, *ptstemp, *headtemp, *partstemp, *boxtemp; 
	CString info, fname;	
	char fplcurecord[86]; //size of fpl dbrecord + 2
	int steppos;
	char msg[100];
	char *fplname;
	CString errmsg;
	int doleft, doright;
	
	if (SPolycounts[7] == 0)
	{
		Ptrdlg->SetDlgItemText(IDC_PLACESCU,"No Such Cases");		
		return;
	}
	fname.Format("%s%splccu.dbf",Outfilepath,Outfiletitle);			
	dbfout = fopen(fname,"wb");
	if (dbfout == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	ptstemp = fopen("pts.tmp","wb");
	if (ptstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	headtemp = fopen("head.tmp","wb");
	if (headtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	boxtemp = fopen("box.tmp","wb");
	if (boxtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	partstemp = fopen("parts.tmp","wb");
	if (partstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	    
	fpl = (Fpl_Border_Type *)calloc(SPolycounts[7]+Watercut*SPolycounts[0],sizeof(Fpl_Border_Type));
	written = 0;
	for (num = 0; num < CountI; num++)
	{
		if (strcmp(TypeIs[num].Fplcul,TypeIs[num].Fplcur) == 0)
		{
			if (Watercut)
			{

				if (TypeIs[num].Waterl == TypeIs[num].Waterr)
					continue;
			}
			else
				continue;		
		}
		doleft = 0;
			
		if (strcmp(TypeIs[num].Fplcul,"     ") != 0)
		{//left case
			if (Watercut)
			{

				if (!TypeIs[num].Waterl)
					doleft = 1;
			}
			else
				doleft = 1;
			if (doleft)
			{
				sprintf(fpl[written].County,"%2s%3s",TypeIs[num].State, TypeIs[num].County);
				sprintf(fpl[written].Id,"%s",TypeIs[num].Fplcul);
				sprintf(fpl[written].Tlid,"%s",TypeIs[num].Tlid);
				fpl[written].Frlong = Type1s[num].Frlong;
				fpl[written].Frlat = Type1s[num].Frlat;
				fpl[written].Tolong = Type1s[num].Tolong;
				fpl[written].Tolat = Type1s[num].Tolat;
				fpl[written].Chosen = 0;
				fpl[written].Flip = 1;
				written++;
			}
		}
		doright = 0;
		if (strcmp(TypeIs[num].Fplcur,"     ") != 0)
		{
			if (Watercut)
			{
				if (!TypeIs[num].Waterr)
					doright = 1;
			}
			else
				doright = 1;
			if (doright)
			{
				sprintf(fpl[written].County,"%2s%3s",TypeIs[num].State,TypeIs[num].County);
				sprintf(fpl[written].Id,"%s",TypeIs[num].Fplcur);
				sprintf(fpl[written].Tlid,"%s",TypeIs[num].Tlid);
				fpl[written].Frlong = Type1s[num].Frlong;
				fpl[written].Frlat = Type1s[num].Frlat;
				fpl[written].Tolong = Type1s[num].Tolong;
				fpl[written].Tolat = Type1s[num].Tolat;
				fpl[written].Chosen = 0;
				fpl[written].Flip = 0;
				written++;
			}
		}
		
		if (written > SPolycounts[7]+Watercut * SPolycounts[0])
		{
			Ptrdlg->ErrorMessage("the number of Places current border lines exceeds the count");				
			MissingFile = -1;
			return;
		}
	}
	//time to chain	
	Ptrdlg->m_strProcess.Format("Gathering Place Boundary Lines");
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	qsort((void *)fpl,written,sizeof(Fpl_Border_Type),(compfn)CompareFpl);
	FileMinX = FileMinY = LARGE;
	FileMaxX = FileMaxY = -LARGE;
	CurrentMinX = CurrentMinY = LARGE;
	CurrentMaxX = CurrentMaxY = -LARGE;
	curcase = 0;
	polyid = 1;
	Npts = 0; 
	nparts = 1;
	ptcount = 0;
	Build_db_Header(dbfout,0,dbFplcu);
	Build_db_FieldHeaders(dbfout,dbFplcu);
	fplname = Get_TypeC_Name(3,fpl[curcase].Id,"");
    //sprintf(fplrecord," %-8d%-5s%-5s%-66s",polyid,fpl[curcase].County,
	//	fpl[curcase].Id, fplname);
	sprintf(fplcurecord," %-8d",polyid);
	sprintf(&fplcurecord[9],"%-5s",fpl[curcase].County);
	sprintf(&fplcurecord[14],"%-5s",fpl[curcase].Id);
	sprintf(&fplcurecord[19],"%-66s",fplname);
	fwrite(&fplcurecord,sizeof(fplcurecord)-1,1,dbfout);
	if (fpl[0].Flip == 0)
	{
		curX = fpl[0].Tolong;
		curY = fpl[0].Tolat;		
		Pts[Npts].Longitude = fpl[curcase].Frlong;
		Pts[Npts].Latitude = fpl[curcase].Frlat;
		Npts++;
		Get_Shape_Points(fpl[curcase].Tlid, fpl[curcase].Flip);
		Pts[Npts].Longitude = fpl[curcase].Tolong;
		Pts[Npts].Latitude = fpl[curcase].Tolat;
		Npts++;
		fpl[curcase].Chosen = 1;		
	}
	else
	{
		curX = fpl[0].Frlong;
		curY = fpl[0].Frlat;		
		Pts[Npts].Longitude = fpl[curcase].Tolong;
		Pts[Npts].Latitude = fpl[curcase].Tolat;
		Npts++;
		Get_Shape_Points(fpl[curcase].Tlid, fpl[curcase].Flip);
		Pts[Npts].Longitude = fpl[curcase].Frlong;
		Pts[Npts].Latitude = fpl[curcase].Frlat;
		Npts++;
		fpl[curcase].Chosen = 1;		
	}
	ptcount += Npts;
	
    fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
	
	if (Pts[0].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < CurrentMinY)
		CurrentMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[0].Latitude;	
	if (Pts[0].Longitude < FileMinX)
		FileMinX = Pts[0].Longitude;
	if (Pts[0].Longitude > FileMaxX)
		FileMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < FileMinY)
		FileMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > FileMaxY)
		FileMaxY = Pts[0].Latitude;

	if (Pts[Npts-1].Longitude < CurrentMinX)
		CurrentMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < CurrentMinY)
		CurrentMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[Npts-1].Latitude;	
	if (Pts[Npts-1].Longitude < FileMinX)
		FileMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > FileMaxX)
		FileMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < FileMinY)
		FileMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > FileMaxY)
		FileMaxY = Pts[Npts-1].Latitude;		
	n = 1;
	steppos = (int)(n*100/written);	
	Ptrdlg->m_Progress.SetPos(steppos);
    while (n < written)
	{
		//printf("\n Have written %ld of %ld fpl boundary lines",n, written);
		sprintf(msg,"processed %d of %d records",n,written);
		Ptrdlg->SetDlgItemText(IDC_PLACESCU,msg);		
		found = 0;
		for (i = 1; i < written; i++)
         {
			Npts = 0;
			if (fpl[i].Chosen != 0)
				continue;
			if (fpl[i].Flip == 0)
			{
				if ((fpl[i].Frlong == curX) && (fpl[i].Frlat == curY))
				{                          
					if (strcmp(fpl[i].Id,fpl[curcase].Id) != 0)
						continue;	            
					Get_Shape_Points(fpl[i].Tlid,fpl[i].Flip);
					Pts[Npts].Longitude = fpl[i].Tolong;
					Pts[Npts].Latitude = fpl[i].Tolat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					fpl[i].Chosen = 1;            
					found = 1;                      
					curX = fpl[i].Tolong;
					curY = fpl[i].Tolat;                
					curcase = i;
					break;
				}
			}
			else
			{
				if ((fpl[i].Tolong == curX) && (fpl[i].Tolat == curY))
				{
					if (strcmp(fpl[i].Id,fpl[curcase].Id) != 0)
						continue;	            
					Get_Shape_Points(fpl[i].Tlid,fpl[i].Flip);
					Pts[Npts].Longitude = fpl[i].Frlong;
					Pts[Npts].Latitude = fpl[i].Frlat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = fpl[i].Frlong;
					curY = fpl[i].Frlat;                        
					fpl[i].Chosen = 1;	
					found = 1;          
					curcase = i;
					break;
				}
			}
        }//close for loop
		if (found == 0) //initialize new case, eg, new ring or new poly
		{			
			fwrite(&ptcount,sizeof(int),1,headtemp);
			ptcount = 0;
			for (i = 0; i < written; i++) //check for new ring in poly
            {                    
         		if (fpl[i].Chosen != 0)
					continue;             		
				if (strcmp(fpl[i].Id, fpl[curcase].Id) != 0)
					continue;
				//if we get here it is a new ring in current poly
				found = 1;
				nparts++;
				Npts = 0;
				if (fpl[i].Flip == 0)
				{
					Pts[Npts].Longitude = fpl[i].Frlong;
					Pts[Npts].Latitude = fpl[i].Frlat;
					Npts++;
					Get_Shape_Points(fpl[i].Tlid,fpl[i].Flip);
					Pts[Npts].Longitude = fpl[i].Tolong;
					Pts[Npts].Latitude = fpl[i].Tolat;
					Npts++;			
    				n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					fpl[i].Chosen = 1;
    		   		curX = fpl[i].Tolong;
    				curY = fpl[i].Tolat;
					curcase = i;
					break;
				}
				else
				{
					Pts[Npts].Longitude = fpl[i].Tolong;
					Pts[Npts].Latitude = fpl[i].Tolat;
					Npts++;
					Get_Shape_Points(fpl[i].Tlid,fpl[i].Flip);
					Pts[Npts].Longitude = fpl[i].Frlong;
					Pts[Npts].Latitude = fpl[i].Frlat;
					Npts++;			
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					fpl[i].Chosen = 1;
    		   		curX = fpl[i].Frlong;
    				curY = fpl[i].Frlat;
					curcase = i;
					break;
				}
    		}
    	}
		if (found == 0) // new poly, first ring
		{
			
			fwrite(&nparts,sizeof(int),1,partstemp);
			nparts = 1;
			fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
			CurrentMinX = CurrentMinY = LARGE;
			CurrentMaxX = CurrentMaxY = -LARGE;

			for (i = 0; i < written; i++)//first check for new ring in current poly
            {                    
         		if (fpl[i].Chosen != 0)
					continue;             
				polyid++;
				fplname = Get_TypeC_Name(3,fpl[i].Id,"");
				//sprintf(fplrecord," %-8d%-5s%-5s%-66s",polyid,fpl[i].County,
				//fpl[i].Id, fplname);
				sprintf(fplcurecord," %-8d",polyid);
				sprintf(&fplcurecord[9],"%-5s",fpl[i].County);
				sprintf(&fplcurecord[14],"%-5s",fpl[i].Id);
				sprintf(&fplcurecord[19],"%-66s",fplname);
	
				//sprintf(fplrecord," %-8d%-5s%-5s",polyid,fpl[i].County,fpl[i].Id);
				fwrite(&fplcurecord,sizeof(fplcurecord)-1,1,dbfout);    		
				Npts = 0;
				if (fpl[i].Flip == 0)
				{
					Pts[Npts].Longitude = fpl[i].Frlong;
					Pts[Npts].Latitude = fpl[i].Frlat;
					Npts++;
					Get_Shape_Points(fpl[i].Tlid,fpl[i].Flip);
					Pts[Npts].Longitude = fpl[i].Tolong;
					Pts[Npts].Latitude = fpl[i].Tolat;
					Npts++;					
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					fpl[i].Chosen = 1;            
					found = 1;                      
					curX = fpl[i].Tolong;
					curY = fpl[i].Tolat;                
					curcase = i;
					break;					
				}
				else
				{
					Pts[Npts].Longitude = fpl[i].Tolong;
					Pts[Npts].Latitude = fpl[i].Tolat;
					Npts++;
					Get_Shape_Points(fpl[i].Tlid,fpl[i].Flip);
					Pts[Npts].Longitude = fpl[i].Frlong;
					Pts[Npts].Latitude = fpl[i].Frlat;
					Npts++;				
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = fpl[i].Frlong;
					curY = fpl[i].Frlat;                        
					fpl[i].Chosen = 1;		
					found = 1;          
					curcase = i;	
					break;					
				}	
			}
		}
		//by now found should be 1
		if (found == 0)
		{
			info.Format("ERROR - found is zero");
			Ptrdlg->ErrorMessage(info);									
			MissingFile = -1;
			return;
		}
		ptcount += Npts;
		fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
		if (Pts[0].Longitude < CurrentMinX)
			CurrentMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < CurrentMinY)
			CurrentMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[0].Latitude;	
		if (Pts[0].Longitude < FileMinX)
			FileMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > FileMaxX)
			FileMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < FileMinY)
			FileMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > FileMaxY)
			FileMaxY = Pts[0].Latitude;

		if (Pts[Npts-1].Longitude < CurrentMinX)
			CurrentMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < CurrentMinY)
			CurrentMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[Npts-1].Latitude;	
		if (Pts[Npts-1].Longitude < FileMinX)
			FileMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > FileMaxX)
			FileMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < FileMinY)
			FileMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > FileMaxY)
			FileMaxY = Pts[Npts-1].Latitude;		
	}//close while loop
	fwrite(&ptcount,sizeof(int),1,headtemp);
	fwrite(&nparts,sizeof(int),1,partstemp);
	fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
	fclose(boxtemp);
	fclose(headtemp);
	fclose(ptstemp);
	fclose(partstemp);
	sprintf(msg,"processed %d of %d records",n,written);
	Ptrdlg->SetDlgItemText(IDC_PLACESCU,msg);		
	//printf("\n Have written %ld of %ld fpl boundary lines",n, written);
	write_eof(dbfout);
	rewind(dbfout);
	Build_db_Header(dbfout,polyid,dbFplcu);
	Build_Poly_Shape("plccu");
	Ptrdlg->m_strPlacescu.Format("%d Places",polyid);
	Ptrdlg->SetDlgItemText(IDC_PLACESCU,Ptrdlg->m_strPlacescu);	
    fclose(dbfout);
	free(fpl);
	fprintf(LOG,"Wrote %d Places Current polygons to shape %s%splccu\n", polyid,Outfilepath,
		Outfiletitle);		
}

void Match_Poly_Lines_Air90()
{
	int polyid, found, i, nparts, ptcount;
	long num, n, written, curcase;
	Air_Border_Type *air;
	double  curX, curY;	
    FILE  *dbfout, *ptstemp, *headtemp, *partstemp, *boxtemp; 
	CString info, fname;	
	char airrecord[85]; //size of fpl dbrecord + 2
	int steppos;
	char msg[100];
	char *airname;
	CString errmsg;	
	int doleft, doright;
	if (APolycounts[6] == 0)
	{
		Ptrdlg->SetDlgItemText(IDC_AIR,"No Such Cases");		
		return;
	}
	fname.Format("%s%sair.dbf",Outfilepath,Outfiletitle);			
	dbfout = fopen(fname,"wb");
	if (dbfout == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	ptstemp = fopen("pts.tmp","wb");
	if (ptstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	headtemp = fopen("head.tmp","wb");
	if (headtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	boxtemp = fopen("box.tmp","wb");
	if (boxtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	partstemp = fopen("parts.tmp","wb");
	if (partstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	
	air = (Air_Border_Type *)calloc(APolycounts[6]+Watercut*SPolycounts[0],sizeof(Air_Border_Type));
	written = 0;
	for (num = 0; num < CountI; num++)
	{
		if (strcmp(TypeIs[num].Air90l, TypeIs[num].Air90r) == 0)
		{
			if (Watercut)
			{

				if (TypeIs[num].Waterl == TypeIs[num].Waterr)
					continue;
			}
			else
				continue;		
		}
		doleft = 0;

		if (strcmp(TypeIs[num].Air90l,"    ") != 0)
		{//left case
			if (Watercut)
			{

				if (!TypeIs[num].Waterl)
					doleft = 1;
			}
			else
				doleft = 1;
			if (doleft)
			{
				sprintf(air[written].County,"%s",TypeIs[num].County90l);
				sprintf(air[written].Id,"%s",TypeIs[num].Air90l);
				sprintf(air[written].Tlid,"%s",Type1s[num].Tlid);
				air[written].Frlong = Type1s[num].Frlong;
				air[written].Frlat = Type1s[num].Frlat;
				air[written].Tolong = Type1s[num].Tolong;
				air[written].Tolat = Type1s[num].Tolat;
				air[written].Chosen = 0;
				air[written].Flip = 1;
				written++;
			}
		}
		doright = 0;
		if (strcmp(TypeIs[num].Air90r,"    ") != 0)
		{//rightcase 
		//printf("\nright case");
			if (Watercut)
			{
				if (!TypeIs[num].Waterr)
					doright = 1;
			}
			else
				doright = 1;
			if (doright)
			{
				sprintf(air[written].County,"%s",TypeIs[num].County90r);
				sprintf(air[written].Id,"%s",TypeIs[num].Air90r);
				sprintf(air[written].Tlid,"%s",Type1s[num].Tlid);
				air[written].Frlong = Type1s[num].Frlong;
				air[written].Frlat = Type1s[num].Frlat;
				air[written].Tolong = Type1s[num].Tolong;
				air[written].Tolat = Type1s[num].Tolat;
				air[written].Chosen = 0;
				air[written].Flip = 0;
				written++;
			}
		}
	}
	if (written > APolycounts[6]+Watercut*SPolycounts[0])
	{
		Ptrdlg->ErrorMessage("the number of AIR border lines exceeds the count");				
		MissingFile = -1;
		return;
	}
	Ptrdlg->m_strProcess.Format("Gathering AIR Boundary Lines");
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	//time to chain	
	qsort((void *)air,written,sizeof(Air_Border_Type),(compfn)CompareAir);
	FileMinX = FileMinY = LARGE;
	FileMaxX = FileMaxY = -LARGE;
	CurrentMinX = CurrentMinY = LARGE;
	CurrentMaxX = CurrentMaxY = -LARGE;
	curcase = 0;
	polyid = 1;
	Npts = 0; 
	nparts = 1;
	ptcount = 0;
	Build_db_Header(dbfout,0,dbAir);
	Build_db_FieldHeaders(dbfout,dbAir);
	airname = Get_TypeC_Name(4,air[curcase].Id,"");
    //sprintf(airrecord," %-8d%-5s%-4s%-66s",polyid,air[curcase].County,air[curcase].Id,
	//	airname);
	sprintf(airrecord," %-8d",polyid);
	sprintf(&airrecord[9],"%-5s",air[curcase].County);
	sprintf(&airrecord[14],"%-4s",air[curcase].Id);
	sprintf(&airrecord[18],"%-66s",airname);
	fwrite(&airrecord,sizeof(airrecord)-1,1,dbfout);
	if (air[0].Flip == 0)
	{
		curX = air[0].Tolong;
		curY = air[0].Tolat;		
		Pts[Npts].Longitude = air[curcase].Frlong;
		Pts[Npts].Latitude = air[curcase].Frlat;
		Npts++;
		Get_Shape_Points(air[curcase].Tlid, air[curcase].Flip);
		Pts[Npts].Longitude = air[curcase].Tolong;
		Pts[Npts].Latitude = air[curcase].Tolat;
		Npts++;
		air[curcase].Chosen = 1;		
	}
	else
	{
		curX = air[0].Frlong;
		curY = air[0].Frlat;		
		Pts[Npts].Longitude = air[curcase].Tolong;
		Pts[Npts].Latitude = air[curcase].Tolat;
		Npts++;
		Get_Shape_Points(air[curcase].Tlid, air[curcase].Flip);
		Pts[Npts].Longitude = air[curcase].Frlong;
		Pts[Npts].Latitude = air[curcase].Frlat;
		Npts++;
		air[curcase].Chosen = 1;		
	}
	ptcount += Npts;
	
    fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
	
	if (Pts[0].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < CurrentMinY)
		CurrentMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[0].Latitude;	
	if (Pts[0].Longitude < FileMinX)
		FileMinX = Pts[0].Longitude;
	if (Pts[0].Longitude > FileMaxX)
		FileMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < FileMinY)
		FileMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > FileMaxY)
		FileMaxY = Pts[0].Latitude;

	if (Pts[Npts-1].Longitude < CurrentMinX)
		CurrentMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < CurrentMinY)
		CurrentMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[Npts-1].Latitude;	
	if (Pts[Npts-1].Longitude < FileMinX)
		FileMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > FileMaxX)
		FileMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < FileMinY)
		FileMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > FileMaxY)
		FileMaxY = Pts[Npts-1].Latitude;		
	n = 1;
	steppos = (int)(n*100/written);	
	Ptrdlg->m_Progress.SetPos(steppos);
    while (n < written)
	{
		//printf("\n Have written %ld of %ld fpl boundary lines",n, written);
		sprintf(msg,"processed %d of %d records",n,written);
		Ptrdlg->SetDlgItemText(IDC_AIR,msg);		
		found = 0;
		for (i = 1; i < written; i++)
         {
			Npts = 0;
			if (air[i].Chosen != 0)
				continue;
			if (air[i].Flip == 0)
			{
				if ((air[i].Frlong == curX) && (air[i].Frlat == curY))
				{                          
					if (strcmp(air[i].Id,air[curcase].Id) != 0)
						continue;	            
					Get_Shape_Points(air[i].Tlid,air[i].Flip);
					Pts[Npts].Longitude = air[i].Tolong;
					Pts[Npts].Latitude = air[i].Tolat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					air[i].Chosen = 1;            
					found = 1;                      
					curX = air[i].Tolong;
					curY = air[i].Tolat;                
					curcase = i;
					break;
				}
			}
			else
			{
				if ((air[i].Tolong == curX) && (air[i].Tolat == curY))
				{
					if (strcmp(air[i].Id,air[curcase].Id) != 0)
						continue;	            
					Get_Shape_Points(air[i].Tlid,air[i].Flip);
					Pts[Npts].Longitude = air[i].Frlong;
					Pts[Npts].Latitude = air[i].Frlat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = air[i].Frlong;
					curY = air[i].Frlat;                        
					air[i].Chosen = 1;	
					found = 1;          
					curcase = i;
					break;
				}
			}
        }//close for loop
		if (found == 0) //initialize new case, eg, new ring or new poly
		{			
			fwrite(&ptcount,sizeof(int),1,headtemp);
			ptcount = 0;
			for (i = 0; i < written; i++) //check for new ring in poly
            {                    
         		if (air[i].Chosen != 0)
					continue;             		
				if (strcmp(air[i].Id, air[curcase].Id) != 0)
					continue;
				//if we get here it is a new ring in current poly
				found = 1;
				nparts++;
				Npts = 0;
				if (air[i].Flip == 0)
				{
					Pts[Npts].Longitude = air[i].Frlong;
					Pts[Npts].Latitude = air[i].Frlat;
					Npts++;
					Get_Shape_Points(air[i].Tlid,air[i].Flip);
					Pts[Npts].Longitude = air[i].Tolong;
					Pts[Npts].Latitude = air[i].Tolat;
					Npts++;			
    				n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					air[i].Chosen = 1;
    		   		curX = air[i].Tolong;
    				curY = air[i].Tolat;
					curcase = i;
					break;
				}
				else
				{
					Pts[Npts].Longitude = air[i].Tolong;
					Pts[Npts].Latitude = air[i].Tolat;
					Npts++;
					Get_Shape_Points(air[i].Tlid,air[i].Flip);
					Pts[Npts].Longitude = air[i].Frlong;
					Pts[Npts].Latitude = air[i].Frlat;
					Npts++;			
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					air[i].Chosen = 1;
    		   		curX = air[i].Frlong;
    				curY = air[i].Frlat;
					curcase = i;
					break;
				}
    		}
    	}
		if (found == 0) // new poly, first ring
		{
			
			fwrite(&nparts,sizeof(int),1,partstemp);
			nparts = 1;
			fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
			CurrentMinX = CurrentMinY = LARGE;
			CurrentMaxX = CurrentMaxY = -LARGE;

			for (i = 0; i < written; i++)//first check for new ring in current poly
            {                    
         		if (air[i].Chosen != 0)
					continue;             
				polyid++;
				airname = Get_TypeC_Name(4,air[i].Id,"");
				//sprintf(airrecord," %-8d%-5s%-4s%-66s",polyid,air[i].County,air[i].Id,
				//	airname);
				sprintf(airrecord," %-8d",polyid);
				sprintf(&airrecord[9],"%-5s",air[i].County);
				sprintf(&airrecord[14],"%-4s",air[i].Id);
				sprintf(&airrecord[18],"%-66s",airname);
	
				//sprintf(airrecord," %-8d%-5s%-4s",polyid,air[i].County,air[i].Id);
				fwrite(&airrecord,sizeof(airrecord)-1,1,dbfout);    		
				Npts = 0;
				if (air[i].Flip == 0)
				{
					Pts[Npts].Longitude = air[i].Frlong;
					Pts[Npts].Latitude = air[i].Frlat;
					Npts++;
					Get_Shape_Points(air[i].Tlid,air[i].Flip);
					Pts[Npts].Longitude = air[i].Tolong;
					Pts[Npts].Latitude = air[i].Tolat;
					Npts++;					
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					air[i].Chosen = 1;            
					found = 1;                      
					curX = air[i].Tolong;
					curY = air[i].Tolat;                
					curcase = i;
					break;					
				}
				else
				{
					Pts[Npts].Longitude = air[i].Tolong;
					Pts[Npts].Latitude = air[i].Tolat;
					Npts++;
					Get_Shape_Points(air[i].Tlid,air[i].Flip);
					Pts[Npts].Longitude = air[i].Frlong;
					Pts[Npts].Latitude = air[i].Frlat;
					Npts++;				
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = air[i].Frlong;
					curY = air[i].Frlat;                        
					air[i].Chosen = 1;		
					found = 1;          
					curcase = i;	
					break;					
				}	
			}
		}
		//by now found should be 1
		if (found == 0)
		{
			info.Format("ERROR - found is zero");
			Ptrdlg->ErrorMessage(info);									
			MissingFile = -1;
			return;
		}
		ptcount += Npts;
		fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
		if (Pts[0].Longitude < CurrentMinX)
			CurrentMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < CurrentMinY)
			CurrentMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[0].Latitude;	
		if (Pts[0].Longitude < FileMinX)
			FileMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > FileMaxX)
			FileMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < FileMinY)
			FileMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > FileMaxY)
			FileMaxY = Pts[0].Latitude;

		if (Pts[Npts-1].Longitude < CurrentMinX)
			CurrentMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < CurrentMinY)
			CurrentMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[Npts-1].Latitude;	
		if (Pts[Npts-1].Longitude < FileMinX)
			FileMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > FileMaxX)
			FileMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < FileMinY)
			FileMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > FileMaxY)
			FileMaxY = Pts[Npts-1].Latitude;		
	}//close while loop
	fwrite(&ptcount,sizeof(int),1,headtemp);
	fwrite(&nparts,sizeof(int),1,partstemp);
	fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
	fclose(boxtemp);
	fclose(headtemp);
	fclose(ptstemp);
	fclose(partstemp);
	sprintf(msg,"processed %d of %d records",n,written);
	Ptrdlg->SetDlgItemText(IDC_AIR,msg);		
	//printf("\n Have written %ld of %ld fpl boundary lines",n, written);
	write_eof(dbfout);
	rewind(dbfout);
	Build_db_Header(dbfout,polyid,dbAir);
	Build_Poly_Shape("air");
	Ptrdlg->m_strAir90.Format("%d Indian/Alaskan Native Areas",polyid);
	Ptrdlg->SetDlgItemText(IDC_AIR,Ptrdlg->m_strAir90);	
    fclose(dbfout);
	free(air);
	fprintf(LOG,"Wrote %d Indian/Alaskan Native Areas 1990 polygons to shape %s%sair\n", polyid,
		Outfilepath, Outfiletitle);		
}
void Match_Poly_Lines_Aircu()
{
	int polyid, found, i, nparts, ptcount;
	long num, n, written, curcase;
	Air_Border_Type *air;
	double  curX, curY;	
    FILE  *dbfout, *ptstemp, *headtemp, *partstemp, *boxtemp; 
	CString info, fname;	
	char airrecord[85]; //size of fpl dbrecord + 2
	int steppos;
	char msg[100];
	char *airname;
	CString errmsg;	
	int doleft, doright;
	if (SPolycounts[9] == 0)
	{
		Ptrdlg->SetDlgItemText(IDC_AIRCU,"No Such Cases");		
		return;
	}
	fname.Format("%s%saircu.dbf",Outfilepath,Outfiletitle);			
	dbfout = fopen(fname,"wb");
	if (dbfout == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	ptstemp = fopen("pts.tmp","wb");
	if (ptstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	headtemp = fopen("head.tmp","wb");
	if (headtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	boxtemp = fopen("box.tmp","wb");
	if (boxtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	partstemp = fopen("parts.tmp","wb");
	if (partstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	
	air = (Air_Border_Type *)calloc(SPolycounts[9]+Watercut*SPolycounts[0],sizeof(Air_Border_Type));
	written = 0;
	for (num = 0; num < CountI; num++)
	{
		if (strcmp(TypeIs[num].Aircul, TypeIs[num].Aircur) == 0)
		{
			if (Watercut)
			{

				if (TypeIs[num].Waterl == TypeIs[num].Waterr)
					continue;
			}
			else
				continue;		
		}
		doleft = 0;
			
		if (strcmp(TypeIs[num].Aircul,"    ") != 0)
		{//left case
			if (Watercut)
			{
				if (!TypeIs[num].Waterl)
					doleft = 1;
			}
			else
				doleft = 1;
			if (doleft)
			{
				sprintf(air[written].County,"%2s%3s",TypeIs[num].State,TypeIs[num].County);
				sprintf(air[written].Id,"%s",TypeIs[num].Aircul);
				sprintf(air[written].Tlid,"%s",Type1s[num].Tlid);
				air[written].Frlong = Type1s[num].Frlong;
				air[written].Frlat = Type1s[num].Frlat;
				air[written].Tolong = Type1s[num].Tolong;
				air[written].Tolat = Type1s[num].Tolat;
				air[written].Chosen = 0;
				air[written].Flip = 1;
				written++;
			}
		}
		doright = 0;
		if (strcmp(TypeIs[num].Aircur,"    ") != 0)
		{//rightcase 
		//printf("\nright case");
			if (Watercut)
			{
				if (!TypeIs[num].Waterr)
					doright = 1;
			}
			else
				doright = 1;
			if (doright)
			{
				sprintf(air[written].County,"%2s%3s",TypeIs[num].State,TypeIs[num].County);
				sprintf(air[written].Id,"%s",TypeIs[num].Aircur);
				sprintf(air[written].Tlid,"%s",Type1s[num].Tlid);
				air[written].Frlong = Type1s[num].Frlong;
				air[written].Frlat = Type1s[num].Frlat;
				air[written].Tolong = Type1s[num].Tolong;
				air[written].Tolat = Type1s[num].Tolat;
				air[written].Chosen = 0;
				air[written].Flip = 0;
				written++;
			}
		}
	}
	if (written > SPolycounts[9]+Watercut * SPolycounts[0])
	{
		Ptrdlg->ErrorMessage("the number of AIR Current border lines exceeds the count");				
		MissingFile = -1;
		return;
	}
	Ptrdlg->m_strProcess.Format("Gathering AIR Boundary Lines");
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	//time to chain	
	qsort((void *)air,written,sizeof(Air_Border_Type),(compfn)CompareAir);
	FileMinX = FileMinY = LARGE;
	FileMaxX = FileMaxY = -LARGE;
	CurrentMinX = CurrentMinY = LARGE;
	CurrentMaxX = CurrentMaxY = -LARGE;
	curcase = 0;
	polyid = 1;
	Npts = 0; 
	nparts = 1;
	ptcount = 0;
	Build_db_Header(dbfout,0,dbAircu);
	Build_db_FieldHeaders(dbfout,dbAircu);
	airname = Get_TypeC_Name(4,air[curcase].Id,"");
    //sprintf(airrecord," %-8d%-5s%-4s%-66s",polyid,air[curcase].County,air[curcase].Id,
	//	airname);
	sprintf(airrecord," %-8d",polyid);
	sprintf(&airrecord[9],"%-5s",air[curcase].County);
	sprintf(&airrecord[14],"%-4s",air[curcase].Id);
	sprintf(&airrecord[18],"%-66s",airname);
	fwrite(&airrecord,sizeof(airrecord)-1,1,dbfout);
	if (air[0].Flip == 0)
	{
		curX = air[0].Tolong;
		curY = air[0].Tolat;		
		Pts[Npts].Longitude = air[curcase].Frlong;
		Pts[Npts].Latitude = air[curcase].Frlat;
		Npts++;
		Get_Shape_Points(air[curcase].Tlid, air[curcase].Flip);
		Pts[Npts].Longitude = air[curcase].Tolong;
		Pts[Npts].Latitude = air[curcase].Tolat;
		Npts++;
		air[curcase].Chosen = 1;		
	}
	else
	{
		curX = air[0].Frlong;
		curY = air[0].Frlat;		
		Pts[Npts].Longitude = air[curcase].Tolong;
		Pts[Npts].Latitude = air[curcase].Tolat;
		Npts++;
		Get_Shape_Points(air[curcase].Tlid, air[curcase].Flip);
		Pts[Npts].Longitude = air[curcase].Frlong;
		Pts[Npts].Latitude = air[curcase].Frlat;
		Npts++;
		air[curcase].Chosen = 1;		
	}
	ptcount += Npts;
	
    fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
	
	if (Pts[0].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < CurrentMinY)
		CurrentMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[0].Latitude;	
	if (Pts[0].Longitude < FileMinX)
		FileMinX = Pts[0].Longitude;
	if (Pts[0].Longitude > FileMaxX)
		FileMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < FileMinY)
		FileMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > FileMaxY)
		FileMaxY = Pts[0].Latitude;

	if (Pts[Npts-1].Longitude < CurrentMinX)
		CurrentMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < CurrentMinY)
		CurrentMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[Npts-1].Latitude;	
	if (Pts[Npts-1].Longitude < FileMinX)
		FileMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > FileMaxX)
		FileMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < FileMinY)
		FileMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > FileMaxY)
		FileMaxY = Pts[Npts-1].Latitude;		
	n = 1;
	steppos = (int)(n*100/written);	
	Ptrdlg->m_Progress.SetPos(steppos);
    while (n < written)
	{
		//printf("\n Have written %ld of %ld fpl boundary lines",n, written);
		sprintf(msg,"processed %d of %d records",n,written);
		Ptrdlg->SetDlgItemText(IDC_AIRCU,msg);		
		found = 0;
		for (i = 1; i < written; i++)
         {
			Npts = 0;
			if (air[i].Chosen != 0)
				continue;
			if (air[i].Flip == 0)
			{
				if ((air[i].Frlong == curX) && (air[i].Frlat == curY))
				{                          
					if (strcmp(air[i].Id,air[curcase].Id) != 0)
						continue;	            
					Get_Shape_Points(air[i].Tlid,air[i].Flip);
					Pts[Npts].Longitude = air[i].Tolong;
					Pts[Npts].Latitude = air[i].Tolat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					air[i].Chosen = 1;            
					found = 1;                      
					curX = air[i].Tolong;
					curY = air[i].Tolat;                
					curcase = i;
					break;
				}
			}
			else
			{
				if ((air[i].Tolong == curX) && (air[i].Tolat == curY))
				{
					if (strcmp(air[i].Id,air[curcase].Id) != 0)
						continue;	            
					Get_Shape_Points(air[i].Tlid,air[i].Flip);
					Pts[Npts].Longitude = air[i].Frlong;
					Pts[Npts].Latitude = air[i].Frlat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = air[i].Frlong;
					curY = air[i].Frlat;                        
					air[i].Chosen = 1;	
					found = 1;          
					curcase = i;
					break;
				}
			}
        }//close for loop
		if (found == 0) //initialize new case, eg, new ring or new poly
		{			
			fwrite(&ptcount,sizeof(int),1,headtemp);
			ptcount = 0;
			for (i = 0; i < written; i++) //check for new ring in poly
            {                    
         		if (air[i].Chosen != 0)
					continue;             		
				if (strcmp(air[i].Id, air[curcase].Id) != 0)
					continue;
				//if we get here it is a new ring in current poly
				found = 1;
				nparts++;
				Npts = 0;
				if (air[i].Flip == 0)
				{
					Pts[Npts].Longitude = air[i].Frlong;
					Pts[Npts].Latitude = air[i].Frlat;
					Npts++;
					Get_Shape_Points(air[i].Tlid,air[i].Flip);
					Pts[Npts].Longitude = air[i].Tolong;
					Pts[Npts].Latitude = air[i].Tolat;
					Npts++;			
    				n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					air[i].Chosen = 1;
    		   		curX = air[i].Tolong;
    				curY = air[i].Tolat;
					curcase = i;
					break;
				}
				else
				{
					Pts[Npts].Longitude = air[i].Tolong;
					Pts[Npts].Latitude = air[i].Tolat;
					Npts++;
					Get_Shape_Points(air[i].Tlid,air[i].Flip);
					Pts[Npts].Longitude = air[i].Frlong;
					Pts[Npts].Latitude = air[i].Frlat;
					Npts++;			
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					air[i].Chosen = 1;
    		   		curX = air[i].Frlong;
    				curY = air[i].Frlat;
					curcase = i;
					break;
				}
    		}
    	}
		if (found == 0) // new poly, first ring
		{
			
			fwrite(&nparts,sizeof(int),1,partstemp);
			nparts = 1;
			fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
			CurrentMinX = CurrentMinY = LARGE;
			CurrentMaxX = CurrentMaxY = -LARGE;

			for (i = 0; i < written; i++)//first check for new ring in current poly
            {                    
         		if (air[i].Chosen != 0)
					continue;             
				polyid++;
				airname = Get_TypeC_Name(4,air[i].Id,"");
				//sprintf(airrecord," %-8d%-5s%-4s%-66s",polyid,air[i].County,air[i].Id,
				//	airname);
				sprintf(airrecord," %-8d",polyid);
				sprintf(&airrecord[9],"%-5s",air[i].County);
				sprintf(&airrecord[14],"%-4s",air[i].Id);
				sprintf(&airrecord[18],"%-66s",airname);
	
				//sprintf(airrecord," %-8d%-5s%-4s",polyid,air[i].County,air[i].Id);
				fwrite(&airrecord,sizeof(airrecord)-1,1,dbfout);    		
				Npts = 0;
				if (air[i].Flip == 0)
				{
					Pts[Npts].Longitude = air[i].Frlong;
					Pts[Npts].Latitude = air[i].Frlat;
					Npts++;
					Get_Shape_Points(air[i].Tlid,air[i].Flip);
					Pts[Npts].Longitude = air[i].Tolong;
					Pts[Npts].Latitude = air[i].Tolat;
					Npts++;					
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					air[i].Chosen = 1;            
					found = 1;                      
					curX = air[i].Tolong;
					curY = air[i].Tolat;                
					curcase = i;
					break;					
				}
				else
				{
					Pts[Npts].Longitude = air[i].Tolong;
					Pts[Npts].Latitude = air[i].Tolat;
					Npts++;
					Get_Shape_Points(air[i].Tlid,air[i].Flip);
					Pts[Npts].Longitude = air[i].Frlong;
					Pts[Npts].Latitude = air[i].Frlat;
					Npts++;				
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = air[i].Frlong;
					curY = air[i].Frlat;                        
					air[i].Chosen = 1;		
					found = 1;          
					curcase = i;	
					break;					
				}	
			}
		}
		//by now found should be 1
		if (found == 0)
		{
			info.Format("ERROR - found is zero");
			Ptrdlg->ErrorMessage(info);									
			MissingFile = -1;
			return;
		}
		ptcount += Npts;
		fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
		if (Pts[0].Longitude < CurrentMinX)
			CurrentMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < CurrentMinY)
			CurrentMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[0].Latitude;	
		if (Pts[0].Longitude < FileMinX)
			FileMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > FileMaxX)
			FileMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < FileMinY)
			FileMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > FileMaxY)
			FileMaxY = Pts[0].Latitude;

		if (Pts[Npts-1].Longitude < CurrentMinX)
			CurrentMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < CurrentMinY)
			CurrentMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[Npts-1].Latitude;	
		if (Pts[Npts-1].Longitude < FileMinX)
			FileMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > FileMaxX)
			FileMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < FileMinY)
			FileMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > FileMaxY)
			FileMaxY = Pts[Npts-1].Latitude;		
	}//close while loop
	fwrite(&ptcount,sizeof(int),1,headtemp);
	fwrite(&nparts,sizeof(int),1,partstemp);
	fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
	fclose(boxtemp);
	fclose(headtemp);
	fclose(ptstemp);
	fclose(partstemp);
	sprintf(msg,"processed %d of %d records",n,written);
	Ptrdlg->SetDlgItemText(IDC_AIRCU,msg);		
	//printf("\n Have written %ld of %ld fpl boundary lines",n, written);
	write_eof(dbfout);
	rewind(dbfout);
	Build_db_Header(dbfout,polyid,dbAircu);
	Build_Poly_Shape("aircu");
	Ptrdlg->m_strAircu.Format("%d Indian/Alaskan Native Areas",polyid);
	Ptrdlg->SetDlgItemText(IDC_AIRCU,Ptrdlg->m_strAircu);	
    fclose(dbfout);
	free(air);
	fprintf(LOG,"Wrote %d Indian/Alaskan Native Areas Current polygons to shape %s%saircu\n",
		polyid,Outfilepath,Outfiletitle);		
}
void Match_Poly_Lines_Collection2000()
{
	int polyid, found, i, nparts, ptcount;
	long num, n, written, curcase;
	CollectionBlock_Border_Type *col;
	double  curX, curY;	
    FILE  *dbfout, *ptstemp, *headtemp, *partstemp, *boxtemp; 
	CString info, fname;	
	char colrecord[43];
	int steppos;
	char msg[100];
	//no watercut for this case
	//char *airname;
	char *teatype[] = {{"Mailout/Mailback"},{"Update/Leave"},{"List/Enumerate"},{"Remote Alaska"},{"Update/Enumerate",},{"Military"}};
	
	CString errmsg;	
	if (SPolycounts[10] == 0)
	{
		Ptrdlg->SetDlgItemText(IDC_COLBLKS00,"No Such Cases");		
		return;
	}
	fname.Format("%s%scolblk.dbf",Outfilepath,Outfiletitle);			
	dbfout = fopen(fname,"wb");
	if (dbfout == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	ptstemp = fopen("pts.tmp","wb");
	if (ptstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	headtemp = fopen("head.tmp","wb");
	if (headtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	boxtemp = fopen("box.tmp","wb");
	if (boxtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	partstemp = fopen("parts.tmp","wb");
	if (partstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	
	col = (CollectionBlock_Border_Type *)calloc(SPolycounts[10],sizeof(CollectionBlock_Border_Type));
	written = 0;
	for (num = 0; num < CountI; num++)
	{
		if (strcmp(TypeIs[num].Colblkl, TypeIs[num].Colblkr) == 0)
			continue;
		if (strcmp(TypeIs[num].Colblkl,"                 ") != 0)		                              
		{//left case			
			sprintf(col[written].Id,"%s",TypeIs[num].Colblkl);
			sprintf(col[written].Tlid,"%s",Type1s[num].Tlid);
			col[written].Frlong = Type1s[num].Frlong;
			col[written].Frlat = Type1s[num].Frlat;
			col[written].Tolong = Type1s[num].Tolong;
			col[written].Tolat = Type1s[num].Tolat;
			col[written].Chosen = 0;
			col[written].Flip = 1;
			written++;
		}
		if (strcmp(TypeIs[num].Colblkr,"                 ") != 0)
		{//rightcase 
		//printf("\nright case");			
			sprintf(col[written].Id,"%s",TypeIs[num].Colblkr);
			sprintf(col[written].Tlid,"%s",Type1s[num].Tlid);
			col[written].Frlong = Type1s[num].Frlong;
			col[written].Frlat = Type1s[num].Frlat;
			col[written].Tolong = Type1s[num].Tolong;
			col[written].Tolat = Type1s[num].Tolat;
			col[written].Chosen = 0;
			col[written].Flip = 0;
			written++;
		}
	}
	if (written > SPolycounts[10])
	{
		Ptrdlg->ErrorMessage("the number of Collection Block border lines exceeds the count");				
		MissingFile = -1;
		return;
	}
	Ptrdlg->m_strProcess.Format("Gathering Collection Blocks");
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	//time to chain	
	qsort((void *)col,written,sizeof(CollectionBlock_Border_Type),(compfn)CompareCollectionBlock);
	FileMinX = FileMinY = LARGE;
	FileMaxX = FileMaxY = -LARGE;
	CurrentMinX = CurrentMinY = LARGE;
	CurrentMaxX = CurrentMaxY = -LARGE;
	curcase = 0;
	polyid = 1;
	Npts = 0; 
	nparts = 1;
	ptcount = 0;
	Build_db_Header(dbfout,0,dbCollectionBlocks);
	Build_db_FieldHeaders(dbfout,dbCollectionBlocks);
	
    //sprintf(airrecord," %-8d%-5s%-4s%-66s",polyid,air[curcase].County,air[curcase].Id,
	//	airname);
	sprintf(colrecord," %-8d",polyid);
	sprintf(&colrecord[9],"%-s",col[curcase].Id);
	char * teaname;
	int ival;
	//Nscanf(&Record[1],4,"%d",&Type1s[k].Version);
	Nscanf(&colrecord[20],1,"%d",&ival);
	teaname = (char *)calloc(17,sizeof(char));
	switch (ival)
	{
	case 1:
		sprintf(&colrecord[26],"%-s",teatype[0]);
		break;
	case 2:
		sprintf(&colrecord[26],"%-s",teatype[1]);
		break;
	case 3:
		sprintf(&colrecord[26],"%-s",teatype[2]);
		break;
	case 4:
		sprintf(&colrecord[26],"%-s",teatype[3]);
		break;
	case 5:
		sprintf(&colrecord[26],"%-s",teatype[4]);
		break;
	case 6:
		sprintf(&colrecord[26],"%-s",teatype[5]);
		break;
	default:
		sprintf(&colrecord[26],"unknown");
		break;
	}
	free(teaname);
	//sprintf(&airrecord[14],"%-4s",air[curcase].Id);
	//sprintf(&airrecord[18],"%-58s",airname);
	fwrite(&colrecord,sizeof(colrecord)-1,1,dbfout);
	if (col[0].Flip == 0)
	{
		curX = col[0].Tolong;
		curY = col[0].Tolat;		
		Pts[Npts].Longitude = col[curcase].Frlong;
		Pts[Npts].Latitude = col[curcase].Frlat;
		Npts++;
		Get_Shape_Points(col[curcase].Tlid, col[curcase].Flip);
		Pts[Npts].Longitude = col[curcase].Tolong;
		Pts[Npts].Latitude = col[curcase].Tolat;
		Npts++;
		col[curcase].Chosen = 1;		
	}
	else
	{
		curX = col[0].Frlong;
		curY = col[0].Frlat;		
		Pts[Npts].Longitude = col[curcase].Tolong;
		Pts[Npts].Latitude = col[curcase].Tolat;
		Npts++;
		Get_Shape_Points(col[curcase].Tlid, col[curcase].Flip);
		Pts[Npts].Longitude = col[curcase].Frlong;
		Pts[Npts].Latitude = col[curcase].Frlat;
		Npts++;
		col[curcase].Chosen = 1;		
	}
	ptcount += Npts;
	
    fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
	
	if (Pts[0].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < CurrentMinY)
		CurrentMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[0].Latitude;	
	if (Pts[0].Longitude < FileMinX)
		FileMinX = Pts[0].Longitude;
	if (Pts[0].Longitude > FileMaxX)
		FileMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < FileMinY)
		FileMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > FileMaxY)
		FileMaxY = Pts[0].Latitude;

	if (Pts[Npts-1].Longitude < CurrentMinX)
		CurrentMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < CurrentMinY)
		CurrentMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[Npts-1].Latitude;	
	if (Pts[Npts-1].Longitude < FileMinX)
		FileMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > FileMaxX)
		FileMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < FileMinY)
		FileMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > FileMaxY)
		FileMaxY = Pts[Npts-1].Latitude;		
	n = 1;
	steppos = (int)(n*100/written);	
	Ptrdlg->m_Progress.SetPos(steppos);
    while (n < written)
	{
		//printf("\n Have written %ld of %ld fpl boundary lines",n, written);
		sprintf(msg,"processed %d of %d records",n,written);
		Ptrdlg->SetDlgItemText(IDC_COLBLKS00,msg);		
		found = 0;
		for (i = 1; i < written; i++)
         {
			Npts = 0;
			if (col[i].Chosen != 0)
				continue;
			if (col[i].Flip == 0)
			{
				if ((col[i].Frlong == curX) && (col[i].Frlat == curY))
				{                          
					if (strcmp(col[i].Id,col[curcase].Id) != 0)
						continue;	            
					Get_Shape_Points(col[i].Tlid,col[i].Flip);
					Pts[Npts].Longitude = col[i].Tolong;
					Pts[Npts].Latitude = col[i].Tolat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					col[i].Chosen = 1;            
					found = 1;                      
					curX = col[i].Tolong;
					curY = col[i].Tolat;                
					curcase = i;
					break;
				}
			}
			else
			{
				if ((col[i].Tolong == curX) && (col[i].Tolat == curY))
				{
					if (strcmp(col[i].Id,col[curcase].Id) != 0)
						continue;	            
					Get_Shape_Points(col[i].Tlid,col[i].Flip);
					Pts[Npts].Longitude = col[i].Frlong;
					Pts[Npts].Latitude = col[i].Frlat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = col[i].Frlong;
					curY = col[i].Frlat;                        
					col[i].Chosen = 1;	
					found = 1;          
					curcase = i;
					break;
				}
			}
        }//close for loop
		if (found == 0) //initialize new case, eg, new ring or new poly
		{			
			fwrite(&ptcount,sizeof(int),1,headtemp);
			ptcount = 0;
			for (i = 0; i < written; i++) //check for new ring in poly
            {                    
         		if (col[i].Chosen != 0)
					continue;             		
				if (strcmp(col[i].Id, col[curcase].Id) != 0)
					continue;
				//if we get here it is a new ring in current poly
				found = 1;
				nparts++;
				Npts = 0;
				if (col[i].Flip == 0)
				{
					Pts[Npts].Longitude = col[i].Frlong;
					Pts[Npts].Latitude = col[i].Frlat;
					Npts++;
					Get_Shape_Points(col[i].Tlid,col[i].Flip);
					Pts[Npts].Longitude = col[i].Tolong;
					Pts[Npts].Latitude = col[i].Tolat;
					Npts++;			
    				n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					col[i].Chosen = 1;
    		   		curX = col[i].Tolong;
    				curY = col[i].Tolat;
					curcase = i;
					break;
				}
				else
				{
					Pts[Npts].Longitude = col[i].Tolong;
					Pts[Npts].Latitude = col[i].Tolat;
					Npts++;
					Get_Shape_Points(col[i].Tlid,col[i].Flip);
					Pts[Npts].Longitude = col[i].Frlong;
					Pts[Npts].Latitude = col[i].Frlat;
					Npts++;			
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					col[i].Chosen = 1;
    		   		curX = col[i].Frlong;
    				curY = col[i].Frlat;
					curcase = i;
					break;
				}
    		}
    	}
		if (found == 0) // new poly, first ring
		{
			
			fwrite(&nparts,sizeof(int),1,partstemp);
			nparts = 1;
			fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
			CurrentMinX = CurrentMinY = LARGE;
			CurrentMaxX = CurrentMaxY = -LARGE;

			for (i = 0; i < written; i++)//first check for new ring in current poly
            {                    
         		if (col[i].Chosen != 0)
					continue;             
				polyid++;
				//airname = Get_TypeC_Name(4,air[i].Id);
				//sprintf(airrecord," %-8d%-5s%-4s%-66s",polyid,air[i].County,air[i].Id,
				//	airname);
				sprintf(colrecord," %-8d",polyid);
				sprintf(&colrecord[9],"%-s",col[i].Id);
				//rintf(&airrecord[14],"%-4s",air[i].Id);
				//sprintf(&airrecord[18],"%-58s",airname);
				
				teaname = (char *)calloc(17,sizeof(char));
				
				Nscanf(&colrecord[20],1,"%d",&ival);
				switch (ival)
				{
				case 1:
					sprintf(&colrecord[26],"%-s",teatype[0]);
					break;
				case 2:
					sprintf(&colrecord[26],"%-s",teatype[1]);
					break;
				case 3:
					sprintf(&colrecord[26],"%-s",teatype[2]);
					break;
				case 4:
					sprintf(&colrecord[26],"%-s",teatype[3]);
					break;
				case 5:
					sprintf(&colrecord[26],"%-s",teatype[4]);
					break;
				case 6:
					sprintf(&colrecord[26],"%-s",teatype[5]);
					break;
				default:
					sprintf(&colrecord[26],"unknown");
					break;
				}
				free(teaname);
				
	
				//sprintf(airrecord," %-8d%-5s%-4s",polyid,air[i].County,air[i].Id);
				fwrite(&colrecord,sizeof(colrecord)-1,1,dbfout);    		
				Npts = 0;
				if (col[i].Flip == 0)
				{
					Pts[Npts].Longitude = col[i].Frlong;
					Pts[Npts].Latitude = col[i].Frlat;
					Npts++;
					Get_Shape_Points(col[i].Tlid,col[i].Flip);
					Pts[Npts].Longitude = col[i].Tolong;
					Pts[Npts].Latitude = col[i].Tolat;
					Npts++;					
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					col[i].Chosen = 1;            
					found = 1;                      
					curX = col[i].Tolong;
					curY = col[i].Tolat;                
					curcase = i;
					break;					
				}
				else
				{
					Pts[Npts].Longitude = col[i].Tolong;
					Pts[Npts].Latitude = col[i].Tolat;
					Npts++;
					Get_Shape_Points(col[i].Tlid,col[i].Flip);
					Pts[Npts].Longitude = col[i].Frlong;
					Pts[Npts].Latitude = col[i].Frlat;
					Npts++;				
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = col[i].Frlong;
					curY = col[i].Frlat;                        
					col[i].Chosen = 1;		
					found = 1;          
					curcase = i;	
					break;					
				}	
			}
		}
		//by now found should be 1
		if (found == 0)
		{
			info.Format("ERROR - found is zero");
			Ptrdlg->ErrorMessage(info);									
			MissingFile = -1;
			return;
		}
		ptcount += Npts;
		fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
		if (Pts[0].Longitude < CurrentMinX)
			CurrentMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < CurrentMinY)
			CurrentMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[0].Latitude;	
		if (Pts[0].Longitude < FileMinX)
			FileMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > FileMaxX)
			FileMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < FileMinY)
			FileMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > FileMaxY)
			FileMaxY = Pts[0].Latitude;

		if (Pts[Npts-1].Longitude < CurrentMinX)
			CurrentMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < CurrentMinY)
			CurrentMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[Npts-1].Latitude;	
		if (Pts[Npts-1].Longitude < FileMinX)
			FileMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > FileMaxX)
			FileMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < FileMinY)
			FileMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > FileMaxY)
			FileMaxY = Pts[Npts-1].Latitude;		
	}//close while loop
	fwrite(&ptcount,sizeof(int),1,headtemp);
	fwrite(&nparts,sizeof(int),1,partstemp);
	fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
	fclose(boxtemp);
	fclose(headtemp);
	fclose(ptstemp);
	fclose(partstemp);
	sprintf(msg,"processed %d of %d records",n,written);
	Ptrdlg->SetDlgItemText(IDC_COLBLKS00,msg);		
	//printf("\n Have written %ld of %ld fpl boundary lines",n, written);
	write_eof(dbfout);
	rewind(dbfout);
	Build_db_Header(dbfout,polyid,dbCollectionBlocks);
	Build_Poly_Shape("colblk");
	Ptrdlg->m_strColblks00.Format("%d Collection Blocks",polyid);
	Ptrdlg->SetDlgItemText(IDC_COLBLKS00,Ptrdlg->m_strColblks00);	
    fclose(dbfout);
	free(col);
	fprintf(LOG,"Wrote %d Census 2000 Collection Blocks to shape %s%scolblk\n", polyid,
		Outfilepath, Outfiletitle);		
}
void Match_Poly_Lines_All97()
{
	int polyid, found, i, nparts, ptcount;
	long num, n, written, curcase;
	Poly_Border_Type97 *poly;
	double  curX, curY;	
    FILE  *dbfout, *ptstemp, *headtemp, *partstemp, *boxtemp; 
	CString info, fname, errmsg;	
	char polyrecord[150]; //size of fpl dbrecord + 2
	int steppos;
	char msg[100];
	long maxpolys;
//	int tazid;

	
	if ((AllACount == 0) && (AllSCount == 0))
	{
		errmsg.Format("No polygons to process",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;		
	}	
	Ptrdlg->m_strProcess.Format("Gathering Boundary Lines");
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	Ptrdlg->m_Progress.SetPos(0);

	fname.Format("%s%sall.dbf",Outfilepath,Outfiletitle);			
	dbfout = fopen(fname,"wb");
	if (dbfout == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	ptstemp = fopen("pts.tmp","wb");
	if (ptstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	headtemp = fopen("head.tmp","wb");
	if (headtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	boxtemp = fopen("box.tmp","wb");
	if (boxtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	partstemp = fopen("parts.tmp","wb");
	if (partstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	if (AllACount > AllSCount){
		poly = (Poly_Border_Type97 *)calloc(AllACount,sizeof(Poly_Border_Type97));	
		maxpolys = AllACount;
	}
	else{
		poly = (Poly_Border_Type97 *)calloc(AllSCount,sizeof(Poly_Border_Type97));	
		maxpolys = AllSCount;
	}
	written = 0;
	for (num = 0; num < CountI; num++)
	{
		steppos = (int)(num*100/CountI);	
		Ptrdlg->m_Progress.SetPos(steppos);	

//		fprintf(LOG,"left %s right %s\n",TypeIs[num].Polyidl, TypeIs[num].Polyidr);
		if (strcmp(TypeIs[num].Polyidl,TypeIs[num].Polyidr)== 0)
			continue;		
		
		if (strcmp(TypeIs[num].Polyidl,"          ") != 0)
			{//left case	
				sprintf(poly[written].Polyid,"%s",TypeIs[num].Polyidl);
				sprintf(poly[written].Cenid,"%s",TypeIs[num].Cenidl);
				sprintf(poly[written].State,"%s",TypeIs[num].State);
				sprintf(poly[written].County,"%s",TypeIs[num].County);
				poly[written].Waterflag = TypeIs[num].Waterl;
				sprintf(poly[written].Cmsamsa,"%s",TypeIs[num].Msal);
				sprintf(poly[written].Pmsa,"%s",TypeIs[num].Pmsl);
				sprintf(poly[written].Fair,"%s",TypeIs[num].Faircul);
				sprintf(poly[written].Air,"%s",TypeIs[num].Aircul);
				poly[written].Trust = TypeIs[num].Trustl;
				sprintf(poly[written].Anrc,"%s",TypeIs[num].Anrcl);
				sprintf(poly[written].Fccity,"%s",TypeIs[num].Fccityl);
				sprintf(poly[written].Fmcd,"%s",TypeIs[num].Fmcdcul);
				sprintf(poly[written].Fsmcd,"%s",TypeIs[num].Fsmcdcul);
				sprintf(poly[written].Fpl,"%s",TypeIs[num].Fplcul);				
				sprintf(poly[written].Cdcu,"%s",TypeIs[num].Cdcul);
				sprintf(poly[written].Stsenate,"%s",TypeIs[num].Senatel);
				sprintf(poly[written].Sthouse,"%s",TypeIs[num].Housel);				
				sprintf(poly[written].Fair90,"%s",TypeIs[num].Fair90l);
				sprintf(poly[written].Fmcd90,"%s",TypeIs[num].Fmcd90l);
				sprintf(poly[written].Fpl90,"%s",TypeIs[num].Fpl90l);
				sprintf(poly[written].Ctbna90,"%s",TypeIs[num].Ctbna90l);
				sprintf(poly[written].Blk90,"%s",TypeIs[num].Blk90l);
				sprintf(poly[written].Cd106,"%s",TypeIs[num].Cd106l);
				sprintf(poly[written].Cd108,"%s",TypeIs[num].Cd108l);
				sprintf(poly[written].Sdelm,"%s",TypeIs[num].Elml);				
				sprintf(poly[written].Sdsec,"%s",TypeIs[num].Secl);
				sprintf(poly[written].Sduni,"%s",TypeIs[num].Unil);
				sprintf(poly[written].Taz,"%s",TypeIs[num].Tazl);
				sprintf(poly[written].Ua90,"%s",TypeIs[num].Urb90l);
				poly[written].Urbflag = TypeIs[num].Urbflagl;
				sprintf(poly[written].Ctpp,"%s",&TypeIs[num].Tazl[6]);
				sprintf(poly[written].State90,"%2s",TypeIs[num].County90l);
				sprintf(poly[written].Coun90,"%3s",&TypeIs[num].County90l[2]);
				sprintf(poly[written].Air90,"%s",TypeIs[num].Air90l);
				sprintf(poly[written].Vote90,"%s",Type3s[num].Vtd90l);	
				sprintf(poly[written].Tlid,"%s",TypeIs[num].Tlid);
				poly[written].Frlong = Type1s[num].Frlong;
				poly[written].Frlat = Type1s[num].Frlat;
				poly[written].Tolong = Type1s[num].Tolong;
				poly[written].Tolat = Type1s[num].Tolat;
				poly[written].Chosen = 0;
				poly[written].Flip = 1;
				written++;
			}
		if (strcmp(TypeIs[num].Polyidr, "          ") != 0)
			{//rightcase 
				sprintf(poly[written].Polyid,"%s",TypeIs[num].Polyidr);
				sprintf(poly[written].Cenid,"%s",TypeIs[num].Cenidr);
				sprintf(poly[written].State,"%s",TypeIs[num].State);
				sprintf(poly[written].County,"%s",TypeIs[num].County);
				poly[written].Waterflag = TypeIs[num].Waterr;
				sprintf(poly[written].Cmsamsa,"%s",TypeIs[num].Msar);
				sprintf(poly[written].Pmsa,"%s",TypeIs[num].Pmsl);
				sprintf(poly[written].Fair,"%s",TypeIs[num].Faircur);
				sprintf(poly[written].Air,"%s",TypeIs[num].Aircur);
				poly[written].Trust = TypeIs[num].Trustr;
				sprintf(poly[written].Anrc,"%s",TypeIs[num].Anrcr);
				sprintf(poly[written].Fccity,"%s",TypeIs[num].Fccityr);
				sprintf(poly[written].Fmcd,"%s",TypeIs[num].Fmcdcur);
				sprintf(poly[written].Fsmcd,"%s",TypeIs[num].Fsmcdcur);
				sprintf(poly[written].Fpl,"%s",TypeIs[num].Fplcur);
				sprintf(poly[written].Cdcu,"%s",TypeIs[num].Cdcur);
				sprintf(poly[written].Stsenate,"%s",TypeIs[num].Senater);
				sprintf(poly[written].Sthouse,"%s",TypeIs[num].Houser);				
				sprintf(poly[written].Fair90,"%s",TypeIs[num].Fair90r);
				sprintf(poly[written].Fmcd90,"%s",TypeIs[num].Fmcd90r);
				sprintf(poly[written].Fpl90,"%s",TypeIs[num].Fpl90r);
				sprintf(poly[written].Ctbna90,"%s",TypeIs[num].Ctbna90r);
				sprintf(poly[written].Blk90,"%s",TypeIs[num].Blk90r);
				sprintf(poly[written].Cd106,"%s",TypeIs[num].Cd106r);
				sprintf(poly[written].Cd108,"%s",TypeIs[num].Cd108r);
				sprintf(poly[written].Sdelm,"%s",TypeIs[num].Elmr);				
				sprintf(poly[written].Sdsec,"%s",TypeIs[num].Secr);
				sprintf(poly[written].Sduni,"%s",TypeIs[num].Unir);
				sprintf(poly[written].Taz,"%s",TypeIs[num].Tazr);
				sprintf(poly[written].Ua90,"%s",TypeIs[num].Urb90r);
				poly[written].Urbflag = TypeIs[num].Urbflagr;
				sprintf(poly[written].Ctpp,"%s",&TypeIs[num].Tazr[6]);
				sprintf(poly[written].State90,"%2s",TypeIs[num].County90r);
				sprintf(poly[written].Coun90,"%3s",&TypeIs[num].County90r[2]);
				sprintf(poly[written].Air90,"%s",TypeIs[num].Air90r);
				sprintf(poly[written].Vote90,"%s",Type3s[num].Vtd90r);
				sprintf(poly[written].Tlid,"%s",TypeIs[num].Tlid);				
				poly[written].Frlong = Type1s[num].Frlong;
				poly[written].Frlat = Type1s[num].Frlat;
				poly[written].Tolong = Type1s[num].Tolong;
				poly[written].Tolat = Type1s[num].Tolat;
				poly[written].Chosen = 0;
				poly[written].Flip = 0;
				written++;
			}
	}	
	if (written > maxpolys)
	{
		Ptrdlg->ErrorMessage("the number of polygon border lines exceeds the count");				
		MissingFile = -1;
		return;
	}
	Ptrdlg->m_strProcess.Format("Sorting Polygon Boundaries");
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	Ptrdlg->m_Progress.SetPos(0);
	qsort((void *)poly,written,sizeof(Poly_Border_Type97),(compfn)ComparePoly97);	
	FileMinX = FileMinY = LARGE;
	FileMaxX = FileMaxY = -LARGE;
	CurrentMinX = CurrentMinY = LARGE;
	CurrentMaxX = CurrentMaxY = -LARGE;
	curcase = 0;
	polyid = 1;
	Npts = 0; 
	nparts = 1;
	ptcount = 0;
	Build_db_Header(dbfout,0,dbPolys97);
	Build_db_FieldHeaders(dbfout,dbPolys97);	
	sprintf(polyrecord," %-10s",poly[curcase].Polyid);
	sprintf(&polyrecord[11],"%-5s",poly[curcase].Cenid);
	sprintf(&polyrecord[16],"%-2s",poly[curcase].State);
	sprintf(&polyrecord[18],"%-3s",poly[curcase].County);
	sprintf(&polyrecord[21],"%1d",poly[curcase].Waterflag);
	sprintf(&polyrecord[22],"%-4s",poly[curcase].Cmsamsa);
	sprintf(&polyrecord[26],"%-4s",poly[curcase].Pmsa);
	sprintf(&polyrecord[30],"%-5s",poly[curcase].Fair);
	sprintf(&polyrecord[35],"%-5s",poly[curcase].Air);
	sprintf(&polyrecord[40],"%c",poly[curcase].Trust);
	sprintf(&polyrecord[41],"%-2s",poly[curcase].Anrc);
	sprintf(&polyrecord[43],"%-5s",poly[curcase].Fccity);
	sprintf(&polyrecord[48],"%-5s",poly[curcase].Fmcd);
	sprintf(&polyrecord[53],"%-5s",poly[curcase].Fsmcd);
	sprintf(&polyrecord[58],"%-5s",poly[curcase].Fpl);
	sprintf(&polyrecord[63],"%-2s",poly[curcase].Cdcu);
	sprintf(&polyrecord[65],"%-6s",poly[curcase].Stsenate);
	sprintf(&polyrecord[71],"%-6s",poly[curcase].Sthouse);	
	sprintf(&polyrecord[77],"%-5s",poly[curcase].Fair90);
	sprintf(&polyrecord[82],"%-5s",poly[curcase].Fmcd90);
	sprintf(&polyrecord[87],"%-5s",poly[curcase].Fpl90);
	sprintf(&polyrecord[92],"%-6s",poly[curcase].Ctbna90);
	sprintf(&polyrecord[98],"%-4s",poly[curcase].Blk90);
	sprintf(&polyrecord[102],"%-2s",poly[curcase].Cd106);
	sprintf(&polyrecord[104],"%-2s",poly[curcase].Cd108);
	sprintf(&polyrecord[106],"%-5s",poly[curcase].Sdelm);//start from here
	sprintf(&polyrecord[111],"%-5s",poly[curcase].Sdsec);
	sprintf(&polyrecord[116],"%-5s",poly[curcase].Sduni);
	sprintf(&polyrecord[121],"%-6s",poly[curcase].Taz);
	sprintf(&polyrecord[127],"%-4s",poly[curcase].Ua90);
	sprintf(&polyrecord[131],"%c",poly[curcase].Urbflag);
	sprintf(&polyrecord[132],"%-4s",poly[curcase].Ctpp);
	sprintf(&polyrecord[136],"%-2s",poly[curcase].State90);
	sprintf(&polyrecord[138],"%-3s",poly[curcase].Coun90);
	sprintf(&polyrecord[141],"%-4s",poly[curcase].Air90);
	sprintf(&polyrecord[145],"%-4s",poly[curcase].Vote90);

	
	fwrite(&polyrecord,sizeof(polyrecord)-1,1,dbfout);
	if (poly[0].Flip == 0)
	{
		curX = poly[0].Tolong;
		curY = poly[0].Tolat;		
		Pts[Npts].Longitude = poly[curcase].Frlong;
		Pts[Npts].Latitude = poly[curcase].Frlat;
		Npts++;
		Get_Shape_Points(poly[curcase].Tlid, poly[curcase].Flip);
		Pts[Npts].Longitude = poly[curcase].Tolong;
		Pts[Npts].Latitude = poly[curcase].Tolat;
		Npts++;
		poly[curcase].Chosen = 1;		
	}
	else
	{
		curX = poly[0].Frlong;
		curY = poly[0].Frlat;		
		Pts[Npts].Longitude = poly[curcase].Tolong;
		Pts[Npts].Latitude = poly[curcase].Tolat;
		Npts++;
		Get_Shape_Points(poly[curcase].Tlid, poly[curcase].Flip);
		Pts[Npts].Longitude = poly[curcase].Frlong;
		Pts[Npts].Latitude = poly[curcase].Frlat;
		Npts++;
		poly[curcase].Chosen = 1;		
	}
	ptcount += Npts;
	
    fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
	
	if (Pts[0].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < CurrentMinY)
		CurrentMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[0].Latitude;	
	if (Pts[0].Longitude < FileMinX)
		FileMinX = Pts[0].Longitude;
	if (Pts[0].Longitude > FileMaxX)
		FileMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < FileMinY)
		FileMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > FileMaxY)
		FileMaxY = Pts[0].Latitude;

	if (Pts[Npts-1].Longitude < CurrentMinX)
		CurrentMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < CurrentMinY)
		CurrentMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[Npts-1].Latitude;	
	if (Pts[Npts-1].Longitude < FileMinX)
		FileMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > FileMaxX)
		FileMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < FileMinY)
		FileMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > FileMaxY)
		FileMaxY = Pts[Npts-1].Latitude;		
	n = 1;
//	steppos = (int)(n*100/written);	
//	Ptrdlg->m_Progress.SetPos(steppos);	
	Ptrdlg->m_strProcess.Format("Building Polygons");
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	steppos = (int)(n*100/written);	
	Ptrdlg->m_Progress.SetPos(steppos);	
    while (n < written)
	{
		sprintf(msg,"processed %d of %d records",n,written);
		Ptrdlg->SetDlgItemText(IDC_ALL,msg);		
		found = 0;
		for (i = 1; i < written; i++)
         {
			Npts = 0;
			if (poly[i].Chosen != 0)
				continue;
			if (poly[i].Flip == 0)
			{
				if ((poly[i].Frlong == curX) && (poly[i].Frlat == curY))
				{                          
					if (strcmp(poly[i].Polyid,poly[curcase].Polyid) != 0)
						continue;	            
					if (strcmp(poly[i].Cenid,poly[curcase].Cenid) != 0)
						continue;
					Get_Shape_Points(poly[i].Tlid,poly[i].Flip);
					Pts[Npts].Longitude = poly[i].Tolong;
					Pts[Npts].Latitude = poly[i].Tolat;
					Npts++;
					n++;
					//steppos = (int)(n*100/written);	
					//Ptrdlg->m_Progress.SetPos(steppos);
					poly[i].Chosen = 1;            
					found = 1;                      
					curX = poly[i].Tolong;
					curY = poly[i].Tolat;                
					curcase = i;
					break;
				}
			}
			else
			{
				if ((poly[i].Tolong == curX) && (poly[i].Tolat == curY))
				{
					if (strcmp(poly[i].Polyid,poly[curcase].Polyid) != 0)
						continue;	            
					if (strcmp(poly[i].Cenid,poly[curcase].Cenid) != 0)
						continue;
					Get_Shape_Points(poly[i].Tlid,poly[i].Flip);
					Pts[Npts].Longitude = poly[i].Frlong;
					Pts[Npts].Latitude = poly[i].Frlat;
					Npts++;
					n++;
					//steppos = (int)(n*100/written);	
					//Ptrdlg->m_Progress.SetPos(steppos);
					curX = poly[i].Frlong;
					curY = poly[i].Frlat;                        
					poly[i].Chosen = 1;	
					found = 1;          
					curcase = i;
					break;
				}
			}
        }//close for loop
		if (found == 0) //initialize new case, eg, new ring or new poly
		{			
			fwrite(&ptcount,sizeof(int),1,headtemp);
			ptcount = 0;
			for (i = 0; i < written; i++) //check for new ring in poly
            {                    
         		if (poly[i].Chosen != 0)
					continue;    
				if (strcmp(poly[i].Polyid,poly[curcase].Polyid) != 0)
					continue;	            
				if (strcmp(poly[i].Cenid,poly[curcase].Cenid) != 0)
					continue;
				//if we get here it is a new ring in current poly
				found = 1;
				nparts++;
				Npts = 0;
				if (poly[i].Flip == 0)
				{
					Pts[Npts].Longitude = poly[i].Frlong;
					Pts[Npts].Latitude = poly[i].Frlat;
					Npts++;
					Get_Shape_Points(poly[i].Tlid,poly[i].Flip);
					Pts[Npts].Longitude = poly[i].Tolong;
					Pts[Npts].Latitude = poly[i].Tolat;
					Npts++;			
    				n++;
					//steppos = (int)(n*100/written);	
					//Ptrdlg->m_Progress.SetPos(steppos);
					poly[i].Chosen = 1;
    		   		curX = poly[i].Tolong;
    				curY = poly[i].Tolat;
					curcase = i;
					break;
				}
				else
				{
					Pts[Npts].Longitude = poly[i].Tolong;
					Pts[Npts].Latitude = poly[i].Tolat;
					Npts++;
					Get_Shape_Points(poly[i].Tlid,poly[i].Flip);
					Pts[Npts].Longitude = poly[i].Frlong;
					Pts[Npts].Latitude = poly[i].Frlat;
					Npts++;			
					n++;
					//steppos = (int)(n*100/written);	
					//Ptrdlg->m_Progress.SetPos(steppos);
					poly[i].Chosen = 1;
    		   		curX = poly[i].Frlong;
    				curY = poly[i].Frlat;
					curcase = i;
					break;
				}
    		}
    	}
		if (found == 0) // new poly, first ring
		{
			
			fwrite(&nparts,sizeof(int),1,partstemp);
			nparts = 1;
			fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
			CurrentMinX = CurrentMinY = LARGE;
			CurrentMaxX = CurrentMaxY = -LARGE;
			for (i = 0; i < written; i++)//first check for new ring in current poly
            {                    
         		if (poly[i].Chosen != 0)
					continue;             
				polyid++;
				//sprintf(tazrecord," %-8d%-5s%-6s",polyid,taz[i].County,taz[i].Taz);					
				//sprintf(&tazrecord[20],"%-4s",taz[i].Ctpp);	
							sprintf(polyrecord," %-10s",poly[i].Polyid);
				sprintf(&polyrecord[11],"%-5s",poly[i].Cenid);
				sprintf(&polyrecord[16],"%-2s",poly[i].State);
				sprintf(&polyrecord[18],"%-3s",poly[i].County);
				sprintf(&polyrecord[21],"%1d",poly[i].Waterflag);
				sprintf(&polyrecord[22],"%-4s",poly[i].Cmsamsa);
				sprintf(&polyrecord[26],"%-4s",poly[i].Pmsa);
				sprintf(&polyrecord[30],"%-5s",poly[i].Fair);
				sprintf(&polyrecord[35],"%-5s",poly[i].Air);
				sprintf(&polyrecord[40],"%c",poly[i].Trust);
				sprintf(&polyrecord[41],"%-2s",poly[i].Anrc);
				sprintf(&polyrecord[43],"%-5s",poly[i].Fccity);
				sprintf(&polyrecord[48],"%-5s",poly[i].Fmcd);
				sprintf(&polyrecord[53],"%-5s",poly[i].Fsmcd);
				sprintf(&polyrecord[58],"%-5s",poly[i].Fpl);
				sprintf(&polyrecord[63],"%-2s",poly[i].Cdcu);
				sprintf(&polyrecord[65],"%-6s",poly[i].Stsenate);
				sprintf(&polyrecord[71],"%-6s",poly[i].Sthouse);	
				sprintf(&polyrecord[77],"%-5s",poly[i].Fair90);
				sprintf(&polyrecord[82],"%-5s",poly[i].Fmcd90);
				sprintf(&polyrecord[87],"%-5s",poly[i].Fpl90);
				sprintf(&polyrecord[92],"%-6s",poly[i].Ctbna90);
				sprintf(&polyrecord[98],"%-4s",poly[i].Blk90);
				sprintf(&polyrecord[102],"%-2s",poly[i].Cd106);
				sprintf(&polyrecord[104],"%-2s",poly[i].Cd108);
				sprintf(&polyrecord[106],"%-5s",poly[i].Sdelm);//start from here
				sprintf(&polyrecord[111],"%-5s",poly[i].Sdsec);
				sprintf(&polyrecord[116],"%-5s",poly[i].Sduni);
				sprintf(&polyrecord[121],"%-6s",poly[i].Taz);
				sprintf(&polyrecord[127],"%-4s",poly[i].Ua90);
				sprintf(&polyrecord[131],"%c",poly[i].Urbflag);
				sprintf(&polyrecord[132],"%-4s",poly[i].Ctpp);
				sprintf(&polyrecord[136],"%-2s",poly[i].State90);
				sprintf(&polyrecord[138],"%-3s",poly[i].Coun90);
				sprintf(&polyrecord[141],"%-4s",poly[i].Air90);
				sprintf(&polyrecord[145],"%-4s",poly[i].Vote90);

				
				fwrite(&polyrecord,sizeof(polyrecord)-1,1,dbfout);    		
				Npts = 0;
				if (poly[i].Flip == 0)
				{
					Pts[Npts].Longitude = poly[i].Frlong;
					Pts[Npts].Latitude = poly[i].Frlat;
					Npts++;
					Get_Shape_Points(poly[i].Tlid,poly[i].Flip);
					Pts[Npts].Longitude = poly[i].Tolong;
					Pts[Npts].Latitude = poly[i].Tolat;
					Npts++;					
					n++;
					//steppos = (int)(n*100/written);	
					//Ptrdlg->m_Progress.SetPos(steppos);
					poly[i].Chosen = 1;            
					found = 1;                      
					curX = poly[i].Tolong;
					curY = poly[i].Tolat;                
					curcase = i;
					break;					
				}
				else
				{
					Pts[Npts].Longitude = poly[i].Tolong;
					Pts[Npts].Latitude = poly[i].Tolat;
					Npts++;
					Get_Shape_Points(poly[i].Tlid,poly[i].Flip);
					Pts[Npts].Longitude = poly[i].Frlong;
					Pts[Npts].Latitude = poly[i].Frlat;
					Npts++;				
					n++;
//					steppos = (int)(n*100/written);	
//					Ptrdlg->m_Progress.SetPos(steppos);
					curX = poly[i].Frlong;
					curY = poly[i].Frlat;                        
					poly[i].Chosen = 1;		
					found = 1;          
					curcase = i;	
					break;					
				}	
			}
		}
		//by now found should be 1
		if (found == 0)
		{
			info.Format("ERROR - found is zero");
			Ptrdlg->ErrorMessage(info);									
			MissingFile = -1;
			return;
		}
		ptcount += Npts;
		fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
		if (Pts[0].Longitude < CurrentMinX)
			CurrentMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < CurrentMinY)
			CurrentMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[0].Latitude;	
		if (Pts[0].Longitude < FileMinX)
			FileMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > FileMaxX)
			FileMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < FileMinY)
			FileMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > FileMaxY)
			FileMaxY = Pts[0].Latitude;

		if (Pts[Npts-1].Longitude < CurrentMinX)
			CurrentMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < CurrentMinY)
			CurrentMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[Npts-1].Latitude;	
		if (Pts[Npts-1].Longitude < FileMinX)
			FileMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > FileMaxX)
			FileMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < FileMinY)
			FileMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > FileMaxY)
			FileMaxY = Pts[Npts-1].Latitude;	
		steppos = (int)(n*100/written);	
		Ptrdlg->m_Progress.SetPos(steppos);	

	}//close while loop
	fwrite(&ptcount,sizeof(int),1,headtemp);
	fwrite(&nparts,sizeof(int),1,partstemp);
	fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
	fclose(boxtemp);
	fclose(headtemp);
	fclose(ptstemp);
	fclose(partstemp);
	sprintf(msg,"processed %d of %d records",n,written);
	Ptrdlg->SetDlgItemText(IDC_ALL,msg);			
	write_eof(dbfout);
	rewind(dbfout);
	Ptrdlg->m_Progress.SetPos(0);
	Build_db_Header(dbfout,polyid,dbPolys97);
	Build_Poly_Shape("all");
	Ptrdlg->m_strAll.Format("%d Census Polygons",polyid);
	Ptrdlg->SetDlgItemText(IDC_ALL,Ptrdlg->m_strAll);
	fclose(dbfout);
	free(poly);
	fprintf(LOG,"Wrote %d polygons\n", polyid);		
}

void Match_Poly_Lines_All()
{
	int polyid, found, i, nparts, ptcount;
	long num, n, written, curcase;
	Poly_Border_Type *poly;
	double  curX, curY;	
    FILE  *dbfout, *ptstemp, *headtemp, *partstemp, *boxtemp; 
	CString info, fname, errmsg;	
	char polyrecord[172]; //size of fpl dbrecord + 2
	int steppos;
	char msg[100];
	long maxpolys;
//	int tazid;

	
	if ((AllACount == 0) && (AllSCount == 0))
	{
		errmsg.Format("No polygons to process",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;		
	}	
	Ptrdlg->m_strProcess.Format("Gathering Boundary Lines");
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	Ptrdlg->m_Progress.SetPos(0);

	fname.Format("%s%sall.dbf",Outfilepath,Outfiletitle);			
	dbfout = fopen(fname,"wb");
	if (dbfout == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	ptstemp = fopen("pts.tmp","wb");
	if (ptstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	headtemp = fopen("head.tmp","wb");
	if (headtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	boxtemp = fopen("box.tmp","wb");
	if (boxtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	partstemp = fopen("parts.tmp","wb");
	if (partstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	if (AllACount > AllSCount){
		poly = (Poly_Border_Type *)calloc(AllACount,sizeof(Poly_Border_Type));	
		maxpolys = AllACount;
	}
	else{
		poly = (Poly_Border_Type *)calloc(AllSCount,sizeof(Poly_Border_Type));	
		maxpolys = AllSCount;
	}
	written = 0;
	for (num = 0; num < CountI; num++)
	{
		steppos = (int)(num*100/CountI);	
		Ptrdlg->m_Progress.SetPos(steppos);	

//		fprintf(LOG,"left %s right %s\n",TypeIs[num].Polyidl, TypeIs[num].Polyidr);
		if (strcmp(TypeIs[num].Polyidl,TypeIs[num].Polyidr)== 0)
			continue;		
		
		if (strcmp(TypeIs[num].Polyidl,"          ") != 0)
			{//left case	
				sprintf(poly[written].Polyid,"%s",TypeIs[num].Polyidl);
				sprintf(poly[written].Cenid,"%s",TypeIs[num].Cenidl);
				sprintf(poly[written].State,"%s",TypeIs[num].State);
				sprintf(poly[written].County,"%s",TypeIs[num].County);
				poly[written].Waterflag = TypeIs[num].Waterl;
				sprintf(poly[written].Cmsamsa,"%s",TypeIs[num].Msal);
				sprintf(poly[written].Pmsa,"%s",TypeIs[num].Pmsl);
				sprintf(poly[written].Fair,"%s",TypeIs[num].Faircul);
				sprintf(poly[written].Air,"%s",TypeIs[num].Aircul);	
				poly[written].Trust = TypeIs[num].Trustl;
				sprintf(poly[written].Anrc,"%s",TypeIs[num].Anrcl);
				sprintf(poly[written].Fccity,"%s",TypeIs[num].Fccityl);
				sprintf(poly[written].Fmcd,"%s",TypeIs[num].Fmcdcul);
				sprintf(poly[written].Fsmcd,"%s",TypeIs[num].Fsmcdcul);
				sprintf(poly[written].Fpl,"%s",TypeIs[num].Fplcul);
				sprintf(poly[written].Cdcu,"%s",TypeIs[num].Cdcul);
				sprintf(poly[written].Stsenate,"%s",TypeIs[num].Senatel);
				sprintf(poly[written].Sthouse,"%s",TypeIs[num].Housel);
				sprintf(poly[written].Census6,"%s",TypeIs[num].Census6l);
				poly[written].Tea = TypeIs[num].Colblkl[11];
				sprintf(poly[written].Statecol,"%2s",TypeIs[num].Colblkl);
				sprintf(poly[written].Councol,"%3s",&TypeIs[num].Colblkl[2]);
				sprintf(poly[written].Blkcol,"%5s",&TypeIs[num].Colblkl[5]);
				poly[written].Blksufcol = TypeIs[num].Colblkl[10];
				sprintf(poly[written].Zcta,"%5s",&TypeIs[num].Colblkl[12]);	
				sprintf(poly[written].Fair90,"%s",TypeIs[num].Fair90l);
				sprintf(poly[written].Fmcd90,"%s",TypeIs[num].Fmcd90l);
				sprintf(poly[written].Fpl90,"%s",TypeIs[num].Fpl90l);
				sprintf(poly[written].Ctbna90,"%s",TypeIs[num].Ctbna90l);
				sprintf(poly[written].Blk90,"%s",TypeIs[num].Blk90l);
				sprintf(poly[written].Cd106,"%s",TypeIs[num].Cd106l);
				sprintf(poly[written].Cd108,"%s",TypeIs[num].Cd108l);
				sprintf(poly[written].Sdelm,"%s",TypeIs[num].Elml);					
				sprintf(poly[written].Sdsec,"%s",TypeIs[num].Secl);
				sprintf(poly[written].Sduni,"%s",TypeIs[num].Unil);
				sprintf(poly[written].Taz,"%6s",TypeIs[num].Tazl);
				sprintf(poly[written].Ua90,"%s",TypeIs[num].Urb90l);				
				poly[written].Urbflag = TypeIs[num].Urbflagl;
				sprintf(poly[written].Ctpp,"%4s",&TypeIs[num].Tazl[6]);
				sprintf(poly[written].State90,"%2s",TypeIs[num].County90l);
				sprintf(poly[written].Coun90,"%3s",&TypeIs[num].County90l[2]);
				sprintf(poly[written].Air90,"%s",TypeIs[num].Air90l);
				sprintf(poly[written].Vote,"%s",Type3s[num].Vtd90l);
				sprintf(poly[written].Tlid,"%s",TypeIs[num].Tlid);
				poly[written].Frlong = Type1s[num].Frlong;
				poly[written].Frlat = Type1s[num].Frlat;
				poly[written].Tolong = Type1s[num].Tolong;
				poly[written].Tolat = Type1s[num].Tolat;
				poly[written].Chosen = 0;
				poly[written].Flip = 1;
				written++;
			}
		if (strcmp(TypeIs[num].Polyidr, "          ") != 0)
			{//rightcase 
				sprintf(poly[written].Polyid,"%s",TypeIs[num].Polyidr);
				sprintf(poly[written].Cenid,"%s",TypeIs[num].Cenidr);
				sprintf(poly[written].State,"%s",TypeIs[num].State);
				sprintf(poly[written].County,"%s",TypeIs[num].County);
				poly[written].Waterflag = TypeIs[num].Waterr;
				sprintf(poly[written].Cmsamsa,"%s",TypeIs[num].Msar);
				sprintf(poly[written].Pmsa,"%s",TypeIs[num].Pmsr);
				sprintf(poly[written].Fair,"%s",TypeIs[num].Faircur);
				sprintf(poly[written].Air,"%s",TypeIs[num].Aircur);	
				poly[written].Trust = TypeIs[num].Trustr;
				sprintf(poly[written].Anrc,"%s",TypeIs[num].Anrcr);
				sprintf(poly[written].Fccity,"%s",TypeIs[num].Fccityr);
				sprintf(poly[written].Fmcd,"%s",TypeIs[num].Fmcdcur);
				sprintf(poly[written].Fsmcd,"%s",TypeIs[num].Fsmcdcur);
				sprintf(poly[written].Fpl,"%s",TypeIs[num].Fplcur);
				sprintf(poly[written].Cdcu,"%s",TypeIs[num].Cdcur);
				sprintf(poly[written].Stsenate,"%s",TypeIs[num].Senater);
				sprintf(poly[written].Sthouse,"%s",TypeIs[num].Houser);
				sprintf(poly[written].Census6,"%s",TypeIs[num].Census6r);
				poly[written].Tea = TypeIs[num].Colblkr[11];
				sprintf(poly[written].Statecol,"%2s",TypeIs[num].Colblkr);
				sprintf(poly[written].Councol,"%3s",&TypeIs[num].Colblkr[2]);
				sprintf(poly[written].Blkcol,"%5s",&TypeIs[num].Colblkr[5]);
				poly[written].Blksufcol = TypeIs[num].Colblkr[10];
				sprintf(poly[written].Zcta,"%5s",&TypeIs[num].Colblkr[12]);	
				sprintf(poly[written].Fair90,"%s",TypeIs[num].Fair90r);
				sprintf(poly[written].Fmcd90,"%s",TypeIs[num].Fmcd90r);
				sprintf(poly[written].Fpl90,"%s",TypeIs[num].Fpl90r);
				sprintf(poly[written].Ctbna90,"%s",TypeIs[num].Ctbna90r);
				sprintf(poly[written].Blk90,"%s",TypeIs[num].Blk90r);
				sprintf(poly[written].Cd106,"%s",TypeIs[num].Cd106r);
				sprintf(poly[written].Cd108,"%s",TypeIs[num].Cd108r);
				sprintf(poly[written].Sdelm,"%s",TypeIs[num].Elmr);					
				sprintf(poly[written].Sdsec,"%s",TypeIs[num].Secr);
				sprintf(poly[written].Sduni,"%s",TypeIs[num].Unir);
				sprintf(poly[written].Taz,"%6s",TypeIs[num].Tazr);
				sprintf(poly[written].Ua90,"%s",TypeIs[num].Urb90r);				
				poly[written].Urbflag = TypeIs[num].Urbflagr;
				sprintf(poly[written].Ctpp,"%4s",&TypeIs[num].Tazr[6]);
				sprintf(poly[written].State90,"%2s",TypeIs[num].County90r);
				sprintf(poly[written].Coun90,"%3s",&TypeIs[num].County90r[2]);
				sprintf(poly[written].Air90,"%s",TypeIs[num].Air90r);			
				sprintf(poly[written].Vote,"%s",Type3s[num].Vtd90r);
				sprintf(poly[written].Tlid,"%s",TypeIs[num].Tlid);				
				poly[written].Frlong = Type1s[num].Frlong;
				poly[written].Frlat = Type1s[num].Frlat;
				poly[written].Tolong = Type1s[num].Tolong;
				poly[written].Tolat = Type1s[num].Tolat;
				poly[written].Chosen = 0;
				poly[written].Flip = 0;
				written++;
			}
	}	
	if (written > maxpolys)
	{
		Ptrdlg->ErrorMessage("the number of polygon border lines exceeds the count");				
		MissingFile = -1;
		return;
	}
	Ptrdlg->m_strProcess.Format("Sorting Polygon Boundaries");
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	Ptrdlg->m_Progress.SetPos(0);
	qsort((void *)poly,written,sizeof(Poly_Border_Type),(compfn)ComparePoly);	
	FileMinX = FileMinY = LARGE;
	FileMaxX = FileMaxY = -LARGE;
	CurrentMinX = CurrentMinY = LARGE;
	CurrentMaxX = CurrentMaxY = -LARGE;
	curcase = 0;
	polyid = 1;
	Npts = 0; 
	nparts = 1;
	ptcount = 0;
	Build_db_Header(dbfout,0,dbPolys98);
	Build_db_FieldHeaders(dbfout,dbPolys98);	
	sprintf(polyrecord," %-10s",poly[curcase].Polyid);
	sprintf(&polyrecord[11],"%-5s",poly[curcase].Cenid);
	sprintf(&polyrecord[16],"%-2s",poly[curcase].State);
	sprintf(&polyrecord[18],"%-3s",poly[curcase].County);
	sprintf(&polyrecord[21],"%1d",poly[curcase].Waterflag);
	sprintf(&polyrecord[22],"%-4s",poly[curcase].Cmsamsa);
	sprintf(&polyrecord[26],"%-4s",poly[curcase].Pmsa);
	sprintf(&polyrecord[30],"%-5s",poly[curcase].Fair);
	sprintf(&polyrecord[35],"%-5s",poly[curcase].Air);
	sprintf(&polyrecord[40],"%c",poly[curcase].Trust);
	sprintf(&polyrecord[41],"%-2s",poly[curcase].Anrc);
	sprintf(&polyrecord[43],"%-5s",poly[curcase].Fccity);
	sprintf(&polyrecord[48],"%-5s",poly[curcase].Fmcd);
	sprintf(&polyrecord[53],"%-5s",poly[curcase].Fsmcd);
	sprintf(&polyrecord[58],"%-5s",poly[curcase].Fpl);
	sprintf(&polyrecord[63],"%c",poly[curcase].Tea);
	sprintf(&polyrecord[64],"%-2s",poly[curcase].Cdcu);
	sprintf(&polyrecord[66],"%-6s",poly[curcase].Stsenate);
	sprintf(&polyrecord[72],"%-6s",poly[curcase].Sthouse);
	sprintf(&polyrecord[78],"%-5s",poly[curcase].Census6);
	sprintf(&polyrecord[83],"%-2s",poly[curcase].Statecol);
	sprintf(&polyrecord[85],"%-3s",poly[curcase].Councol);
	sprintf(&polyrecord[88],"%-5s",poly[curcase].Blkcol);
	sprintf(&polyrecord[93],"%c",poly[curcase].Blksufcol);
	sprintf(&polyrecord[94],"%5s",poly[curcase].Zcta);
	sprintf(&polyrecord[99],"%-5s",poly[curcase].Fair90);
	sprintf(&polyrecord[104],"%-5s",poly[curcase].Fmcd90);
	sprintf(&polyrecord[109],"%-5s",poly[curcase].Fpl90);
	sprintf(&polyrecord[114],"%-6s",poly[curcase].Ctbna90);
	sprintf(&polyrecord[120],"%-4s",poly[curcase].Blk90);
	sprintf(&polyrecord[124],"%-2s",poly[curcase].Cd106);
	sprintf(&polyrecord[126],"%-2s",poly[curcase].Cd108);
	sprintf(&polyrecord[128],"%-5s",poly[curcase].Sdelm);
	sprintf(&polyrecord[133],"%-5s",poly[curcase].Sdsec);
	sprintf(&polyrecord[138],"%-5s",poly[curcase].Sduni);
	sprintf(&polyrecord[143],"%-6s",poly[curcase].Taz);
	sprintf(&polyrecord[149],"%-4s",poly[curcase].Ua90);
	sprintf(&polyrecord[153],"%c",poly[curcase].Urbflag);
	sprintf(&polyrecord[154],"%-4s",poly[curcase].Ctpp);
	sprintf(&polyrecord[158],"%-2s",poly[curcase].State90);
	sprintf(&polyrecord[160],"%-3s",poly[curcase].Coun90);
	sprintf(&polyrecord[163],"%-4s",poly[curcase].Air90);
	sprintf(&polyrecord[167],"%-4s",poly[curcase].Vote);
	fwrite(&polyrecord,sizeof(polyrecord)-1,1,dbfout);
	if (poly[0].Flip == 0)
	{
		curX = poly[0].Tolong;
		curY = poly[0].Tolat;		
		Pts[Npts].Longitude = poly[curcase].Frlong;
		Pts[Npts].Latitude = poly[curcase].Frlat;
		Npts++;
		Get_Shape_Points(poly[curcase].Tlid, poly[curcase].Flip);
		Pts[Npts].Longitude = poly[curcase].Tolong;
		Pts[Npts].Latitude = poly[curcase].Tolat;
		Npts++;
		poly[curcase].Chosen = 1;		
	}
	else
	{
		curX = poly[0].Frlong;
		curY = poly[0].Frlat;		
		Pts[Npts].Longitude = poly[curcase].Tolong;
		Pts[Npts].Latitude = poly[curcase].Tolat;
		Npts++;
		Get_Shape_Points(poly[curcase].Tlid, poly[curcase].Flip);
		Pts[Npts].Longitude = poly[curcase].Frlong;
		Pts[Npts].Latitude = poly[curcase].Frlat;
		Npts++;
		poly[curcase].Chosen = 1;		
	}
	ptcount += Npts;
	
    fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
	
	if (Pts[0].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < CurrentMinY)
		CurrentMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[0].Latitude;	
	if (Pts[0].Longitude < FileMinX)
		FileMinX = Pts[0].Longitude;
	if (Pts[0].Longitude > FileMaxX)
		FileMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < FileMinY)
		FileMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > FileMaxY)
		FileMaxY = Pts[0].Latitude;

	if (Pts[Npts-1].Longitude < CurrentMinX)
		CurrentMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < CurrentMinY)
		CurrentMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[Npts-1].Latitude;	
	if (Pts[Npts-1].Longitude < FileMinX)
		FileMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > FileMaxX)
		FileMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < FileMinY)
		FileMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > FileMaxY)
		FileMaxY = Pts[Npts-1].Latitude;		
	n = 1;
//	steppos = (int)(n*100/written);	
//	Ptrdlg->m_Progress.SetPos(steppos);	
	Ptrdlg->m_strProcess.Format("Building Polygons");
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	steppos = (int)(n*100/written);	
	Ptrdlg->m_Progress.SetPos(steppos);	
    while (n < written)
	{		
		sprintf(msg,"processed %d of %d records",n,written);
		Ptrdlg->SetDlgItemText(IDC_ALL,msg);		
		found = 0;
		for (i = 1; i < written; i++)
         {
			Npts = 0;
			if (poly[i].Chosen != 0)
				continue;
			if (poly[i].Flip == 0)
			{
				if ((poly[i].Frlong == curX) && (poly[i].Frlat == curY))
				{                          
					if (strcmp(poly[i].Polyid,poly[curcase].Polyid) != 0)
						continue;	            
					if (strcmp(poly[i].Cenid,poly[curcase].Cenid) != 0)
						continue;
					Get_Shape_Points(poly[i].Tlid,poly[i].Flip);
					Pts[Npts].Longitude = poly[i].Tolong;
					Pts[Npts].Latitude = poly[i].Tolat;
					Npts++;
					n++;
					//steppos = (int)(n*100/written);	
					//Ptrdlg->m_Progress.SetPos(steppos);
					poly[i].Chosen = 1;            
					found = 1;                      
					curX = poly[i].Tolong;
					curY = poly[i].Tolat;                
					curcase = i;
					break;
				}
			}
			else
			{
				if ((poly[i].Tolong == curX) && (poly[i].Tolat == curY))
				{
					if (strcmp(poly[i].Polyid,poly[curcase].Polyid) != 0)
						continue;	            
					if (strcmp(poly[i].Cenid,poly[curcase].Cenid) != 0)
						continue;
					Get_Shape_Points(poly[i].Tlid,poly[i].Flip);
					Pts[Npts].Longitude = poly[i].Frlong;
					Pts[Npts].Latitude = poly[i].Frlat;
					Npts++;
					n++;
					//steppos = (int)(n*100/written);	
					//Ptrdlg->m_Progress.SetPos(steppos);
					curX = poly[i].Frlong;
					curY = poly[i].Frlat;                        
					poly[i].Chosen = 1;	
					found = 1;          
					curcase = i;
					break;
				}
			}
        }//close for loop
		if (found == 0) //initialize new case, eg, new ring or new poly
		{			
			fwrite(&ptcount,sizeof(int),1,headtemp);
			ptcount = 0;
			for (i = 0; i < written; i++) //check for new ring in poly
            {                    
         		if (poly[i].Chosen != 0)
					continue;    
				if (strcmp(poly[i].Polyid,poly[curcase].Polyid) != 0)
					continue;	            
				if (strcmp(poly[i].Cenid,poly[curcase].Cenid) != 0)
					continue;
				//if we get here it is a new ring in current poly
				found = 1;
				nparts++;
				Npts = 0;
				if (poly[i].Flip == 0)
				{
					Pts[Npts].Longitude = poly[i].Frlong;
					Pts[Npts].Latitude = poly[i].Frlat;
					Npts++;
					Get_Shape_Points(poly[i].Tlid,poly[i].Flip);
					Pts[Npts].Longitude = poly[i].Tolong;
					Pts[Npts].Latitude = poly[i].Tolat;
					Npts++;			
    				n++;
					//steppos = (int)(n*100/written);	
					//Ptrdlg->m_Progress.SetPos(steppos);
					poly[i].Chosen = 1;
    		   		curX = poly[i].Tolong;
    				curY = poly[i].Tolat;
					curcase = i;
					break;
				}
				else
				{
					Pts[Npts].Longitude = poly[i].Tolong;
					Pts[Npts].Latitude = poly[i].Tolat;
					Npts++;
					Get_Shape_Points(poly[i].Tlid,poly[i].Flip);
					Pts[Npts].Longitude = poly[i].Frlong;
					Pts[Npts].Latitude = poly[i].Frlat;
					Npts++;			
					n++;
					//steppos = (int)(n*100/written);	
					//Ptrdlg->m_Progress.SetPos(steppos);
					poly[i].Chosen = 1;
    		   		curX = poly[i].Frlong;
    				curY = poly[i].Frlat;
					curcase = i;
					break;
				}
    		}
    	}
		if (found == 0) // new poly, first ring
		{
			
			fwrite(&nparts,sizeof(int),1,partstemp);
			nparts = 1;
			fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
			CurrentMinX = CurrentMinY = LARGE;
			CurrentMaxX = CurrentMaxY = -LARGE;
			for (i = 0; i < written; i++)//first check for new ring in current poly
            {                    
         		if (poly[i].Chosen != 0)
					continue;             
				polyid++;
				//sprintf(tazrecord," %-8d%-5s%-6s",polyid,taz[i].County,taz[i].Taz);					
				//sprintf(&tazrecord[20],"%-4s",taz[i].Ctpp);	
			sprintf(polyrecord," %-10s",poly[i].Polyid);
			sprintf(&polyrecord[11],"%-5s",poly[i].Cenid);
			sprintf(&polyrecord[16],"%-2s",poly[i].State);
			sprintf(&polyrecord[18],"%-3s",poly[i].County);
			sprintf(&polyrecord[21],"%1d",poly[i].Waterflag);
			sprintf(&polyrecord[22],"%-4s",poly[i].Cmsamsa);
			sprintf(&polyrecord[26],"%-4s",poly[i].Pmsa);
			sprintf(&polyrecord[30],"%-5s",poly[i].Fair);
			sprintf(&polyrecord[35],"%-5s",poly[i].Air);
			sprintf(&polyrecord[40],"%c",poly[i].Trust);
			sprintf(&polyrecord[41],"%-2s",poly[i].Anrc);
			sprintf(&polyrecord[43],"%-5s",poly[i].Fccity);
			sprintf(&polyrecord[48],"%-5s",poly[i].Fmcd);
			sprintf(&polyrecord[53],"%-5s",poly[i].Fsmcd);
			sprintf(&polyrecord[58],"%-5s",poly[i].Fpl);
			sprintf(&polyrecord[63],"%c",poly[i].Tea);
			sprintf(&polyrecord[64],"%-2s",poly[i].Cdcu);
			sprintf(&polyrecord[66],"%-6s",poly[i].Stsenate);
			sprintf(&polyrecord[72],"%-6s",poly[i].Sthouse);
			sprintf(&polyrecord[78],"%-5s",poly[i].Census6);
			sprintf(&polyrecord[83],"%-2s",poly[i].Statecol);
			sprintf(&polyrecord[85],"%-3s",poly[i].Councol);
			sprintf(&polyrecord[88],"%-5s",poly[i].Blkcol);
			sprintf(&polyrecord[93],"%c",poly[i].Blksufcol);
			sprintf(&polyrecord[94],"%5s",poly[i].Zcta);
			sprintf(&polyrecord[99],"%-5s",poly[i].Fair90);
			sprintf(&polyrecord[104],"%-5s",poly[i].Fmcd90);
			sprintf(&polyrecord[109],"%-5s",poly[i].Fpl90);
			sprintf(&polyrecord[114],"%-6s",poly[i].Ctbna90);
			sprintf(&polyrecord[120],"%-4s",poly[i].Blk90);
			sprintf(&polyrecord[124],"%-2s",poly[i].Cd106);
			sprintf(&polyrecord[126],"%-2s",poly[i].Cd108);
			sprintf(&polyrecord[128],"%-5s",poly[i].Sdelm);
			sprintf(&polyrecord[133],"%-5s",poly[i].Sdsec);
			sprintf(&polyrecord[138],"%-5s",poly[i].Sduni);
			sprintf(&polyrecord[143],"%-6s",poly[i].Taz);
			sprintf(&polyrecord[149],"%-4s",poly[i].Ua90);
			sprintf(&polyrecord[153],"%c",poly[i].Urbflag);
			sprintf(&polyrecord[154],"%-4s",poly[i].Ctpp);
			sprintf(&polyrecord[158],"%-2s",poly[i].State90);
			sprintf(&polyrecord[160],"%-3s",poly[i].Coun90);
			sprintf(&polyrecord[163],"%-4s",poly[i].Air90);
			sprintf(&polyrecord[167],"%-4s",poly[i].Vote);
				
				fwrite(&polyrecord,sizeof(polyrecord)-1,1,dbfout);    		
				Npts = 0;
				if (poly[i].Flip == 0)
				{
					Pts[Npts].Longitude = poly[i].Frlong;
					Pts[Npts].Latitude = poly[i].Frlat;
					Npts++;
					Get_Shape_Points(poly[i].Tlid,poly[i].Flip);
					Pts[Npts].Longitude = poly[i].Tolong;
					Pts[Npts].Latitude = poly[i].Tolat;
					Npts++;					
					n++;
					//steppos = (int)(n*100/written);	
					//Ptrdlg->m_Progress.SetPos(steppos);
					poly[i].Chosen = 1;            
					found = 1;                      
					curX = poly[i].Tolong;
					curY = poly[i].Tolat;                
					curcase = i;
					break;					
				}
				else
				{
					Pts[Npts].Longitude = poly[i].Tolong;
					Pts[Npts].Latitude = poly[i].Tolat;
					Npts++;
					Get_Shape_Points(poly[i].Tlid,poly[i].Flip);
					Pts[Npts].Longitude = poly[i].Frlong;
					Pts[Npts].Latitude = poly[i].Frlat;
					Npts++;				
					n++;
//					steppos = (int)(n*100/written);	
//					Ptrdlg->m_Progress.SetPos(steppos);
					curX = poly[i].Frlong;
					curY = poly[i].Frlat;                        
					poly[i].Chosen = 1;		
					found = 1;          
					curcase = i;	
					break;					
				}	
			}
		}
		//by now found should be 1
		if (found == 0)
		{
			info.Format("ERROR - found is zero");
			Ptrdlg->ErrorMessage(info);									
			MissingFile = -1;
			return;
		}
		ptcount += Npts;
		fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
		if (Pts[0].Longitude < CurrentMinX)
			CurrentMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < CurrentMinY)
			CurrentMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[0].Latitude;	
		if (Pts[0].Longitude < FileMinX)
			FileMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > FileMaxX)
			FileMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < FileMinY)
			FileMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > FileMaxY)
			FileMaxY = Pts[0].Latitude;

		if (Pts[Npts-1].Longitude < CurrentMinX)
			CurrentMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < CurrentMinY)
			CurrentMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[Npts-1].Latitude;	
		if (Pts[Npts-1].Longitude < FileMinX)
			FileMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > FileMaxX)
			FileMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < FileMinY)
			FileMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > FileMaxY)
			FileMaxY = Pts[Npts-1].Latitude;	
		steppos = (int)(n*100/written);	
		Ptrdlg->m_Progress.SetPos(steppos);	

	}//close while loop
	fwrite(&ptcount,sizeof(int),1,headtemp);
	fwrite(&nparts,sizeof(int),1,partstemp);
	fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
	fclose(boxtemp);
	fclose(headtemp);
	fclose(ptstemp);
	fclose(partstemp);
	sprintf(msg,"processed %d of %d records",n,written);
	Ptrdlg->SetDlgItemText(IDC_ALL,msg);			
	write_eof(dbfout);
	rewind(dbfout);
	Ptrdlg->m_Progress.SetPos(0);
	Build_db_Header(dbfout,polyid,dbPolys98);
	Build_Poly_Shape("all");
	Ptrdlg->m_strAll.Format("%d Census Polygons",polyid);
	Ptrdlg->SetDlgItemText(IDC_ALL,Ptrdlg->m_strAll);
    fclose(dbfout);
	free(poly);
	fprintf(LOG,"Wrote %d polygons to shape %s%s\n", polyid, Outfilepath,Outfiletitle);		
}

void Match_Poly_Lines_Vote()
{
	int polyid, found, i, nparts, ptcount;
	long num, n, written, curcase;
	Vote_Border_Type *vote;
	double  curX, curY;	
    FILE  *dbfout, *ptstemp, *headtemp, *partstemp, *boxtemp; 	
	CString info, fname;	
	char voterecord[85]; //size of fpl dbrecord + 2
	int steppos;
	char msg[100];
	char *votename;
	CString errmsg;
	int doleft, doright;
	
	if (Polycounts[0] == 0)
	{
		Ptrdlg->SetDlgItemText(IDC_VOTING,"No Such Cases");		
		return;
	}
	fname.Format("%s%svot.dbf",Outfilepath,Outfiletitle);			
	dbfout = fopen(fname,"wb");
	if (dbfout == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	ptstemp = fopen("pts.tmp","wb");
	if (ptstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	headtemp = fopen("head.tmp","wb");
	if (headtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	boxtemp = fopen("box.tmp","wb");
	if (boxtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	partstemp = fopen("parts.tmp","wb");
	if (partstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	
	vote = (Vote_Border_Type *)calloc(Polycounts[0]+Watercut*SPolycounts[0],sizeof(Vote_Border_Type));
	
	written = 0;
	for (num = 0; num < Count3; num++)
	{
		if (Type3s[num].BorderType == 0)
		{
			if (Watercut)
			{

				if (TypeIs[num].Waterl == TypeIs[num].Waterr)
					continue;
			}
			else
				continue;		
		}
		doleft = 0;
	
	//		continue;		
		//printf("\nwritten %d polycount %d",written,Polycounts[5]);
		//we know it is a border type 4 line		
		//if ((strcmp(Type3s[num].State90l,Curstate) == 0) && (strcmp(Type3s[num].Coun90l,Curcounty) == 0))
		if (strcmp(Type3s[num].Vtd90l,"    ") != 0)
		{//left case
			if (Watercut)
			{
				if (!TypeIs[num].Waterl)
					doleft = 1;
			}
			else
				doleft = 1;
			if (doleft)
			{	
				sprintf(vote[written].County,"%s%s",Type3s[num].State90l,Type3s[num].Coun90l);
				sprintf(vote[written].Id,"%s",Type3s[num].Vtd90l);
				sprintf(vote[written].Tlid,"%s",Type3s[num].Tlid);
				vote[written].Frlong = Type1s[num].Frlong;
				vote[written].Frlat = Type1s[num].Frlat;
				vote[written].Tolong = Type1s[num].Tolong;
				vote[written].Tolat = Type1s[num].Tolat;
				vote[written].Chosen = 0;
				vote[written].Flip = 1;
				written++;
			}
		}
		//if ((strcmp(Type3s[num].State90r,Curstate) == 0) && (strcmp(Type3s[num].Coun90r,Curcounty) == 0))
		doright = 0;
		if (strcmp(Type3s[num].Vtd90r,"    ") != 0)
		{//rightcase 
			if (Watercut)
			{
				if (!TypeIs[num].Waterr)				
					doright = 1;
			}
			else
				doright = 1;
			if (doright)
			{
				sprintf(vote[written].County,"%s%s",Type3s[num].State90r,Type3s[num].Coun90r);
				sprintf(vote[written].Id,"%s",Type3s[num].Vtd90r);
				sprintf(vote[written].Tlid,"%s",Type3s[num].Tlid);
				vote[written].Frlong = Type1s[num].Frlong;
				vote[written].Frlat = Type1s[num].Frlat;
				vote[written].Tolong = Type1s[num].Tolong;
				vote[written].Tolat = Type1s[num].Tolat;
				vote[written].Chosen = 0;
				vote[written].Flip = 0;
				written++;
			}
		}
	}	
	if (written > Polycounts[0]+Watercut*SPolycounts[0])
	{
		Ptrdlg->ErrorMessage("the number of Voting District border lines exceeds the count");				
		MissingFile = -1;
		return;
	}
	if (written == 0)
	{
		if (!Watercut)
			fprintf(LOG,"There are no lines for voting districts\n");
		else
		{
			fprintf(LOG,"All voting districts for this county coincide with water polygons\n");
			fprintf(LOG,"Try turning off the water polygon clipping option\n");
		}
		return;
	}

	//time to chain		
	Ptrdlg->m_strProcess.Format("Gathering Voting District Boundary Lines");
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	qsort((void *)vote,written,sizeof(Vote_Border_Type),(compfn)CompareVote);
	FileMinX = FileMinY = LARGE;
	FileMaxX = FileMaxY = -LARGE;
	CurrentMinX = CurrentMinY = LARGE;
	CurrentMaxX = CurrentMaxY = -LARGE;
	curcase = 0;
	polyid = 1;
	Npts = 0; 
	nparts = 1;
	ptcount = 0;
	Build_db_Header(dbfout,0,dbVote);
	Build_db_FieldHeaders(dbfout,dbVote);	
	votename = Get_TypeC_Name(6,vote[curcase].Id,vote[curcase].County);
    //sprintf(voterecord," %-8d%-5s%-4s%-66s",polyid,vote[curcase].County,
	//	vote[curcase].Id,votename);
	sprintf(voterecord," %-8d",polyid);
	sprintf(&voterecord[9],"%-5s",vote[curcase].County);
	sprintf(&voterecord[14],"%-4s",vote[curcase].Id);
	sprintf(&voterecord[18],"%-66s",votename);
	fwrite(&voterecord,sizeof(voterecord)-1,1,dbfout);
	if (vote[0].Flip == 0)
	{
		curX = vote[0].Tolong;
		curY = vote[0].Tolat;		
		Pts[Npts].Longitude = vote[curcase].Frlong;
		Pts[Npts].Latitude = vote[curcase].Frlat;
		Npts++;
		Get_Shape_Points(vote[curcase].Tlid, vote[curcase].Flip);
		Pts[Npts].Longitude = vote[curcase].Tolong;
		Pts[Npts].Latitude = vote[curcase].Tolat;
		Npts++;
		vote[curcase].Chosen = 1;		
	}
	else
	{
		curX = vote[0].Frlong;
		curY = vote[0].Frlat;		
		Pts[Npts].Longitude = vote[curcase].Tolong;
		Pts[Npts].Latitude = vote[curcase].Tolat;
		Npts++;
		Get_Shape_Points(vote[curcase].Tlid, vote[curcase].Flip);
		Pts[Npts].Longitude = vote[curcase].Frlong;
		Pts[Npts].Latitude = vote[curcase].Frlat;
		Npts++;
		vote[curcase].Chosen = 1;		
	}
	ptcount += Npts;
	
    fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
	
	if (Pts[0].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < CurrentMinY)
		CurrentMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[0].Latitude;	
	if (Pts[0].Longitude < FileMinX)
		FileMinX = Pts[0].Longitude;
	if (Pts[0].Longitude > FileMaxX)
		FileMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < FileMinY)
		FileMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > FileMaxY)
		FileMaxY = Pts[0].Latitude;

	if (Pts[Npts-1].Longitude < CurrentMinX)
		CurrentMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < CurrentMinY)
		CurrentMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[Npts-1].Latitude;	
	if (Pts[Npts-1].Longitude < FileMinX)
		FileMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > FileMaxX)
		FileMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < FileMinY)
		FileMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > FileMaxY)
		FileMaxY = Pts[Npts-1].Latitude;		
	n = 1;
	steppos = (int)(n*100/written);	
	Ptrdlg->m_Progress.SetPos(steppos);
    while (n < written)
	{
		//printf("\n Have written %ld of %ld fpl boundary lines",n, written);
		sprintf(msg,"processed %d of %d records",n,written);
		Ptrdlg->SetDlgItemText(IDC_VOTING,msg);		
		found = 0;
		for (i = 1; i < written; i++)
         {
			Npts = 0;
			if (vote[i].Chosen != 0)
				continue;
			if (vote[i].Flip == 0)
			{
				if ((vote[i].Frlong == curX) && (vote[i].Frlat == curY))
				{                          
					if (strcmp(vote[i].Id,vote[curcase].Id) != 0)
						continue;	            
					Get_Shape_Points(vote[i].Tlid,vote[i].Flip);
					Pts[Npts].Longitude = vote[i].Tolong;
					Pts[Npts].Latitude = vote[i].Tolat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					vote[i].Chosen = 1;            
					found = 1;                      
					curX = vote[i].Tolong;
					curY = vote[i].Tolat;                
					curcase = i;
					break;
				}
			}
			else
			{
				if ((vote[i].Tolong == curX) && (vote[i].Tolat == curY))
				{
					if (strcmp(vote[i].Id,vote[curcase].Id) != 0)
						continue;	            
					Get_Shape_Points(vote[i].Tlid,vote[i].Flip);
					Pts[Npts].Longitude = vote[i].Frlong;
					Pts[Npts].Latitude = vote[i].Frlat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = vote[i].Frlong;
					curY = vote[i].Frlat;                        
					vote[i].Chosen = 1;	
					found = 1;          
					curcase = i;
					break;
				}
			}
        }//close for loop
		if (found == 0) //initialize new case, eg, new ring or new poly
		{			
			fwrite(&ptcount,sizeof(int),1,headtemp);
			ptcount = 0;
			for (i = 0; i < written; i++) //check for new ring in poly
            {                    
         		if (vote[i].Chosen != 0)
					continue;             		
				if (strcmp(vote[i].Id, vote[curcase].Id) != 0)
					continue;
				//if we get here it is a new ring in current poly
				found = 1;
				nparts++;
				Npts = 0;
				if (vote[i].Flip == 0)
				{
					Pts[Npts].Longitude = vote[i].Frlong;
					Pts[Npts].Latitude = vote[i].Frlat;
					Npts++;
					Get_Shape_Points(vote[i].Tlid,vote[i].Flip);
					Pts[Npts].Longitude = vote[i].Tolong;
					Pts[Npts].Latitude = vote[i].Tolat;
					Npts++;			
    				n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					vote[i].Chosen = 1;
    		   		curX = vote[i].Tolong;
    				curY = vote[i].Tolat;
					curcase = i;
					break;
				}
				else
				{
					Pts[Npts].Longitude = vote[i].Tolong;
					Pts[Npts].Latitude = vote[i].Tolat;
					Npts++;
					Get_Shape_Points(vote[i].Tlid,vote[i].Flip);
					Pts[Npts].Longitude = vote[i].Frlong;
					Pts[Npts].Latitude = vote[i].Frlat;
					Npts++;			
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					vote[i].Chosen = 1;
    		   		curX = vote[i].Frlong;
    				curY = vote[i].Frlat;
					curcase = i;
					break;
				}
    		}
    	}
		if (found == 0) // new poly, first ring
		{
			
			fwrite(&nparts,sizeof(int),1,partstemp);
			nparts = 1;
			fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
			CurrentMinX = CurrentMinY = LARGE;
			CurrentMaxX = CurrentMaxY = -LARGE;

			for (i = 0; i < written; i++)//first check for new ring in current poly
            {                    
         		if (vote[i].Chosen != 0)
					continue;             
				polyid++;
				votename = Get_TypeC_Name(6,vote[i].Id,vote[i].County);
				//sprintf(voterecord," %-8d%-5s%-4s%-66s",polyid,vote[i].County,
				//	vote[i].Id,votename);
				sprintf(voterecord," %-8d",polyid);
				sprintf(&voterecord[9],"%-5s",vote[i].County);
				sprintf(&voterecord[14],"%-4s",vote[i].Id);
				sprintf(&voterecord[18],"%-66s",votename);
	
				//sprintf(voterecord," %-8d%-5s%-4s",polyid,vote[i].County,vote[i].Id);
				fwrite(&voterecord,sizeof(voterecord)-1,1,dbfout);    						
				Npts = 0;
				if (vote[i].Flip == 0)
				{
					Pts[Npts].Longitude = vote[i].Frlong;
					Pts[Npts].Latitude = vote[i].Frlat;
					Npts++;
					Get_Shape_Points(vote[i].Tlid,vote[i].Flip);
					Pts[Npts].Longitude = vote[i].Tolong;
					Pts[Npts].Latitude = vote[i].Tolat;
					Npts++;					
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					vote[i].Chosen = 1;            
					found = 1;                      
					curX = vote[i].Tolong;
					curY = vote[i].Tolat;                
					curcase = i;
					break;					
				}
				else
				{
					Pts[Npts].Longitude = vote[i].Tolong;
					Pts[Npts].Latitude = vote[i].Tolat;
					Npts++;
					Get_Shape_Points(vote[i].Tlid,vote[i].Flip);
					Pts[Npts].Longitude = vote[i].Frlong;
					Pts[Npts].Latitude = vote[i].Frlat;
					Npts++;				
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = vote[i].Frlong;
					curY = vote[i].Frlat;                        
					vote[i].Chosen = 1;		
					found = 1;          
					curcase = i;	
					break;					
				}	
			}
		}
		//by now found should be 1
		if (found == 0)
		{
			info.Format("ERROR - found is zero");
			Ptrdlg->ErrorMessage(info);									
			MissingFile = -1;
			return;
		}
		ptcount += Npts;
		fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
		if (Pts[0].Longitude < CurrentMinX)
			CurrentMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < CurrentMinY)
			CurrentMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[0].Latitude;	
		if (Pts[0].Longitude < FileMinX)
			FileMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > FileMaxX)
			FileMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < FileMinY)
			FileMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > FileMaxY)
			FileMaxY = Pts[0].Latitude;

		if (Pts[Npts-1].Longitude < CurrentMinX)
			CurrentMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < CurrentMinY)
			CurrentMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[Npts-1].Latitude;	
		if (Pts[Npts-1].Longitude < FileMinX)
			FileMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > FileMaxX)
			FileMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < FileMinY)
			FileMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > FileMaxY)
			FileMaxY = Pts[Npts-1].Latitude;		
	}//close while loop
	fwrite(&ptcount,sizeof(int),1,headtemp);
	fwrite(&nparts,sizeof(int),1,partstemp);
	fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
	fclose(boxtemp);
	fclose(headtemp);
	fclose(ptstemp);
	fclose(partstemp);
	sprintf(msg,"processed %d of %d records",n,written);
	Ptrdlg->SetDlgItemText(IDC_VOTING,msg);		
	//printf("\n Have written %ld of %ld fpl boundary lines",n, written);
	write_eof(dbfout);	
	rewind(dbfout);
	Build_db_Header(dbfout,polyid,dbVote);
	Build_Poly_Shape("vot");
	Ptrdlg->m_strVoting.Format("%d Voting Districts",polyid);
	Ptrdlg->SetDlgItemText(IDC_VOTING,Ptrdlg->m_strVoting);
    fclose(dbfout);
	free(vote);
	fprintf(LOG,"Wrote %d Voting District polygons to shape %s%svot\n", polyid,Outfilepath,
		Outfiletitle);		
}
void Match_Poly_Lines_Anrc()
{
	int polyid, found, i, nparts, ptcount;
	long num, n, written, curcase;
	Anrc_Border_Type *anrc;
	double  curX, curY;	
    FILE  *dbfout, *ptstemp, *headtemp, *partstemp, *boxtemp; 	
	CString info, fname;	
	char anrcrecord[83]; //size of fpl dbrecord + 2
	int steppos;
	char msg[100];	
	char *anrcname;
	CString errmsg;
	int doleft, doright;

	if (SPolycounts[6] == 0)
	{
		Ptrdlg->SetDlgItemText(IDC_ANRC,"No Such Cases");		
		return;
	}
		
	fname.Format("%s%sarc.dbf",Outfilepath,Outfiletitle);			
	dbfout = fopen(fname,"wb");
	if (dbfout == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	ptstemp = fopen("pts.tmp","wb");
	if (ptstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	headtemp = fopen("head.tmp","wb");
	if (headtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	boxtemp = fopen("box.tmp","wb");
	if (boxtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	partstemp = fopen("parts.tmp","wb");
	if (partstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	
    
	anrc = (Anrc_Border_Type *)calloc(SPolycounts[6]*Watercut*SPolycounts[0],sizeof(Anrc_Border_Type));
	written = 0;
	for (num = 0; num < CountI; num++)
	{
		if (strcmp(TypeIs[num].Anrcl,TypeIs[num].Anrcr)== 0)
		{
			if (Watercut)
			{

				if (TypeIs[num].Waterl == TypeIs[num].Waterr)
					continue;
			}
			else
				continue;		
		}
		doleft = 0;
		
		if (strcmp(TypeIs[num].Anrcl,"  ") != 0)
		{//left case	
			if (Watercut)
			{
				if (!TypeIs[num].Waterl)
					doleft = 1;
			}
			else
				doleft = 1;
			if (doleft)
			{
				sprintf(anrc[written].County,"%s%s",TypeIs[num].State,TypeIs[num].County);				
				sprintf(anrc[written].Id,"%2s",TypeIs[num].Anrcl);								
				sprintf(anrc[written].Tlid,"%s",TypeIs[num].Tlid);
				anrc[written].Frlong = Type1s[num].Frlong;
				anrc[written].Frlat = Type1s[num].Frlat;
				anrc[written].Tolong = Type1s[num].Tolong;
				anrc[written].Tolat = Type1s[num].Tolat;
				anrc[written].Chosen = 0;
				anrc[written].Flip = 1;
				written++;
			}
		}
		doright = 0;
		if (strcmp(TypeIs[num].Anrcr, "  ") != 0)
		{//rightcase 
			//printf("\nright case");			
			if (Watercut)
			{
				if(!TypeIs[num].Waterr)
					doright = 1;
			}
			else
				doright = 1;
			if (doright)
			{
				sprintf(anrc[written].County,"%s%s",TypeIs[num].State,TypeIs[num].County);				
				sprintf(anrc[written].Id,"%2s",TypeIs[num].Anrcr);				
				sprintf(anrc[written].Tlid,"%s",TypeIs[num].Tlid);				
				anrc[written].Frlong = Type1s[num].Frlong;
				anrc[written].Frlat = Type1s[num].Frlat;
				anrc[written].Tolong = Type1s[num].Tolong;
				anrc[written].Tolat = Type1s[num].Tolat;
				anrc[written].Chosen = 0;
				anrc[written].Flip = 0;
				written++;
			}
		}

	}	
	if (written > SPolycounts[6]+Watercut*SPolycounts[0])
	{
		Ptrdlg->ErrorMessage("the number of Anrc border lines exceeds the count");				
		MissingFile = -1;
		return;
	}
	if (written == 0)
	{
		if (!Watercut)
			fprintf(LOG,"There are no lines for Alaska Native Regional Coorporations\n");
		else
		{
			fprintf(LOG,"All the ANRCs for this county coincide with water polygons\n");
			fprintf(LOG,"Try turning off the water polygon clipping option\n");
		}
		return;
	}
/*
	
	for (num = 0; num < Count1; num++)
	{
		if (Type3s[num].BorderType[8] == 0)
			continue;		
		if ((strcmp(Type3s[num].State90l,Curstate) == 0) && (strcmp(Type3s[num].Coun90l,Curcounty) == 0))
		  if (strcmp(Type3s[num].Anrcl,"  ") != 0)
			{//left case
				sprintf(anrc[written].County,"%s%s",Type3s[num].State90l,Type3s[num].Coun90l);
				sprintf(anrc[written].Id,"%s",Type3s[num].Anrcl);
				sprintf(anrc[written].Tlid,"%s",Type3s[num].Tlid);
				anrc[written].Frlong = Type1s[num].Frlong;
				anrc[written].Frlat = Type1s[num].Frlat;
				anrc[written].Tolong = Type1s[num].Tolong;
				anrc[written].Tolat = Type1s[num].Tolat;
				anrc[written].Chosen = 0;
				anrc[written].Flip = 1;
				written++;				
			}
		if ((strcmp(Type3s[num].State90r,Curstate) == 0) && (strcmp(Type3s[num].Coun90r,Curcounty) == 0))
		  if (strcmp(Type3s[num].Anrcr,"  ") != 0)
			{//rightcase 
			//printf("\nright case");
				sprintf(anrc[written].County,"%s%s",Type3s[num].State90r,Type3s[num].Coun90r);
				sprintf(anrc[written].Id,"%s",Type3s[num].Anrcr);
				sprintf(anrc[written].Tlid,"%s",Type3s[num].Tlid);
				anrc[written].Frlong = Type1s[num].Frlong;
				anrc[written].Frlat = Type1s[num].Frlat;
				anrc[written].Tolong = Type1s[num].Tolong;
				anrc[written].Tolat = Type1s[num].Tolat;
				anrc[written].Chosen = 0;
				anrc[written].Flip = 0;
				written++;
			}
	}
	if (written > Polycounts[8])
	{
		Ptrdlg->ErrorMessage("the number of Alaska Native Regional Corporation border lines exceeds the count");				
		MissingFile = -1;
		return;
	}*/
	//time to chain	
	Ptrdlg->m_strProcess.Format("Gathering ANRC Boundary Lines");
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	qsort((void *)anrc,written,sizeof(Anrc_Border_Type),(compfn)CompareAnrc);
	FileMinX = FileMinY = LARGE;
	FileMaxX = FileMaxY = -LARGE;
	CurrentMinX = CurrentMinY = LARGE;
	CurrentMaxX = CurrentMaxY = -LARGE;
	curcase = 0;
	polyid = 1;
	Npts = 0; 
	nparts = 1;
	ptcount = 0;
	Build_db_Header(dbfout,0,dbAnrc);
	Build_db_FieldHeaders(dbfout,dbAnrc);
	anrcname = Get_TypeC_Name(5,anrc[curcase].Id,"");
	//sprintf(anrcrecord," %-8d%-5s%-2s%-66s",polyid,anrc[curcase].County,anrc[curcase].Id,
	//	anrcname);
	sprintf(anrcrecord," %-8d",polyid);
	sprintf(&anrcrecord[9],"%-5s",anrc[curcase].County);
	sprintf(&anrcrecord[14],"%-2s",anrc[curcase].Id);
	sprintf(&anrcrecord[16],"%-66s",anrcname);
	fwrite(&anrcrecord,sizeof(anrcrecord)-1,1,dbfout);
	if (anrc[0].Flip == 0)
	{
		curX = anrc[0].Tolong;
		curY = anrc[0].Tolat;		
		Pts[Npts].Longitude = anrc[curcase].Frlong;
		Pts[Npts].Latitude = anrc[curcase].Frlat;
		Npts++;
		Get_Shape_Points(anrc[curcase].Tlid, anrc[curcase].Flip);
		Pts[Npts].Longitude = anrc[curcase].Tolong;
		Pts[Npts].Latitude = anrc[curcase].Tolat;
		Npts++;
		anrc[curcase].Chosen = 1;		
	}
	else
	{
		curX = anrc[0].Frlong;
		curY = anrc[0].Frlat;		
		Pts[Npts].Longitude = anrc[curcase].Tolong;
		Pts[Npts].Latitude = anrc[curcase].Tolat;
		Npts++;
		Get_Shape_Points(anrc[curcase].Tlid, anrc[curcase].Flip);
		Pts[Npts].Longitude = anrc[curcase].Frlong;
		Pts[Npts].Latitude = anrc[curcase].Frlat;
		Npts++;
		anrc[curcase].Chosen = 1;		
	}
	ptcount += Npts;
	
    fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
	
	if (Pts[0].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < CurrentMinY)
		CurrentMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[0].Latitude;	
	if (Pts[0].Longitude < FileMinX)
		FileMinX = Pts[0].Longitude;
	if (Pts[0].Longitude > FileMaxX)
		FileMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < FileMinY)
		FileMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > FileMaxY)
		FileMaxY = Pts[0].Latitude;

	if (Pts[Npts-1].Longitude < CurrentMinX)
		CurrentMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < CurrentMinY)
		CurrentMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[Npts-1].Latitude;	
	if (Pts[Npts-1].Longitude < FileMinX)
		FileMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > FileMaxX)
		FileMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < FileMinY)
		FileMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > FileMaxY)
		FileMaxY = Pts[Npts-1].Latitude;		
	n = 1;
	steppos = (int)(n*100/written);	
	Ptrdlg->m_Progress.SetPos(steppos);
    while (n < written)
	{
		//printf("\n Have written %ld of %ld fpl boundary lines",n, written);
		sprintf(msg,"processed %d of %d records",n,written);
		Ptrdlg->SetDlgItemText(IDC_ANRC,msg);		
		found = 0;
		for (i = 1; i < written; i++)
         {
			Npts = 0;
			if (anrc[i].Chosen != 0)
				continue;
			if (anrc[i].Flip == 0)
			{
				if ((anrc[i].Frlong == curX) && (anrc[i].Frlat == curY))
				{                          
					if (strcmp(anrc[i].Id,anrc[curcase].Id) != 0)
						continue;	            
					Get_Shape_Points(anrc[i].Tlid,anrc[i].Flip);
					Pts[Npts].Longitude = anrc[i].Tolong;
					Pts[Npts].Latitude = anrc[i].Tolat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					anrc[i].Chosen = 1;            
					found = 1;                      
					curX = anrc[i].Tolong;
					curY = anrc[i].Tolat;                
					curcase = i;
					break;
				}
			}
			else
			{
				if ((anrc[i].Tolong == curX) && (anrc[i].Tolat == curY))
				{
					if (strcmp(anrc[i].Id,anrc[curcase].Id) != 0)
						continue;	            
					Get_Shape_Points(anrc[i].Tlid,anrc[i].Flip);
					Pts[Npts].Longitude = anrc[i].Frlong;
					Pts[Npts].Latitude = anrc[i].Frlat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = anrc[i].Frlong;
					curY = anrc[i].Frlat;                        
					anrc[i].Chosen = 1;	
					found = 1;          
					curcase = i;
					break;
				}
			}
        }//close for loop
		if (found == 0) //initialize new case, eg, new ring or new poly
		{			
			fwrite(&ptcount,sizeof(int),1,headtemp);
			ptcount = 0;
			for (i = 0; i < written; i++) //check for new ring in poly
            {                    
         		if (anrc[i].Chosen != 0)
					continue;             		
				if (strcmp(anrc[i].Id, anrc[curcase].Id) != 0)
					continue;
				//if we get here it is a new ring in current poly
				found = 1;
				nparts++;
				Npts = 0;
				if (anrc[i].Flip == 0)
				{
					Pts[Npts].Longitude = anrc[i].Frlong;
					Pts[Npts].Latitude = anrc[i].Frlat;
					Npts++;
					Get_Shape_Points(anrc[i].Tlid,anrc[i].Flip);
					Pts[Npts].Longitude = anrc[i].Tolong;
					Pts[Npts].Latitude = anrc[i].Tolat;
					Npts++;			
    				n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					anrc[i].Chosen = 1;
    		   		curX = anrc[i].Tolong;
    				curY = anrc[i].Tolat;
					curcase = i;
					break;
				}
				else
				{
					Pts[Npts].Longitude = anrc[i].Tolong;
					Pts[Npts].Latitude = anrc[i].Tolat;
					Npts++;
					Get_Shape_Points(anrc[i].Tlid,anrc[i].Flip);
					Pts[Npts].Longitude = anrc[i].Frlong;
					Pts[Npts].Latitude = anrc[i].Frlat;
					Npts++;			
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					anrc[i].Chosen = 1;
    		   		curX = anrc[i].Frlong;
    				curY = anrc[i].Frlat;
					curcase = i;
					break;
				}
    		}
    	}
		if (found == 0) // new poly, first ring
		{
			
			fwrite(&nparts,sizeof(int),1,partstemp);
			nparts = 1;
			fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
			CurrentMinX = CurrentMinY = LARGE;
			CurrentMaxX = CurrentMaxY = -LARGE;

			for (i = 0; i < written; i++)//first check for new ring in current poly
            {                    
         		if (anrc[i].Chosen != 0)
					continue;             
				polyid++;				
				anrcname = Get_TypeC_Name(5,anrc[i].Id,"");
	//			sprintf(anrcrecord," %-8d%-5s%-2s%-66s",polyid,anrc[i].County,anrc[i].Id,
	//				anrcname);
				sprintf(anrcrecord," %-8d",polyid);
				sprintf(&anrcrecord[9],"%-5s",anrc[i].County);
				sprintf(&anrcrecord[14],"%-2s",anrc[i].Id);
				sprintf(&anrcrecord[16],"%-66s",anrcname);
	
				//sprintf(anrcrecord," %-8d%-5s%-2s",polyid,anrc[i].County,anrc[i].Id);
				fwrite(&anrcrecord,sizeof(anrcrecord)-1,1,dbfout);    		
				Npts = 0;
				if (anrc[i].Flip == 0)
				{
					Pts[Npts].Longitude = anrc[i].Frlong;
					Pts[Npts].Latitude = anrc[i].Frlat;
					Npts++;
					Get_Shape_Points(anrc[i].Tlid,anrc[i].Flip);
					Pts[Npts].Longitude = anrc[i].Tolong;
					Pts[Npts].Latitude = anrc[i].Tolat;
					Npts++;					
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					anrc[i].Chosen = 1;            
					found = 1;                      
					curX = anrc[i].Tolong;
					curY = anrc[i].Tolat;                
					curcase = i;
					break;					
				}
				else
				{
					Pts[Npts].Longitude = anrc[i].Tolong;
					Pts[Npts].Latitude = anrc[i].Tolat;
					Npts++;
					Get_Shape_Points(anrc[i].Tlid,anrc[i].Flip);
					Pts[Npts].Longitude = anrc[i].Frlong;
					Pts[Npts].Latitude = anrc[i].Frlat;
					Npts++;				
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = anrc[i].Frlong;
					curY = anrc[i].Frlat;                        
					anrc[i].Chosen = 1;		
					found = 1;          
					curcase = i;	
					break;					
				}	
			}
		}
		//by now found should be 1
		if (found == 0)
		{
			info.Format("ERROR - found is zero");
			Ptrdlg->ErrorMessage(info);									
			MissingFile = -1;
			return;
		}
		ptcount += Npts;
		fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
		if (Pts[0].Longitude < CurrentMinX)
			CurrentMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < CurrentMinY)
			CurrentMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[0].Latitude;	
		if (Pts[0].Longitude < FileMinX)
			FileMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > FileMaxX)
			FileMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < FileMinY)
			FileMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > FileMaxY)
			FileMaxY = Pts[0].Latitude;

		if (Pts[Npts-1].Longitude < CurrentMinX)
			CurrentMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < CurrentMinY)
			CurrentMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[Npts-1].Latitude;	
		if (Pts[Npts-1].Longitude < FileMinX)
			FileMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > FileMaxX)
			FileMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < FileMinY)
			FileMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > FileMaxY)
			FileMaxY = Pts[Npts-1].Latitude;		
	}//close while loop
	fwrite(&ptcount,sizeof(int),1,headtemp);
	fwrite(&nparts,sizeof(int),1,partstemp);
	fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
	fclose(boxtemp);
	fclose(headtemp);
	fclose(ptstemp);
	fclose(partstemp);
	sprintf(msg,"processed %d of %d records",n,written);
	Ptrdlg->SetDlgItemText(IDC_ANRC,msg);		
	//printf("\n Have written %ld of %ld fpl boundary lines",n, written);
	write_eof(dbfout);
	rewind(dbfout);
	Build_db_Header(dbfout,polyid,dbAnrc);
	Build_Poly_Shape("arc");
	Ptrdlg->m_strAnrc.Format("%d Alaska Regional Corporations",polyid);
	Ptrdlg->SetDlgItemText(IDC_ANRC,Ptrdlg->m_strAnrc);
    fclose(dbfout);
	free(anrc);
	fprintf(LOG,"Wrote %d Alaska Regional Corporation polygons to shape %s%sarc\n", polyid,
		Outfilepath,Outfiletitle);		
}
void Match_Poly_Lines_Kgl()
{
	int polyid, found, i, nparts, ptcount;
	long num, n, written, curcase;
	Kgl_Border_Type *kgl;
	double  curX, curY;	
    FILE  *dbfout, *ptstemp, *headtemp, *partstemp, *boxtemp; 
	CString info, fname, errmsg;	
	char kglrecord[58]; //size of fpl dbrecord + 2
	int steppos;
	char msg[100];
//	FILE *addtab;
//	char addrecord[99]; 
//	int featnum;
	
	if (Polycounts[0] == 0)
	{
		Ptrdlg->SetDlgItemText(IDC_KGL,"No Such Cases");		
		return;
	}
		
	fname.Format("%s%skgl.dbf",Outfilepath,Outfiletitle);			
	dbfout = fopen(fname,"wb");
	if (dbfout == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	ptstemp = fopen("pts.tmp","wb");
	if (ptstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	headtemp = fopen("head.tmp","wb");
	if (headtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	boxtemp = fopen("box.tmp","wb");
	if (boxtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	partstemp = fopen("parts.tmp","wb");
	if (partstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	kgl = (Kgl_Border_Type *)calloc(Polycounts[0],sizeof(Kgl_Border_Type));
	written = 0;
	for (num = 0; num < CountI; num++)
	{
		if (TypeIs[num].Kgll == TypeIs[num].Kglr)
			continue;		
		
		if (TypeIs[num].Kgll >= 0)
			{//left case
				sprintf(kgl[written].County,"%s%s",TypeIs[num].State,TypeIs[num].County);
				kgl[written].Polyid = TypeIs[num].Kgll;
				sprintf(kgl[written].Tlid,"%s",TypeIs[num].Tlid);
				kgl[written].Frlong = Type1s[num].Frlong;
				kgl[written].Frlat = Type1s[num].Frlat;
				kgl[written].Tolong = Type1s[num].Tolong;
				kgl[written].Tolat = Type1s[num].Tolat;
				kgl[written].Chosen = 0;
				kgl[written].Flip = 1;
				written++;
			}
		if (TypeIs[num].Kglr >= 0)
			{//rightcase 
			//printf("\nright case");
				sprintf(kgl[written].County,"%s%s",TypeIs[num].State,TypeIs[num].County);
				kgl[written].Polyid = TypeIs[num].Kglr;
				sprintf(kgl[written].Tlid,"%s",TypeIs[num].Tlid);
				kgl[written].Frlong = Type1s[num].Frlong;
				kgl[written].Frlat = Type1s[num].Frlat;
				kgl[written].Tolong = Type1s[num].Tolong;
				kgl[written].Tolat = Type1s[num].Tolat;
				kgl[written].Chosen = 0;
				kgl[written].Flip = 0;
				written++;
			}
	}
	if (written > Polycounts[0])
	{
		Ptrdlg->ErrorMessage("the number of Key Geographic Location border lines exceeds the count");				
		MissingFile = -1;
		return;
	}
	//time to chain
	Ptrdlg->m_strProcess.Format("Gathering KGL Boundary Lines");
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	qsort((void *)kgl,written,sizeof(Kgl_Border_Type),(compfn)CompareKgl);
	FileMinX = FileMinY = LARGE;
	FileMaxX = FileMaxY = -LARGE;
	CurrentMinX = CurrentMinY = LARGE;
	CurrentMaxX = CurrentMaxY = -LARGE;
	curcase = 0;
	polyid = 1;
	Npts = 0; 
	nparts = 1;
	ptcount = 0;
	Build_db_Header(dbfout,0,dbKgl);
	Build_db_FieldHeaders(dbfout,dbKgl);
    /*sprintf(kglrecord," %-8d%-10d%-5s%-3s%-30s",polyid,atoi(Type9s[kgl[curcase].Polyid].Polyid),
		kgl[curcase].County,Type9s[kgl[curcase].Polyid].Cfcc, 
		Type9s[kgl[curcase].Polyid].Kglname);*/
	sprintf(kglrecord," %-8d",polyid);
	sprintf(&kglrecord[9],"%-10d",atoi(Type9s[kgl[curcase].Polyid].Polyid));
	sprintf(&kglrecord[19],"%-5s",kgl[curcase].County);
	sprintf(&kglrecord[24],"%-3s",Type9s[kgl[curcase].Polyid].Cfcc);
	sprintf(&kglrecord[27],"%-30s",Type9s[kgl[curcase].Polyid].Kglname);
	fwrite(&kglrecord,sizeof(kglrecord)-1,1,dbfout);
	if (kgl[0].Flip == 0)
	{
		curX = kgl[0].Tolong;
		curY = kgl[0].Tolat;		
		Pts[Npts].Longitude = kgl[curcase].Frlong;
		Pts[Npts].Latitude = kgl[curcase].Frlat;
		Npts++;
		Get_Shape_Points(kgl[curcase].Tlid, kgl[curcase].Flip);
		Pts[Npts].Longitude = kgl[curcase].Tolong;
		Pts[Npts].Latitude = kgl[curcase].Tolat;
		Npts++;
		kgl[curcase].Chosen = 1;		
	}
	else
	{
		curX = kgl[0].Frlong;
		curY = kgl[0].Frlat;		
		Pts[Npts].Longitude = kgl[curcase].Tolong;
		Pts[Npts].Latitude = kgl[curcase].Tolat;
		Npts++;
		Get_Shape_Points(kgl[curcase].Tlid, kgl[curcase].Flip);
		Pts[Npts].Longitude = kgl[curcase].Frlong;
		Pts[Npts].Latitude = kgl[curcase].Frlat;
		Npts++;
		kgl[curcase].Chosen = 1;		
	}
	ptcount += Npts;
	
    fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
	
	if (Pts[0].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < CurrentMinY)
		CurrentMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[0].Latitude;	
	if (Pts[0].Longitude < FileMinX)
		FileMinX = Pts[0].Longitude;
	if (Pts[0].Longitude > FileMaxX)
		FileMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < FileMinY)
		FileMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > FileMaxY)
		FileMaxY = Pts[0].Latitude;

	if (Pts[Npts-1].Longitude < CurrentMinX)
		CurrentMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < CurrentMinY)
		CurrentMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[Npts-1].Latitude;	
	if (Pts[Npts-1].Longitude < FileMinX)
		FileMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > FileMaxX)
		FileMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < FileMinY)
		FileMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > FileMaxY)
		FileMaxY = Pts[Npts-1].Latitude;		
	n = 1;
	steppos = (int)(n*100/written);	
	Ptrdlg->m_Progress.SetPos(steppos);
    while (n < written)
	{
		//printf("\n Have written %ld of %ld fpl boundary lines",n, written);
		sprintf(msg,"processed %d of %d records",n,written);
		Ptrdlg->SetDlgItemText(IDC_KGL,msg);		
		found = 0;
		for (i = 1; i < written; i++)
         {
			Npts = 0;
			if (kgl[i].Chosen != 0)
				continue;
			if (kgl[i].Flip == 0)
			{
				if ((kgl[i].Frlong == curX) && (kgl[i].Frlat == curY))
				{                          
					if (kgl[i].Polyid != kgl[curcase].Polyid) 
						continue;	            
					Get_Shape_Points(kgl[i].Tlid,kgl[i].Flip);
					Pts[Npts].Longitude = kgl[i].Tolong;
					Pts[Npts].Latitude = kgl[i].Tolat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					kgl[i].Chosen = 1;            
					found = 1;                      
					curX = kgl[i].Tolong;
					curY = kgl[i].Tolat;                
					curcase = i;
					break;
				}
			}
			else
			{
				if ((kgl[i].Tolong == curX) && (kgl[i].Tolat == curY))
				{
					if (kgl[i].Polyid != kgl[curcase].Polyid)
						continue;	            
					Get_Shape_Points(kgl[i].Tlid,kgl[i].Flip);
					Pts[Npts].Longitude = kgl[i].Frlong;
					Pts[Npts].Latitude = kgl[i].Frlat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = kgl[i].Frlong;
					curY = kgl[i].Frlat;                        
					kgl[i].Chosen = 1;	
					found = 1;          
					curcase = i;
					break;
				}
			}
        }//close for loop
		if (found == 0) //initialize new case, eg, new ring or new poly
		{			
			fwrite(&ptcount,sizeof(int),1,headtemp);
			ptcount = 0;
			for (i = 0; i < written; i++) //check for new ring in poly
            {                    
         		if (kgl[i].Chosen != 0)
					continue;             		
				if (kgl[i].Polyid != kgl[curcase].Polyid)
					continue;
				//if we get here it is a new ring in current poly
				found = 1;
				nparts++;
				Npts = 0;
				if (kgl[i].Flip == 0)
				{
					Pts[Npts].Longitude = kgl[i].Frlong;
					Pts[Npts].Latitude = kgl[i].Frlat;
					Npts++;
					Get_Shape_Points(kgl[i].Tlid,kgl[i].Flip);
					Pts[Npts].Longitude = kgl[i].Tolong;
					Pts[Npts].Latitude = kgl[i].Tolat;
					Npts++;			
    				n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					kgl[i].Chosen = 1;
    		   		curX = kgl[i].Tolong;
    				curY = kgl[i].Tolat;
					curcase = i;
					break;
				}
				else
				{
					Pts[Npts].Longitude = kgl[i].Tolong;
					Pts[Npts].Latitude = kgl[i].Tolat;
					Npts++;
					Get_Shape_Points(kgl[i].Tlid,kgl[i].Flip);
					Pts[Npts].Longitude = kgl[i].Frlong;
					Pts[Npts].Latitude = kgl[i].Frlat;
					Npts++;			
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					kgl[i].Chosen = 1;
    		   		curX = kgl[i].Frlong;
    				curY = kgl[i].Frlat;
					curcase = i;
					break;
				}
    		}
    	}
		if (found == 0) // new poly, first ring
		{
			
			fwrite(&nparts,sizeof(int),1,partstemp);
			nparts = 1;
			fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
			CurrentMinX = CurrentMinY = LARGE;
			CurrentMaxX = CurrentMaxY = -LARGE;

			for (i = 0; i < written; i++)//first check for new ring in current poly
            {                    
         		if (kgl[i].Chosen != 0)
					continue;             
				polyid++;
				/*sprintf(kglrecord," %-8d%-10d%-5s%-3s%-30s",polyid,
					atoi(Type9s[kgl[i].Polyid].Polyid),kgl[i].County,Type9s[kgl[i].Polyid].Cfcc,
					Type9s[kgl[i].Polyid].Kglname);				*/
				sprintf(kglrecord," %-8d",polyid);
				sprintf(&kglrecord[9],"%-10d",atoi(Type9s[kgl[i].Polyid].Polyid));
				sprintf(&kglrecord[19],"%-5s",kgl[i].County);
				sprintf(&kglrecord[24],"%-3s",Type9s[kgl[i].Polyid].Cfcc);
				sprintf(&kglrecord[27],"%-30s",Type9s[kgl[i].Polyid].Kglname);
				fwrite(&kglrecord,sizeof(kglrecord)-1,1,dbfout);    		
				Npts = 0;
				if (kgl[i].Flip == 0)
				{
					Pts[Npts].Longitude = kgl[i].Frlong;
					Pts[Npts].Latitude = kgl[i].Frlat;
					Npts++;
					Get_Shape_Points(kgl[i].Tlid,kgl[i].Flip);
					Pts[Npts].Longitude = kgl[i].Tolong;
					Pts[Npts].Latitude = kgl[i].Tolat;
					Npts++;					
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					kgl[i].Chosen = 1;            
					found = 1;                      
					curX = kgl[i].Tolong;
					curY = kgl[i].Tolat;                
					curcase = i;
					break;					
				}
				else
				{
					Pts[Npts].Longitude = kgl[i].Tolong;
					Pts[Npts].Latitude = kgl[i].Tolat;
					Npts++;
					Get_Shape_Points(kgl[i].Tlid,kgl[i].Flip);
					Pts[Npts].Longitude = kgl[i].Frlong;
					Pts[Npts].Latitude = kgl[i].Frlat;
					Npts++;				
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = kgl[i].Frlong;
					curY = kgl[i].Frlat;                        
					kgl[i].Chosen = 1;		
					found = 1;          
					curcase = i;	
					break;					
				}	
			}
		}
		//by now found should be 1
		if (found == 0)
		{
			info.Format("ERROR - found is zero");
			Ptrdlg->ErrorMessage(info);									
			MissingFile = -1;
			return;
		}
		ptcount += Npts;
		fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
		if (Pts[0].Longitude < CurrentMinX)
			CurrentMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < CurrentMinY)
			CurrentMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[0].Latitude;	
		if (Pts[0].Longitude < FileMinX)
			FileMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > FileMaxX)
			FileMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < FileMinY)
			FileMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > FileMaxY)
			FileMaxY = Pts[0].Latitude;

		if (Pts[Npts-1].Longitude < CurrentMinX)
			CurrentMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < CurrentMinY)
			CurrentMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[Npts-1].Latitude;	
		if (Pts[Npts-1].Longitude < FileMinX)
			FileMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > FileMaxX)
			FileMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < FileMinY)
			FileMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > FileMaxY)
			FileMaxY = Pts[Npts-1].Latitude;		
	}//close while loop
	fwrite(&ptcount,sizeof(int),1,headtemp);
	fwrite(&nparts,sizeof(int),1,partstemp);
	fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
	fclose(boxtemp);
	fclose(headtemp);
	fclose(ptstemp);
	fclose(partstemp);
	sprintf(msg,"processed %d of %d records",n,written);
	Ptrdlg->SetDlgItemText(IDC_KGL,msg);		
	//printf("\n Have written %ld of %ld fpl boundary lines",n, written);
	write_eof(dbfout);
	rewind(dbfout);
	Build_db_Header(dbfout,polyid,dbKgl);
	//AfxMessageBox("have written kgl dbf file");
	//AfxMessageBox("calling build poly shape");
	Build_Poly_Shape("kgl");
	Ptrdlg->m_strKgl.Format("%d Key Geographic Locations",polyid);
	Ptrdlg->SetDlgItemText(IDC_KGL,Ptrdlg->m_strKgl);
    fclose(dbfout);
	free(kgl);
	fprintf(LOG,"Wrote %d Key Geographic Location polygons to shape %s%skgl\n", polyid, Outfilepath,
		Outfiletitle);		
}
void KglAdd()
{
	FILE *dbfout;
	char addrecord[100];
	CString fname, errmsg;
	int featnum;
	CString repval;
	fname.Format("%s%sadd.dbf",Outfilepath,Outfiletitle);			
	dbfout = fopen(fname,"wb");
	if (dbfout == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	//this section is needed to write out the address matching table
	//AfxMessageBox("writing file");
	Build_db_Header(dbfout,0,dbKgladd);
	Build_db_FieldHeaders(dbfout,dbKgladd);
    
	//fwrite(&kglrecord,sizeof(kglrecord)-1,1,dbfout);
	int count  = 0;
	for (int i = 0; i < Count9; i++)
	{
		//sprintf(msg,"i = %d",i);
		//AfxMessageBox(i);
	
		if (strcmp(Type9s[i].Feat,"        ") == 0)
			continue;
		featnum = Get_Feature(Type9s[i].Feat);
		if (featnum >= 0)		
		{
			//sprintf(addrecord," %-10d%-30s%-11s%-2s%-30s%-4s%-2s%-5s%-4s",atoi(Type9s[i].Polyid),
			//	Type9s[i].Kglname,Type9s[i].Kgladd,Type5s[featnum].Fedirp,Type5s[featnum].Fename,
			//	Type5s[featnum].Fetype,Type5s[featnum].Fedirs,Type9s[i].Kglzip,Type9s[i].Kglzip4);
			sprintf(addrecord," %-10d",atoi(Type9s[i].Polyid));
			sprintf(&addrecord[11],"%-30s",Type9s[i].Kglname);
			sprintf(&addrecord[41],"%-11s",Type9s[i].Kgladd);
			sprintf(&addrecord[52],"%-2s",Type5s[featnum].Fedirp);
			sprintf(&addrecord[54],"%-30s",Type5s[featnum].Fename);
			sprintf(&addrecord[84],"%-4s",Type5s[featnum].Fetype);
			sprintf(&addrecord[88],"%-2s",Type5s[featnum].Fedirs);
			sprintf(&addrecord[90],"%-5s",Type9s[i].Kglzip);
			sprintf(&addrecord[95],"%-4s",Type9s[i].Kglzip4);
		}

		count++;
		fwrite(&addrecord,sizeof(addrecord)-1,1,dbfout);
	}
	write_eof(dbfout);
	rewind(dbfout);
	Build_db_Header(dbfout,count,dbKgladd);
	fclose(dbfout);
	fprintf(LOG,"Wrote %d Key Geographic Location address records to file %s\n", count, fname);		
}		
void Match_Poly_Lines_Land()
{
	int polyid, found, i, nparts, ptcount;
	long num, n, written, curcase;
	Land_Border_Type *land;
	double  curX, curY;	
    FILE  *dbfout, *ptstemp, *headtemp, *partstemp, *boxtemp; 
	CString info, fname, errmsg;	
	char landrecord[68]; //size of fpl dbrecord + 2
	int steppos;
	char msg[100];
	int landid;

	
	if (Polycounts[0] == 0)
	{
		Ptrdlg->SetDlgItemText(IDC_LANDPOLY,"No Such Cases");		
		return;
	}
		
	fname.Format("%s%slpy.dbf",Outfilepath,Outfiletitle);			
	dbfout = fopen(fname,"wb");
	if (dbfout == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	ptstemp = fopen("pts.tmp","wb");
	if (ptstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	headtemp = fopen("head.tmp","wb");
	if (headtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	boxtemp = fopen("box.tmp","wb");
	if (boxtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	partstemp = fopen("parts.tmp","wb");
	if (partstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	land = (Land_Border_Type *)calloc(Polycounts[0],sizeof(Land_Border_Type));
	written = 0;
	for (num = 0; num < CountI; num++)
	{
		if (TypeIs[num].Landl == TypeIs[num].Landr)
			continue;		
		
		if (TypeIs[num].Landl >= 0)
			{//left case
				sprintf(land[written].County,"%s%s",TypeIs[num].State,TypeIs[num].County);
				land[written].Polyid = TypeIs[num].Landl;
				sprintf(land[written].Tlid,"%s",TypeIs[num].Tlid);
				land[written].Frlong = Type1s[num].Frlong;
				land[written].Frlat = Type1s[num].Frlat;
				land[written].Tolong = Type1s[num].Tolong;
				land[written].Tolat = Type1s[num].Tolat;
				land[written].Chosen = 0;
				land[written].Flip = 1;
				written++;
			}
		if (TypeIs[num].Landr >= 0)
			{//rightcase 
			//printf("\nright case");
				sprintf(land[written].County,"%s%s",TypeIs[num].State,TypeIs[num].County);
				land[written].Polyid = TypeIs[num].Landr;		
				sprintf(land[written].Tlid,"%s",TypeIs[num].Tlid);
				land[written].Frlong = Type1s[num].Frlong;
				land[written].Frlat = Type1s[num].Frlat;
				land[written].Tolong = Type1s[num].Tolong;
				land[written].Tolat = Type1s[num].Tolat;
				land[written].Chosen = 0;
				land[written].Flip = 0;
				written++;
			}
	}
	if (written > Polycounts[0])
	{
		Ptrdlg->ErrorMessage("the number of Landmark border lines exceeds the count");				
		MissingFile = -1;
		return;
	}
	//time to chain	
	Ptrdlg->m_strProcess.Format("Gathering Landmark Boundary Lines");
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	qsort((void *)land,written,sizeof(Land_Border_Type),(compfn)CompareLand);
	FileMinX = FileMinY = LARGE;
	FileMaxX = FileMaxY = -LARGE;
	CurrentMinX = CurrentMinY = LARGE;
	CurrentMaxX = CurrentMaxY = -LARGE;
	curcase = 0;
	polyid = 1;
	Npts = 0; 
	nparts = 1;
	ptcount = 0;
	Build_db_Header(dbfout,0,dbLand);
	Build_db_FieldHeaders(dbfout,dbLand);	
	landid = Get_Land7(Type8s[land[curcase].Polyid].Land); //returns the seqnum of in land list of this case
	//sprintf(landrecord," %-8d%-10d%-5s%-3s%-30s%-10d",polyid,atoi(Type8s[land[curcase].Polyid].Polyid),
	//	land[curcase].County,Type7s[landid].Cfcc,Type7s[landid].Laname,Type8s[land[curcase].Polyid].Land);
	sprintf(landrecord," %-8d", polyid);
	sprintf(&landrecord[9],"%-10d",atoi(Type8s[land[curcase].Polyid].Polyid));
	sprintf(&landrecord[19],"%-5s",land[curcase].County);
	sprintf(&landrecord[24],"%-3s",Type7s[landid].Cfcc);
	sprintf(&landrecord[27],"%-30s",Type7s[landid].Laname);
	sprintf(&landrecord[57],"%-10d",Type8s[land[curcase].Polyid].Land);
    fwrite(&landrecord,sizeof(landrecord)-1,1,dbfout);
	if (land[0].Flip == 0)
	{
		curX = land[0].Tolong;
		curY = land[0].Tolat;		
		Pts[Npts].Longitude = land[curcase].Frlong;
		Pts[Npts].Latitude = land[curcase].Frlat;
		Npts++;
		Get_Shape_Points(land[curcase].Tlid, land[curcase].Flip);
		Pts[Npts].Longitude = land[curcase].Tolong;
		Pts[Npts].Latitude = land[curcase].Tolat;
		Npts++;
		land[curcase].Chosen = 1;		
	}
	else
	{
		curX = land[0].Frlong;
		curY = land[0].Frlat;		
		Pts[Npts].Longitude = land[curcase].Tolong;
		Pts[Npts].Latitude = land[curcase].Tolat;
		Npts++;
		Get_Shape_Points(land[curcase].Tlid, land[curcase].Flip);
		Pts[Npts].Longitude = land[curcase].Frlong;
		Pts[Npts].Latitude = land[curcase].Frlat;
		Npts++;
		land[curcase].Chosen = 1;		
	}
	ptcount += Npts;
	
    fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
	
	if (Pts[0].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < CurrentMinY)
		CurrentMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[0].Latitude;	
	if (Pts[0].Longitude < FileMinX)
		FileMinX = Pts[0].Longitude;
	if (Pts[0].Longitude > FileMaxX)
		FileMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < FileMinY)
		FileMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > FileMaxY)
		FileMaxY = Pts[0].Latitude;

	if (Pts[Npts-1].Longitude < CurrentMinX)
		CurrentMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < CurrentMinY)
		CurrentMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[Npts-1].Latitude;	
	if (Pts[Npts-1].Longitude < FileMinX)
		FileMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > FileMaxX)
		FileMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < FileMinY)
		FileMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > FileMaxY)
		FileMaxY = Pts[Npts-1].Latitude;		
	n = 1;
	steppos = (int)(n*100/written);	
	Ptrdlg->m_Progress.SetPos(steppos);
    while (n < written)
	{
		//printf("\n Have written %ld of %ld fpl boundary lines",n, written);
		sprintf(msg,"processed %d of %d records",n,written);
		Ptrdlg->SetDlgItemText(IDC_LANDPOLY,msg);		
		found = 0;
		for (i = 1; i < written; i++)
         {
			Npts = 0;
			if (land[i].Chosen != 0)
				continue;
			if (land[i].Flip == 0)
			{
				if ((land[i].Frlong == curX) && (land[i].Frlat == curY))
				{                          
					if (land[i].Polyid != land[curcase].Polyid) 
						continue;	            
					Get_Shape_Points(land[i].Tlid,land[i].Flip);
					Pts[Npts].Longitude = land[i].Tolong;
					Pts[Npts].Latitude = land[i].Tolat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					land[i].Chosen = 1;            
					found = 1;                      
					curX = land[i].Tolong;
					curY = land[i].Tolat;                
					curcase = i;
					break;
				}
			}
			else
			{
				if ((land[i].Tolong == curX) && (land[i].Tolat == curY))
				{
					if (land[i].Polyid != land[curcase].Polyid)
						continue;	            
					Get_Shape_Points(land[i].Tlid,land[i].Flip);
					Pts[Npts].Longitude = land[i].Frlong;
					Pts[Npts].Latitude = land[i].Frlat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = land[i].Frlong;
					curY = land[i].Frlat;                        
					land[i].Chosen = 1;	
					found = 1;          
					curcase = i;
					break;
				}
			}
        }//close for loop
		if (found == 0) //initialize new case, eg, new ring or new poly
		{			
			fwrite(&ptcount,sizeof(int),1,headtemp);
			ptcount = 0;
			for (i = 0; i < written; i++) //check for new ring in poly
            {                    
         		if (land[i].Chosen != 0)
					continue;             		
				if (land[i].Polyid != land[curcase].Polyid)
					continue;
				//if we get here it is a new ring in current poly
				found = 1;
				nparts++;
				Npts = 0;
				if (land[i].Flip == 0)
				{
					Pts[Npts].Longitude = land[i].Frlong;
					Pts[Npts].Latitude = land[i].Frlat;
					Npts++;
					Get_Shape_Points(land[i].Tlid,land[i].Flip);
					Pts[Npts].Longitude = land[i].Tolong;
					Pts[Npts].Latitude = land[i].Tolat;
					Npts++;			
    				n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					land[i].Chosen = 1;
    		   		curX = land[i].Tolong;
    				curY = land[i].Tolat;
					curcase = i;
					break;
				}
				else
				{
					Pts[Npts].Longitude = land[i].Tolong;
					Pts[Npts].Latitude = land[i].Tolat;
					Npts++;
					Get_Shape_Points(land[i].Tlid,land[i].Flip);
					Pts[Npts].Longitude = land[i].Frlong;
					Pts[Npts].Latitude = land[i].Frlat;
					Npts++;			
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					land[i].Chosen = 1;
    		   		curX = land[i].Frlong;
    				curY = land[i].Frlat;
					curcase = i;
					break;
				}
    		}
    	}
		if (found == 0) // new poly, first ring
		{
			
			fwrite(&nparts,sizeof(int),1,partstemp);
			nparts = 1;
			fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
			CurrentMinX = CurrentMinY = LARGE;
			CurrentMaxX = CurrentMaxY = -LARGE;

			for (i = 0; i < written; i++)//first check for new ring in current poly
            {                    
         		if (land[i].Chosen != 0)
					continue;             
				polyid++;
				landid = Get_Land7(Type8s[land[i].Polyid].Land); //returns the seqnum of in land list of this case
				//sprintf(landrecord," %-8d%-10d%-5s%-3s%-30s%-10d",polyid,
				//	atoi(Type8s[land[i].Polyid].Polyid),land[i].County,
				//	Type7s[landid].Cfcc,Type7s[landid].Laname,
				//	Type8s[land[i].Polyid].Land);	
				sprintf(landrecord," %-8d", polyid);
				sprintf(&landrecord[9],"%-10d",atoi(Type8s[land[i].Polyid].Polyid));
				sprintf(&landrecord[19],"%-5s",land[i].County);
				sprintf(&landrecord[24],"%-3s",Type7s[landid].Cfcc);
				sprintf(&landrecord[27],"%-30s",Type7s[landid].Laname);
				sprintf(&landrecord[57],"%-10d",Type8s[land[i].Polyid].Land);
    
				fwrite(&landrecord,sizeof(landrecord)-1,1,dbfout);    		
				Npts = 0;
				if (land[i].Flip == 0)
				{
					Pts[Npts].Longitude = land[i].Frlong;
					Pts[Npts].Latitude = land[i].Frlat;
					Npts++;
					Get_Shape_Points(land[i].Tlid,land[i].Flip);
					Pts[Npts].Longitude = land[i].Tolong;
					Pts[Npts].Latitude = land[i].Tolat;
					Npts++;					
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					land[i].Chosen = 1;            
					found = 1;                      
					curX = land[i].Tolong;
					curY = land[i].Tolat;                
					curcase = i;
					break;					
				}
				else
				{
					Pts[Npts].Longitude = land[i].Tolong;
					Pts[Npts].Latitude = land[i].Tolat;
					Npts++;
					Get_Shape_Points(land[i].Tlid,land[i].Flip);
					Pts[Npts].Longitude = land[i].Frlong;
					Pts[Npts].Latitude = land[i].Frlat;
					Npts++;				
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = land[i].Frlong;
					curY = land[i].Frlat;                        
					land[i].Chosen = 1;		
					found = 1;          
					curcase = i;	
					break;					
				}	
			}
		}
		//by now found should be 1
		if (found == 0)
		{
			info.Format("ERROR - found is zero");
			Ptrdlg->ErrorMessage(info);									
			MissingFile = -1;
			return;
		}
		ptcount += Npts;
		fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
		if (Pts[0].Longitude < CurrentMinX)
			CurrentMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < CurrentMinY)
			CurrentMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[0].Latitude;	
		if (Pts[0].Longitude < FileMinX)
			FileMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > FileMaxX)
			FileMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < FileMinY)
			FileMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > FileMaxY)
			FileMaxY = Pts[0].Latitude;

		if (Pts[Npts-1].Longitude < CurrentMinX)
			CurrentMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < CurrentMinY)
			CurrentMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[Npts-1].Latitude;	
		if (Pts[Npts-1].Longitude < FileMinX)
			FileMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > FileMaxX)
			FileMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < FileMinY)
			FileMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > FileMaxY)
			FileMaxY = Pts[Npts-1].Latitude;		
	}//close while loop
	fwrite(&ptcount,sizeof(int),1,headtemp);
	fwrite(&nparts,sizeof(int),1,partstemp);
	fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
	fclose(boxtemp);
	fclose(headtemp);
	fclose(ptstemp);
	fclose(partstemp);
	sprintf(msg,"processed %d of %d records",n,written);
	Ptrdlg->SetDlgItemText(IDC_LANDPOLY,msg);		
	//printf("\n Have written %ld of %ld fpl boundary lines",n, written);
	write_eof(dbfout);
	rewind(dbfout);
	Build_db_Header(dbfout,polyid,dbLand);
	Build_Poly_Shape("lpy");
	Ptrdlg->m_strLandpoly.Format("%d Landmark Polygons",polyid);
	Ptrdlg->SetDlgItemText(IDC_LANDPOLY,Ptrdlg->m_strLandpoly);
    fclose(dbfout);
	free(land);
	fprintf(LOG,"Wrote %d Landmark polygons to shape %s%slpy\n", polyid,Outfilepath,
		Outfiletitle);		
}
void Match_Poly_Lines_Taz()
{
	int polyid, found, i, nparts, ptcount;
	long num, n, written, curcase;
	Taz_Border_Type *taz;
	double  curX, curY;	
    FILE  *dbfout, *ptstemp, *headtemp, *partstemp, *boxtemp; 
	CString info, fname, errmsg;	
	char tazrecord[25]; //size of fpl dbrecord + 2
	int steppos;
	char msg[100];
	int doleft, doright;
//	int tazid;

	
	if (APolycounts[7] == 0)
	{
		Ptrdlg->SetDlgItemText(IDC_TAZ,"No Such Cases");		
		return;
	}	
	fname.Format("%s%staz.dbf",Outfilepath,Outfiletitle);			
	dbfout = fopen(fname,"wb");
	if (dbfout == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	ptstemp = fopen("pts.tmp","wb");
	if (ptstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	headtemp = fopen("head.tmp","wb");
	if (headtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	boxtemp = fopen("box.tmp","wb");
	if (boxtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	partstemp = fopen("parts.tmp","wb");
	if (partstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	taz = (Taz_Border_Type *)calloc(APolycounts[7]+Watercut*SPolycounts[0],sizeof(Taz_Border_Type));	
	written = 0;
	for (num = 0; num < CountI; num++)
	{
		if (strcmp(TypeIs[num].Tazl,TypeIs[num].Tazr)== 0)
		{
			if (Watercut)
			{

				if (TypeIs[num].Waterl == TypeIs[num].Waterr)
					continue;
			}
			else
				continue;		
		}
		doleft = 0;			
		
		if (strcmp(TypeIs[num].Tazl,"          ") != 0)
		{//left case	
			if (Watercut)
			{

				if (!TypeIs[num].Waterl)
					doleft = 1;
			}
			else
				doleft = 1;
			if (doleft)
			{
				sprintf(taz[written].County,"%s%s",TypeIs[num].State,TypeIs[num].County);				
				sprintf(taz[written].Taz,"%6s",TypeIs[num].Tazl);				
				sprintf(taz[written].Ctpp,"%4s",&TypeIs[num].Tazl[6]);				
				sprintf(taz[written].Tlid,"%s",TypeIs[num].Tlid);
				taz[written].Frlong = Type1s[num].Frlong;
				taz[written].Frlat = Type1s[num].Frlat;
				taz[written].Tolong = Type1s[num].Tolong;
				taz[written].Tolat = Type1s[num].Tolat;
				taz[written].Chosen = 0;
				taz[written].Flip = 1;
				written++;
			}
		}
		doright = 0;
		if (strcmp(TypeIs[num].Tazr, "          ") != 0)
		{//rightcase 
			//printf("\nright case");			
			if (Watercut)
			{
				if (!TypeIs[num].Waterr)
					doright = 1;
			}
			else
				doright = 1;
			if (doright)
			{
				sprintf(taz[written].County,"%s%s",TypeIs[num].State,TypeIs[num].County);				
				sprintf(taz[written].Taz,"%6s",TypeIs[num].Tazr);				
				sprintf(taz[written].Ctpp,"%4s",&TypeIs[num].Tazr[6]);				
				sprintf(taz[written].Tlid,"%s",TypeIs[num].Tlid);				
				taz[written].Frlong = Type1s[num].Frlong;
				taz[written].Frlat = Type1s[num].Frlat;
				taz[written].Tolong = Type1s[num].Tolong;
				taz[written].Tolat = Type1s[num].Tolat;
				taz[written].Chosen = 0;
				taz[written].Flip = 0;
				written++;
			}
		}
	}	
	if (written > APolycounts[7]+Watercut*SPolycounts[0])
	{
		Ptrdlg->ErrorMessage("the number of Taz border lines exceeds the count");				
		MissingFile = -1;
		return;
	}
	if (written == 0)
	{
		if (!Watercut)
			fprintf(LOG,"There are no lines for Traffic Analysis Zones\n");
		else
		{
			fprintf(LOG,"All TAZs for this county coincide with water polygons\n");
			fprintf(LOG,"Try turning off the water polygon clipping option\n");
		}
		return;
	}
	
	//time to chain		
	Ptrdlg->m_strProcess.Format("Gathering TAZ Boundary Lines");
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	qsort((void *)taz,written,sizeof(Taz_Border_Type),(compfn)CompareTaz);	
	FileMinX = FileMinY = LARGE;
	FileMaxX = FileMaxY = -LARGE;
	CurrentMinX = CurrentMinY = LARGE;
	CurrentMaxX = CurrentMaxY = -LARGE;
	curcase = 0;
	polyid = 1;
	Npts = 0; 
	nparts = 1;
	ptcount = 0;
	Build_db_Header(dbfout,0,dbTaz);
	Build_db_FieldHeaders(dbfout,dbTaz);	
//	sprintf(tazrecord," %8d%-5s%-6s",polyid,taz[curcase].County,taz[curcase].Taz);
//	sprintf(&tazrecord[20],"%-4s",taz[curcase].Ctpp);	
	sprintf(tazrecord," %-8d",polyid);
	sprintf(&tazrecord[9],"%-5s",taz[curcase].County);
	sprintf(&tazrecord[14],"%-6s",taz[curcase].Taz);
	sprintf(&tazrecord[20],"%-4s",taz[curcase].Ctpp);
	fwrite(&tazrecord,sizeof(tazrecord)-1,1,dbfout);
	if (taz[0].Flip == 0)
	{
		curX = taz[0].Tolong;
		curY = taz[0].Tolat;		
		Pts[Npts].Longitude = taz[curcase].Frlong;
		Pts[Npts].Latitude = taz[curcase].Frlat;
		Npts++;
		Get_Shape_Points(taz[curcase].Tlid, taz[curcase].Flip);
		Pts[Npts].Longitude = taz[curcase].Tolong;
		Pts[Npts].Latitude = taz[curcase].Tolat;
		Npts++;
		taz[curcase].Chosen = 1;		
	}
	else
	{
		curX = taz[0].Frlong;
		curY = taz[0].Frlat;		
		Pts[Npts].Longitude = taz[curcase].Tolong;
		Pts[Npts].Latitude = taz[curcase].Tolat;
		Npts++;
		Get_Shape_Points(taz[curcase].Tlid, taz[curcase].Flip);
		Pts[Npts].Longitude = taz[curcase].Frlong;
		Pts[Npts].Latitude = taz[curcase].Frlat;
		Npts++;
		taz[curcase].Chosen = 1;		
	}
	ptcount += Npts;
	
    fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
	
	if (Pts[0].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < CurrentMinY)
		CurrentMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[0].Latitude;	
	if (Pts[0].Longitude < FileMinX)
		FileMinX = Pts[0].Longitude;
	if (Pts[0].Longitude > FileMaxX)
		FileMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < FileMinY)
		FileMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > FileMaxY)
		FileMaxY = Pts[0].Latitude;

	if (Pts[Npts-1].Longitude < CurrentMinX)
		CurrentMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < CurrentMinY)
		CurrentMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[Npts-1].Latitude;	
	if (Pts[Npts-1].Longitude < FileMinX)
		FileMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > FileMaxX)
		FileMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < FileMinY)
		FileMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > FileMaxY)
		FileMaxY = Pts[Npts-1].Latitude;		
	n = 1;
	steppos = (int)(n*100/written);	
	Ptrdlg->m_Progress.SetPos(steppos);
    while (n < written)
	{		
		sprintf(msg,"processed %d of %d records",n,written);
		Ptrdlg->SetDlgItemText(IDC_TAZ,msg);		
		found = 0;
		for (i = 1; i < written; i++)
         {
			Npts = 0;
			if (taz[i].Chosen != 0)
				continue;
			if (taz[i].Flip == 0)
			{
				if ((taz[i].Frlong == curX) && (taz[i].Frlat == curY))
				{                          
					if (strcmp(taz[i].Taz,taz[curcase].Taz) != 0)
						continue;	            
					if (strcmp(taz[i].Ctpp,taz[curcase].Ctpp) != 0)
						continue;
					Get_Shape_Points(taz[i].Tlid,taz[i].Flip);
					Pts[Npts].Longitude = taz[i].Tolong;
					Pts[Npts].Latitude = taz[i].Tolat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					taz[i].Chosen = 1;            
					found = 1;                      
					curX = taz[i].Tolong;
					curY = taz[i].Tolat;                
					curcase = i;
					break;
				}
			}
			else
			{
				if ((taz[i].Tolong == curX) && (taz[i].Tolat == curY))
				{
					if (strcmp(taz[i].Taz,taz[curcase].Taz) != 0)
						continue;	            
					if (strcmp(taz[i].Ctpp,taz[curcase].Ctpp) != 0)
						continue;
					Get_Shape_Points(taz[i].Tlid,taz[i].Flip);
					Pts[Npts].Longitude = taz[i].Frlong;
					Pts[Npts].Latitude = taz[i].Frlat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = taz[i].Frlong;
					curY = taz[i].Frlat;                        
					taz[i].Chosen = 1;	
					found = 1;          
					curcase = i;
					break;
				}
			}
        }//close for loop
		if (found == 0) //initialize new case, eg, new ring or new poly
		{			
			fwrite(&ptcount,sizeof(int),1,headtemp);
			ptcount = 0;
			for (i = 0; i < written; i++) //check for new ring in poly
            {                    
         		if (taz[i].Chosen != 0)
					continue;    
				if (strcmp(taz[i].Taz,taz[curcase].Taz) != 0)
					continue;	            
				if (strcmp(taz[i].Ctpp,taz[curcase].Ctpp) != 0)
					continue;
				//if we get here it is a new ring in current poly
				found = 1;
				nparts++;
				Npts = 0;
				if (taz[i].Flip == 0)
				{
					Pts[Npts].Longitude = taz[i].Frlong;
					Pts[Npts].Latitude = taz[i].Frlat;
					Npts++;
					Get_Shape_Points(taz[i].Tlid,taz[i].Flip);
					Pts[Npts].Longitude = taz[i].Tolong;
					Pts[Npts].Latitude = taz[i].Tolat;
					Npts++;			
    				n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					taz[i].Chosen = 1;
    		   		curX = taz[i].Tolong;
    				curY = taz[i].Tolat;
					curcase = i;
					break;
				}
				else
				{
					Pts[Npts].Longitude = taz[i].Tolong;
					Pts[Npts].Latitude = taz[i].Tolat;
					Npts++;
					Get_Shape_Points(taz[i].Tlid,taz[i].Flip);
					Pts[Npts].Longitude = taz[i].Frlong;
					Pts[Npts].Latitude = taz[i].Frlat;
					Npts++;			
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					taz[i].Chosen = 1;
    		   		curX = taz[i].Frlong;
    				curY = taz[i].Frlat;
					curcase = i;
					break;
				}
    		}
    	}
		if (found == 0) // new poly, first ring
		{
			
			fwrite(&nparts,sizeof(int),1,partstemp);
			nparts = 1;
			fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
			CurrentMinX = CurrentMinY = LARGE;
			CurrentMaxX = CurrentMaxY = -LARGE;

			for (i = 0; i < written; i++)//first check for new ring in current poly
            {                    
         		if (taz[i].Chosen != 0)
					continue;             
				polyid++;
				//sprintf(tazrecord," %-8d%-5s%-6s",polyid,taz[i].County,taz[i].Taz);					
				//sprintf(&tazrecord[20],"%-4s",taz[i].Ctpp);	
				sprintf(tazrecord," %-8d",polyid);
				sprintf(&tazrecord[9],"%-5s",taz[i].County);
				sprintf(&tazrecord[14],"%-6s",taz[i].Taz);
				sprintf(&tazrecord[20],"%-4s",taz[i].Ctpp);
	
				fwrite(&tazrecord,sizeof(tazrecord)-1,1,dbfout);    		
				Npts = 0;
				if (taz[i].Flip == 0)
				{
					Pts[Npts].Longitude = taz[i].Frlong;
					Pts[Npts].Latitude = taz[i].Frlat;
					Npts++;
					Get_Shape_Points(taz[i].Tlid,taz[i].Flip);
					Pts[Npts].Longitude = taz[i].Tolong;
					Pts[Npts].Latitude = taz[i].Tolat;
					Npts++;					
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					taz[i].Chosen = 1;            
					found = 1;                      
					curX = taz[i].Tolong;
					curY = taz[i].Tolat;                
					curcase = i;
					break;					
				}
				else
				{
					Pts[Npts].Longitude = taz[i].Tolong;
					Pts[Npts].Latitude = taz[i].Tolat;
					Npts++;
					Get_Shape_Points(taz[i].Tlid,taz[i].Flip);
					Pts[Npts].Longitude = taz[i].Frlong;
					Pts[Npts].Latitude = taz[i].Frlat;
					Npts++;				
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = taz[i].Frlong;
					curY = taz[i].Frlat;                        
					taz[i].Chosen = 1;		
					found = 1;          
					curcase = i;	
					break;					
				}	
			}
		}
		//by now found should be 1
		if (found == 0)
		{
			info.Format("ERROR - found is zero");
			Ptrdlg->ErrorMessage(info);									
			MissingFile = -1;
			return;
		}
		ptcount += Npts;
		fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
		if (Pts[0].Longitude < CurrentMinX)
			CurrentMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < CurrentMinY)
			CurrentMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[0].Latitude;	
		if (Pts[0].Longitude < FileMinX)
			FileMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > FileMaxX)
			FileMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < FileMinY)
			FileMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > FileMaxY)
			FileMaxY = Pts[0].Latitude;

		if (Pts[Npts-1].Longitude < CurrentMinX)
			CurrentMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < CurrentMinY)
			CurrentMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[Npts-1].Latitude;	
		if (Pts[Npts-1].Longitude < FileMinX)
			FileMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > FileMaxX)
			FileMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < FileMinY)
			FileMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > FileMaxY)
			FileMaxY = Pts[Npts-1].Latitude;		
	}//close while loop
	fwrite(&ptcount,sizeof(int),1,headtemp);
	fwrite(&nparts,sizeof(int),1,partstemp);
	fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
	fclose(boxtemp);
	fclose(headtemp);
	fclose(ptstemp);
	fclose(partstemp);
	sprintf(msg,"processed %d of %d records",n,written);
	Ptrdlg->SetDlgItemText(IDC_TAZ,msg);			
	write_eof(dbfout);
	rewind(dbfout);
	Build_db_Header(dbfout,polyid,dbTaz);
	Build_Poly_Shape("taz");
	Ptrdlg->m_strTaz.Format("%d Traffic Analysis Zones",polyid);
	Ptrdlg->SetDlgItemText(IDC_TAZ,Ptrdlg->m_strTaz);
    fclose(dbfout);
	free(taz);
	fprintf(LOG,"Wrote %d Traffic Analysis Zones polygon to shape %s%staz\n", polyid,
		Outfilepath,Outfiletitle);		
}
void Match_Poly_Lines_Urban90()
{
	int polyid, found, i, nparts, ptcount;
	long num, n, written, curcase;
	Urban_Border_Type *urb;
	double  curX, curY;	
    FILE  *dbfout, *ptstemp, *headtemp, *partstemp, *boxtemp; 
	CString info, fname, errmsg, trimname;	
	char urbrecord[86]; //size of fpl dbrecord + 2
	int steppos;
	char msg[100];
	char * urbname; //new june 19
	int doleft, doright;
	
	if (APolycounts[8] == 0)
	{
		Ptrdlg->SetDlgItemText(IDC_URB,"No Such Cases");		
		return;
	}	
	fname.Format("%s%surb.dbf",Outfilepath,Outfiletitle);			
	dbfout = fopen(fname,"wb");
	if (dbfout == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	ptstemp = fopen("pts.tmp","wb");
	if (ptstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	headtemp = fopen("head.tmp","wb");
	if (headtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	boxtemp = fopen("box.tmp","wb");
	if (boxtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	partstemp = fopen("parts.tmp","wb");
	if (partstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	urb = (Urban_Border_Type *)calloc(APolycounts[8]+Watercut*SPolycounts[0],sizeof(Urban_Border_Type));	
	written = 0;
	for (num = 0; num < CountI; num++)
	{
		if (strcmp(TypeIs[num].Urb90l,TypeIs[num].Urb90r)== 0)
		{
			if (Watercut)
			{

				if (TypeIs[num].Waterl == TypeIs[num].Waterr)
					continue;
			}
			else
				continue;		
		}
		doleft = 0;	
		
		if (strcmp(TypeIs[num].Urb90l,"     ") != 0)
		{//left case	
			if (Watercut)
			{

				if (!TypeIs[num].Waterl)
					doleft = 1;
			}
			else
				doleft = 1;
			if (doleft)
			{
				sprintf(urb[written].County,"%s%s",TypeIs[num].State,TypeIs[num].County);				
				sprintf(urb[written].Uacode,"%-5s",TypeIs[num].Urb90l);				
				//sprintf(urb[written].Urbflag,"%c",TypeIs[num].Urbl[4]);				
				//urb[written].Urbflag = TypeIs[num].Urbl[4];
				sprintf(urb[written].Tlid,"%s",TypeIs[num].Tlid);
				urb[written].Frlong = Type1s[num].Frlong;
				urb[written].Frlat = Type1s[num].Frlat;
				urb[written].Tolong = Type1s[num].Tolong;
				urb[written].Tolat = Type1s[num].Tolat;
				urb[written].Chosen = 0;
				urb[written].Flip = 1;
				written++;
			}
		}
		doright = 0;
		if (strcmp(TypeIs[num].Urb90r, "     ") != 0)
		{//rightcase 
			//printf("\nright case");			
			if (Watercut)
			{
				if (!TypeIs[num].Waterr)
					doright = 1;
			}
			else
				doright = 1;
			if (doright)
			{
				sprintf(urb[written].County,"%s%s",TypeIs[num].State,TypeIs[num].County);				
				sprintf(urb[written].Uacode,"%-5s",TypeIs[num].Urb90r);				
				//sprintf(urb[written].Urbflag,"%c",TypeIs[num].Urbr[4]);				
				//urb[written].Urbflag = TypeIs[num].Urbr[4];
				sprintf(urb[written].Tlid,"%s",TypeIs[num].Tlid);				
				urb[written].Frlong = Type1s[num].Frlong;
				urb[written].Frlat = Type1s[num].Frlat;
				urb[written].Tolong = Type1s[num].Tolong;
				urb[written].Tolat = Type1s[num].Tolat;
				urb[written].Chosen = 0;
				urb[written].Flip = 0;
				written++;
			}
		}
	}	
	if (written > APolycounts[8]+Watercut*SPolycounts[0])
	{
		Ptrdlg->ErrorMessage("the number of Urban border lines exceeds the count");				
		MissingFile = -1;
		return;
	}
	if (written == 0)
	{
		if (!Watercut)
			fprintf(LOG,"There are no lines for urban polygons\n");
		else
		{
			fprintf(LOG,"All urban polygons for this county coincide with water polygons\n");
			fprintf(LOG,"Try turning off the water polygon clipping option\n");
		}
		return;
	}
	
	//time to chain		
	Ptrdlg->m_strProcess.Format("Gathering Urban Boundary Lines");
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	qsort((void *)urb,written,sizeof(Urban_Border_Type),(compfn)CompareUrb);	
	FileMinX = FileMinY = LARGE;
	FileMaxX = FileMaxY = -LARGE;
	CurrentMinX = CurrentMinY = LARGE;
	CurrentMaxX = CurrentMaxY = -LARGE;
	curcase = 0;
	polyid = 1;
	Npts = 0; 
	nparts = 1;
	ptcount = 0;
	Build_db_Header(dbfout,0,dbUrb);
	Build_db_FieldHeaders(dbfout,dbUrb);	
	//sprintf(urbrecord," %8d%-5s%-4s",polyid,urb[curcase].County,urb[curcase].Uacode);
	sprintf(urbrecord," %-8d",polyid);
	sprintf(&urbrecord[9],"%-5s",urb[curcase].County);
	sprintf(&urbrecord[14],"%-5s",urb[curcase].Uacode);
	urbname = Get_TypeC_Name(7,urb[curcase].Uacode,"");
	trimname.Format("%s",urbname);
	trimname.TrimRight();
	//CString repval;
	//repval.Format("returned %s",urbname);
	//AfxMessageBox(repval);
	sprintf(&urbrecord[19],"%-66s",trimname);
	//here now
		//urb[curcase].Urbflag);	
	fwrite(&urbrecord,sizeof(urbrecord)-1,1,dbfout);
	if (urb[0].Flip == 0)
	{
		curX = urb[0].Tolong;
		curY = urb[0].Tolat;		
		Pts[Npts].Longitude = urb[curcase].Frlong;
		Pts[Npts].Latitude = urb[curcase].Frlat;
		Npts++;
		Get_Shape_Points(urb[curcase].Tlid, urb[curcase].Flip);
		Pts[Npts].Longitude = urb[curcase].Tolong;
		Pts[Npts].Latitude = urb[curcase].Tolat;
		Npts++;
		urb[curcase].Chosen = 1;		
	}
	else
	{
		curX = urb[0].Frlong;
		curY = urb[0].Frlat;		
		Pts[Npts].Longitude = urb[curcase].Tolong;
		Pts[Npts].Latitude = urb[curcase].Tolat;
		Npts++;
		Get_Shape_Points(urb[curcase].Tlid, urb[curcase].Flip);
		Pts[Npts].Longitude = urb[curcase].Frlong;
		Pts[Npts].Latitude = urb[curcase].Frlat;
		Npts++;
		urb[curcase].Chosen = 1;		
	}
	ptcount += Npts;
	
    fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
	
	if (Pts[0].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < CurrentMinY)
		CurrentMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[0].Latitude;	
	if (Pts[0].Longitude < FileMinX)
		FileMinX = Pts[0].Longitude;
	if (Pts[0].Longitude > FileMaxX)
		FileMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < FileMinY)
		FileMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > FileMaxY)
		FileMaxY = Pts[0].Latitude;

	if (Pts[Npts-1].Longitude < CurrentMinX)
		CurrentMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < CurrentMinY)
		CurrentMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[Npts-1].Latitude;	
	if (Pts[Npts-1].Longitude < FileMinX)
		FileMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > FileMaxX)
		FileMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < FileMinY)
		FileMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > FileMaxY)
		FileMaxY = Pts[Npts-1].Latitude;		
	n = 1;
	steppos = (int)(n*100/written);	
	Ptrdlg->m_Progress.SetPos(steppos);
    while (n < written)
	{		
		sprintf(msg,"processed %d of %d records",n,written);
		Ptrdlg->SetDlgItemText(IDC_URB,msg);		
		found = 0;
		for (i = 1; i < written; i++)
         {
			Npts = 0;
			if (urb[i].Chosen != 0)
				continue;
			if (urb[i].Flip == 0)
			{
				if ((urb[i].Frlong == curX) && (urb[i].Frlat == curY))
				{                          
					if (strcmp(urb[i].Uacode,urb[curcase].Uacode) != 0)
						continue;	            
					//if (urb[i].Urbflag != urb[i].Urbflag)
					//	continue;
					Get_Shape_Points(urb[i].Tlid,urb[i].Flip);
					Pts[Npts].Longitude = urb[i].Tolong;
					Pts[Npts].Latitude = urb[i].Tolat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					urb[i].Chosen = 1;            
					found = 1;                      
					curX = urb[i].Tolong;
					curY = urb[i].Tolat;                
					curcase = i;
					break;
				}
			}
			else
			{
				if ((urb[i].Tolong == curX) && (urb[i].Tolat == curY))
				{
					if (strcmp(urb[i].Uacode,urb[curcase].Uacode) != 0)
						continue;	            
					//if (urb[i].Urbflag != urb[curcase].Urbflag)
					//	continue;
					Get_Shape_Points(urb[i].Tlid,urb[i].Flip);
					Pts[Npts].Longitude = urb[i].Frlong;
					Pts[Npts].Latitude = urb[i].Frlat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = urb[i].Frlong;
					curY = urb[i].Frlat;                        
					urb[i].Chosen = 1;	
					found = 1;          
					curcase = i;
					break;
				}
			}
        }//close for loop
		if (found == 0) //initialize new case, eg, new ring or new poly
		{			
			fwrite(&ptcount,sizeof(int),1,headtemp);
			ptcount = 0;
			for (i = 0; i < written; i++) //check for new ring in poly
            {                    
         		if (urb[i].Chosen != 0)
					continue;    
				if (strcmp(urb[i].Uacode,urb[curcase].Uacode) != 0)
					continue;	            
				//if (urb[i].Urbflag != urb[curcase].Urbflag)
				//	continue;
				//if we get here it is a new ring in current poly
				found = 1;
				nparts++;
				Npts = 0;
				if (urb[i].Flip == 0)
				{
					Pts[Npts].Longitude = urb[i].Frlong;
					Pts[Npts].Latitude = urb[i].Frlat;
					Npts++;
					Get_Shape_Points(urb[i].Tlid,urb[i].Flip);
					Pts[Npts].Longitude = urb[i].Tolong;
					Pts[Npts].Latitude = urb[i].Tolat;
					Npts++;			
    				n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					urb[i].Chosen = 1;
    		   		curX = urb[i].Tolong;
    				curY = urb[i].Tolat;
					curcase = i;
					break;
				}
				else
				{
					Pts[Npts].Longitude = urb[i].Tolong;
					Pts[Npts].Latitude = urb[i].Tolat;
					Npts++;
					Get_Shape_Points(urb[i].Tlid,urb[i].Flip);
					Pts[Npts].Longitude = urb[i].Frlong;
					Pts[Npts].Latitude = urb[i].Frlat;
					Npts++;			
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					urb[i].Chosen = 1;
    		   		curX = urb[i].Frlong;
    				curY = urb[i].Frlat;
					curcase = i;
					break;
				}
    		}
    	}
		if (found == 0) // new poly, first ring
		{
			
			fwrite(&nparts,sizeof(int),1,partstemp);
			nparts = 1;
			fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
			CurrentMinX = CurrentMinY = LARGE;
			CurrentMaxX = CurrentMaxY = -LARGE;

			for (i = 0; i < written; i++)//first check for new ring in current poly
            {                    
         		if (urb[i].Chosen != 0)
					continue;             
				polyid++;
				//sprintf(urbrecord," %-8d%-5s%-4s",polyid,urb[i].County,urb[i].Uacode);
				sprintf(urbrecord," %-8d",polyid);
				sprintf(&urbrecord[9],"%-5s",urb[i].County);
				sprintf(&urbrecord[14],"%-5s",urb[i].Uacode);
				urbname = Get_TypeC_Name(7,urb[i].Uacode,"");				
				trimname.Format("%s",urbname);
				trimname.TrimRight();
				sprintf(&urbrecord[19],"%-66s",trimname);
					//urb[i].Urbflag);
				fwrite(&urbrecord,sizeof(urbrecord)-1,1,dbfout);    		
				Npts = 0;
				if (urb[i].Flip == 0)
				{
					Pts[Npts].Longitude = urb[i].Frlong;
					Pts[Npts].Latitude = urb[i].Frlat;
					Npts++;
					Get_Shape_Points(urb[i].Tlid,urb[i].Flip);
					Pts[Npts].Longitude = urb[i].Tolong;
					Pts[Npts].Latitude = urb[i].Tolat;
					Npts++;					
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					urb[i].Chosen = 1;            
					found = 1;                      
					curX = urb[i].Tolong;
					curY = urb[i].Tolat;                
					curcase = i;
					break;					
				}
				else
				{
					Pts[Npts].Longitude = urb[i].Tolong;
					Pts[Npts].Latitude = urb[i].Tolat;
					Npts++;
					Get_Shape_Points(urb[i].Tlid,urb[i].Flip);
					Pts[Npts].Longitude = urb[i].Frlong;
					Pts[Npts].Latitude = urb[i].Frlat;
					Npts++;				
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = urb[i].Frlong;
					curY = urb[i].Frlat;                        
					urb[i].Chosen = 1;		
					found = 1;          
					curcase = i;	
					break;					
				}	
			}
		}
		//by now found should be 1
		if (found == 0)
		{
			info.Format("ERROR - found is zero");
			Ptrdlg->ErrorMessage(info);									
			MissingFile = -1;
			return;
		}
		ptcount += Npts;
		fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
		if (Pts[0].Longitude < CurrentMinX)
			CurrentMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < CurrentMinY)
			CurrentMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[0].Latitude;	
		if (Pts[0].Longitude < FileMinX)
			FileMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > FileMaxX)
			FileMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < FileMinY)
			FileMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > FileMaxY)
			FileMaxY = Pts[0].Latitude;

		if (Pts[Npts-1].Longitude < CurrentMinX)
			CurrentMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < CurrentMinY)
			CurrentMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[Npts-1].Latitude;	
		if (Pts[Npts-1].Longitude < FileMinX)
			FileMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > FileMaxX)
			FileMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < FileMinY)
			FileMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > FileMaxY)
			FileMaxY = Pts[Npts-1].Latitude;		
	}//close while loop
	fwrite(&ptcount,sizeof(int),1,headtemp);
	fwrite(&nparts,sizeof(int),1,partstemp);
	fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
	fclose(boxtemp);
	fclose(headtemp);
	fclose(ptstemp);
	fclose(partstemp);
	sprintf(msg,"processed %d of %d records",n,written);
	Ptrdlg->SetDlgItemText(IDC_URB,msg);			
	write_eof(dbfout);
	rewind(dbfout);
	Build_db_Header(dbfout,polyid,dbUrb);
	Build_Poly_Shape("urb");
	Ptrdlg->m_strUrb.Format("%d Urban Polygons",polyid);
	Ptrdlg->SetDlgItemText(IDC_URB,Ptrdlg->m_strUrb);
    fclose(dbfout);
	free(urb);
	fprintf(LOG,"Wrote %d Urban Coded polygons to shape %s%surb\n", polyid,Outfilepath,
		Outfiletitle);		
}
void Match_Poly_Lines_Elementary()
{
	int polyid, found, i, nparts, ptcount;
	long num, n, written, curcase;
	Elementary_Border_Type *elm;
	double  curX, curY;	
    FILE  *dbfout, *ptstemp, *headtemp, *partstemp, *boxtemp; 
	CString info, fname, errmsg;	
	char elmrecord[20];
	int steppos;
	char msg[100];
	int doleft, doright;


	
	if (APolycounts[9] == 0)
	{
		Ptrdlg->SetDlgItemText(IDC_ELEM,"No Such Cases");		
		return;
	}	
	fname.Format("%s%selm.dbf",Outfilepath,Outfiletitle);			
	dbfout = fopen(fname,"wb");
	if (dbfout == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	ptstemp = fopen("pts.tmp","wb");
	if (ptstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	headtemp = fopen("head.tmp","wb");
	if (headtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	boxtemp = fopen("box.tmp","wb");
	if (boxtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	partstemp = fopen("parts.tmp","wb");
	if (partstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	elm = (Elementary_Border_Type *)calloc(APolycounts[9]+Watercut*SPolycounts[0],sizeof(Elementary_Border_Type));	
	written = 0;
	for (num = 0; num < CountI; num++)
	{
		if (strcmp(TypeIs[num].Elml,TypeIs[num].Elmr)== 0)
		{
			if (Watercut)
			{

				if (TypeIs[num].Waterl == TypeIs[num].Waterr)
					continue;
			}
			else
				continue;		
		}
		doleft = 0;
		
		if (strcmp(TypeIs[num].Elml,"     ") != 0)
		{//left case	
			if (Watercut)
			{

				if (!TypeIs[num].Waterl)
					doleft = 1;
			}
			else
				doleft = 1;
			if (doleft)
			{
				sprintf(elm[written].County,"%s%s",TypeIs[num].State,TypeIs[num].County);				
				sprintf(elm[written].Elementary,"%5s",TypeIs[num].Elml);				
				//sprintf(urb[written].Urbflag,"%c",TypeIs[num].Urbl[4]);				
				//urb[written].Urbflag = TypeIs[num].Urbl[4];
				sprintf(elm[written].Tlid,"%s",TypeIs[num].Tlid);
				elm[written].Frlong = Type1s[num].Frlong;
				elm[written].Frlat = Type1s[num].Frlat;
				elm[written].Tolong = Type1s[num].Tolong;
				elm[written].Tolat = Type1s[num].Tolat;
				elm[written].Chosen = 0;
				elm[written].Flip = 1;
				written++;
			}
		}
		doright = 0;
		if (strcmp(TypeIs[num].Elmr, "     ") != 0)
		{//rightcase 
			//printf("\nright case");			
			if (Watercut)
			{
				if (TypeIs[num].Waterr)
					doright = 1;
			}
			else
				doright = 1;
			if (doright)
			{
				sprintf(elm[written].County,"%s%s",TypeIs[num].State,TypeIs[num].County);				
				sprintf(elm[written].Elementary,"%5s",TypeIs[num].Elmr);				
				//sprintf(urb[written].Urbflag,"%c",TypeIs[num].Urbr[4]);				
				//urb[written].Urbflag = TypeIs[num].Urbr[4];
				sprintf(elm[written].Tlid,"%s",TypeIs[num].Tlid);				
				elm[written].Frlong = Type1s[num].Frlong;
				elm[written].Frlat = Type1s[num].Frlat;
				elm[written].Tolong = Type1s[num].Tolong;
				elm[written].Tolat = Type1s[num].Tolat;
				elm[written].Chosen = 0;
				elm[written].Flip = 0;
				written++;
			}
		}
	}	
	if (written > APolycounts[9]+Watercut*SPolycounts[0])
	{
		Ptrdlg->ErrorMessage("the number of Elementary border lines exceeds the count");				
		MissingFile = -1;
		return;
	}
	if (written == 0)
	{
		if (!Watercut)
			fprintf(LOG,"There are no lines for elementary school polygons\n");
		else
		{
			fprintf(LOG,"All elementary school polygons for this county coincide with water polygons\n");
			fprintf(LOG,"Try turning off the water polygon clipping option\n");
		}
		return;
	}
	
	//time to chain		
	Ptrdlg->m_strProcess.Format("Gathering Elementary School Boundary Lines");
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	qsort((void *)elm,written,sizeof(Elementary_Border_Type),(compfn)CompareElementary);	
	FileMinX = FileMinY = LARGE;
	FileMaxX = FileMaxY = -LARGE;
	CurrentMinX = CurrentMinY = LARGE;
	CurrentMaxX = CurrentMaxY = -LARGE;
	curcase = 0;
	polyid = 1;
	Npts = 0; 
	nparts = 1;
	ptcount = 0;
	Build_db_Header(dbfout,0,dbElementary);
	Build_db_FieldHeaders(dbfout,dbElementary);	
	//sprintf(elmrecord," %8d%-5s%-5s",polyid,elm[curcase].County,elm[curcase].Elementary);
	sprintf(elmrecord," %-8d", polyid);
	sprintf(&elmrecord[9],"%-5s",elm[curcase].County);
	sprintf(&elmrecord[14],"%-5s",elm[curcase].Elementary);
		//urb[curcase].Urbflag);	
	fwrite(&elmrecord,sizeof(elmrecord)-1,1,dbfout);
	if (elm[0].Flip == 0)
	{
		curX = elm[0].Tolong;
		curY = elm[0].Tolat;		
		Pts[Npts].Longitude = elm[curcase].Frlong;
		Pts[Npts].Latitude = elm[curcase].Frlat;
		Npts++;
		Get_Shape_Points(elm[curcase].Tlid, elm[curcase].Flip);
		Pts[Npts].Longitude = elm[curcase].Tolong;
		Pts[Npts].Latitude = elm[curcase].Tolat;
		Npts++;
		elm[curcase].Chosen = 1;		
	}
	else
	{
		curX = elm[0].Frlong;
		curY = elm[0].Frlat;		
		Pts[Npts].Longitude = elm[curcase].Tolong;
		Pts[Npts].Latitude = elm[curcase].Tolat;
		Npts++;
		Get_Shape_Points(elm[curcase].Tlid, elm[curcase].Flip);
		Pts[Npts].Longitude = elm[curcase].Frlong;
		Pts[Npts].Latitude = elm[curcase].Frlat;
		Npts++;
		elm[curcase].Chosen = 1;		
	}
	ptcount += Npts;
	
    fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
	
	if (Pts[0].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < CurrentMinY)
		CurrentMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[0].Latitude;	
	if (Pts[0].Longitude < FileMinX)
		FileMinX = Pts[0].Longitude;
	if (Pts[0].Longitude > FileMaxX)
		FileMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < FileMinY)
		FileMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > FileMaxY)
		FileMaxY = Pts[0].Latitude;

	if (Pts[Npts-1].Longitude < CurrentMinX)
		CurrentMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < CurrentMinY)
		CurrentMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[Npts-1].Latitude;	
	if (Pts[Npts-1].Longitude < FileMinX)
		FileMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > FileMaxX)
		FileMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < FileMinY)
		FileMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > FileMaxY)
		FileMaxY = Pts[Npts-1].Latitude;		
	n = 1;
	steppos = (int)(n*100/written);	
	Ptrdlg->m_Progress.SetPos(steppos);
    while (n < written)
	{		
		sprintf(msg,"processed %d of %d records",n,written);
		Ptrdlg->SetDlgItemText(IDC_ELEM,msg);		
		found = 0;
		for (i = 1; i < written; i++)
         {
			Npts = 0;
			if (elm[i].Chosen != 0)
				continue;
			if (elm[i].Flip == 0)
			{
				if ((elm[i].Frlong == curX) && (elm[i].Frlat == curY))
				{                          
					if (strcmp(elm[i].Elementary,elm[curcase].Elementary) != 0)
						continue;	            
					//if (urb[i].Urbflag != urb[i].Urbflag)
					//	continue;
					Get_Shape_Points(elm[i].Tlid,elm[i].Flip);
					Pts[Npts].Longitude = elm[i].Tolong;
					Pts[Npts].Latitude = elm[i].Tolat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					elm[i].Chosen = 1;            
					found = 1;                      
					curX = elm[i].Tolong;
					curY = elm[i].Tolat;                
					curcase = i;
					break;
				}
			}
			else
			{
				if ((elm[i].Tolong == curX) && (elm[i].Tolat == curY))
				{
					if (strcmp(elm[i].Elementary,elm[curcase].Elementary) != 0)
						continue;	            
					//if (urb[i].Urbflag != urb[curcase].Urbflag)
					//	continue;
					Get_Shape_Points(elm[i].Tlid,elm[i].Flip);
					Pts[Npts].Longitude = elm[i].Frlong;
					Pts[Npts].Latitude = elm[i].Frlat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = elm[i].Frlong;
					curY = elm[i].Frlat;                        
					elm[i].Chosen = 1;	
					found = 1;          
					curcase = i;
					break;
				}
			}
        }//close for loop
		if (found == 0) //initialize new case, eg, new ring or new poly
		{			
			fwrite(&ptcount,sizeof(int),1,headtemp);
			ptcount = 0;
			for (i = 0; i < written; i++) //check for new ring in poly
            {                    
         		if (elm[i].Chosen != 0)
					continue;    
				if (strcmp(elm[i].Elementary,elm[curcase].Elementary) != 0)
					continue;	            
				//if (urb[i].Urbflag != urb[curcase].Urbflag)
				//	continue;
				//if we get here it is a new ring in current poly
				found = 1;
				nparts++;
				Npts = 0;
				if (elm[i].Flip == 0)
				{
					Pts[Npts].Longitude = elm[i].Frlong;
					Pts[Npts].Latitude = elm[i].Frlat;
					Npts++;
					Get_Shape_Points(elm[i].Tlid,elm[i].Flip);
					Pts[Npts].Longitude = elm[i].Tolong;
					Pts[Npts].Latitude = elm[i].Tolat;
					Npts++;			
    				n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					elm[i].Chosen = 1;
    		   		curX = elm[i].Tolong;
    				curY = elm[i].Tolat;
					curcase = i;
					break;
				}
				else
				{
					Pts[Npts].Longitude = elm[i].Tolong;
					Pts[Npts].Latitude = elm[i].Tolat;
					Npts++;
					Get_Shape_Points(elm[i].Tlid,elm[i].Flip);
					Pts[Npts].Longitude = elm[i].Frlong;
					Pts[Npts].Latitude = elm[i].Frlat;
					Npts++;			
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					elm[i].Chosen = 1;
    		   		curX = elm[i].Frlong;
    				curY = elm[i].Frlat;
					curcase = i;
					break;
				}
    		}
    	}
		if (found == 0) // new poly, first ring
		{
			
			fwrite(&nparts,sizeof(int),1,partstemp);
			nparts = 1;
			fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
			CurrentMinX = CurrentMinY = LARGE;
			CurrentMaxX = CurrentMaxY = -LARGE;

			for (i = 0; i < written; i++)//first check for new ring in current poly
            {                    
         		if (elm[i].Chosen != 0)
					continue;             
				polyid++;
				//sprintf(elmrecord," %-8d%-5s%-5s",polyid,elm[i].County,elm[i].Elementary);
					//urb[i].Urbflag);
				sprintf(elmrecord," %-8d", polyid);
				sprintf(&elmrecord[9],"%-5s",elm[i].County);
				sprintf(&elmrecord[14],"%-5s",elm[i].Elementary);
	
				fwrite(&elmrecord,sizeof(elmrecord)-1,1,dbfout);    		
				Npts = 0;
				if (elm[i].Flip == 0)
				{
					Pts[Npts].Longitude = elm[i].Frlong;
					Pts[Npts].Latitude = elm[i].Frlat;
					Npts++;
					Get_Shape_Points(elm[i].Tlid,elm[i].Flip);
					Pts[Npts].Longitude = elm[i].Tolong;
					Pts[Npts].Latitude = elm[i].Tolat;
					Npts++;					
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					elm[i].Chosen = 1;            
					found = 1;                      
					curX = elm[i].Tolong;
					curY = elm[i].Tolat;                
					curcase = i;
					break;					
				}
				else
				{
					Pts[Npts].Longitude = elm[i].Tolong;
					Pts[Npts].Latitude = elm[i].Tolat;
					Npts++;
					Get_Shape_Points(elm[i].Tlid,elm[i].Flip);
					Pts[Npts].Longitude = elm[i].Frlong;
					Pts[Npts].Latitude = elm[i].Frlat;
					Npts++;				
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = elm[i].Frlong;
					curY = elm[i].Frlat;                        
					elm[i].Chosen = 1;		
					found = 1;          
					curcase = i;	
					break;					
				}	
			}
		}
		//by now found should be 1
		if (found == 0)
		{
			info.Format("ERROR - found is zero");
			Ptrdlg->ErrorMessage(info);									
			MissingFile = -1;
			return;
		}
		ptcount += Npts;
		fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
		if (Pts[0].Longitude < CurrentMinX)
			CurrentMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < CurrentMinY)
			CurrentMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[0].Latitude;	
		if (Pts[0].Longitude < FileMinX)
			FileMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > FileMaxX)
			FileMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < FileMinY)
			FileMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > FileMaxY)
			FileMaxY = Pts[0].Latitude;

		if (Pts[Npts-1].Longitude < CurrentMinX)
			CurrentMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < CurrentMinY)
			CurrentMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[Npts-1].Latitude;	
		if (Pts[Npts-1].Longitude < FileMinX)
			FileMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > FileMaxX)
			FileMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < FileMinY)
			FileMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > FileMaxY)
			FileMaxY = Pts[Npts-1].Latitude;		
	}//close while loop
	fwrite(&ptcount,sizeof(int),1,headtemp);
	fwrite(&nparts,sizeof(int),1,partstemp);
	fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
	fclose(boxtemp);
	fclose(headtemp);
	fclose(ptstemp);
	fclose(partstemp);
	sprintf(msg,"processed %d of %d records",n,written);
	Ptrdlg->SetDlgItemText(IDC_ELEM,msg);			
	write_eof(dbfout);
	rewind(dbfout);
	Build_db_Header(dbfout,polyid,dbElementary);
	Build_Poly_Shape("elm");
	Ptrdlg->m_strElem.Format("%d Elementary School Districts",polyid);
	Ptrdlg->SetDlgItemText(IDC_ELEM,Ptrdlg->m_strElem);
    fclose(dbfout);
	free(elm);
	fprintf(LOG,"Wrote %d Elementary School District polygons to shape %s%selm\n", polyid,
		Outfilepath, Outfiletitle);		
}
void Match_Poly_Lines_Middle()
{
	int polyid, found, i, nparts, ptcount;
	long num, n, written, curcase;
	Middle_Border_Type *mid;
	double  curX, curY;	
    FILE  *dbfout, *ptstemp, *headtemp, *partstemp, *boxtemp; 
	CString info, fname, errmsg;	
	char midrecord[20];
	int steppos;
	char msg[100];
	int doleft, doright;


	
	if (APolycounts[12] == 0)
	{
		Ptrdlg->SetDlgItemText(IDC_MIDDLE,"No Such Cases");		
		return;
	}	
	fname.Format("%s%smid.dbf",Outfilepath,Outfiletitle);			
	dbfout = fopen(fname,"wb");
	if (dbfout == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	ptstemp = fopen("pts.tmp","wb");
	if (ptstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	headtemp = fopen("head.tmp","wb");
	if (headtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	boxtemp = fopen("box.tmp","wb");
	if (boxtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	partstemp = fopen("parts.tmp","wb");
	if (partstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	mid = (Middle_Border_Type *)calloc(APolycounts[12]+Watercut*SPolycounts[0],sizeof(Middle_Border_Type));	
	written = 0;
	for (num = 0; num < CountI; num++)
	{
		if (strcmp(TypeIs[num].Midl,TypeIs[num].Midr)== 0)
		{
			if (Watercut)
			{

				if (TypeIs[num].Waterl == TypeIs[num].Waterr)
					continue;
			}
			else
				continue;		
		}
		doleft = 0;
		
		if (strcmp(TypeIs[num].Midl,"     ") != 0)
		{//left case	
			if (Watercut)
			{

				if (!TypeIs[num].Waterl)
					doleft = 1;
			}
			else
				doleft = 1;
			if (doleft)
			{
				sprintf(mid[written].County,"%s%s",TypeIs[num].State,TypeIs[num].County);				
				sprintf(mid[written].Middle,"%5s",TypeIs[num].Midl);				
				//sprintf(urb[written].Urbflag,"%c",TypeIs[num].Urbl[4]);				
				//urb[written].Urbflag = TypeIs[num].Urbl[4];
				sprintf(mid[written].Tlid,"%s",TypeIs[num].Tlid);
				mid[written].Frlong = Type1s[num].Frlong;
				mid[written].Frlat = Type1s[num].Frlat;
				mid[written].Tolong = Type1s[num].Tolong;
				mid[written].Tolat = Type1s[num].Tolat;
				mid[written].Chosen = 0;
				mid[written].Flip = 1;
				written++;
			}
		}
		doright = 0;
		if (strcmp(TypeIs[num].Midr, "     ") != 0)
		{//rightcase 
			//printf("\nright case");			
			if (Watercut)
			{
				if (TypeIs[num].Waterr)
					doright = 1;
			}
			else
				doright = 1;
			if (doright)
			{
				sprintf(mid[written].County,"%s%s",TypeIs[num].State,TypeIs[num].County);				
				sprintf(mid[written].Middle,"%5s",TypeIs[num].Midr);				
				//sprintf(urb[written].Urbflag,"%c",TypeIs[num].Urbr[4]);				
				//urb[written].Urbflag = TypeIs[num].Urbr[4];
				sprintf(mid[written].Tlid,"%s",TypeIs[num].Tlid);				
				mid[written].Frlong = Type1s[num].Frlong;
				mid[written].Frlat = Type1s[num].Frlat;
				mid[written].Tolong = Type1s[num].Tolong;
				mid[written].Tolat = Type1s[num].Tolat;
				mid[written].Chosen = 0;
				mid[written].Flip = 0;
				written++;
			}
		}
	}	
	if (written > APolycounts[12]+Watercut*SPolycounts[0])
	{
		Ptrdlg->ErrorMessage("the number of Middle border lines exceeds the count");				
		MissingFile = -1;
		return;
	}
	if (written == 0)
	{
		if (!Watercut)
			fprintf(LOG,"There are no lines for Middle School polygons\n");
		else
		{
			fprintf(LOG,"All Middle School districts for this county coincide with water polygons\n");
			fprintf(LOG,"Try turning off the water polygon clipping option\n");
		}
		return;
	}
	
	//time to chain		
	Ptrdlg->m_strProcess.Format("Gathering Middle School Boundary Lines");
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	qsort((void *)mid,written,sizeof(Middle_Border_Type),(compfn)CompareMiddle);	
	FileMinX = FileMinY = LARGE;
	FileMaxX = FileMaxY = -LARGE;
	CurrentMinX = CurrentMinY = LARGE;
	CurrentMaxX = CurrentMaxY = -LARGE;
	curcase = 0;
	polyid = 1;
	Npts = 0; 
	nparts = 1;
	ptcount = 0;
	Build_db_Header(dbfout,0,dbMiddle);
	Build_db_FieldHeaders(dbfout,dbMiddle);	
	//sprintf(elmrecord," %8d%-5s%-5s",polyid,elm[curcase].County,elm[curcase].Elementary);
	sprintf(midrecord," %-8d", polyid);
	sprintf(&midrecord[9],"%-5s",mid[curcase].County);
	sprintf(&midrecord[14],"%-5s",mid[curcase].Middle);
		//urb[curcase].Urbflag);	
	fwrite(&midrecord,sizeof(midrecord)-1,1,dbfout);
	if (mid[0].Flip == 0)
	{
		curX = mid[0].Tolong;
		curY = mid[0].Tolat;		
		Pts[Npts].Longitude = mid[curcase].Frlong;
		Pts[Npts].Latitude = mid[curcase].Frlat;
		Npts++;
		Get_Shape_Points(mid[curcase].Tlid, mid[curcase].Flip);
		Pts[Npts].Longitude = mid[curcase].Tolong;
		Pts[Npts].Latitude = mid[curcase].Tolat;
		Npts++;
		mid[curcase].Chosen = 1;		
	}
	else
	{
		curX = mid[0].Frlong;
		curY = mid[0].Frlat;		
		Pts[Npts].Longitude = mid[curcase].Tolong;
		Pts[Npts].Latitude = mid[curcase].Tolat;
		Npts++;
		Get_Shape_Points(mid[curcase].Tlid, mid[curcase].Flip);
		Pts[Npts].Longitude = mid[curcase].Frlong;
		Pts[Npts].Latitude = mid[curcase].Frlat;
		Npts++;
		mid[curcase].Chosen = 1;		
	}
	ptcount += Npts;
	
    fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
	
	if (Pts[0].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < CurrentMinY)
		CurrentMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[0].Latitude;	
	if (Pts[0].Longitude < FileMinX)
		FileMinX = Pts[0].Longitude;
	if (Pts[0].Longitude > FileMaxX)
		FileMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < FileMinY)
		FileMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > FileMaxY)
		FileMaxY = Pts[0].Latitude;

	if (Pts[Npts-1].Longitude < CurrentMinX)
		CurrentMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < CurrentMinY)
		CurrentMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[Npts-1].Latitude;	
	if (Pts[Npts-1].Longitude < FileMinX)
		FileMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > FileMaxX)
		FileMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < FileMinY)
		FileMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > FileMaxY)
		FileMaxY = Pts[Npts-1].Latitude;		
	n = 1;
	steppos = (int)(n*100/written);	
	Ptrdlg->m_Progress.SetPos(steppos);
    while (n < written)
	{		
		sprintf(msg,"processed %d of %d records",n,written);
		Ptrdlg->SetDlgItemText(IDC_MIDDLE,msg);		
		found = 0;
		for (i = 1; i < written; i++)
         {
			Npts = 0;
			if (mid[i].Chosen != 0)
				continue;
			if (mid[i].Flip == 0)
			{
				if ((mid[i].Frlong == curX) && (mid[i].Frlat == curY))
				{                          
					if (strcmp(mid[i].Middle,mid[curcase].Middle) != 0)
						continue;	            
					//if (urb[i].Urbflag != urb[i].Urbflag)
					//	continue;
					Get_Shape_Points(mid[i].Tlid,mid[i].Flip);
					Pts[Npts].Longitude = mid[i].Tolong;
					Pts[Npts].Latitude = mid[i].Tolat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					mid[i].Chosen = 1;            
					found = 1;                      
					curX = mid[i].Tolong;
					curY = mid[i].Tolat;                
					curcase = i;
					break;
				}
			}
			else
			{
				if ((mid[i].Tolong == curX) && (mid[i].Tolat == curY))
				{
					if (strcmp(mid[i].Middle,mid[curcase].Middle) != 0)
						continue;	            
					//if (urb[i].Urbflag != urb[curcase].Urbflag)
					//	continue;
					Get_Shape_Points(mid[i].Tlid,mid[i].Flip);
					Pts[Npts].Longitude = mid[i].Frlong;
					Pts[Npts].Latitude = mid[i].Frlat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = mid[i].Frlong;
					curY = mid[i].Frlat;                        
					mid[i].Chosen = 1;	
					found = 1;          
					curcase = i;
					break;
				}
			}
        }//close for loop
		if (found == 0) //initialize new case, eg, new ring or new poly
		{			
			fwrite(&ptcount,sizeof(int),1,headtemp);
			ptcount = 0;
			for (i = 0; i < written; i++) //check for new ring in poly
            {                    
         		if (mid[i].Chosen != 0)
					continue;    
				if (strcmp(mid[i].Middle,mid[curcase].Middle) != 0)
					continue;	            
				//if (urb[i].Urbflag != urb[curcase].Urbflag)
				//	continue;
				//if we get here it is a new ring in current poly
				found = 1;
				nparts++;
				Npts = 0;
				if (mid[i].Flip == 0)
				{
					Pts[Npts].Longitude = mid[i].Frlong;
					Pts[Npts].Latitude = mid[i].Frlat;
					Npts++;
					Get_Shape_Points(mid[i].Tlid,mid[i].Flip);
					Pts[Npts].Longitude = mid[i].Tolong;
					Pts[Npts].Latitude = mid[i].Tolat;
					Npts++;			
    				n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					mid[i].Chosen = 1;
    		   		curX = mid[i].Tolong;
    				curY = mid[i].Tolat;
					curcase = i;
					break;
				}
				else
				{
					Pts[Npts].Longitude = mid[i].Tolong;
					Pts[Npts].Latitude = mid[i].Tolat;
					Npts++;
					Get_Shape_Points(mid[i].Tlid,mid[i].Flip);
					Pts[Npts].Longitude = mid[i].Frlong;
					Pts[Npts].Latitude = mid[i].Frlat;
					Npts++;			
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					mid[i].Chosen = 1;
    		   		curX = mid[i].Frlong;
    				curY = mid[i].Frlat;
					curcase = i;
					break;
				}
    		}
    	}
		if (found == 0) // new poly, first ring
		{
			
			fwrite(&nparts,sizeof(int),1,partstemp);
			nparts = 1;
			fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
			CurrentMinX = CurrentMinY = LARGE;
			CurrentMaxX = CurrentMaxY = -LARGE;

			for (i = 0; i < written; i++)//first check for new ring in current poly
            {                    
         		if (mid[i].Chosen != 0)
					continue;             
				polyid++;
				//sprintf(elmrecord," %-8d%-5s%-5s",polyid,elm[i].County,elm[i].Elementary);
					//urb[i].Urbflag);
				sprintf(midrecord," %-8d", polyid);
				sprintf(&midrecord[9],"%-5s",mid[i].County);
				sprintf(&midrecord[14],"%-5s",mid[i].Middle);
	
				fwrite(&midrecord,sizeof(midrecord)-1,1,dbfout);    		
				Npts = 0;
				if (mid[i].Flip == 0)
				{
					Pts[Npts].Longitude = mid[i].Frlong;
					Pts[Npts].Latitude = mid[i].Frlat;
					Npts++;
					Get_Shape_Points(mid[i].Tlid,mid[i].Flip);
					Pts[Npts].Longitude = mid[i].Tolong;
					Pts[Npts].Latitude = mid[i].Tolat;
					Npts++;					
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					mid[i].Chosen = 1;            
					found = 1;                      
					curX = mid[i].Tolong;
					curY = mid[i].Tolat;                
					curcase = i;
					break;					
				}
				else
				{
					Pts[Npts].Longitude = mid[i].Tolong;
					Pts[Npts].Latitude = mid[i].Tolat;
					Npts++;
					Get_Shape_Points(mid[i].Tlid,mid[i].Flip);
					Pts[Npts].Longitude = mid[i].Frlong;
					Pts[Npts].Latitude = mid[i].Frlat;
					Npts++;				
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = mid[i].Frlong;
					curY = mid[i].Frlat;                        
					mid[i].Chosen = 1;		
					found = 1;          
					curcase = i;	
					break;					
				}	
			}
		}
		//by now found should be 1
		if (found == 0)
		{
			info.Format("ERROR - found is zero");
			Ptrdlg->ErrorMessage(info);									
			MissingFile = -1;
			return;
		}
		ptcount += Npts;
		fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
		if (Pts[0].Longitude < CurrentMinX)
			CurrentMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < CurrentMinY)
			CurrentMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[0].Latitude;	
		if (Pts[0].Longitude < FileMinX)
			FileMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > FileMaxX)
			FileMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < FileMinY)
			FileMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > FileMaxY)
			FileMaxY = Pts[0].Latitude;

		if (Pts[Npts-1].Longitude < CurrentMinX)
			CurrentMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < CurrentMinY)
			CurrentMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[Npts-1].Latitude;	
		if (Pts[Npts-1].Longitude < FileMinX)
			FileMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > FileMaxX)
			FileMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < FileMinY)
			FileMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > FileMaxY)
			FileMaxY = Pts[Npts-1].Latitude;		
	}//close while loop
	fwrite(&ptcount,sizeof(int),1,headtemp);
	fwrite(&nparts,sizeof(int),1,partstemp);
	fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
	fclose(boxtemp);
	fclose(headtemp);
	fclose(ptstemp);
	fclose(partstemp);
	sprintf(msg,"processed %d of %d records",n,written);
	Ptrdlg->SetDlgItemText(IDC_MIDDLE,msg);			
	write_eof(dbfout);
	rewind(dbfout);
	Build_db_Header(dbfout,polyid,dbMiddle);
	Build_Poly_Shape("mid");
	Ptrdlg->m_strMiddle.Format("%d Middle School Districts",polyid);
	Ptrdlg->SetDlgItemText(IDC_MIDDLE,Ptrdlg->m_strMiddle);
    fclose(dbfout);
	free(mid);
	fprintf(LOG,"Wrote %d Middle School District polygons to shape %s%smid\n", polyid,
		Outfilepath, Outfiletitle);		
}

void Match_Poly_Lines_Secondary()
{
	int polyid, found, i, nparts, ptcount;
	long num, n, written, curcase;
	Secondary_Border_Type *sec;
	double  curX, curY;	
    FILE  *dbfout, *ptstemp, *headtemp, *partstemp, *boxtemp; 
	CString info, fname, errmsg;	
	char secrecord[20];
	int steppos;
	char msg[100];
	int doleft, doright;

	
	if (APolycounts[10] == 0)
	{
		Ptrdlg->SetDlgItemText(IDC_SECONDARY,"No Such Cases");		
		return;
	}	
	fname.Format("%s%ssec.dbf",Outfilepath,Outfiletitle);			
	dbfout = fopen(fname,"wb");
	if (dbfout == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	ptstemp = fopen("pts.tmp","wb");
	if (ptstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	headtemp = fopen("head.tmp","wb");
	if (headtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	boxtemp = fopen("box.tmp","wb");
	if (boxtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	partstemp = fopen("parts.tmp","wb");
	if (partstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	sec = (Secondary_Border_Type *)calloc(APolycounts[10]+Watercut*SPolycounts[0],sizeof(Secondary_Border_Type));	
	written = 0;
	for (num = 0; num < CountI; num++)
	{
		if (strcmp(TypeIs[num].Secl,TypeIs[num].Secr)== 0)
		{
			if (Watercut)
			{

				if (TypeIs[num].Waterl == TypeIs[num].Waterr)
					continue;
			}
			else
				continue;		
		}
		doleft = 0;
		
		if (strcmp(TypeIs[num].Secl,"     ") != 0)
		{//left case	
			if (Watercut)
			{

				if (!TypeIs[num].Waterl)
					doleft = 1;
			}
			else
				doleft = 1;
			if (doleft)
			{
				sprintf(sec[written].County,"%s%s",TypeIs[num].State,TypeIs[num].County);				
				sprintf(sec[written].Secondary,"%5s",TypeIs[num].Secl);				
				//sprintf(urb[written].Urbflag,"%c",TypeIs[num].Urbl[4]);				
				//urb[written].Urbflag = TypeIs[num].Urbl[4];
				sprintf(sec[written].Tlid,"%s",TypeIs[num].Tlid);
				sec[written].Frlong = Type1s[num].Frlong;
				sec[written].Frlat = Type1s[num].Frlat;
				sec[written].Tolong = Type1s[num].Tolong;
				sec[written].Tolat = Type1s[num].Tolat;
				sec[written].Chosen = 0;
				sec[written].Flip = 1;
				written++;
			}
		}
		doright = 0;
		if (strcmp(TypeIs[num].Secr, "     ") != 0)
		{//rightcase 
			//printf("\nright case");			
			if (Watercut)
			{
				if (!TypeIs[num].Waterr)
					doright = 1;
			}
			else
				doright = 1;
			if (doright)
			{
				sprintf(sec[written].County,"%s%s",TypeIs[num].State,TypeIs[num].County);				
				sprintf(sec[written].Secondary,"%5s",TypeIs[num].Secr);				
				//sprintf(urb[written].Urbflag,"%c",TypeIs[num].Urbr[4]);				
				//urb[written].Urbflag = TypeIs[num].Urbr[4];
				sprintf(sec[written].Tlid,"%s",TypeIs[num].Tlid);				
				sec[written].Frlong = Type1s[num].Frlong;
				sec[written].Frlat = Type1s[num].Frlat;
				sec[written].Tolong = Type1s[num].Tolong;
				sec[written].Tolat = Type1s[num].Tolat;
				sec[written].Chosen = 0;
				sec[written].Flip = 0;
				written++;
			}
		}
	}	
	if (written > APolycounts[10]+Watercut*SPolycounts[0])
	{
		Ptrdlg->ErrorMessage("the number of Secondary border lines exceeds the count");				
		MissingFile = -1;
		return;
	}
	if (written == 0)
	{
		if (!Watercut)
			fprintf(LOG,"There are no lines for Secondary School polygons\n");
		else
		{
			fprintf(LOG,"All Secondary School polygon for this county coincide with water polygons\n");
			fprintf(LOG,"Try turning off the water polygon clipping option\n");
		}
		return;
	}
	
	//time to chain		
	Ptrdlg->m_strProcess.Format("Gathering Secondary School Boundary Lines");
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	qsort((void *)sec,written,sizeof(Secondary_Border_Type),(compfn)CompareSecondary);	
	FileMinX = FileMinY = LARGE;
	FileMaxX = FileMaxY = -LARGE;
	CurrentMinX = CurrentMinY = LARGE;
	CurrentMaxX = CurrentMaxY = -LARGE;
	curcase = 0;
	polyid = 1;
	Npts = 0; 
	nparts = 1;
	ptcount = 0;
	Build_db_Header(dbfout,0,dbSecondary);
	Build_db_FieldHeaders(dbfout,dbSecondary);	
	//sprintf(secrecord," %8d%-5s%-5s",polyid,sec[curcase].County,sec[curcase].Secondary);
	sprintf(secrecord," %-8d",polyid);
	sprintf(&secrecord[9],"%5s",sec[curcase].County);
	sprintf(&secrecord[14],"%5s",sec[curcase].Secondary);
		//urb[curcase].Urbflag);	
	fwrite(&secrecord,sizeof(secrecord)-1,1,dbfout);
	if (sec[0].Flip == 0)
	{
		curX = sec[0].Tolong;
		curY = sec[0].Tolat;		
		Pts[Npts].Longitude = sec[curcase].Frlong;
		Pts[Npts].Latitude = sec[curcase].Frlat;
		Npts++;
		Get_Shape_Points(sec[curcase].Tlid, sec[curcase].Flip);
		Pts[Npts].Longitude = sec[curcase].Tolong;
		Pts[Npts].Latitude = sec[curcase].Tolat;
		Npts++;
		sec[curcase].Chosen = 1;		
	}
	else
	{
		curX = sec[0].Frlong;
		curY = sec[0].Frlat;		
		Pts[Npts].Longitude = sec[curcase].Tolong;
		Pts[Npts].Latitude = sec[curcase].Tolat;
		Npts++;
		Get_Shape_Points(sec[curcase].Tlid, sec[curcase].Flip);
		Pts[Npts].Longitude = sec[curcase].Frlong;
		Pts[Npts].Latitude = sec[curcase].Frlat;
		Npts++;
		sec[curcase].Chosen = 1;		
	}
	ptcount += Npts;
	
    fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
	
	if (Pts[0].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < CurrentMinY)
		CurrentMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[0].Latitude;	
	if (Pts[0].Longitude < FileMinX)
		FileMinX = Pts[0].Longitude;
	if (Pts[0].Longitude > FileMaxX)
		FileMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < FileMinY)
		FileMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > FileMaxY)
		FileMaxY = Pts[0].Latitude;

	if (Pts[Npts-1].Longitude < CurrentMinX)
		CurrentMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < CurrentMinY)
		CurrentMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[Npts-1].Latitude;	
	if (Pts[Npts-1].Longitude < FileMinX)
		FileMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > FileMaxX)
		FileMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < FileMinY)
		FileMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > FileMaxY)
		FileMaxY = Pts[Npts-1].Latitude;		
	n = 1;
	steppos = (int)(n*100/written);	
	Ptrdlg->m_Progress.SetPos(steppos);
    while (n < written)
	{		
		sprintf(msg,"processed %d of %d records",n,written);
		Ptrdlg->SetDlgItemText(IDC_SECONDARY,msg);		
		found = 0;
		for (i = 1; i < written; i++)
         {
			Npts = 0;
			if (sec[i].Chosen != 0)
				continue;
			if (sec[i].Flip == 0)
			{
				if ((sec[i].Frlong == curX) && (sec[i].Frlat == curY))
				{                          
					if (strcmp(sec[i].Secondary,sec[curcase].Secondary) != 0)
						continue;	            
					//if (urb[i].Urbflag != urb[i].Urbflag)
					//	continue;
					Get_Shape_Points(sec[i].Tlid,sec[i].Flip);
					Pts[Npts].Longitude = sec[i].Tolong;
					Pts[Npts].Latitude = sec[i].Tolat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					sec[i].Chosen = 1;            
					found = 1;                      
					curX = sec[i].Tolong;
					curY = sec[i].Tolat;                
					curcase = i;
					break;
				}
			}
			else
			{
				if ((sec[i].Tolong == curX) && (sec[i].Tolat == curY))
				{
					if (strcmp(sec[i].Secondary,sec[curcase].Secondary) != 0)
						continue;	            
					//if (urb[i].Urbflag != urb[curcase].Urbflag)
					//	continue;
					Get_Shape_Points(sec[i].Tlid,sec[i].Flip);
					Pts[Npts].Longitude = sec[i].Frlong;
					Pts[Npts].Latitude = sec[i].Frlat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = sec[i].Frlong;
					curY = sec[i].Frlat;                        
					sec[i].Chosen = 1;	
					found = 1;          
					curcase = i;
					break;
				}
			}
        }//close for loop
		if (found == 0) //initialize new case, eg, new ring or new poly
		{			
			fwrite(&ptcount,sizeof(int),1,headtemp);
			ptcount = 0;
			for (i = 0; i < written; i++) //check for new ring in poly
            {                    
         		if (sec[i].Chosen != 0)
					continue;    
				if (strcmp(sec[i].Secondary,sec[curcase].Secondary) != 0)
					continue;	            
				//if (urb[i].Urbflag != urb[curcase].Urbflag)
				//	continue;
				//if we get here it is a new ring in current poly
				found = 1;
				nparts++;
				Npts = 0;
				if (sec[i].Flip == 0)
				{
					Pts[Npts].Longitude = sec[i].Frlong;
					Pts[Npts].Latitude = sec[i].Frlat;
					Npts++;
					Get_Shape_Points(sec[i].Tlid,sec[i].Flip);
					Pts[Npts].Longitude = sec[i].Tolong;
					Pts[Npts].Latitude = sec[i].Tolat;
					Npts++;			
    				n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					sec[i].Chosen = 1;
    		   		curX = sec[i].Tolong;
    				curY = sec[i].Tolat;
					curcase = i;
					break;
				}
				else
				{
					Pts[Npts].Longitude = sec[i].Tolong;
					Pts[Npts].Latitude = sec[i].Tolat;
					Npts++;
					Get_Shape_Points(sec[i].Tlid,sec[i].Flip);
					Pts[Npts].Longitude = sec[i].Frlong;
					Pts[Npts].Latitude = sec[i].Frlat;
					Npts++;			
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					sec[i].Chosen = 1;
    		   		curX = sec[i].Frlong;
    				curY = sec[i].Frlat;
					curcase = i;
					break;
				}
    		}
    	}
		if (found == 0) // new poly, first ring
		{
			
			fwrite(&nparts,sizeof(int),1,partstemp);
			nparts = 1;
			fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
			CurrentMinX = CurrentMinY = LARGE;
			CurrentMaxX = CurrentMaxY = -LARGE;

			for (i = 0; i < written; i++)//first check for new ring in current poly
            {                    
         		if (sec[i].Chosen != 0)
					continue;             
				polyid++;
				//sprintf(secrecord," %-8d%-5s%-5s",polyid,sec[i].County,sec[i].Secondary);
					//urb[i].Urbflag);
				sprintf(secrecord," %-8d",polyid);
				sprintf(&secrecord[9],"%5s",sec[i].County);
				sprintf(&secrecord[14],"%5s",sec[i].Secondary);
	
				fwrite(&secrecord,sizeof(secrecord)-1,1,dbfout);    		
				Npts = 0;
				if (sec[i].Flip == 0)
				{
					Pts[Npts].Longitude = sec[i].Frlong;
					Pts[Npts].Latitude = sec[i].Frlat;
					Npts++;
					Get_Shape_Points(sec[i].Tlid,sec[i].Flip);
					Pts[Npts].Longitude = sec[i].Tolong;
					Pts[Npts].Latitude = sec[i].Tolat;
					Npts++;					
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					sec[i].Chosen = 1;            
					found = 1;                      
					curX = sec[i].Tolong;
					curY = sec[i].Tolat;                
					curcase = i;
					break;					
				}
				else
				{
					Pts[Npts].Longitude = sec[i].Tolong;
					Pts[Npts].Latitude = sec[i].Tolat;
					Npts++;
					Get_Shape_Points(sec[i].Tlid,sec[i].Flip);
					Pts[Npts].Longitude = sec[i].Frlong;
					Pts[Npts].Latitude = sec[i].Frlat;
					Npts++;				
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = sec[i].Frlong;
					curY = sec[i].Frlat;                        
					sec[i].Chosen = 1;		
					found = 1;          
					curcase = i;	
					break;					
				}	
			}
		}
		//by now found should be 1
		if (found == 0)
		{
			info.Format("ERROR - found is zero");
			Ptrdlg->ErrorMessage(info);									
			MissingFile = -1;
			return;
		}
		ptcount += Npts;
		fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
		if (Pts[0].Longitude < CurrentMinX)
			CurrentMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < CurrentMinY)
			CurrentMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[0].Latitude;	
		if (Pts[0].Longitude < FileMinX)
			FileMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > FileMaxX)
			FileMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < FileMinY)
			FileMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > FileMaxY)
			FileMaxY = Pts[0].Latitude;

		if (Pts[Npts-1].Longitude < CurrentMinX)
			CurrentMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < CurrentMinY)
			CurrentMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[Npts-1].Latitude;	
		if (Pts[Npts-1].Longitude < FileMinX)
			FileMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > FileMaxX)
			FileMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < FileMinY)
			FileMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > FileMaxY)
			FileMaxY = Pts[Npts-1].Latitude;		
	}//close while loop
	fwrite(&ptcount,sizeof(int),1,headtemp);
	fwrite(&nparts,sizeof(int),1,partstemp);
	fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
	fclose(boxtemp);
	fclose(headtemp);
	fclose(ptstemp);
	fclose(partstemp);
	sprintf(msg,"processed %d of %d records",n,written);
	Ptrdlg->SetDlgItemText(IDC_SECONDARY,msg);			
	write_eof(dbfout);
	rewind(dbfout);
	Build_db_Header(dbfout,polyid,dbSecondary);
	Build_Poly_Shape("sec");
	Ptrdlg->m_strSecondary.Format("%d Secondary School Districts",polyid);
	Ptrdlg->SetDlgItemText(IDC_SECONDARY,Ptrdlg->m_strSecondary);
    fclose(dbfout);
	free(sec);
	fprintf(LOG,"Wrote %d Secondary School District polygons to shape %s%ssec\n", polyid,Outfilepath,
		Outfiletitle);		
}
void Match_Poly_Lines_Unified()
{
	int polyid, found, i, nparts, ptcount;
	long num, n, written, curcase;
	Unified_Border_Type *uni;
	double  curX, curY;	
    FILE  *dbfout, *ptstemp, *headtemp, *partstemp, *boxtemp; 
	CString info, fname, errmsg;	
	char unirecord[20];
	int steppos;
	char msg[100];
	int doleft, doright;


	
	if (APolycounts[11] == 0)
	{
		Ptrdlg->SetDlgItemText(IDC_UNIFIED,"No Such Cases");		
		return;
	}	
	fname.Format("%s%suni.dbf",Outfilepath,Outfiletitle);			
	dbfout = fopen(fname,"wb");
	if (dbfout == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	ptstemp = fopen("pts.tmp","wb");
	if (ptstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	headtemp = fopen("head.tmp","wb");
	if (headtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	boxtemp = fopen("box.tmp","wb");
	if (boxtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	partstemp = fopen("parts.tmp","wb");
	if (partstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	uni = (Unified_Border_Type *)calloc(APolycounts[11]+Watercut*SPolycounts[0],sizeof(Unified_Border_Type));	
	written = 0;
	for (num = 0; num < CountI; num++)
	{
		if (strcmp(TypeIs[num].Unil,TypeIs[num].Unir)== 0)
		{
			if (Watercut)
			{

				if (TypeIs[num].Waterl == TypeIs[num].Waterr)
					continue;
			}
			else
				continue;		
		}
		doleft = 0;
		
		if (strcmp(TypeIs[num].Unil,"     ") != 0)
		{//left case	
			if (Watercut)
			{

				if (!TypeIs[num].Waterl)
					doleft = 1;
			}
			else
				doleft = 1;
			if (doleft)
			{
				sprintf(uni[written].County,"%s%s",TypeIs[num].State,TypeIs[num].County);				
				sprintf(uni[written].Unified,"%5s",TypeIs[num].Unil);				
				//sprintf(urb[written].Urbflag,"%c",TypeIs[num].Urbl[4]);				
				//urb[written].Urbflag = TypeIs[num].Urbl[4];
				sprintf(uni[written].Tlid,"%s",TypeIs[num].Tlid);
				uni[written].Frlong = Type1s[num].Frlong;
				uni[written].Frlat = Type1s[num].Frlat;
				uni[written].Tolong = Type1s[num].Tolong;
				uni[written].Tolat = Type1s[num].Tolat;
				uni[written].Chosen = 0;
				uni[written].Flip = 1;
				written++;
			}
		}
		doright = 0;
		if (strcmp(TypeIs[num].Unir, "     ") != 0)
			{//rightcase 
			//printf("\nright case");			
			if (Watercut)
			{

				if (!TypeIs[num].Waterr)
					doright = 1;
			}
			else
				doright = 1;
			if (doright)
			{
				sprintf(uni[written].County,"%s%s",TypeIs[num].State,TypeIs[num].County);				
				sprintf(uni[written].Unified,"%5s",TypeIs[num].Unir);				
				//sprintf(urb[written].Urbflag,"%c",TypeIs[num].Urbr[4]);				
				//urb[written].Urbflag = TypeIs[num].Urbr[4];
				sprintf(uni[written].Tlid,"%s",TypeIs[num].Tlid);				
				uni[written].Frlong = Type1s[num].Frlong;
				uni[written].Frlat = Type1s[num].Frlat;
				uni[written].Tolong = Type1s[num].Tolong;
				uni[written].Tolat = Type1s[num].Tolat;
				uni[written].Chosen = 0;
				uni[written].Flip = 0;
				written++;
			}
		}
	}	
	if (written > APolycounts[11]+Watercut*SPolycounts[0])
	{
		Ptrdlg->ErrorMessage("the number of Unified border lines exceeds the count");				
		MissingFile = -1;
		return;
	}
	if (written == 0)
	{
		if (!Watercut)
			fprintf(LOG,"There are no lines for Unified School District polygons\n");
		else
		{
			fprintf(LOG,"All Unified School District polygons for this county coincide with water polygons\n");
			fprintf(LOG,"Try turning off the water polygon clipping option\n");
		}
		return;
	}
	
	//time to chain		
	Ptrdlg->m_strProcess.Format("Gathering Unified School Boundary Lines");
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	qsort((void *)uni,written,sizeof(Unified_Border_Type),(compfn)CompareUnified);	
	FileMinX = FileMinY = LARGE;
	FileMaxX = FileMaxY = -LARGE;
	CurrentMinX = CurrentMinY = LARGE;
	CurrentMaxX = CurrentMaxY = -LARGE;
	curcase = 0;
	polyid = 1;
	Npts = 0; 
	nparts = 1;
	ptcount = 0;
	Build_db_Header(dbfout,0,dbUnified);
	Build_db_FieldHeaders(dbfout,dbUnified);	
	//sprintf(unirecord," %8d%-5s%-5s",polyid,uni[curcase].County,uni[curcase].Unified);
	sprintf(unirecord," %-8d",polyid);
	sprintf(&unirecord[9],"%-5s",uni[curcase].County);
	sprintf(&unirecord[14],"%-5s",uni[curcase].Unified);
		//urb[curcase].Urbflag);	
	fwrite(&unirecord,sizeof(unirecord)-1,1,dbfout);
	if (uni[0].Flip == 0)
	{
		curX = uni[0].Tolong;
		curY = uni[0].Tolat;		
		Pts[Npts].Longitude = uni[curcase].Frlong;
		Pts[Npts].Latitude = uni[curcase].Frlat;
		Npts++;
		Get_Shape_Points(uni[curcase].Tlid, uni[curcase].Flip);
		Pts[Npts].Longitude = uni[curcase].Tolong;
		Pts[Npts].Latitude = uni[curcase].Tolat;
		Npts++;
		uni[curcase].Chosen = 1;		
	}
	else
	{
		curX = uni[0].Frlong;
		curY = uni[0].Frlat;		
		Pts[Npts].Longitude = uni[curcase].Tolong;
		Pts[Npts].Latitude = uni[curcase].Tolat;
		Npts++;
		Get_Shape_Points(uni[curcase].Tlid, uni[curcase].Flip);
		Pts[Npts].Longitude = uni[curcase].Frlong;
		Pts[Npts].Latitude = uni[curcase].Frlat;
		Npts++;
		uni[curcase].Chosen = 1;		
	}
	ptcount += Npts;
	
    fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
	
	if (Pts[0].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < CurrentMinY)
		CurrentMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[0].Latitude;	
	if (Pts[0].Longitude < FileMinX)
		FileMinX = Pts[0].Longitude;
	if (Pts[0].Longitude > FileMaxX)
		FileMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < FileMinY)
		FileMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > FileMaxY)
		FileMaxY = Pts[0].Latitude;

	if (Pts[Npts-1].Longitude < CurrentMinX)
		CurrentMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < CurrentMinY)
		CurrentMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[Npts-1].Latitude;	
	if (Pts[Npts-1].Longitude < FileMinX)
		FileMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > FileMaxX)
		FileMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < FileMinY)
		FileMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > FileMaxY)
		FileMaxY = Pts[Npts-1].Latitude;		
	n = 1;
	steppos = (int)(n*100/written);	
	Ptrdlg->m_Progress.SetPos(steppos);
    while (n < written)
	{		
		sprintf(msg,"processed %d of %d records",n,written);
		Ptrdlg->SetDlgItemText(IDC_UNIFIED,msg);		
		found = 0;
		for (i = 1; i < written; i++)
         {
			Npts = 0;
			if (uni[i].Chosen != 0)
				continue;
			if (uni[i].Flip == 0)
			{
				if ((uni[i].Frlong == curX) && (uni[i].Frlat == curY))
				{                          
					if (strcmp(uni[i].Unified,uni[curcase].Unified) != 0)
						continue;	            
					//if (urb[i].Urbflag != urb[i].Urbflag)
					//	continue;
					Get_Shape_Points(uni[i].Tlid,uni[i].Flip);
					Pts[Npts].Longitude = uni[i].Tolong;
					Pts[Npts].Latitude = uni[i].Tolat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					uni[i].Chosen = 1;            
					found = 1;                      
					curX = uni[i].Tolong;
					curY = uni[i].Tolat;                
					curcase = i;
					break;
				}
			}
			else
			{
				if ((uni[i].Tolong == curX) && (uni[i].Tolat == curY))
				{
					if (strcmp(uni[i].Unified,uni[curcase].Unified) != 0)
						continue;	            
					//if (urb[i].Urbflag != urb[curcase].Urbflag)
					//	continue;
					Get_Shape_Points(uni[i].Tlid,uni[i].Flip);
					Pts[Npts].Longitude = uni[i].Frlong;
					Pts[Npts].Latitude = uni[i].Frlat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = uni[i].Frlong;
					curY = uni[i].Frlat;                        
					uni[i].Chosen = 1;	
					found = 1;          
					curcase = i;
					break;
				}
			}
        }//close for loop
		if (found == 0) //initialize new case, eg, new ring or new poly
		{			
			fwrite(&ptcount,sizeof(int),1,headtemp);
			ptcount = 0;
			for (i = 0; i < written; i++) //check for new ring in poly
            {                    
         		if (uni[i].Chosen != 0)
					continue;    
				if (strcmp(uni[i].Unified,uni[curcase].Unified) != 0)
					continue;	            
				//if (urb[i].Urbflag != urb[curcase].Urbflag)
				//	continue;
				//if we get here it is a new ring in current poly
				found = 1;
				nparts++;
				Npts = 0;
				if (uni[i].Flip == 0)
				{
					Pts[Npts].Longitude = uni[i].Frlong;
					Pts[Npts].Latitude = uni[i].Frlat;
					Npts++;
					Get_Shape_Points(uni[i].Tlid,uni[i].Flip);
					Pts[Npts].Longitude = uni[i].Tolong;
					Pts[Npts].Latitude = uni[i].Tolat;
					Npts++;			
    				n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					uni[i].Chosen = 1;
    		   		curX = uni[i].Tolong;
    				curY = uni[i].Tolat;
					curcase = i;
					break;
				}
				else
				{
					Pts[Npts].Longitude = uni[i].Tolong;
					Pts[Npts].Latitude = uni[i].Tolat;
					Npts++;
					Get_Shape_Points(uni[i].Tlid,uni[i].Flip);
					Pts[Npts].Longitude = uni[i].Frlong;
					Pts[Npts].Latitude = uni[i].Frlat;
					Npts++;			
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					uni[i].Chosen = 1;
    		   		curX = uni[i].Frlong;
    				curY = uni[i].Frlat;
					curcase = i;
					break;
				}
    		}
    	}
		if (found == 0) // new poly, first ring
		{
			
			fwrite(&nparts,sizeof(int),1,partstemp);
			nparts = 1;
			fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
			CurrentMinX = CurrentMinY = LARGE;
			CurrentMaxX = CurrentMaxY = -LARGE;

			for (i = 0; i < written; i++)//first check for new ring in current poly
            {                    
         		if (uni[i].Chosen != 0)
					continue;             
				polyid++;
				//sprintf(unirecord," %-8d%-5s%-5s",polyid,uni[i].County,uni[i].Unified);
				sprintf(unirecord," %-8d",polyid);
				sprintf(&unirecord[9],"%-5s",uni[i].County);
				sprintf(&unirecord[14],"%-5s",uni[i].Unified);
	
				//urb[i].Urbflag);
				fwrite(&unirecord,sizeof(unirecord)-1,1,dbfout);    		
				Npts = 0;
				if (uni[i].Flip == 0)
				{
					Pts[Npts].Longitude = uni[i].Frlong;
					Pts[Npts].Latitude = uni[i].Frlat;
					Npts++;
					Get_Shape_Points(uni[i].Tlid,uni[i].Flip);
					Pts[Npts].Longitude = uni[i].Tolong;
					Pts[Npts].Latitude = uni[i].Tolat;
					Npts++;					
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					uni[i].Chosen = 1;            
					found = 1;                      
					curX = uni[i].Tolong;
					curY = uni[i].Tolat;                
					curcase = i;
					break;					
				}
				else
				{
					Pts[Npts].Longitude = uni[i].Tolong;
					Pts[Npts].Latitude = uni[i].Tolat;
					Npts++;
					Get_Shape_Points(uni[i].Tlid,uni[i].Flip);
					Pts[Npts].Longitude = uni[i].Frlong;
					Pts[Npts].Latitude = uni[i].Frlat;
					Npts++;				
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = uni[i].Frlong;
					curY = uni[i].Frlat;                        
					uni[i].Chosen = 1;		
					found = 1;          
					curcase = i;	
					break;					
				}	
			}
		}
		//by now found should be 1
		if (found == 0)
		{
			info.Format("ERROR - found is zero");
			Ptrdlg->ErrorMessage(info);									
			MissingFile = -1;
			return;
		}
		ptcount += Npts;
		fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
		if (Pts[0].Longitude < CurrentMinX)
			CurrentMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < CurrentMinY)
			CurrentMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[0].Latitude;	
		if (Pts[0].Longitude < FileMinX)
			FileMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > FileMaxX)
			FileMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < FileMinY)
			FileMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > FileMaxY)
			FileMaxY = Pts[0].Latitude;

		if (Pts[Npts-1].Longitude < CurrentMinX)
			CurrentMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < CurrentMinY)
			CurrentMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[Npts-1].Latitude;	
		if (Pts[Npts-1].Longitude < FileMinX)
			FileMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > FileMaxX)
			FileMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < FileMinY)
			FileMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > FileMaxY)
			FileMaxY = Pts[Npts-1].Latitude;		
	}//close while loop
	fwrite(&ptcount,sizeof(int),1,headtemp);
	fwrite(&nparts,sizeof(int),1,partstemp);
	fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
	fclose(boxtemp);
	fclose(headtemp);
	fclose(ptstemp);
	fclose(partstemp);
	sprintf(msg,"processed %d of %d records",n,written);
	Ptrdlg->SetDlgItemText(IDC_UNIFIED,msg);			
	write_eof(dbfout);
	rewind(dbfout);
	Build_db_Header(dbfout,polyid,dbUnified);
	Build_Poly_Shape("uni");
	Ptrdlg->m_strUnified.Format("%d Unified School Districts",polyid);
	Ptrdlg->SetDlgItemText(IDC_UNIFIED,Ptrdlg->m_strUnified);
    fclose(dbfout);
	free(uni);
	fprintf(LOG,"Wrote %d Unified School District polygons to shape %s%suni\n", polyid,
		Outfilepath, Outfiletitle);		
}

void Match_Poly_Lines_Water()
{
	int polyid, found, i, nparts, ptcount;
	long num, n, written, curcase;
	Water_Border_Type *wat;
	double  curX, curY;	
    FILE  *dbfout, *ptstemp, *headtemp, *partstemp, *boxtemp; 
	CString info, fname, errmsg;	
	char watrecord[48]; 
	int steppos;
	char msg[100];
	int landid;
	char leftwater[34],rightwater[34];


	
	if (SPolycounts[0] == 0)
	{
		Ptrdlg->SetDlgItemText(IDC_WATER,"No Such Cases");		
		return;
	}	
	fname.Format("%s%swat.dbf",Outfilepath,Outfiletitle);			
	dbfout = fopen(fname,"wb");
	if (dbfout == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	ptstemp = fopen("pts.tmp","wb");
	if (ptstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	headtemp = fopen("head.tmp","wb");
	if (headtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	boxtemp = fopen("box.tmp","wb");
	if (boxtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	partstemp = fopen("parts.tmp","wb");
	if (partstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	wat = (Water_Border_Type *)calloc(SPolycounts[0],sizeof(Water_Border_Type));		
	written = 0;
	
	for (num = 0; num < CountI; num++)
	{	
	//	if ((TypeIs[num].Waterl == 1) ||(TypeIs[num].Landl != -1))
		//the following is to see if we can "dissolve"
		if ((TypeIs[num].Waterl == 1) && (TypeIs[num].Waterr == 1))
		{
			if ((TypeIs[num].Landl == -1) && (TypeIs[num].Landr == -1))
				continue;
			if (TypeIs[num].Landl != -1)
			{
				landid = Get_Land7(Type8s[TypeIs[num].Landl].Land);
				sprintf(leftwater,"%s%s",Type7s[landid].Cfcc,Type7s[landid].Laname);
			}
			else
				sprintf(leftwater,"                                 ");
			if (TypeIs[num].Landr != -1)
			{
				landid = Get_Land7(Type8s[TypeIs[num].Landr].Land);
				sprintf(rightwater,"%s%s",Type7s[landid].Cfcc,Type7s[landid].Laname);
			}
			else
				sprintf(rightwater,"                                 ");
			if(strncmp(leftwater,rightwater,33) == 0)
				continue;
		}
		if (TypeIs[num].Waterl == 1)
			{//left case	
				sprintf(wat[written].County,"%s%s",TypeIs[num].State,TypeIs[num].County);				
				//sprintf(wat[written].Uacode,"%4s",TypeIs[num].Urbl);				
				//sprintf(wat[written].Urbflag,"%c",&TypeIs[num].Urbl[4]);				
				sprintf(wat[written].Tlid,"%s",TypeIs[num].Tlid);
				wat[written].Frlong = Type1s[num].Frlong;
				wat[written].Frlat = Type1s[num].Frlat;
				wat[written].Tolong = Type1s[num].Tolong;
				wat[written].Tolat = Type1s[num].Tolat;
				wat[written].Chosen = 0;
				wat[written].Flip = 1;
	
				if (TypeIs[num].Landl != -1)
				{
					landid = Get_Land7(Type8s[TypeIs[num].Landl].Land);
					sprintf(wat[written].Water,"%s%s",Type7s[landid].Cfcc,Type7s[landid].Laname);
				}
				else
					sprintf(wat[written].Water,"                                 ");
				written++;
			}
		if (TypeIs[num].Waterr == 1)
		//if ((TypeIs[num].Waterr == 1) ||(TypeIs[num].Landr != -1))
			{//rightcase 
			//printf("\nright case");			
				sprintf(wat[written].County,"%s%s",TypeIs[num].State,TypeIs[num].County);				
				//sprintf(urb[written].Uacode,"%4s",TypeIs[num].Urbr);				
				//sprintf(urb[written].Urbflag,"%c",&TypeIs[num].Urbr[4]);				
				sprintf(wat[written].Tlid,"%s",TypeIs[num].Tlid);				
				wat[written].Frlong = Type1s[num].Frlong;
				wat[written].Frlat = Type1s[num].Frlat;
				wat[written].Tolong = Type1s[num].Tolong;
				wat[written].Tolat = Type1s[num].Tolat;
				wat[written].Chosen = 0;
				wat[written].Flip = 0;
				if (TypeIs[num].Landr != -1)
				{
					landid = Get_Land7(Type8s[TypeIs[num].Landr].Land);
					sprintf(wat[written].Water,"%s%s",Type7s[landid].Cfcc,Type7s[landid].Laname);
				}
				else
					sprintf(wat[written].Water,"                                 ");
				written++;
			}
	}	
	if (written > SPolycounts[0])
	{
		Ptrdlg->ErrorMessage("the number of Water border lines exceeds the count");				
		MissingFile = -1;
		return;
	}
	//time to chain		
	//CString repval;
	//repval.Format("written = %d",written);
	//AfxMessageBox(repval);
	Ptrdlg->m_strProcess.Format("Gathering Water Poly Boundary Lines");
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	qsort((void *)wat,written,sizeof(Water_Border_Type),(compfn)CompareWat);	
	FileMinX = FileMinY = LARGE;
	FileMaxX = FileMaxY = -LARGE;
	CurrentMinX = CurrentMinY = LARGE;
	CurrentMaxX = CurrentMaxY = -LARGE;
	curcase = 0;
	polyid = 1;
	Npts = 0; 
	nparts = 1;
	ptcount = 0;
	Build_db_Header(dbfout,0,dbWater);
	Build_db_FieldHeaders(dbfout,dbWater);	
	//char wflag;
	//wflag = '1';
	//sprintf(watrecord," %8d%-5s%-33s",polyid,wat[curcase].County,wat[curcase].Water);
	sprintf(watrecord," %8d", polyid);
	sprintf(&watrecord[9],"%-5s",wat[curcase].County);
	sprintf(&watrecord[14],"%-33s",wat[curcase].Water);
	/*,urb[curcase].Uacode,
		urb[curcase].Urbflag);	*/
	//AfxMessageBox("writing record 1");
	fwrite(&watrecord,sizeof(watrecord)-1,1,dbfout);
	if (wat[0].Flip == 0)
	{
		curX = wat[0].Tolong;
		curY = wat[0].Tolat;		
		Pts[Npts].Longitude = wat[curcase].Frlong;
		Pts[Npts].Latitude = wat[curcase].Frlat;
		Npts++;
		Get_Shape_Points(wat[curcase].Tlid, wat[curcase].Flip);
		Pts[Npts].Longitude = wat[curcase].Tolong;
		Pts[Npts].Latitude = wat[curcase].Tolat;
		Npts++;
		wat[curcase].Chosen = 1;		
	}
	else
	{
		curX = wat[0].Frlong;
		curY = wat[0].Frlat;		
		Pts[Npts].Longitude = wat[curcase].Tolong;
		Pts[Npts].Latitude = wat[curcase].Tolat;
		Npts++;
		Get_Shape_Points(wat[curcase].Tlid, wat[curcase].Flip);
		Pts[Npts].Longitude = wat[curcase].Frlong;
		Pts[Npts].Latitude = wat[curcase].Frlat;
		Npts++;
		wat[curcase].Chosen = 1;		
	}
	ptcount += Npts;
	
    fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
	
	if (Pts[0].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < CurrentMinY)
		CurrentMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[0].Latitude;	
	if (Pts[0].Longitude < FileMinX)
		FileMinX = Pts[0].Longitude;
	if (Pts[0].Longitude > FileMaxX)
		FileMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < FileMinY)
		FileMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > FileMaxY)
		FileMaxY = Pts[0].Latitude;

	if (Pts[Npts-1].Longitude < CurrentMinX)
		CurrentMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < CurrentMinY)
		CurrentMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[Npts-1].Latitude;	
	if (Pts[Npts-1].Longitude < FileMinX)
		FileMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > FileMaxX)
		FileMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < FileMinY)
		FileMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > FileMaxY)
		FileMaxY = Pts[Npts-1].Latitude;		
	n = 1;
	steppos = (int)(n*100/written);	
	Ptrdlg->m_Progress.SetPos(steppos);
    while (n < written)
	{		
		sprintf(msg,"processed %d of %d records",n,written);
		Ptrdlg->SetDlgItemText(IDC_WATER,msg);		
		found = 0;
		for (i = 1; i < written; i++)
         {
			Npts = 0;
			if (wat[i].Chosen != 0)
				continue;
			if (wat[i].Flip == 0)
			{
				if ((wat[i].Frlong == curX) && (wat[i].Frlat == curY))
				{   
					if (strcmp(wat[i].Water,wat[curcase].Water) != 0)
						continue;	            	
					Get_Shape_Points(wat[i].Tlid,wat[i].Flip);
					Pts[Npts].Longitude = wat[i].Tolong;
					Pts[Npts].Latitude = wat[i].Tolat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					wat[i].Chosen = 1;            
					found = 1;                      
					curX = wat[i].Tolong;
					curY = wat[i].Tolat;                
					curcase = i;
					break;
				}
			}
			else
			{
				if ((wat[i].Tolong == curX) && (wat[i].Tolat == curY))
				{	
					if (strcmp(wat[i].Water,wat[curcase].Water) != 0)
						continue;	            						
					Get_Shape_Points(wat[i].Tlid,wat[i].Flip);
					Pts[Npts].Longitude = wat[i].Frlong;
					Pts[Npts].Latitude = wat[i].Frlat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = wat[i].Frlong;
					curY = wat[i].Frlat;                        
					wat[i].Chosen = 1;	
					found = 1;          
					curcase = i;
					break;
				}
			}
        }//close for loop
		if (found == 0) //initialize new case, eg, new ring or new poly
		{			
			fwrite(&ptcount,sizeof(int),1,headtemp);
			ptcount = 0;
			for (i = 0; i < written; i++) //check for new ring in poly
            {                    
         		if (wat[i].Chosen != 0)
					continue;    
				if (strcmp(wat[i].Water,wat[curcase].Water) != 0)
					continue;	            						
				
				//if we get here it is a new ring in current poly
				found = 1;
				nparts++;
				Npts = 0;
				if (wat[i].Flip == 0)
				{
					Pts[Npts].Longitude = wat[i].Frlong;
					Pts[Npts].Latitude = wat[i].Frlat;
					Npts++;
					Get_Shape_Points(wat[i].Tlid,wat[i].Flip);
					Pts[Npts].Longitude = wat[i].Tolong;
					Pts[Npts].Latitude = wat[i].Tolat;
					Npts++;			
    				n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					wat[i].Chosen = 1;
    		   		curX = wat[i].Tolong;
    				curY = wat[i].Tolat;
					curcase = i;
					break;
				}
				else
				{
					Pts[Npts].Longitude = wat[i].Tolong;
					Pts[Npts].Latitude = wat[i].Tolat;
					Npts++;
					Get_Shape_Points(wat[i].Tlid,wat[i].Flip);
					Pts[Npts].Longitude = wat[i].Frlong;
					Pts[Npts].Latitude = wat[i].Frlat;
					Npts++;			
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					wat[i].Chosen = 1;
    		   		curX = wat[i].Frlong;
    				curY = wat[i].Frlat;
					curcase = i;
					break;
				}
    		}
    	}
		if (found == 0) // new poly, first ring
		{
			
			fwrite(&nparts,sizeof(int),1,partstemp);
			nparts = 1;
			fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
			CurrentMinX = CurrentMinY = LARGE;
			CurrentMaxX = CurrentMaxY = -LARGE;

			for (i = 0; i < written; i++)//first check for new ring in current poly
            {                    
         		if (wat[i].Chosen != 0)
					continue;             
				polyid++;
	//			sprintf(watrecord," %-8d%-5s%-33s",polyid,wat[i].County,wat[i].Water);
				sprintf(watrecord," %8d", polyid);
				sprintf(&watrecord[9],"%-5s",wat[i].County);
				sprintf(&watrecord[14],"%-33s",wat[i].Water);
	
				/*rb[i].Uacode,	rb[i].Urbflag);*/
				//repval.Format("writing record %d",polyid);
				//AfxMessageBox(repval);
				fwrite(&watrecord,sizeof(watrecord)-1,1,dbfout);    		
				Npts = 0;
				if (wat[i].Flip == 0)
				{
					Pts[Npts].Longitude = wat[i].Frlong;
					Pts[Npts].Latitude = wat[i].Frlat;
					Npts++;
					Get_Shape_Points(wat[i].Tlid,wat[i].Flip);
					Pts[Npts].Longitude = wat[i].Tolong;
					Pts[Npts].Latitude = wat[i].Tolat;
					Npts++;					
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					wat[i].Chosen = 1;            
					found = 1;                      
					curX = wat[i].Tolong;
					curY = wat[i].Tolat;                
					curcase = i;
					break;					
				}
				else
				{
					Pts[Npts].Longitude = wat[i].Tolong;
					Pts[Npts].Latitude = wat[i].Tolat;
					Npts++;
					Get_Shape_Points(wat[i].Tlid,wat[i].Flip);
					Pts[Npts].Longitude = wat[i].Frlong;
					Pts[Npts].Latitude = wat[i].Frlat;
					Npts++;				
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = wat[i].Frlong;
					curY = wat[i].Frlat;                        
					wat[i].Chosen = 1;		
					found = 1;          
					curcase = i;	
					break;					
				}	
			}
		}
		//by now found should be 1
		if (found == 0)
		{
			info.Format("ERROR - found is zero");
			Ptrdlg->ErrorMessage(info);									
			MissingFile = -1;
			return;
		}
		ptcount += Npts;
		fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
		if (Pts[0].Longitude < CurrentMinX)
			CurrentMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < CurrentMinY)
			CurrentMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[0].Latitude;	
		if (Pts[0].Longitude < FileMinX)
			FileMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > FileMaxX)
			FileMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < FileMinY)
			FileMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > FileMaxY)
			FileMaxY = Pts[0].Latitude;

		if (Pts[Npts-1].Longitude < CurrentMinX)
			CurrentMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < CurrentMinY)
			CurrentMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[Npts-1].Latitude;	
		if (Pts[Npts-1].Longitude < FileMinX)
			FileMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > FileMaxX)
			FileMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < FileMinY)
			FileMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > FileMaxY)
			FileMaxY = Pts[Npts-1].Latitude;		
	}//close while loop
	fwrite(&ptcount,sizeof(int),1,headtemp);
	fwrite(&nparts,sizeof(int),1,partstemp);
	fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
	fclose(boxtemp);
	fclose(headtemp);
	fclose(ptstemp);
	fclose(partstemp);
	sprintf(msg,"processed %d of %d records",n,written);
	Ptrdlg->SetDlgItemText(IDC_WATER,msg);			
	write_eof(dbfout);
	rewind(dbfout);
	Build_db_Header(dbfout,polyid,dbWater);
	Build_Poly_Shape("wat");
	Ptrdlg->m_strWat.Format("%d Water Polygons",polyid);
	Ptrdlg->SetDlgItemText(IDC_WATER,Ptrdlg->m_strWat);
    fclose(dbfout);
	free(wat);
	fprintf(LOG,"Wrote %d Water polygons to shape %s%swat\n", polyid,Outfilepath,
		Outfiletitle);		
}
void Match_Poly_Lines_Cmsamsa()
{
	int polyid, found, i, nparts, ptcount;
	long num, n, written, curcase;
	Cmsamsa_Border_Type *msa;
	double  curX, curY;	
    FILE  *dbfout, *ptstemp, *headtemp, *partstemp, *boxtemp; 
	CString info, fname, errmsg, trimname;	
	char msarecord[85]; //size of fpl dbrecord + 2
	int steppos;
	char msg[100];
	char *msaname;
	int doleft, doright;

	if (SPolycounts[1] == 0)
	{
		Ptrdlg->SetDlgItemText(IDC_CMSAMSA,"No Such Cases");		
		return;
	}	
	fname.Format("%s%smsa.dbf",Outfilepath,Outfiletitle);			
	dbfout = fopen(fname,"wb");
	if (dbfout == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	ptstemp = fopen("pts.tmp","wb");
	if (ptstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	headtemp = fopen("head.tmp","wb");
	if (headtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	boxtemp = fopen("box.tmp","wb");
	if (boxtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	partstemp = fopen("parts.tmp","wb");
	if (partstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	msa = (Cmsamsa_Border_Type *)calloc(SPolycounts[1]+Watercut*SPolycounts[0],sizeof(Cmsamsa_Border_Type));	
	written = 0;
	for (num = 0; num < CountI; num++)
	{
		if (strcmp(TypeIs[num].Msal,TypeIs[num].Msar)== 0)
		{
			if (Watercut)
			{

				if (TypeIs[num].Waterl == TypeIs[num].Waterr)
					continue;
			}
			else
				continue;		
		}
		doleft = 0;
		
		if (strcmp(TypeIs[num].Msal,"    ") != 0)
		{//left case	
			if (Watercut)
			{

				if (!TypeIs[num].Waterl)
					doleft = 1;
			}
			else
				doleft = 1;
			if (doleft)
			{
				sprintf(msa[written].County,"%s%s",TypeIs[num].State,TypeIs[num].County);				
				sprintf(msa[written].Cmsamsa,"%4s",TypeIs[num].Msal);				
				//sprintf(urb[written].Urbflag,"%c",TypeIs[num].Urbl[4]);				
				//urb[written].Urbflag = TypeIs[num].Urbl[4];
				sprintf(msa[written].Tlid,"%s",TypeIs[num].Tlid);
				msa[written].Frlong = Type1s[num].Frlong;
				msa[written].Frlat = Type1s[num].Frlat;
				msa[written].Tolong = Type1s[num].Tolong;
				msa[written].Tolat = Type1s[num].Tolat;
				msa[written].Chosen = 0;
				msa[written].Flip = 1;
				written++;
			}
		}
		doright = 0;
		if (strcmp(TypeIs[num].Msar, "    ") != 0)
		{//rightcase 
			if (Watercut)
			{
				if (!TypeIs[num].Waterr)
					doright = 1;
			}
			else
				doright = 1;
			if (doright)
			{
			//printf("\nright case");			
				sprintf(msa[written].County,"%s%s",TypeIs[num].State,TypeIs[num].County);				
				sprintf(msa[written].Cmsamsa,"%4s",TypeIs[num].Msar);				
				//sprintf(urb[written].Urbflag,"%c",TypeIs[num].Urbr[4]);				
				//urb[written].Urbflag = TypeIs[num].Urbr[4];
				sprintf(msa[written].Tlid,"%s",TypeIs[num].Tlid);				
				msa[written].Frlong = Type1s[num].Frlong;
				msa[written].Frlat = Type1s[num].Frlat;
				msa[written].Tolong = Type1s[num].Tolong;
				msa[written].Tolat = Type1s[num].Tolat;
				msa[written].Chosen = 0;
				msa[written].Flip = 0;
				written++;
			}
		}
	}	
	if (written > SPolycounts[1]+Watercut*SPolycounts[0])
	{
		Ptrdlg->ErrorMessage("the number of CMSAMSA border lines exceeds the count");				
		MissingFile = -1;
		return;
	}
	if (written == 0)
	{
		if (!Watercut)
			fprintf(LOG,"There are no lines for CMSA/MSA polygons\n");
		else
		{
			fprintf(LOG,"All CMSA and MSA polygons for this county coincide with water polygons\n");
			fprintf(LOG,"Try turning off the water polygon clipping option\n");
		}
		return;
	}
	
	//time to chain		
	Ptrdlg->m_strProcess.Format("Gathering CMSA/MSA Boundary Lines");
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	qsort((void *)msa,written,sizeof(Cmsamsa_Border_Type),(compfn)CompareMsa);	
	FileMinX = FileMinY = LARGE;
	FileMaxX = FileMaxY = -LARGE;
	CurrentMinX = CurrentMinY = LARGE;
	CurrentMaxX = CurrentMaxY = -LARGE;
	curcase = 0;
	polyid = 1;
	Npts = 0; 
	nparts = 1;
	ptcount = 0;
	Build_db_Header(dbfout,0,dbMsa);
	Build_db_FieldHeaders(dbfout,dbMsa);	
	//sprintf(msarecord," %8d%-5s%-4s",polyid,msa[curcase].County,msa[curcase].Cmsamsa);
	sprintf(msarecord," %-8d", polyid);
	sprintf(&msarecord[9],"%-5s",msa[curcase].County);
	sprintf(&msarecord[14],"%-4s",msa[curcase].Cmsamsa);
	msaname = Get_TypeC_Name(8,msa[curcase].Cmsamsa,"");
	trimname.Format("%s",msaname);
	trimname.TrimRight();
	sprintf(&msarecord[18],"%-66s",trimname);
		//urb[curcase].Urbflag);	
	fwrite(&msarecord,sizeof(msarecord)-1,1,dbfout);
	if (msa[0].Flip == 0)
	{
		curX = msa[0].Tolong;
		curY = msa[0].Tolat;		
		Pts[Npts].Longitude = msa[curcase].Frlong;
		Pts[Npts].Latitude = msa[curcase].Frlat;
		Npts++;
		Get_Shape_Points(msa[curcase].Tlid, msa[curcase].Flip);
		Pts[Npts].Longitude = msa[curcase].Tolong;
		Pts[Npts].Latitude = msa[curcase].Tolat;
		Npts++;
		msa[curcase].Chosen = 1;		
	}
	else
	{
		curX = msa[0].Frlong;
		curY = msa[0].Frlat;		
		Pts[Npts].Longitude = msa[curcase].Tolong;
		Pts[Npts].Latitude = msa[curcase].Tolat;
		Npts++;
		Get_Shape_Points(msa[curcase].Tlid, msa[curcase].Flip);
		Pts[Npts].Longitude = msa[curcase].Frlong;
		Pts[Npts].Latitude = msa[curcase].Frlat;
		Npts++;
		msa[curcase].Chosen = 1;		
	}
	ptcount += Npts;
	
    fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
	
	if (Pts[0].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < CurrentMinY)
		CurrentMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[0].Latitude;	
	if (Pts[0].Longitude < FileMinX)
		FileMinX = Pts[0].Longitude;
	if (Pts[0].Longitude > FileMaxX)
		FileMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < FileMinY)
		FileMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > FileMaxY)
		FileMaxY = Pts[0].Latitude;

	if (Pts[Npts-1].Longitude < CurrentMinX)
		CurrentMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < CurrentMinY)
		CurrentMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[Npts-1].Latitude;	
	if (Pts[Npts-1].Longitude < FileMinX)
		FileMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > FileMaxX)
		FileMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < FileMinY)
		FileMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > FileMaxY)
		FileMaxY = Pts[Npts-1].Latitude;		
	n = 1;
	steppos = (int)(n*100/written);	
	Ptrdlg->m_Progress.SetPos(steppos);
    while (n < written)
	{		
		sprintf(msg,"processed %d of %d records",n,written);
		Ptrdlg->SetDlgItemText(IDC_CMSAMSA,msg);		
		found = 0;
		for (i = 1; i < written; i++)
         {
			Npts = 0;
			if (msa[i].Chosen != 0)
				continue;
			if (msa[i].Flip == 0)
			{
				if ((msa[i].Frlong == curX) && (msa[i].Frlat == curY))
				{                          
					if (strcmp(msa[i].Cmsamsa,msa[curcase].Cmsamsa) != 0)
						continue;	            
					//if (urb[i].Urbflag != urb[i].Urbflag)
					//	continue;
					Get_Shape_Points(msa[i].Tlid,msa[i].Flip);
					Pts[Npts].Longitude = msa[i].Tolong;
					Pts[Npts].Latitude = msa[i].Tolat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					msa[i].Chosen = 1;            
					found = 1;                      
					curX = msa[i].Tolong;
					curY = msa[i].Tolat;                
					curcase = i;
					break;
				}
			}
			else
			{
				if ((msa[i].Tolong == curX) && (msa[i].Tolat == curY))
				{
					if (strcmp(msa[i].Cmsamsa,msa[curcase].Cmsamsa) != 0)
						continue;	            
					//if (urb[i].Urbflag != urb[curcase].Urbflag)
					//	continue;
					Get_Shape_Points(msa[i].Tlid,msa[i].Flip);
					Pts[Npts].Longitude = msa[i].Frlong;
					Pts[Npts].Latitude = msa[i].Frlat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = msa[i].Frlong;
					curY = msa[i].Frlat;                        
					msa[i].Chosen = 1;	
					found = 1;          
					curcase = i;
					break;
				}
			}
        }//close for loop
		if (found == 0) //initialize new case, eg, new ring or new poly
		{			
			fwrite(&ptcount,sizeof(int),1,headtemp);
			ptcount = 0;
			for (i = 0; i < written; i++) //check for new ring in poly
            {                    
         		if (msa[i].Chosen != 0)
					continue;    
				if (strcmp(msa[i].Cmsamsa,msa[curcase].Cmsamsa) != 0)
					continue;	            
				//if (urb[i].Urbflag != urb[curcase].Urbflag)
				//	continue;
				//if we get here it is a new ring in current poly
				found = 1;
				nparts++;
				Npts = 0;
				if (msa[i].Flip == 0)
				{
					Pts[Npts].Longitude = msa[i].Frlong;
					Pts[Npts].Latitude = msa[i].Frlat;
					Npts++;
					Get_Shape_Points(msa[i].Tlid,msa[i].Flip);
					Pts[Npts].Longitude = msa[i].Tolong;
					Pts[Npts].Latitude = msa[i].Tolat;
					Npts++;			
    				n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					msa[i].Chosen = 1;
    		   		curX = msa[i].Tolong;
    				curY = msa[i].Tolat;
					curcase = i;
					break;
				}
				else
				{
					Pts[Npts].Longitude = msa[i].Tolong;
					Pts[Npts].Latitude = msa[i].Tolat;
					Npts++;
					Get_Shape_Points(msa[i].Tlid,msa[i].Flip);
					Pts[Npts].Longitude = msa[i].Frlong;
					Pts[Npts].Latitude = msa[i].Frlat;
					Npts++;			
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					msa[i].Chosen = 1;
    		   		curX = msa[i].Frlong;
    				curY = msa[i].Frlat;
					curcase = i;
					break;
				}
    		}
    	}
		if (found == 0) // new poly, first ring
		{
			
			fwrite(&nparts,sizeof(int),1,partstemp);
			nparts = 1;
			fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
			CurrentMinX = CurrentMinY = LARGE;
			CurrentMaxX = CurrentMaxY = -LARGE;

			for (i = 0; i < written; i++)//first check for new ring in current poly
            {                    
         		if (msa[i].Chosen != 0)
					continue;             
				polyid++;
				//sprintf(msarecord," %-8d%-5s%-4s",polyid,msa[i].County,msa[i].Cmsamsa);
				sprintf(msarecord," %-8d", polyid);
				sprintf(&msarecord[9],"%-5s",msa[i].County);
				sprintf(&msarecord[14],"%-4s",msa[i].Cmsamsa);
					//urb[i].Urbflag);
				msaname = Get_TypeC_Name(8,msa[i].Cmsamsa,"");
				trimname.Format("%s",msaname);
				trimname.TrimRight();
				sprintf(&msarecord[18],"%-66s",trimname);
				fwrite(&msarecord,sizeof(msarecord)-1,1,dbfout);    		
				Npts = 0;
				if (msa[i].Flip == 0)
				{
					Pts[Npts].Longitude = msa[i].Frlong;
					Pts[Npts].Latitude = msa[i].Frlat;
					Npts++;
					Get_Shape_Points(msa[i].Tlid,msa[i].Flip);
					Pts[Npts].Longitude = msa[i].Tolong;
					Pts[Npts].Latitude = msa[i].Tolat;
					Npts++;					
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					msa[i].Chosen = 1;            
					found = 1;                      
					curX = msa[i].Tolong;
					curY = msa[i].Tolat;                
					curcase = i;
					break;					
				}
				else
				{
					Pts[Npts].Longitude = msa[i].Tolong;
					Pts[Npts].Latitude = msa[i].Tolat;
					Npts++;
					Get_Shape_Points(msa[i].Tlid,msa[i].Flip);
					Pts[Npts].Longitude = msa[i].Frlong;
					Pts[Npts].Latitude = msa[i].Frlat;
					Npts++;				
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = msa[i].Frlong;
					curY = msa[i].Frlat;                        
					msa[i].Chosen = 1;		
					found = 1;          
					curcase = i;	
					break;					
				}	
			}
		}
		//by now found should be 1
		if (found == 0)
		{
			info.Format("ERROR - found is zero");
			Ptrdlg->ErrorMessage(info);									
			MissingFile = -1;
			return;
		}
		ptcount += Npts;
		fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
		if (Pts[0].Longitude < CurrentMinX)
			CurrentMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < CurrentMinY)
			CurrentMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[0].Latitude;	
		if (Pts[0].Longitude < FileMinX)
			FileMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > FileMaxX)
			FileMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < FileMinY)
			FileMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > FileMaxY)
			FileMaxY = Pts[0].Latitude;

		if (Pts[Npts-1].Longitude < CurrentMinX)
			CurrentMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < CurrentMinY)
			CurrentMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[Npts-1].Latitude;	
		if (Pts[Npts-1].Longitude < FileMinX)
			FileMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > FileMaxX)
			FileMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < FileMinY)
			FileMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > FileMaxY)
			FileMaxY = Pts[Npts-1].Latitude;		
	}//close while loop
	fwrite(&ptcount,sizeof(int),1,headtemp);
	fwrite(&nparts,sizeof(int),1,partstemp);
	fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
	fclose(boxtemp);
	fclose(headtemp);
	fclose(ptstemp);
	fclose(partstemp);
	sprintf(msg,"processed %d of %d records",n,written);
	Ptrdlg->SetDlgItemText(IDC_CMSAMSA,msg);			
	write_eof(dbfout);
	rewind(dbfout);
	Build_db_Header(dbfout,polyid,dbMsa);
	Build_Poly_Shape("msa");
	Ptrdlg->m_strCmsamsa.Format("%d CMSA/MSA Polygons",polyid);
	Ptrdlg->SetDlgItemText(IDC_CMSAMSA,Ptrdlg->m_strCmsamsa);
    fclose(dbfout);
	free(msa);
	fprintf(LOG,"Wrote %d CMSA/MSA polygons to shape %s%smsa\n", polyid,Outfilepath,
		Outfiletitle);		
}
void Match_Poly_Lines_Pmsa()
{
	int polyid, found, i, nparts, ptcount;
	long num, n, written, curcase;
	Pmsa_Border_Type *pms;
	double  curX, curY;	
    FILE  *dbfout, *ptstemp, *headtemp, *partstemp, *boxtemp; 
	CString info, fname, errmsg, trimname;	
	char pmsrecord[85]; //size of fpl dbrecord + 2
	int steppos;
	char msg[100];
	char *pmsname;
	int doleft, doright;
	
	if (SPolycounts[2] == 0)
	{
		Ptrdlg->SetDlgItemText(IDC_PMSA,"No Such Cases");		
		return;
	}	
	fname.Format("%s%spms.dbf",Outfilepath,Outfiletitle);			
	dbfout = fopen(fname,"wb");
	if (dbfout == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	ptstemp = fopen("pts.tmp","wb");
	if (ptstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	headtemp = fopen("head.tmp","wb");
	if (headtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	boxtemp = fopen("box.tmp","wb");
	if (boxtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	partstemp = fopen("parts.tmp","wb");
	if (partstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	pms = (Pmsa_Border_Type *)calloc(SPolycounts[2]+Watercut*SPolycounts[0],sizeof(Pmsa_Border_Type));	
	written = 0;
	for (num = 0; num < CountI; num++)
	{
		if (strcmp(TypeIs[num].Pmsl,TypeIs[num].Pmsr)== 0)
		{
			if (Watercut)
			{

				if (TypeIs[num].Waterl == TypeIs[num].Waterr)
					continue;
			}
			else
				continue;		
		}
		doleft = 0;
		
		if (strcmp(TypeIs[num].Pmsl,"    ") != 0)
		{//left case	
			if (Watercut)
			{

				if (!TypeIs[num].Waterl)
					doleft = 1;
			}
			else
				doleft = 1;
			if (doleft)
			{
				sprintf(pms[written].County,"%s%s",TypeIs[num].State,TypeIs[num].County);				
				sprintf(pms[written].Pmsa,"%4s",TypeIs[num].Pmsl);				
				//sprintf(urb[written].Urbflag,"%c",TypeIs[num].Urbl[4]);				
				//urb[written].Urbflag = TypeIs[num].Urbl[4];
				sprintf(pms[written].Tlid,"%s",TypeIs[num].Tlid);
				pms[written].Frlong = Type1s[num].Frlong;
				pms[written].Frlat = Type1s[num].Frlat;
				pms[written].Tolong = Type1s[num].Tolong;
				pms[written].Tolat = Type1s[num].Tolat;
				pms[written].Chosen = 0;
				pms[written].Flip = 1;
				written++;
			}
		}
		doright = 0;
		if (strcmp(TypeIs[num].Pmsr, "    ") != 0)
		{//rightcase 
			if (Watercut)
			{

				if (!TypeIs[num].Waterr)
					doright = 1;
			}
			else
				doright = 1;
			if (doright)
			{
			//printf("\nright case");			
				sprintf(pms[written].County,"%s%s",TypeIs[num].State,TypeIs[num].County);				
				sprintf(pms[written].Pmsa,"%4s",TypeIs[num].Pmsr);				
				//sprintf(urb[written].Urbflag,"%c",TypeIs[num].Urbr[4]);				
				//urb[written].Urbflag = TypeIs[num].Urbr[4];
				sprintf(pms[written].Tlid,"%s",TypeIs[num].Tlid);				
				pms[written].Frlong = Type1s[num].Frlong;
				pms[written].Frlat = Type1s[num].Frlat;
				pms[written].Tolong = Type1s[num].Tolong;
				pms[written].Tolat = Type1s[num].Tolat;
				pms[written].Chosen = 0;
				pms[written].Flip = 0;
				written++;
			}
		}
	}	
	if (written > SPolycounts[2]+Watercut*SPolycounts[0])
	{
		Ptrdlg->ErrorMessage("the number of PMSA border lines exceeds the count");				
		MissingFile = -1;
		return;
	}
	if (written == 0)
	{
		if (!Watercut)
			fprintf(LOG,"There are no lines for PMSA polygons\n");
		else
		{
			fprintf(LOG,"All PMSA polygons for this county coincide with water polygons\n");
			fprintf(LOG,"Try turning off the water polygon clipping option\n");
		}
		return;
	}
	
	//time to chain		
	Ptrdlg->m_strProcess.Format("Gathering CMSA/MSA Boundary Lines");
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	qsort((void *)pms,written,sizeof(Pmsa_Border_Type),(compfn)ComparePmsa);	
	FileMinX = FileMinY = LARGE;
	FileMaxX = FileMaxY = -LARGE;
	CurrentMinX = CurrentMinY = LARGE;
	CurrentMaxX = CurrentMaxY = -LARGE;
	curcase = 0;
	polyid = 1;
	Npts = 0; 
	nparts = 1;
	ptcount = 0;
	Build_db_Header(dbfout,0,dbPms);
	Build_db_FieldHeaders(dbfout,dbPms);	
	//sprintf(pmsrecord," %8d%-5s%-4s",polyid,pms[curcase].County,pms[curcase].Pmsa);
	sprintf(pmsrecord," %-8d",polyid);
	sprintf(&pmsrecord[9],"%-5s",pms[curcase].County);
	sprintf(&pmsrecord[14],"%-4s",pms[curcase].Pmsa);
	pmsname = Get_TypeC_Name(9,pms[curcase].Pmsa,"");
	trimname.Format("%s",pmsname);
	trimname.TrimRight();
	sprintf(&pmsrecord[18],"%-66s",trimname);
		//urb[curcase].Urbflag);	
	fwrite(&pmsrecord,sizeof(pmsrecord)-1,1,dbfout);
	if (pms[0].Flip == 0)
	{
		curX = pms[0].Tolong;
		curY = pms[0].Tolat;		
		Pts[Npts].Longitude = pms[curcase].Frlong;
		Pts[Npts].Latitude = pms[curcase].Frlat;
		Npts++;
		Get_Shape_Points(pms[curcase].Tlid, pms[curcase].Flip);
		Pts[Npts].Longitude = pms[curcase].Tolong;
		Pts[Npts].Latitude = pms[curcase].Tolat;
		Npts++;
		pms[curcase].Chosen = 1;		
	}
	else
	{
		curX = pms[0].Frlong;
		curY = pms[0].Frlat;		
		Pts[Npts].Longitude = pms[curcase].Tolong;
		Pts[Npts].Latitude = pms[curcase].Tolat;
		Npts++;
		Get_Shape_Points(pms[curcase].Tlid, pms[curcase].Flip);
		Pts[Npts].Longitude = pms[curcase].Frlong;
		Pts[Npts].Latitude = pms[curcase].Frlat;
		Npts++;
		pms[curcase].Chosen = 1;		
	}
	ptcount += Npts;
	
    fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
	
	if (Pts[0].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < CurrentMinY)
		CurrentMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[0].Latitude;	
	if (Pts[0].Longitude < FileMinX)
		FileMinX = Pts[0].Longitude;
	if (Pts[0].Longitude > FileMaxX)
		FileMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < FileMinY)
		FileMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > FileMaxY)
		FileMaxY = Pts[0].Latitude;

	if (Pts[Npts-1].Longitude < CurrentMinX)
		CurrentMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < CurrentMinY)
		CurrentMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[Npts-1].Latitude;	
	if (Pts[Npts-1].Longitude < FileMinX)
		FileMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > FileMaxX)
		FileMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < FileMinY)
		FileMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > FileMaxY)
		FileMaxY = Pts[Npts-1].Latitude;		
	n = 1;
	steppos = (int)(n*100/written);	
	Ptrdlg->m_Progress.SetPos(steppos);
    while (n < written)
	{		
		sprintf(msg,"processed %d of %d records",n,written);
		Ptrdlg->SetDlgItemText(IDC_PMSA,msg);		
		found = 0;
		for (i = 1; i < written; i++)
         {
			Npts = 0;
			if (pms[i].Chosen != 0)
				continue;
			if (pms[i].Flip == 0)
			{
				if ((pms[i].Frlong == curX) && (pms[i].Frlat == curY))
				{                          
					if (strcmp(pms[i].Pmsa,pms[curcase].Pmsa) != 0)
						continue;	            
					//if (urb[i].Urbflag != urb[i].Urbflag)
					//	continue;
					Get_Shape_Points(pms[i].Tlid,pms[i].Flip);
					Pts[Npts].Longitude = pms[i].Tolong;
					Pts[Npts].Latitude = pms[i].Tolat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					pms[i].Chosen = 1;            
					found = 1;                      
					curX = pms[i].Tolong;
					curY = pms[i].Tolat;                
					curcase = i;
					break;
				}
			}
			else
			{
				if ((pms[i].Tolong == curX) && (pms[i].Tolat == curY))
				{
					if (strcmp(pms[i].Pmsa,pms[curcase].Pmsa) != 0)
						continue;	            
					//if (urb[i].Urbflag != urb[curcase].Urbflag)
					//	continue;
					Get_Shape_Points(pms[i].Tlid,pms[i].Flip);
					Pts[Npts].Longitude = pms[i].Frlong;
					Pts[Npts].Latitude = pms[i].Frlat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = pms[i].Frlong;
					curY = pms[i].Frlat;                        
					pms[i].Chosen = 1;	
					found = 1;          
					curcase = i;
					break;
				}
			}
        }//close for loop
		if (found == 0) //initialize new case, eg, new ring or new poly
		{			
			fwrite(&ptcount,sizeof(int),1,headtemp);
			ptcount = 0;
			for (i = 0; i < written; i++) //check for new ring in poly
            {                    
         		if (pms[i].Chosen != 0)
					continue;    
				if (strcmp(pms[i].Pmsa,pms[curcase].Pmsa) != 0)
					continue;	            
				//if (urb[i].Urbflag != urb[curcase].Urbflag)
				//	continue;
				//if we get here it is a new ring in current poly
				found = 1;
				nparts++;
				Npts = 0;
				if (pms[i].Flip == 0)
				{
					Pts[Npts].Longitude = pms[i].Frlong;
					Pts[Npts].Latitude = pms[i].Frlat;
					Npts++;
					Get_Shape_Points(pms[i].Tlid,pms[i].Flip);
					Pts[Npts].Longitude = pms[i].Tolong;
					Pts[Npts].Latitude = pms[i].Tolat;
					Npts++;			
    				n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					pms[i].Chosen = 1;
    		   		curX = pms[i].Tolong;
    				curY = pms[i].Tolat;
					curcase = i;
					break;
				}
				else
				{
					Pts[Npts].Longitude = pms[i].Tolong;
					Pts[Npts].Latitude = pms[i].Tolat;
					Npts++;
					Get_Shape_Points(pms[i].Tlid,pms[i].Flip);
					Pts[Npts].Longitude = pms[i].Frlong;
					Pts[Npts].Latitude = pms[i].Frlat;
					Npts++;			
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					pms[i].Chosen = 1;
    		   		curX = pms[i].Frlong;
    				curY = pms[i].Frlat;
					curcase = i;
					break;
				}
    		}
    	}
		if (found == 0) // new poly, first ring
		{
			
			fwrite(&nparts,sizeof(int),1,partstemp);
			nparts = 1;
			fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
			CurrentMinX = CurrentMinY = LARGE;
			CurrentMaxX = CurrentMaxY = -LARGE;

			for (i = 0; i < written; i++)//first check for new ring in current poly
            {                    
         		if (pms[i].Chosen != 0)
					continue;             
				polyid++;
				//sprintf(pmsrecord," %-8d%-5s%-4s",polyid,pms[i].County,pms[i].Pmsa);
				sprintf(pmsrecord," %-8d",polyid);
				sprintf(&pmsrecord[9],"%-5s",pms[i].County);
				sprintf(&pmsrecord[14],"%-4s",pms[i].Pmsa);
				pmsname = Get_TypeC_Name(9,pms[i].Pmsa,"");
				trimname.Format("%s",pmsname);
				trimname.TrimRight();
				sprintf(&pmsrecord[18],"%-66s",trimname);
	
				//urb[i].Urbflag);
				fwrite(&pmsrecord,sizeof(pmsrecord)-1,1,dbfout);    		
				Npts = 0;
				if (pms[i].Flip == 0)
				{
					Pts[Npts].Longitude = pms[i].Frlong;
					Pts[Npts].Latitude = pms[i].Frlat;
					Npts++;
					Get_Shape_Points(pms[i].Tlid,pms[i].Flip);
					Pts[Npts].Longitude = pms[i].Tolong;
					Pts[Npts].Latitude = pms[i].Tolat;
					Npts++;					
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					pms[i].Chosen = 1;            
					found = 1;                      
					curX = pms[i].Tolong;
					curY = pms[i].Tolat;                
					curcase = i;
					break;					
				}
				else
				{
					Pts[Npts].Longitude = pms[i].Tolong;
					Pts[Npts].Latitude = pms[i].Tolat;
					Npts++;
					Get_Shape_Points(pms[i].Tlid,pms[i].Flip);
					Pts[Npts].Longitude = pms[i].Frlong;
					Pts[Npts].Latitude = pms[i].Frlat;
					Npts++;				
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = pms[i].Frlong;
					curY = pms[i].Frlat;                        
					pms[i].Chosen = 1;		
					found = 1;          
					curcase = i;	
					break;					
				}	
			}
		}
		//by now found should be 1
		if (found == 0)
		{
			info.Format("ERROR - found is zero");
			Ptrdlg->ErrorMessage(info);									
			MissingFile = -1;
			return;
		}
		ptcount += Npts;
		fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
		if (Pts[0].Longitude < CurrentMinX)
			CurrentMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < CurrentMinY)
			CurrentMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[0].Latitude;	
		if (Pts[0].Longitude < FileMinX)
			FileMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > FileMaxX)
			FileMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < FileMinY)
			FileMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > FileMaxY)
			FileMaxY = Pts[0].Latitude;

		if (Pts[Npts-1].Longitude < CurrentMinX)
			CurrentMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < CurrentMinY)
			CurrentMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[Npts-1].Latitude;	
		if (Pts[Npts-1].Longitude < FileMinX)
			FileMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > FileMaxX)
			FileMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < FileMinY)
			FileMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > FileMaxY)
			FileMaxY = Pts[Npts-1].Latitude;		
	}//close while loop
	fwrite(&ptcount,sizeof(int),1,headtemp);
	fwrite(&nparts,sizeof(int),1,partstemp);
	fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
	fclose(boxtemp);
	fclose(headtemp);
	fclose(ptstemp);
	fclose(partstemp);
	sprintf(msg,"processed %d of %d records",n,written);
	Ptrdlg->SetDlgItemText(IDC_PMSA,msg);			
	write_eof(dbfout);
	rewind(dbfout);
	Build_db_Header(dbfout,polyid,dbPms);
	Build_Poly_Shape("pms");
	Ptrdlg->m_strPmsa.Format("%d PMSA Polygons",polyid);
	Ptrdlg->SetDlgItemText(IDC_PMSA,Ptrdlg->m_strPmsa);
    fclose(dbfout);
	free(pms);
	fprintf(LOG,"Wrote %d PMSA polygons to shape %s%spms\n", polyid,Outfilepath,Outfiletitle);		
}
void Match_Poly_Lines_Cdcu()
{
	int polyid, found, i, nparts, ptcount;
	long num, n, written, curcase;
	Cdcu_Border_Type *cdc;
	double  curX, curY;	
    FILE  *dbfout, *ptstemp, *headtemp, *partstemp, *boxtemp; 
	CString info, fname, errmsg;	
	char cdcrecord[17]; //size of fpl dbrecord + 2
	int steppos;
	char msg[100];
	int doleft, doright;

	if (SPolycounts[3] == 0)
	{
		Ptrdlg->SetDlgItemText(IDC_CDCU,"No Such Cases");		
		return;
	}	
	fname.Format("%s%scdc.dbf",Outfilepath,Outfiletitle);			
	dbfout = fopen(fname,"wb");
	if (dbfout == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	ptstemp = fopen("pts.tmp","wb");
	if (ptstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	headtemp = fopen("head.tmp","wb");
	if (headtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	boxtemp = fopen("box.tmp","wb");
	if (boxtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	partstemp = fopen("parts.tmp","wb");
	if (partstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	cdc = (Cdcu_Border_Type *)calloc(SPolycounts[3]+Watercut*SPolycounts[0],sizeof(Cdcu_Border_Type));		

	written = 0;
	for (num = 0; num < CountI; num++)
	{
		if (strcmp(TypeIs[num].Cdcul,TypeIs[num].Cdcur)== 0)
		{
			if (Watercut)
			{

				if (TypeIs[num].Waterl == TypeIs[num].Waterr)
					continue;
			}
			else
				continue;		
		}
		doleft = 0;
		
		if (strcmp(TypeIs[num].Cdcul,"  ") != 0)
		{//left case	
			if (Watercut)
			{

				if (!TypeIs[num].Waterl)
					doleft = 1;
			}
			else
				doleft = 1;
			if (doleft)
			{
				sprintf(cdc[written].County,"%s%s",TypeIs[num].State,TypeIs[num].County);				
				sprintf(cdc[written].Cdcu,"%2s",TypeIs[num].Cdcul);				
				//sprintf(urb[written].Urbflag,"%c",TypeIs[num].Urbl[4]);				
				//urb[written].Urbflag = TypeIs[num].Urbl[4];
				sprintf(cdc[written].Tlid,"%s",TypeIs[num].Tlid);
				cdc[written].Frlong = Type1s[num].Frlong;
				cdc[written].Frlat = Type1s[num].Frlat;
				cdc[written].Tolong = Type1s[num].Tolong;
				cdc[written].Tolat = Type1s[num].Tolat;
				cdc[written].Chosen = 0;
				cdc[written].Flip = 1;
				written++;
			}
		}
		doright = 0;
		if (strcmp(TypeIs[num].Cdcur, "  ") != 0)
		{//rightcase 
			if (Watercut)
			{
				if (!TypeIs[num].Waterr)
					doright = 1;
			}
			else
				doright = 1;
			if (doright)
			{
			//printf("\nright case");			
				sprintf(cdc[written].County,"%s%s",TypeIs[num].State,TypeIs[num].County);				
				sprintf(cdc[written].Cdcu,"%2s",TypeIs[num].Cdcur);				
				//sprintf(urb[written].Urbflag,"%c",TypeIs[num].Urbr[4]);				
				//urb[written].Urbflag = TypeIs[num].Urbr[4];
				sprintf(cdc[written].Tlid,"%s",TypeIs[num].Tlid);				
				cdc[written].Frlong = Type1s[num].Frlong;
				cdc[written].Frlat = Type1s[num].Frlat;
				cdc[written].Tolong = Type1s[num].Tolong;
				cdc[written].Tolat = Type1s[num].Tolat;
				cdc[written].Chosen = 0;
				cdc[written].Flip = 0;
				written++;
			}
		}
	}	
	if (written > SPolycounts[3]+Watercut*SPolycounts[0])
	{
		Ptrdlg->ErrorMessage("the number of CDCU border lines exceeds the count");				
		MissingFile = -1;
		return;
	}
	if (written == 0)
	{
		if (!Watercut)
			fprintf(LOG,"There are no lines for CDCU polygons\n");
		else
		{
			fprintf(LOG,"All CDCU for this county coincide with water polygons\n");
			fprintf(LOG,"Try turning off the water polygon clipping option\n");
		}
		return;
	}
	
	//time to chain		
	Ptrdlg->m_strProcess.Format("Gathering CDCU Boundary Lines");
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	qsort((void *)cdc,written,sizeof(Cdcu_Border_Type),(compfn)CompareCdcu);		
	FileMinX = FileMinY = LARGE;
	FileMaxX = FileMaxY = -LARGE;
	CurrentMinX = CurrentMinY = LARGE;
	CurrentMaxX = CurrentMaxY = -LARGE;
	curcase = 0;
	polyid = 1;
	Npts = 0; 
	nparts = 1;
	ptcount = 0;
	Build_db_Header(dbfout,0,dbCdcu);
	Build_db_FieldHeaders(dbfout,dbCdcu);	
	//sprintf(cdcrecord," %8d%-5s%-2s",polyid,cdc[curcase].County,cdc[curcase].Cdcu);
	sprintf(cdcrecord," %8d",polyid);
	sprintf(&cdcrecord[9],"%-5s",cdc[curcase].County);
	sprintf(&cdcrecord[14],"%-2s",cdc[curcase].Cdcu);
		//urb[curcase].Urbflag);	
	fwrite(&cdcrecord,sizeof(cdcrecord)-1,1,dbfout);
	if (cdc[0].Flip == 0)
	{
		curX = cdc[0].Tolong;
		curY = cdc[0].Tolat;		
		Pts[Npts].Longitude = cdc[curcase].Frlong;
		Pts[Npts].Latitude = cdc[curcase].Frlat;
		Npts++;
		Get_Shape_Points(cdc[curcase].Tlid, cdc[curcase].Flip);
		Pts[Npts].Longitude = cdc[curcase].Tolong;
		Pts[Npts].Latitude = cdc[curcase].Tolat;
		Npts++;
		cdc[curcase].Chosen = 1;		
	}
	else
	{
		curX = cdc[0].Frlong;
		curY = cdc[0].Frlat;		
		Pts[Npts].Longitude = cdc[curcase].Tolong;
		Pts[Npts].Latitude = cdc[curcase].Tolat;
		Npts++;
		Get_Shape_Points(cdc[curcase].Tlid, cdc[curcase].Flip);
		Pts[Npts].Longitude = cdc[curcase].Frlong;
		Pts[Npts].Latitude = cdc[curcase].Frlat;
		Npts++;
		cdc[curcase].Chosen = 1;		
	}
	ptcount += Npts;
	
    fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
	
	if (Pts[0].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < CurrentMinY)
		CurrentMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[0].Latitude;	
	if (Pts[0].Longitude < FileMinX)
		FileMinX = Pts[0].Longitude;
	if (Pts[0].Longitude > FileMaxX)
		FileMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < FileMinY)
		FileMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > FileMaxY)
		FileMaxY = Pts[0].Latitude;

	if (Pts[Npts-1].Longitude < CurrentMinX)
		CurrentMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < CurrentMinY)
		CurrentMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[Npts-1].Latitude;	
	if (Pts[Npts-1].Longitude < FileMinX)
		FileMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > FileMaxX)
		FileMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < FileMinY)
		FileMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > FileMaxY)
		FileMaxY = Pts[Npts-1].Latitude;		
	n = 1;
	steppos = (int)(n*100/written);	
	Ptrdlg->m_Progress.SetPos(steppos);
    while (n < written)
	{		
		sprintf(msg,"processed %d of %d records",n,written);
		Ptrdlg->SetDlgItemText(IDC_CDCU,msg);		
		found = 0;
		for (i = 1; i < written; i++)
         {
			Npts = 0;
			if (cdc[i].Chosen != 0)
				continue;
			if (cdc[i].Flip == 0)
			{
				if ((cdc[i].Frlong == curX) && (cdc[i].Frlat == curY))
				{                          
					if (strcmp(cdc[i].Cdcu,cdc[curcase].Cdcu) != 0)
						continue;	            
					//if (urb[i].Urbflag != urb[i].Urbflag)
					//	continue;
					Get_Shape_Points(cdc[i].Tlid,cdc[i].Flip);
					Pts[Npts].Longitude = cdc[i].Tolong;
					Pts[Npts].Latitude = cdc[i].Tolat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					cdc[i].Chosen = 1;            
					found = 1;                      
					curX = cdc[i].Tolong;
					curY = cdc[i].Tolat;                
					curcase = i;
					break;
				}
			}
			else
			{
				if ((cdc[i].Tolong == curX) && (cdc[i].Tolat == curY))
				{
					if (strcmp(cdc[i].Cdcu,cdc[curcase].Cdcu) != 0)
						continue;	            
					//if (urb[i].Urbflag != urb[curcase].Urbflag)
					//	continue;
					Get_Shape_Points(cdc[i].Tlid,cdc[i].Flip);
					Pts[Npts].Longitude = cdc[i].Frlong;
					Pts[Npts].Latitude = cdc[i].Frlat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = cdc[i].Frlong;
					curY = cdc[i].Frlat;                        
					cdc[i].Chosen = 1;	
					found = 1;          
					curcase = i;
					break;
				}
			}
        }//close for loop
		if (found == 0) //initialize new case, eg, new ring or new poly
		{			
			fwrite(&ptcount,sizeof(int),1,headtemp);
			ptcount = 0;
			for (i = 0; i < written; i++) //check for new ring in poly
            {                    
         		if (cdc[i].Chosen != 0)
					continue;    
				if (strcmp(cdc[i].Cdcu,cdc[curcase].Cdcu) != 0)
					continue;	            
				//if (urb[i].Urbflag != urb[curcase].Urbflag)
				//	continue;
				//if we get here it is a new ring in current poly
				found = 1;
				nparts++;
				Npts = 0;
				if (cdc[i].Flip == 0)
				{
					Pts[Npts].Longitude = cdc[i].Frlong;
					Pts[Npts].Latitude = cdc[i].Frlat;
					Npts++;
					Get_Shape_Points(cdc[i].Tlid,cdc[i].Flip);
					Pts[Npts].Longitude = cdc[i].Tolong;
					Pts[Npts].Latitude = cdc[i].Tolat;
					Npts++;			
    				n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					cdc[i].Chosen = 1;
    		   		curX = cdc[i].Tolong;
    				curY = cdc[i].Tolat;
					curcase = i;
					break;
				}
				else
				{
					Pts[Npts].Longitude = cdc[i].Tolong;
					Pts[Npts].Latitude = cdc[i].Tolat;
					Npts++;
					Get_Shape_Points(cdc[i].Tlid,cdc[i].Flip);
					Pts[Npts].Longitude = cdc[i].Frlong;
					Pts[Npts].Latitude = cdc[i].Frlat;
					Npts++;			
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					cdc[i].Chosen = 1;
    		   		curX = cdc[i].Frlong;
    				curY = cdc[i].Frlat;
					curcase = i;
					break;
				}
    		}
    	}
		if (found == 0) // new poly, first ring
		{
			
			fwrite(&nparts,sizeof(int),1,partstemp);
			nparts = 1;
			fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
			CurrentMinX = CurrentMinY = LARGE;
			CurrentMaxX = CurrentMaxY = -LARGE;

			for (i = 0; i < written; i++)//first check for new ring in current poly
            {                    
         		if (cdc[i].Chosen != 0)
					continue;             
				polyid++;
	//			sprintf(cdcrecord," %-8d%-5s%-2s",polyid,cdc[i].County,cdc[i].Cdcu);
				sprintf(cdcrecord," %8d",polyid);
				sprintf(&cdcrecord[9],"%-5s",cdc[i].County);
				sprintf(&cdcrecord[14],"%-2s",cdc[i].Cdcu);
	
					//urb[i].Urbflag);
				fwrite(&cdcrecord,sizeof(cdcrecord)-1,1,dbfout);    		
				Npts = 0;
				if (cdc[i].Flip == 0)
				{
					Pts[Npts].Longitude = cdc[i].Frlong;
					Pts[Npts].Latitude = cdc[i].Frlat;
					Npts++;
					Get_Shape_Points(cdc[i].Tlid,cdc[i].Flip);
					Pts[Npts].Longitude = cdc[i].Tolong;
					Pts[Npts].Latitude = cdc[i].Tolat;
					Npts++;					
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					cdc[i].Chosen = 1;            
					found = 1;                      
					curX = cdc[i].Tolong;
					curY = cdc[i].Tolat;                
					curcase = i;
					break;					
				}
				else
				{
					Pts[Npts].Longitude = cdc[i].Tolong;
					Pts[Npts].Latitude = cdc[i].Tolat;
					Npts++;
					Get_Shape_Points(cdc[i].Tlid,cdc[i].Flip);
					Pts[Npts].Longitude = cdc[i].Frlong;
					Pts[Npts].Latitude = cdc[i].Frlat;
					Npts++;				
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = cdc[i].Frlong;
					curY = cdc[i].Frlat;                        
					cdc[i].Chosen = 1;		
					found = 1;          
					curcase = i;	
					break;					
				}	
			}
		}
		//by now found should be 1
		if (found == 0)
		{
			info.Format("ERROR - found is zero");
			Ptrdlg->ErrorMessage(info);									
			MissingFile = -1;
			return;
		}
		ptcount += Npts;
		fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
		if (Pts[0].Longitude < CurrentMinX)
			CurrentMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < CurrentMinY)
			CurrentMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[0].Latitude;	
		if (Pts[0].Longitude < FileMinX)
			FileMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > FileMaxX)
			FileMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < FileMinY)
			FileMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > FileMaxY)
			FileMaxY = Pts[0].Latitude;

		if (Pts[Npts-1].Longitude < CurrentMinX)
			CurrentMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < CurrentMinY)
			CurrentMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[Npts-1].Latitude;	
		if (Pts[Npts-1].Longitude < FileMinX)
			FileMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > FileMaxX)
			FileMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < FileMinY)
			FileMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > FileMaxY)
			FileMaxY = Pts[Npts-1].Latitude;		
	}//close while loop
	fwrite(&ptcount,sizeof(int),1,headtemp);
	fwrite(&nparts,sizeof(int),1,partstemp);
	fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
	fclose(boxtemp);
	fclose(headtemp);
	fclose(ptstemp);
	fclose(partstemp);
	sprintf(msg,"processed %d of %d records",n,written);
	Ptrdlg->SetDlgItemText(IDC_CDCU,msg);			
	write_eof(dbfout);
	rewind(dbfout);
	Build_db_Header(dbfout,polyid,dbCdcu);
	Build_Poly_Shape("cdc");
	Ptrdlg->m_strCdcu.Format("%d Congressional Districts",polyid);
	Ptrdlg->SetDlgItemText(IDC_CDCU,Ptrdlg->m_strCdcu);
    fclose(dbfout);
	free(cdc);
	fprintf(LOG,"Wrote %d Current Congressional District polygons to shape %s%scdc\n", polyid,
		Outfilepath, Outfiletitle);		
}
void Match_Poly_Lines_House()
{
	int polyid, found, i, nparts, ptcount;
	long num, n, written, curcase;
	State_House_Border_Type *house;
	double  curX, curY;	
    FILE  *dbfout, *ptstemp, *headtemp, *partstemp, *boxtemp; 
	CString info, fname, errmsg;	
	char houserecord[21];
	int steppos;
	char msg[100];
	int doleft, doright;

	if (SPolycounts[4] == 0)
	{
		Ptrdlg->SetDlgItemText(IDC_STHOUSE,"No Such Cases");		
		return;
	}	
	fname.Format("%s%shse.dbf",Outfilepath,Outfiletitle);			
	dbfout = fopen(fname,"wb");
	if (dbfout == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	ptstemp = fopen("pts.tmp","wb");
	if (ptstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	headtemp = fopen("head.tmp","wb");
	if (headtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	boxtemp = fopen("box.tmp","wb");
	if (boxtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	partstemp = fopen("parts.tmp","wb");
	if (partstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	house = (State_House_Border_Type *)calloc(SPolycounts[4]+Watercut*SPolycounts[0],sizeof(State_House_Border_Type));	
	written = 0;
	for (num = 0; num < CountI; num++)
	{
		if (strcmp(TypeIs[num].Housel,TypeIs[num].Houser)== 0)
		{
			if (Watercut)
			{

				if (TypeIs[num].Waterl == TypeIs[num].Waterr)
					continue;
			}
			else
				continue;		
		}
		doleft = 0;
		
		if (strcmp(TypeIs[num].Housel,"      ") != 0)
		{//left case	
			if (Watercut)
			{

				if (!TypeIs[num].Waterl)
					doleft = 1;
			}
			else
				doleft = 1;
			if (doleft)
			{
				sprintf(house[written].County,"%s%s",TypeIs[num].State,TypeIs[num].County);				
				sprintf(house[written].House,"%6s",TypeIs[num].Housel);				
				//sprintf(urb[written].Urbflag,"%c",TypeIs[num].Urbl[4]);				
				//urb[written].Urbflag = TypeIs[num].Urbl[4];
				sprintf(house[written].Tlid,"%s",TypeIs[num].Tlid);
				house[written].Frlong = Type1s[num].Frlong;
				house[written].Frlat = Type1s[num].Frlat;
				house[written].Tolong = Type1s[num].Tolong;
				house[written].Tolat = Type1s[num].Tolat;
				house[written].Chosen = 0;
				house[written].Flip = 1;
				written++;
			}
		}
		doright = 0;
		if (strcmp(TypeIs[num].Houser, "      ") != 0)
		{//rightcase 
			if (Watercut)
			{
				if (!TypeIs[num].Waterr)
					doright = 1;
			}
			else
				doright = 1;
			if (doright)
			{
			//printf("\nright case");			
				sprintf(house[written].County,"%s%s",TypeIs[num].State,TypeIs[num].County);				
				sprintf(house[written].House,"%6s",TypeIs[num].Houser);				
				//sprintf(urb[written].Urbflag,"%c",TypeIs[num].Urbr[4]);				
				//urb[written].Urbflag = TypeIs[num].Urbr[4];
				sprintf(house[written].Tlid,"%s",TypeIs[num].Tlid);				
				house[written].Frlong = Type1s[num].Frlong;
				house[written].Frlat = Type1s[num].Frlat;
				house[written].Tolong = Type1s[num].Tolong;
				house[written].Tolat = Type1s[num].Tolat;
				house[written].Chosen = 0;
				house[written].Flip = 0;
				written++;
			}
		}
	}	
	if (written > SPolycounts[4]+Watercut*SPolycounts[0])
	{
		Ptrdlg->ErrorMessage("the number of State House border lines exceeds the count");				
		MissingFile = -1;
		return;
	}
	if (written == 0)
	{
		if (!Watercut)
			fprintf(LOG,"There are no lines for State House polygons\n");
		else
		{
			fprintf(LOG,"All State House polygons for this county coincide with water polygons\n");
			fprintf(LOG,"Try turning off the water polygon clipping option\n");
		}
		return;
	}
	
	//time to chain		
	Ptrdlg->m_strProcess.Format("Gathering State House Boundary Lines");
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	qsort((void *)house,written,sizeof(State_House_Border_Type),(compfn)CompareHouse);	
	FileMinX = FileMinY = LARGE;
	FileMaxX = FileMaxY = -LARGE;
	CurrentMinX = CurrentMinY = LARGE;
	CurrentMaxX = CurrentMaxY = -LARGE;
	curcase = 0;
	polyid = 1;
	Npts = 0; 
	nparts = 1;
	ptcount = 0;
	Build_db_Header(dbfout,0,dbHouse);
	Build_db_FieldHeaders(dbfout,dbHouse);	
	//sprintf(houserecord," %8d%-5s%-6s",polyid,house[curcase].County,house[curcase].House);
	sprintf(houserecord," %-8d",polyid);
	sprintf(&houserecord[9],"%-5s",house[curcase].County);
	sprintf(&houserecord[14],"%-6s",house[curcase].House);
		//urb[curcase].Urbflag);	
	fwrite(&houserecord,sizeof(houserecord)-1,1,dbfout);
	if (house[0].Flip == 0)
	{
		curX = house[0].Tolong;
		curY = house[0].Tolat;		
		Pts[Npts].Longitude = house[curcase].Frlong;
		Pts[Npts].Latitude = house[curcase].Frlat;
		Npts++;
		Get_Shape_Points(house[curcase].Tlid, house[curcase].Flip);
		Pts[Npts].Longitude = house[curcase].Tolong;
		Pts[Npts].Latitude = house[curcase].Tolat;
		Npts++;
		house[curcase].Chosen = 1;		
	}
	else
	{
		curX = house[0].Frlong;
		curY = house[0].Frlat;		
		Pts[Npts].Longitude = house[curcase].Tolong;
		Pts[Npts].Latitude = house[curcase].Tolat;
		Npts++;
		Get_Shape_Points(house[curcase].Tlid, house[curcase].Flip);
		Pts[Npts].Longitude = house[curcase].Frlong;
		Pts[Npts].Latitude = house[curcase].Frlat;
		Npts++;
		house[curcase].Chosen = 1;		
	}
	ptcount += Npts;
	
    fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
	
	if (Pts[0].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < CurrentMinY)
		CurrentMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[0].Latitude;	
	if (Pts[0].Longitude < FileMinX)
		FileMinX = Pts[0].Longitude;
	if (Pts[0].Longitude > FileMaxX)
		FileMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < FileMinY)
		FileMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > FileMaxY)
		FileMaxY = Pts[0].Latitude;

	if (Pts[Npts-1].Longitude < CurrentMinX)
		CurrentMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < CurrentMinY)
		CurrentMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[Npts-1].Latitude;	
	if (Pts[Npts-1].Longitude < FileMinX)
		FileMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > FileMaxX)
		FileMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < FileMinY)
		FileMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > FileMaxY)
		FileMaxY = Pts[Npts-1].Latitude;		
	n = 1;
	steppos = (int)(n*100/written);	
	Ptrdlg->m_Progress.SetPos(steppos);
    while (n < written)
	{		
		sprintf(msg,"processed %d of %d records",n,written);
		Ptrdlg->SetDlgItemText(IDC_STHOUSE,msg);		
		found = 0;
		for (i = 1; i < written; i++)
         {
			Npts = 0;
			if (house[i].Chosen != 0)
				continue;
			if (house[i].Flip == 0)
			{
				if ((house[i].Frlong == curX) && (house[i].Frlat == curY))
				{                          
					if (strcmp(house[i].House,house[curcase].House) != 0)
						continue;	            
					//if (urb[i].Urbflag != urb[i].Urbflag)
					//	continue;
					Get_Shape_Points(house[i].Tlid,house[i].Flip);
					Pts[Npts].Longitude = house[i].Tolong;
					Pts[Npts].Latitude = house[i].Tolat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					house[i].Chosen = 1;            
					found = 1;                      
					curX = house[i].Tolong;
					curY = house[i].Tolat;                
					curcase = i;
					break;
				}
			}
			else
			{
				if ((house[i].Tolong == curX) && (house[i].Tolat == curY))
				{
					if (strcmp(house[i].House,house[curcase].House) != 0)
						continue;	            
					//if (urb[i].Urbflag != urb[curcase].Urbflag)
					//	continue;
					Get_Shape_Points(house[i].Tlid,house[i].Flip);
					Pts[Npts].Longitude = house[i].Frlong;
					Pts[Npts].Latitude = house[i].Frlat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = house[i].Frlong;
					curY = house[i].Frlat;                        
					house[i].Chosen = 1;	
					found = 1;          
					curcase = i;
					break;
				}
			}
        }//close for loop
		if (found == 0) //initialize new case, eg, new ring or new poly
		{			
			fwrite(&ptcount,sizeof(int),1,headtemp);
			ptcount = 0;
			for (i = 0; i < written; i++) //check for new ring in poly
            {                    
         		if (house[i].Chosen != 0)
					continue;    
				if (strcmp(house[i].House,house[curcase].House) != 0)
					continue;	            
				//if (urb[i].Urbflag != urb[curcase].Urbflag)
				//	continue;
				//if we get here it is a new ring in current poly
				found = 1;
				nparts++;
				Npts = 0;
				if (house[i].Flip == 0)
				{
					Pts[Npts].Longitude = house[i].Frlong;
					Pts[Npts].Latitude = house[i].Frlat;
					Npts++;
					Get_Shape_Points(house[i].Tlid,house[i].Flip);
					Pts[Npts].Longitude = house[i].Tolong;
					Pts[Npts].Latitude = house[i].Tolat;
					Npts++;			
    				n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					house[i].Chosen = 1;
    		   		curX = house[i].Tolong;
    				curY = house[i].Tolat;
					curcase = i;
					break;
				}
				else
				{
					Pts[Npts].Longitude = house[i].Tolong;
					Pts[Npts].Latitude = house[i].Tolat;
					Npts++;
					Get_Shape_Points(house[i].Tlid,house[i].Flip);
					Pts[Npts].Longitude = house[i].Frlong;
					Pts[Npts].Latitude = house[i].Frlat;
					Npts++;			
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					house[i].Chosen = 1;
    		   		curX = house[i].Frlong;
    				curY = house[i].Frlat;
					curcase = i;
					break;
				}
    		}
    	}
		if (found == 0) // new poly, first ring
		{
			
			fwrite(&nparts,sizeof(int),1,partstemp);
			nparts = 1;
			fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
			CurrentMinX = CurrentMinY = LARGE;
			CurrentMaxX = CurrentMaxY = -LARGE;

			for (i = 0; i < written; i++)//first check for new ring in current poly
            {                    
         		if (house[i].Chosen != 0)
					continue;             
				polyid++;
				//sprintf(houserecord," %-8d%-5s%-6s",polyid,house[i].County,house[i].House);
				sprintf(houserecord," %-8d",polyid);
				sprintf(&houserecord[9],"%-5s",house[i].County);
				sprintf(&houserecord[14],"%-6s",house[i].House);
					//urb[i].Urbflag);
				fwrite(&houserecord,sizeof(houserecord)-1,1,dbfout);    		
				Npts = 0;
				if (house[i].Flip == 0)
				{
					Pts[Npts].Longitude = house[i].Frlong;
					Pts[Npts].Latitude = house[i].Frlat;
					Npts++;
					Get_Shape_Points(house[i].Tlid,house[i].Flip);
					Pts[Npts].Longitude = house[i].Tolong;
					Pts[Npts].Latitude = house[i].Tolat;
					Npts++;					
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					house[i].Chosen = 1;            
					found = 1;                      
					curX = house[i].Tolong;
					curY = house[i].Tolat;                
					curcase = i;
					break;					
				}
				else
				{
					Pts[Npts].Longitude = house[i].Tolong;
					Pts[Npts].Latitude = house[i].Tolat;
					Npts++;
					Get_Shape_Points(house[i].Tlid,house[i].Flip);
					Pts[Npts].Longitude = house[i].Frlong;
					Pts[Npts].Latitude = house[i].Frlat;
					Npts++;				
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = house[i].Frlong;
					curY = house[i].Frlat;                        
					house[i].Chosen = 1;		
					found = 1;          
					curcase = i;	
					break;					
				}	
			}
		}
		//by now found should be 1
		if (found == 0)
		{
			info.Format("ERROR - found is zero");
			Ptrdlg->ErrorMessage(info);									
			MissingFile = -1;
			return;
		}
		ptcount += Npts;
		fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
		if (Pts[0].Longitude < CurrentMinX)
			CurrentMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < CurrentMinY)
			CurrentMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[0].Latitude;	
		if (Pts[0].Longitude < FileMinX)
			FileMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > FileMaxX)
			FileMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < FileMinY)
			FileMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > FileMaxY)
			FileMaxY = Pts[0].Latitude;

		if (Pts[Npts-1].Longitude < CurrentMinX)
			CurrentMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < CurrentMinY)
			CurrentMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[Npts-1].Latitude;	
		if (Pts[Npts-1].Longitude < FileMinX)
			FileMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > FileMaxX)
			FileMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < FileMinY)
			FileMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > FileMaxY)
			FileMaxY = Pts[Npts-1].Latitude;		
	}//close while loop
	fwrite(&ptcount,sizeof(int),1,headtemp);
	fwrite(&nparts,sizeof(int),1,partstemp);
	fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
	fclose(boxtemp);
	fclose(headtemp);
	fclose(ptstemp);
	fclose(partstemp);
	sprintf(msg,"processed %d of %d records",n,written);
	Ptrdlg->SetDlgItemText(IDC_STHOUSE,msg);			
	write_eof(dbfout);
	rewind(dbfout);
	Build_db_Header(dbfout,polyid,dbHouse);
	Build_Poly_Shape("hse");
	Ptrdlg->m_strHouse.Format("%d State House Districts",polyid);
	Ptrdlg->SetDlgItemText(IDC_STHOUSE,Ptrdlg->m_strHouse);
    fclose(dbfout);
	free(house);
	fprintf(LOG,"Wrote %d State House District polygons to shape %s%shse\n", polyid,
		Outfilepath, Outfiletitle);		
}
void Match_Poly_Lines_Senate()
{
	int polyid, found, i, nparts, ptcount;
	long num, n, written, curcase;
	State_Senate_Border_Type *senate;
	double  curX, curY;	
    FILE  *dbfout, *ptstemp, *headtemp, *partstemp, *boxtemp; 
	CString info, fname, errmsg;	
	char senaterecord[21];
	int steppos;
	char msg[100];
	int doleft, doright;
	
	if (SPolycounts[5] == 0)
	{
		Ptrdlg->SetDlgItemText(IDC_STSENATE,"No Such Cases");		
		return;
	}	
	fname.Format("%s%ssen.dbf",Outfilepath,Outfiletitle);			
	dbfout = fopen(fname,"wb");
	if (dbfout == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	ptstemp = fopen("pts.tmp","wb");
	if (ptstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	headtemp = fopen("head.tmp","wb");
	if (headtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	boxtemp = fopen("box.tmp","wb");
	if (boxtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	partstemp = fopen("parts.tmp","wb");
	if (partstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	senate = (State_Senate_Border_Type *)calloc(SPolycounts[5]+Watercut*SPolycounts[0],sizeof(State_Senate_Border_Type));	
	written = 0;
	for (num = 0; num < CountI; num++)
	{
		if (strcmp(TypeIs[num].Senatel,TypeIs[num].Senater)== 0)
		{
			if (Watercut)
			{

				if (TypeIs[num].Waterl == TypeIs[num].Waterr)
					continue;
			}
			else
				continue;		
		}
		doleft = 0;
		
		if (strcmp(TypeIs[num].Senatel,"      ") != 0)
		{//left case	
			if (Watercut)
			{
				if (!TypeIs[num].Waterl)
					doleft = 1;
			}
			else
				doleft = 1;
			if (doleft)
			{
				sprintf(senate[written].County,"%s%s",TypeIs[num].State,TypeIs[num].County);				
				sprintf(senate[written].Senate,"%6s",TypeIs[num].Senatel);				
				//sprintf(urb[written].Urbflag,"%c",TypeIs[num].Urbl[4]);				
				//urb[written].Urbflag = TypeIs[num].Urbl[4];
				sprintf(senate[written].Tlid,"%s",TypeIs[num].Tlid);
				senate[written].Frlong = Type1s[num].Frlong;
				senate[written].Frlat = Type1s[num].Frlat;
				senate[written].Tolong = Type1s[num].Tolong;
				senate[written].Tolat = Type1s[num].Tolat;
				senate[written].Chosen = 0;
				senate[written].Flip = 1;
				written++;
			}
		}
		doright = 0;
		if (strcmp(TypeIs[num].Senater, "      ") != 0)
		{//rightcase 
			if (Watercut)
			{
				if (!TypeIs[num].Waterr)
					doright = 1;
			}
			else
				doright = 1;
			if (doright)
			{
			//printf("\nright case");			
				sprintf(senate[written].County,"%s%s",TypeIs[num].State,TypeIs[num].County);				
				sprintf(senate[written].Senate,"%6s",TypeIs[num].Senater);				
				//sprintf(urb[written].Urbflag,"%c",TypeIs[num].Urbr[4]);				
				//urb[written].Urbflag = TypeIs[num].Urbr[4];
				sprintf(senate[written].Tlid,"%s",TypeIs[num].Tlid);				
				senate[written].Frlong = Type1s[num].Frlong;
				senate[written].Frlat = Type1s[num].Frlat;
				senate[written].Tolong = Type1s[num].Tolong;
				senate[written].Tolat = Type1s[num].Tolat;
				senate[written].Chosen = 0;
				senate[written].Flip = 0;
				written++;
			}
		}
	}	
	if (written > SPolycounts[5]+Watercut*SPolycounts[0])
	{
		Ptrdlg->ErrorMessage("the number of State Senate border lines exceeds the count");				
		MissingFile = -1;
		return;
	}
	if (written == 0)
	{
		if (!Watercut)
			fprintf(LOG,"There are no lines for State Senate polygons\n");
		else
		{
			fprintf(LOG,"All State Senate for this county coincide with water polygons\n");
			fprintf(LOG,"Try turning off the water polygon clipping option\n");
		}
		return;
	}
	
	//time to chain		
	Ptrdlg->m_strProcess.Format("Gathering State Senate Boundary Lines");
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	qsort((void *)senate,written,sizeof(State_Senate_Border_Type),(compfn)CompareSenate);	
	FileMinX = FileMinY = LARGE;
	FileMaxX = FileMaxY = -LARGE;
	CurrentMinX = CurrentMinY = LARGE;
	CurrentMaxX = CurrentMaxY = -LARGE;
	curcase = 0;
	polyid = 1;
	Npts = 0; 
	nparts = 1;
	ptcount = 0;
	Build_db_Header(dbfout,0,dbSenate);
	Build_db_FieldHeaders(dbfout,dbSenate);	
	//sprintf(senaterecord," %8d%-5s%-6s",polyid,senate[curcase].County,senate[curcase].Senate);
	sprintf(senaterecord," %8d",polyid);
	sprintf(&senaterecord[9],"%-5s",senate[curcase].County);
	sprintf(&senaterecord[14],"%-6s",senate[curcase].Senate);
		//urb[curcase].Urbflag);	
	fwrite(&senaterecord,sizeof(senaterecord)-1,1,dbfout);
	if (senate[0].Flip == 0)
	{
		curX = senate[0].Tolong;
		curY = senate[0].Tolat;		
		Pts[Npts].Longitude = senate[curcase].Frlong;
		Pts[Npts].Latitude = senate[curcase].Frlat;
		Npts++;
		Get_Shape_Points(senate[curcase].Tlid, senate[curcase].Flip);
		Pts[Npts].Longitude = senate[curcase].Tolong;
		Pts[Npts].Latitude = senate[curcase].Tolat;
		Npts++;
		senate[curcase].Chosen = 1;		
	}
	else
	{
		curX = senate[0].Frlong;
		curY = senate[0].Frlat;		
		Pts[Npts].Longitude = senate[curcase].Tolong;
		Pts[Npts].Latitude = senate[curcase].Tolat;
		Npts++;
		Get_Shape_Points(senate[curcase].Tlid, senate[curcase].Flip);
		Pts[Npts].Longitude = senate[curcase].Frlong;
		Pts[Npts].Latitude = senate[curcase].Frlat;
		Npts++;
		senate[curcase].Chosen = 1;		
	}
	ptcount += Npts;
	
    fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
	
	if (Pts[0].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < CurrentMinY)
		CurrentMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[0].Latitude;	
	if (Pts[0].Longitude < FileMinX)
		FileMinX = Pts[0].Longitude;
	if (Pts[0].Longitude > FileMaxX)
		FileMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < FileMinY)
		FileMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > FileMaxY)
		FileMaxY = Pts[0].Latitude;

	if (Pts[Npts-1].Longitude < CurrentMinX)
		CurrentMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < CurrentMinY)
		CurrentMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[Npts-1].Latitude;	
	if (Pts[Npts-1].Longitude < FileMinX)
		FileMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > FileMaxX)
		FileMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < FileMinY)
		FileMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > FileMaxY)
		FileMaxY = Pts[Npts-1].Latitude;		
	n = 1;
	steppos = (int)(n*100/written);	
	Ptrdlg->m_Progress.SetPos(steppos);
    while (n < written)
	{		
		sprintf(msg,"processed %d of %d records",n,written);
		Ptrdlg->SetDlgItemText(IDC_STSENATE,msg);		
		found = 0;
		for (i = 1; i < written; i++)
         {
			Npts = 0;
			if (senate[i].Chosen != 0)
				continue;
			if (senate[i].Flip == 0)
			{
				if ((senate[i].Frlong == curX) && (senate[i].Frlat == curY))
				{                          
					if (strcmp(senate[i].Senate,senate[curcase].Senate) != 0)
						continue;	            
					//if (urb[i].Urbflag != urb[i].Urbflag)
					//	continue;
					Get_Shape_Points(senate[i].Tlid,senate[i].Flip);
					Pts[Npts].Longitude = senate[i].Tolong;
					Pts[Npts].Latitude = senate[i].Tolat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					senate[i].Chosen = 1;            
					found = 1;                      
					curX = senate[i].Tolong;
					curY = senate[i].Tolat;                
					curcase = i;
					break;
				}
			}
			else
			{
				if ((senate[i].Tolong == curX) && (senate[i].Tolat == curY))
				{
					if (strcmp(senate[i].Senate,senate[curcase].Senate) != 0)
						continue;	            
					//if (urb[i].Urbflag != urb[curcase].Urbflag)
					//	continue;
					Get_Shape_Points(senate[i].Tlid,senate[i].Flip);
					Pts[Npts].Longitude = senate[i].Frlong;
					Pts[Npts].Latitude = senate[i].Frlat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = senate[i].Frlong;
					curY = senate[i].Frlat;                        
					senate[i].Chosen = 1;	
					found = 1;          
					curcase = i;
					break;
				}
			}
        }//close for loop
		if (found == 0) //initialize new case, eg, new ring or new poly
		{			
			fwrite(&ptcount,sizeof(int),1,headtemp);
			ptcount = 0;
			for (i = 0; i < written; i++) //check for new ring in poly
            {                    
         		if (senate[i].Chosen != 0)
					continue;    
				if (strcmp(senate[i].Senate,senate[curcase].Senate) != 0)
					continue;	            
				//if (urb[i].Urbflag != urb[curcase].Urbflag)
				//	continue;
				//if we get here it is a new ring in current poly
				found = 1;
				nparts++;
				Npts = 0;
				if (senate[i].Flip == 0)
				{
					Pts[Npts].Longitude = senate[i].Frlong;
					Pts[Npts].Latitude = senate[i].Frlat;
					Npts++;
					Get_Shape_Points(senate[i].Tlid,senate[i].Flip);
					Pts[Npts].Longitude = senate[i].Tolong;
					Pts[Npts].Latitude = senate[i].Tolat;
					Npts++;			
    				n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					senate[i].Chosen = 1;
    		   		curX = senate[i].Tolong;
    				curY = senate[i].Tolat;
					curcase = i;
					break;
				}
				else
				{
					Pts[Npts].Longitude = senate[i].Tolong;
					Pts[Npts].Latitude = senate[i].Tolat;
					Npts++;
					Get_Shape_Points(senate[i].Tlid,senate[i].Flip);
					Pts[Npts].Longitude = senate[i].Frlong;
					Pts[Npts].Latitude = senate[i].Frlat;
					Npts++;			
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					senate[i].Chosen = 1;
    		   		curX = senate[i].Frlong;
    				curY = senate[i].Frlat;
					curcase = i;
					break;
				}
    		}
    	}
		if (found == 0) // new poly, first ring
		{
			
			fwrite(&nparts,sizeof(int),1,partstemp);
			nparts = 1;
			fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
			CurrentMinX = CurrentMinY = LARGE;
			CurrentMaxX = CurrentMaxY = -LARGE;

			for (i = 0; i < written; i++)//first check for new ring in current poly
            {                    
         		if (senate[i].Chosen != 0)
					continue;             
				polyid++;
	//			sprintf(senaterecord," %-8d%-5s%-6s",polyid,senate[i].County,senate[i].Senate);
					//urb[i].Urbflag);
				sprintf(senaterecord," %8d",polyid);
				sprintf(&senaterecord[9],"%-5s",senate[i].County);
				sprintf(&senaterecord[14],"%-6s",senate[i].Senate);
	
				fwrite(&senaterecord,sizeof(senaterecord)-1,1,dbfout);    		
				Npts = 0;
				if (senate[i].Flip == 0)
				{
					Pts[Npts].Longitude = senate[i].Frlong;
					Pts[Npts].Latitude = senate[i].Frlat;
					Npts++;
					Get_Shape_Points(senate[i].Tlid,senate[i].Flip);
					Pts[Npts].Longitude = senate[i].Tolong;
					Pts[Npts].Latitude = senate[i].Tolat;
					Npts++;					
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					senate[i].Chosen = 1;            
					found = 1;                      
					curX = senate[i].Tolong;
					curY = senate[i].Tolat;                
					curcase = i;
					break;					
				}
				else
				{
					Pts[Npts].Longitude = senate[i].Tolong;
					Pts[Npts].Latitude = senate[i].Tolat;
					Npts++;
					Get_Shape_Points(senate[i].Tlid,senate[i].Flip);
					Pts[Npts].Longitude = senate[i].Frlong;
					Pts[Npts].Latitude = senate[i].Frlat;
					Npts++;				
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = senate[i].Frlong;
					curY = senate[i].Frlat;                        
					senate[i].Chosen = 1;		
					found = 1;          
					curcase = i;	
					break;					
				}	
			}
		}
		//by now found should be 1
		if (found == 0)
		{
			info.Format("ERROR - found is zero");
			Ptrdlg->ErrorMessage(info);									
			MissingFile = -1;
			return;
		}
		ptcount += Npts;
		fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
		if (Pts[0].Longitude < CurrentMinX)
			CurrentMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < CurrentMinY)
			CurrentMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[0].Latitude;	
		if (Pts[0].Longitude < FileMinX)
			FileMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > FileMaxX)
			FileMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < FileMinY)
			FileMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > FileMaxY)
			FileMaxY = Pts[0].Latitude;

		if (Pts[Npts-1].Longitude < CurrentMinX)
			CurrentMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < CurrentMinY)
			CurrentMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[Npts-1].Latitude;	
		if (Pts[Npts-1].Longitude < FileMinX)
			FileMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > FileMaxX)
			FileMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < FileMinY)
			FileMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > FileMaxY)
			FileMaxY = Pts[Npts-1].Latitude;		
	}//close while loop
	fwrite(&ptcount,sizeof(int),1,headtemp);
	fwrite(&nparts,sizeof(int),1,partstemp);
	fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
	fclose(boxtemp);
	fclose(headtemp);
	fclose(ptstemp);
	fclose(partstemp);
	sprintf(msg,"processed %d of %d records",n,written);
	Ptrdlg->SetDlgItemText(IDC_STSENATE,msg);			
	write_eof(dbfout);
	rewind(dbfout);
	Build_db_Header(dbfout,polyid,dbSenate);
	Build_Poly_Shape("sen");
	Ptrdlg->m_strSenate.Format("%d State Senate Districts to shape %s%ssen",polyid, 
		Outfilepath,Outfiletitle);
	Ptrdlg->SetDlgItemText(IDC_STSENATE,Ptrdlg->m_strSenate);
    fclose(dbfout);
	free(senate);

}
void Parse_Type1_Record(long k)
{
	int i;
    Nscanf(Record,1,"%c",&Type1s[k].RecordType);
    Nscanf(&Record[1],4,"%d",&Type1s[k].Version);
    Ascanf(&Record[5],10,Type1s[k].Tlid);
    Nscanf(&Record[15],1,"%d",&Type1s[k].Side1);
    Nscanf(&Record[16],1,"%c",&Type1s[k].Source);
    Ascanf(&Record[17],2,Type1s[k].Fedirp);
    Ascanf(&Record[19],30,Type1s[k].Fename);
    Ascanf(&Record[49],4,Type1s[k].Fetype);
    Ascanf(&Record[53],2,Type1s[k].Fedirs);
    Ascanf(&Record[55],3,Type1s[k].Cfcc);
    Ascanf(&Record[58],11,Type1s[k].Fraddl);
    Ascanf(&Record[69],11,Type1s[k].Toaddl);
    Ascanf(&Record[80],11,Type1s[k].Fraddr);
    Ascanf(&Record[91],11,Type1s[k].Toaddr);
    Nscanf(&Record[102],1,"%d",&Type1s[k].Friaddl);
    Nscanf(&Record[103],1,"%d",&Type1s[k].Toiaddl);
    Nscanf(&Record[104],1,"%d",&Type1s[k].Friaddr);
    Nscanf(&Record[105],1,"%d",&Type1s[k].Toiaddr);
    Ascanf(&Record[106],5,Type1s[k].Zipl);
    Ascanf(&Record[111],5,Type1s[k].Zipr);
    Ascanf(&Record[116],5,Type1s[k].Fairl);
    Ascanf(&Record[121],5,Type1s[k].Fairr);
    Nscanf(&Record[126],1,"%c",&Type1s[k].Trustl);
    Nscanf(&Record[127],1,"%c",&Type1s[k].Trustr);
    Nscanf(&Record[128],1,"%c",&Type1s[k].Census1);
    Nscanf(&Record[129],1,"%c",&Type1s[k].Census2);
    Ascanf(&Record[130],2,Type1s[k].Statel);
    Ascanf(&Record[132],2,Type1s[k].Stater);
    Ascanf(&Record[134],3,Type1s[k].Countyl);
    Ascanf(&Record[137],3,Type1s[k].Countyr);
    Ascanf(&Record[140],5,Type1s[k].Fmcdl);
    Ascanf(&Record[145],5,Type1s[k].Fmcdr);
    Ascanf(&Record[150],5,Type1s[k].Fsmcdl);
    Ascanf(&Record[155],5,Type1s[k].Fsmcdr);
    Ascanf(&Record[160],5,Type1s[k].Fpll);
    Ascanf(&Record[165],5,Type1s[k].Fplr);
    Ascanf(&Record[170],6,Type1s[k].Ctbnal);
    Ascanf(&Record[176],6,Type1s[k].Ctbnar);
	if (Type1s[k].Ctbnal[0] != ' ')
	{
		for (i=1; i < strlen(Type1s[k].Ctbnal); i++)
		{
			if (Type1s[k].Ctbnal[i] == ' ')
				Type1s[k].Ctbnal[i] = '0';
		}
	}    
	if (Type1s[k].Ctbnar[0] != ' ')
	{
		for (i=1; i < strlen(Type1s[k].Ctbnar); i++)
		{
			if (Type1s[k].Ctbnar[i] == ' ')
				Type1s[k].Ctbnar[i] = '0';
		}
	}
    Ascanf(&Record[182],4,Type1s[k].Blkl);
    Ascanf(&Record[186],4,Type1s[k].Blkr);
    Nscanf(&Record[190],10,"%lf",&Type1s[k].Frlong);
    Nscanf(&Record[200],9,"%lf",&Type1s[k].Frlat);
    Nscanf(&Record[209],10,"%lf",&Type1s[k].Tolong);
    Nscanf(&Record[219],9,"%lf",&Type1s[k].Tolat);
	Type1s[k].Frlong /= 1000000;
	Type1s[k].Frlat /= 1000000;
	Type1s[k].Tolong /= 1000000;
	Type1s[k].Tolat /= 1000000;
}
void Parse_Type2_Record(long k)                                       
{     
    int position, i;
    Nscanf(Record,1,"%c",&Type2s[k].RecordType);
    Nscanf(&Record[1],4,"%d",&Type2s[k].Version);
    Ascanf(&Record[5],10,Type2s[k].Tlid);
    Ascanf(&Record[15],3,Type2s[k].Rtsq);
    for (i=0; i<10; i++)
      {              
      position = 18 + (i * 19);
      Nscanf(&Record[position],10,"%lf",&Type2s[k].Point[i].Longitude);
      Nscanf(&Record[position + 10],9,"%lf",&Type2s[k].Point[i].Latitude);
      Type2s[k].Point[i].Longitude = Type2s[k].Point[i].Longitude/1000000;
      Type2s[k].Point[i].Latitude = Type2s[k].Point[i].Latitude/1000000;
      }
}     
void Parse_Type3_Record(long k)
{
	int i;
    Nscanf(Record,1,"%c",&Type3s[k].RecordType);
    Nscanf(&Record[1],4,"%d",&Type3s[k].Version);
    Ascanf(&Record[5],10,Type3s[k].Tlid);
    Ascanf(&Record[15],2,Type3s[k].State90l);
    Ascanf(&Record[17],2,Type3s[k].State90r);
    Ascanf(&Record[19],3,Type3s[k].Coun90l);
    Ascanf(&Record[22],3,Type3s[k].Coun90r);
    Ascanf(&Record[25],5,Type3s[k].Fmcd90l);
    Ascanf(&Record[30],5,Type3s[k].Fmcd90r);
    Ascanf(&Record[35],5,Type3s[k].Fpl90l);
    Ascanf(&Record[40],5,Type3s[k].Fpl90r);
    Ascanf(&Record[45],6,Type3s[k].Ctbnal);
	if (Type3s[k].Ctbnal[0] != ' ')
	{
		for (i=1; i < strlen(Type3s[k].Ctbnal); i++)
		{
			if (Type3s[k].Ctbnal[i] == ' ')
				Type3s[k].Ctbnal[i] = '0';
		}
	}

    Ascanf(&Record[51],6,Type3s[k].Ctbnar);    
	if (Type3s[k].Ctbnar[0] != ' ')
	{
		for (i=1; i < strlen(Type3s[k].Ctbnar); i++)
		{
			if (Type3s[k].Ctbnar[i] == ' ')
				Type3s[k].Ctbnar[i] = '0';
		}
	}
	//luca
	if (TigerVersion >= 97)
	{//these are not in tiger 94-95
		Ascanf(&Record[57],4,Type3s[k].Air90l);
		Ascanf(&Record[61],4,Type3s[k].Air90r);
		Nscanf(&Record[65],1,"%c",&Type3s[k].Trust90l);
		Nscanf(&Record[66],1,"%c",&Type3s[k].Trust90r);
	}
	
    Ascanf(&Record[69],4,Type3s[k].Blk90l);
    Ascanf(&Record[73],4,Type3s[k].Blk90r);
    Ascanf(&Record[77],4,Type3s[k].Aircul);
    Ascanf(&Record[81],4,Type3s[k].Aircur);
	//had to change for TIGER 97 (june 19)
    //Ascanf(&Record[91],2,Type3s[k].Anrcl);
    //Ascanf(&Record[93],2,Type3s[k].Anrcr);
	//luca
	if (TigerVersion == 98)
	{//these are not in 94,95, or standard 97
		Ascanf(&Record[85],5,Type3s[k].Anrcl);
		Ascanf(&Record[90],5,Type3s[k].Anrcr);
		Ascanf(&Record[95],3,Type3s[k].Census3);
		Ascanf(&Record[98],3,Type3s[k].Census4);
	}
	//this is the same for 94-98
	Ascanf(&Record[103],4,Type3s[k].Vtd90l); //luca name change
    Ascanf(&Record[107],4,Type3s[k].Vtd90r);
	if (Type3s[k].Vtd90r[3] == '\0')
		Type3s[k].Vtd90r[3] = ' ';
	
}                                  
void Parse_TypeC_Record(long k)
{
	char tempname[59], tempua[5];
	CString repval;
	Nscanf(Record,1,"%c",&TypeCs[k].RecordType);
    Nscanf(&Record[1],4,"%d",&TypeCs[k].Version);
	Ascanf(&Record[5],2,TypeCs[k].State);
	Ascanf(&Record[7],3,TypeCs[k].County);
	//
	if (TigerVersion == 98)
	{
		Ascanf(&Record[10],4,TypeCs[k].Fipsyr); //luca -- all subsequent columns shift
		Ascanf(&Record[14],5,TypeCs[k].Fips);
		Ascanf(&Record[19],2,TypeCs[k].Fipscc);
		Nscanf(&Record[21],1,"%c",&TypeCs[k].Pdc);
		Ascanf(&Record[22],2,TypeCs[k].Lasad);
		Nscanf(&Record[24],1,"%c",&TypeCs[k].Entity);//luca
		Ascanf(&Record[25],4,TypeCs[k].Ma);//luca
		//Ascanf(&Record[22],2,TypeCs[k].Anrc); //out in luca
		//Ascanf(&Record[24],4,TypeCs[k].Cmsamsa); //out in luca
		//Ascanf(&Record[28],4,TypeCs[k].Pmsa); //out in luca
		Ascanf(&Record[29],5,TypeCs[k].Sd); //luca --empty
		Ascanf(&Record[34],4,TypeCs[k].Air);
		Ascanf(&Record[38],6,TypeCs[k].Vtd);
		Ascanf(&Record[44],5,TypeCs[k].Ua); //new width in luca
		Ascanf(&Record[49],2,TypeCs[k].Anrc); //new location in luca
		Ascanf(&Record[51],3,TypeCs[k].Census5);
		Ascanf(&Record[54],58,tempname);
		sprintf(TypeCs[k].Name,"%-58s        ",tempname);//TypeCs[k].Name); //new width in luca
		//add width to get up to 66 chars
		//strcat(TypeCs[k].Name,"        ");
	}
	else
	{
		Ascanf(&Record[10],2,TypeCs[k].Fipsyr97); //changed in luca
		Ascanf(&Record[12],5,TypeCs[k].Fips);
		Ascanf(&Record[17],2,TypeCs[k].Fipscc);
		Nscanf(&Record[19],1,"%c",&TypeCs[k].Pdc);
		Ascanf(&Record[20],2,TypeCs[k].Lasad);
		if (TigerVersion == 97)
		{
			Nscanf(&Record[22],1,"%c",&TypeCs[k].Entity);
			Ascanf(&Record[23],4,TypeCs[k].Ma);
			Ascanf(&Record[27],5,TypeCs[k].Sd);
		}
		else
		{
			Ascanf(&Record[22],2,TypeCs[k].Anrc);
			Ascanf(&Record[24],4,TypeCs[k].Cmsamsa);
			Ascanf(&Record[28],4,TypeCs[k].Pmsa);
		}
		Ascanf(&Record[32],4,TypeCs[k].Air);
		Ascanf(&Record[36],6,TypeCs[k].Vtd);
		Ascanf(&Record[42],4,tempua);
		sprintf(TypeCs[k].Ua,"%-4s ",tempua);

		//add character to get up to 5 chars
		//strcat(TypeCs[k].Ua," ");
		Ascanf(&Record[46],66,TypeCs[k].Name);
	}
}
void Parse_TypeI_Record(long k)
{
	Nscanf(Record,1,"%c",&TypeIs[k].RecordType);
    Nscanf(&Record[1],4,"%d",&TypeIs[k].Version);
	Ascanf(&Record[5],10,TypeIs[k].Tlid);
	Ascanf(&Record[15],2,TypeIs[k].State);
	Ascanf(&Record[17],3,TypeIs[k].County);
	Nscanf(&Record[20],1,"%c",&TypeIs[k].Rtlink);
	Ascanf(&Record[21],5,TypeIs[k].Cenidl);
	Ascanf(&Record[26],10,TypeIs[k].Polyidl);
	Ascanf(&Record[36],5,TypeIs[k].Cenidr);
	Ascanf(&Record[41],10,TypeIs[k].Polyidr);
	Nscanf(&Record[51],1,"%c",&TypeIs[k].Filler);
}
void Parse_Type9_Record(long k)
{
	Nscanf(Record,1,"%c",&Type9s[k].RecordType);
	Nscanf(&Record[1],4,"%d",&Type9s[k].Version);
	Ascanf(&Record[5],2,Type9s[k].State);
	Ascanf(&Record[7],3,Type9s[k].County);
	Ascanf(&Record[10],5,Type9s[k].Cenid);
	Ascanf(&Record[15],10,Type9s[k].Polyid);
	Nscanf(&Record[25],1,"%c",&Type9s[k].Source);
	Ascanf(&Record[26],3,Type9s[k].Cfcc);
	Ascanf(&Record[29],30,Type9s[k].Kglname);
	Ascanf(&Record[59],11,Type9s[k].Kgladd);
	Ascanf(&Record[70],5,Type9s[k].Kglzip);
	Ascanf(&Record[75],4,Type9s[k].Kglzip4);
	Ascanf(&Record[79],8,Type9s[k].Feat);
	Nscanf(&Record[87],1,"%c",&Type9s[k].Filler);
}
void Parse_Type5_Record(long k)
{
	Nscanf(Record,1,"%c",&Type5s[k].RecordType);	
	Ascanf(&Record[1],2,Type5s[k].State);
	Ascanf(&Record[3],3,Type5s[k].County);
	Ascanf(&Record[6],8,Type5s[k].Feat);
	Ascanf(&Record[14],2,Type5s[k].Fedirp);
	Ascanf(&Record[16],30,Type5s[k].Fename);
	Ascanf(&Record[46],4,Type5s[k].Fetype);
	Ascanf(&Record[50],2,Type5s[k].Fedirp);
}
void Parse_Type4_Record(long k)
{
	Nscanf(Record,1,"%c",&Type4s[k].RecordType);	
	Nscanf(&Record[1],4,"%d",&Type4s[k].Version);
	Ascanf(&Record[5],10,Type4s[k].Tlid);
	Ascanf(&Record[15],3,Type4s[k].Rtsq);
	Ascanf(&Record[18],8,Type4s[k].Feat1);
	Ascanf(&Record[26],8,Type4s[k].Feat2);
	Ascanf(&Record[34],8,Type4s[k].Feat3);
	Ascanf(&Record[42],8,Type4s[k].Feat4);
	Ascanf(&Record[50],8,Type4s[k].Feat5);
}
void Parse_Type7_Record(long k)
{
	Nscanf(Record,1,"%c",&Type7s[k].RecordType);
	Nscanf(&Record[1],4,"%d",&Type7s[k].Version);
	Ascanf(&Record[5],2,Type7s[k].State);
	Ascanf(&Record[7],3,Type7s[k].County);
	Nscanf(&Record[10],10,"%d",&Type7s[k].Land);
	Nscanf(&Record[20],1,"%c",&Type7s[k].Source);
	Ascanf(&Record[21],3,Type7s[k].Cfcc);
	Ascanf(&Record[24],30,Type7s[k].Laname);
	Ascanf(&Record[54],10,Type7s[k].Lalong);
	Ascanf(&Record[64],9,Type7s[k].Lalat);
	Nscanf(&Record[73],1,"%c",&Type7s[k].Filler);
}
void Parse_Type8_Record(long k)
{
	Nscanf(Record,1,"%c",&Type8s[k].RecordType);
	Nscanf(&Record[1],4,"%d",&Type8s[k].Version);
	Ascanf(&Record[5],2,Type8s[k].State);
	Ascanf(&Record[7],3,Type8s[k].County);
	Ascanf(&Record[10],5,Type8s[k].Cenid);
	Ascanf(&Record[15],10,Type8s[k].Polyid);
	Nscanf(&Record[25],10,"%d",&Type8s[k].Land);
	Nscanf(&Record[35],1,"%c",&Type8s[k].Filler);
}
void Parse_TypeA_Record(long k)
{
	int i;
	Nscanf(Record,1,"%c",&TypeAs[k].RecordType);
	Nscanf(&Record[1],4,"%d",&TypeAs[k].Version);
	Ascanf(&Record[5],2,TypeAs[k].State);
	Ascanf(&Record[7],3,TypeAs[k].County);
	Ascanf(&Record[10],5,TypeAs[k].Cenid);
	Ascanf(&Record[15],10,TypeAs[k].Polyid);
	Ascanf(&Record[25],5,TypeAs[k].Fair);
	Ascanf(&Record[30],5,TypeAs[k].Fmcd);
	Ascanf(&Record[35],5,TypeAs[k].Fpl);
	Ascanf(&Record[40],6,TypeAs[k].Ctbna90);
	if (TypeAs[k].Ctbna90[0] != ' ')
	{
		for (i=1; i < strlen(TypeAs[k].Ctbna90); i++)
		{
			if (TypeAs[k].Ctbna90[i] == ' ')
				TypeAs[k].Ctbna90[i] = '0';
		}
	}
	
	Ascanf(&Record[46],4,TypeAs[k].Blk90);
	Ascanf(&Record[50],2,TypeAs[k].Cd106);
	Ascanf(&Record[52],2,TypeAs[k].Cd108);
	Ascanf(&Record[54],5,TypeAs[k].Sdelm);
	if (TigerVersion < 97) //94 or 95
		Ascanf(&Record[59],5,TypeAs[k].Sdmid);
	if (TigerVersion == 98) // only in luca
		Ascanf(&Record[59],5,TypeAs[k].Ua00);  //luca
	Ascanf(&Record[64],5,TypeAs[k].Sdsec);
	Ascanf(&Record[69],5,TypeAs[k].Sduni);
	Ascanf(&Record[74],6,TypeAs[k].Taz);
	Ascanf(&Record[80],4,TypeAs[k].Ua90);
//	strcat(TypeAs[k].Ua90," ");
	TypeAs[k].Ua90[5] = '\0';
	Nscanf(&Record[84],1,"%c",&TypeAs[k].Urbflag);
	Ascanf(&Record[85],4,TypeAs[k].Ctpp);
	//Ascanf(&Record[89],9,TypeAs[k].Rs9); //out in luca
	if (TigerVersion >= 97)
	{
		Ascanf(&Record[89],2,TypeAs[k].State90);//luca
		Ascanf(&Record[91],3,TypeAs[k].County90);//luca
		Ascanf(&Record[94],4,TypeAs[k].Air90);//luca
	}
}	
void Parse_Type6_Record(long k)
{
	Nscanf(Record,1,"%c",&Type6s[k].RecordType);	
	Nscanf(&Record[1],4,"%d",&Type6s[k].Version);
	Ascanf(&Record[5],10,Type6s[k].Tlid);
	Ascanf(&Record[15],3,Type6s[k].Rtsq);
    Ascanf(&Record[18],11,Type6s[k].Fraddl);
    Ascanf(&Record[29],11,Type6s[k].Toaddl);
    Ascanf(&Record[40],11,Type6s[k].Fraddr);
    Ascanf(&Record[51],11,Type6s[k].Toaddr);
    Nscanf(&Record[62],1,"%d",&Type6s[k].Friaddl);
    Nscanf(&Record[63],1,"%d",&Type6s[k].Toiaddl);
    Nscanf(&Record[64],1,"%d",&Type6s[k].Friaddr);
    Nscanf(&Record[65],1,"%d",&Type6s[k].Toiaddr);
    Ascanf(&Record[66],5,Type6s[k].Zipl);
    Ascanf(&Record[71],5,Type6s[k].Zipr);
}
void Parse_TypeZ_Record(long k)
{
	Nscanf(Record,1,"%c",&TypeZs[k].RecordType);	
	Nscanf(&Record[1],4,"%d",&TypeZs[k].Version);
	Ascanf(&Record[5],10,TypeZs[k].Tlid);
	Ascanf(&Record[15],3,TypeZs[k].Rtsq);
	Ascanf(&Record[18],4,TypeZs[k].Zip4l);
	Ascanf(&Record[22],4,TypeZs[k].Zip4r);
}
void Parse_TypeS_Record(long k)
{
	int i;
	char tempsenate[4], temphouse[4];
	Nscanf(Record,1,"%c",&TypeSs[k].RecordType);
	Nscanf(&Record[1],4,"%d",&TypeSs[k].Version);
	Ascanf(&Record[5],2,TypeSs[k].State);
	Ascanf(&Record[7],3,TypeSs[k].County);
	Ascanf(&Record[10],5,TypeSs[k].Cenid);
	Ascanf(&Record[15],10,TypeSs[k].Polyid);
	Nscanf(&Record[25],1,"%d",&TypeSs[k].Water);
	Ascanf(&Record[26],4,TypeSs[k].Cmsamsa);
	Ascanf(&Record[30],4,TypeSs[k].Pmsa);
	Ascanf(&Record[34],5,TypeSs[k].Fair);
	Ascanf(&Record[39],4,TypeSs[k].Air);
	Nscanf(&Record[43],1,"%c",&TypeSs[k].Trust);
	Ascanf(&Record[44],2,TypeSs[k].Anrc);
	Ascanf(&Record[46],2,TypeSs[k].Statecu);
	Ascanf(&Record[48],3,TypeSs[k].Countycu);
	Ascanf(&Record[51],5,TypeSs[k].Fccity);
	Ascanf(&Record[56],5,TypeSs[k].Fmcd);
	Ascanf(&Record[61],5,TypeSs[k].Fsmcd);
	Ascanf(&Record[66],5,TypeSs[k].Fpl);
	if (TigerVersion == 98) //luca
	{
		Ascanf(&Record[71],6,TypeSs[k].Ctbna90);
		if (TypeSs[k].Ctbna90[0] != ' ')
		{
			for (i=1; i < strlen(TypeSs[k].Ctbna90); i++)
			{
				if (TypeSs[k].Ctbna90[i] == ' ')
					TypeSs[k].Ctbna90[i] = '0';
			}
		}

		Ascanf(&Record[77],4,TypeSs[k].Blk90);
		//Nscanf(&Record[81],1,"%c",&TypeSs[k].Rs10);
		Nscanf(&Record[81],1,"%c",&TypeSs[k].Tea); //luca
		Ascanf(&Record[82],2,TypeSs[k].Cdcu);
		Ascanf(&Record[84],3,tempsenate);
		sprintf(TypeSs[k].Stsenate,"%-3s   ",tempsenate); //new width in luca
		//strcat(TypeSs[k].Stsenate,"   ");
		Ascanf(&Record[87],3,temphouse);
		sprintf(TypeSs[k].Sthouse,"%-3s   ",temphouse);  //new width in luca
		//strcat(TypeSs[k].Sthouse,"   ");
		Ascanf(&Record[90],5,TypeSs[k].Census6);
		Ascanf(&Record[96],6,TypeSs[k].Vtd00);
	//Ascanf(&Record[102],6,TypeSs[k].Rs11);
		Ascanf(&Record[102],2,TypeSs[k].Statecol); //luca - start of key fields
		Ascanf(&Record[104],3,TypeSs[k].Councol); //luca
		Ascanf(&Record[107],5,TypeSs[k].Blkcol); //luca
		Nscanf(&Record[112],1,"%c",&TypeSs[k].Blksufcol); //luca
		Ascanf(&Record[113],5,TypeSs[k].Zcta); //empty in luca
	}
	else //Tiger 94-97
	{
		Ascanf(&Record[71],6,TypeSs[k].Ctbna90);
		if (TypeSs[k].Ctbna90[0] != ' ')
		{
			for (i=1; i < strlen(TypeSs[k].Ctbna90); i++)
			{
				if (TypeSs[k].Ctbna90[i] == ' ')
					TypeSs[k].Ctbna90[i] = '0';
			}
		}
		Ascanf(&Record[77],4,TypeSs[k].Blk90);
		Ascanf(&Record[82],2,TypeSs[k].Cdcu);
		Ascanf(&Record[84],6,TypeSs[k].Stsenate);
		Ascanf(&Record[90],6,TypeSs[k].Sthouse);
	}
	/*Nscanf(&Record[108],1,"%c",&TypeSs[k].Rs12);
	Ascanf(&Record[109],5,TypeSs[k].Rs13);
	Ascanf(&Record[114],5,TypeSs[k].Rs14);
	Nscanf(&Record[119],1,"%c",&TypeSs[k].Filler);*/
}
void Nscanf(char *source, int n, const char *format, void *target)
{
   char buffer[BUFFLEN];

   strncpy(buffer,source,n);
   buffer[n] = '\0';         
   
   
    if ((strlen(buffer) == 1) && (buffer[0] == ' '))
       strcpy(buffer,"0");
   
   if (sscanf(buffer,format,target) < 1)
       {
	   //char msg[200];
       //sprintf(msg, "Error: Numeric Conversion Failed On String %s\n Sent %sn", buffer, source);
	   //Ptrdlg->ErrorMessageStop(msg);
	   strcpy(buffer,"0");
       }
}
void Ascanf(char * source,int  n, char * target)
{
   int i;

   for (i = 0; i < n; i++)
      {
      target[i] = source[i];
      }
   target[n] = '\0';
}
int Compare1(RecordType1 * elem1, RecordType1 * elem2)
{
	return(strcmp(elem1->Tlid,elem2->Tlid));
}
int Compare1A(RecordType1 * elem1, RecordType1 * elem2)
{
	char buff1[12],buff2[12];
	sprintf(buff1,"%c%s",elem1->Cfcc[0],elem1->Tlid);
	sprintf(buff2,"%c%s",elem2->Cfcc[0],elem2->Tlid);
	return(strcmp(buff1,buff2));
}
int Compare2(RecordType2 * elem1, RecordType2 * elem2)
{
	char astring[14], bstring[14];
    sprintf(astring,"%10s%3s",elem1->Tlid,elem1->Rtsq);
    sprintf(bstring,"%10s%3s",elem2->Tlid,elem2->Rtsq);
    return (strcmp(astring,bstring));
}
int CompareNodes(Node_type * a, Node_type * b)
{    
     if (a->Longitude > b->Longitude)
        return 1;
     if (a->Longitude == b->Longitude)
        {if (a->Latitude > b->Latitude)
            return 1;
         if (a->Latitude == b->Latitude)
            return 0;
         return -1;
        }
     return -1;      
}
int Compare3(RecordType3 * elem1, RecordType3 * elem2)
{
	return(strcmp(elem1->Tlid,elem2->Tlid));
}
int CompareI(RecordTypeI * elem1, RecordTypeI * elem2)
{
	return(strcmp(elem1->Tlid,elem2->Tlid));
}
int Compare9(RecordType9 *elem1, RecordType9 *elem2)
{
	CString el1, el2;
	el1.Format("%s%s",elem1->Cenid,elem1->Polyid);
	el2.Format("%s%s",elem2->Cenid,elem2->Polyid);
	if (el1 > el2)
		return 1;
	if (el1 == el2)
		return 0;
	return -1;
	//return(strcmp(elem1->Polyid,elem2->Polyid));
	/*if (elem1->Polyid > elem2->Polyid)
		return 1;
	if (elem1->Polyid == elem2->Polyid)
		return 0;
	return -1;*/
}
int Compare5(RecordType5 *elem1, RecordType5 *elem2)
{
	return(strcmp(elem1->Feat, elem2->Feat));
}
int Compare8(RecordType8 *elem1, RecordType8 *elem2)
{
	CString el1, el2;
	el1.Format("%s%s",elem1->Cenid,elem1->Polyid);
	el2.Format("%s%s",elem2->Cenid,elem2->Polyid);
	if (el1 > el2)
		return 1;
	if (el1 == el2)
		return 0;
	return -1;
	//return(strcmp(elem1->Polyid, elem2->Polyid));
}
int CompareA(RecordTypeA *elem1, RecordTypeA *elem2)
{
	CString el1, el2;
	el1.Format("%s%s",elem1->Cenid,elem1->Polyid);
	el2.Format("%s%s",elem2->Cenid,elem2->Polyid);
	if (el1 > el2)
		return 1;
	if (el1 == el2)
		return 0;
	return -1;
	//return(strcmp(elem1->Polyid, elem2->Polyid));
}
int Compare7(RecordType7 *elem1, RecordType7 *elem2)
{
	if (elem1->Land > elem2->Land)
		return 1;
	if (elem1->Land == elem2->Land)
		return 0;
	return -1;
}
int Compare4(RecordType4 * elem1, RecordType4 * elem2)
{
	char astring[14], bstring[14];
    sprintf(astring,"%10s%3s",elem1->Tlid,elem1->Rtsq);
    sprintf(bstring,"%10s%3s",elem2->Tlid,elem2->Rtsq);
    return (strcmp(astring,bstring));	
}
int Compare6(RecordType6 * elem1, RecordType6 * elem2)
{
	char astring[14], bstring[14];
    sprintf(astring,"%10s%3s",elem1->Tlid,elem1->Rtsq);
    sprintf(bstring,"%10s%3s",elem2->Tlid,elem2->Rtsq);
    return (strcmp(astring,bstring));	
}
int CompareZ(RecordTypeZ * elem1, RecordTypeZ * elem2)
{
	char astring[14], bstring[14];
    sprintf(astring,"%10s%3s",elem1->Tlid,elem1->Rtsq);
    sprintf(bstring,"%10s%3s",elem2->Tlid,elem2->Rtsq);
    return (strcmp(astring,bstring));		
}
int CompareS(RecordTypeS *elem1, RecordTypeS *elem2)
{
	CString el1, el2;
	el1.Format("%s%s",elem1->Cenid,elem1->Polyid);
	el2.Format("%s%s",elem2->Cenid,elem2->Polyid);
	if (el1 > el2)
		return 1;
	if (el1 == el2)
		return 0;
	return -1;
}
int CompareCounty(County_Border_Type * elem1, County_Border_Type * elem2)
{
	return(strcmp(elem1->Id,elem2->Id));
}
int CompareTract(Tract_Border_Type * elem1, Tract_Border_Type * elem2)
{
	return(strcmp(elem1->Id,elem2->Id));
}
int CompareGroup(BlockGroup_Border_Type * elem1, BlockGroup_Border_Type * elem2)
{
	return(strcmp(elem1->Id,elem2->Id));
}
int CompareBlock(Block_Border_Type * elem1, Block_Border_Type * elem2)
{
	return(strcmp(elem1->Id,elem2->Id));
}
int CompareFmcd(Fmcd_Border_Type * elem1, Fmcd_Border_Type * elem2)
{
	return(strcmp(elem1->Id,elem2->Id));
}
int CompareFpl(Fpl_Border_Type * elem1, Fpl_Border_Type * elem2)
{
	return(strcmp(elem1->Id,elem2->Id));
}
int CompareAir(Air_Border_Type * elem1, Air_Border_Type * elem2)
{
	return(strcmp(elem1->Id,elem2->Id));
}
int CompareVote(Vote_Border_Type * elem1, Vote_Border_Type * elem2)
{
	return(strcmp(elem1->Id,elem2->Id));
}
int CompareAnrc(Anrc_Border_Type * elem1, Anrc_Border_Type * elem2)
{
	return(strcmp(elem1->Id,elem2->Id));
}
int CompareCollectionBlock(CollectionBlock_Border_Type * elem1, CollectionBlock_Border_Type * elem2)
{
	return(strcmp(elem1->Id,elem2->Id));
}

int CompareKgl(Kgl_Border_Type *elem1, Kgl_Border_Type * elem2)
{
	if (elem1->Polyid > elem2->Polyid)
		return 1;
	if (elem1->Polyid == elem2->Polyid)
		return 0;
	return -1;	
}
int CompareLand(Land_Border_Type *elem1, Land_Border_Type * elem2)
{
	if (elem1->Polyid > elem2->Polyid)
		return 1;
	if (elem1->Polyid == elem2->Polyid)
		return 0;
	return -1;	
}
int CompareTaz(Taz_Border_Type *elem1, Taz_Border_Type * elem2)
{
	CString tazctpp1, tazctpp2;
	tazctpp1.Format("%6s%4s",elem1->Taz,elem1->Ctpp);
	tazctpp2.Format("%6s%4s",elem2->Taz,elem2->Ctpp);
	if (tazctpp1 > tazctpp2)
		return 1;
	if (tazctpp1 == tazctpp2)
		return 0;
	else
		return -1;
}
int CompareUrb(Urban_Border_Type *elem1, Urban_Border_Type * elem2)
{
	/*CString urb1, urb2;
	urb1.Format("%4s%c",elem1->Uacode,elem1->Urbflag);
	urb2.Format("%4s%c",elem2->Uacode,elem2->Urbflag);
	if (urb1 > urb2)
		return 1;
	if (urb1 == urb2)
		return 0;
	else
		return -1;
		*/
	return strcmp(elem1->Uacode, elem2->Uacode);
}
int CompareWat(Water_Border_Type *elem1, Water_Border_Type *elem2)
{
	return strcmp(elem1->Water, elem2->Water);
}
int CompareElementary(Elementary_Border_Type * elem1, Elementary_Border_Type * elem2)
{
	return strcmp(elem1->Elementary, elem2->Elementary);
}
int CompareMiddle(Middle_Border_Type *elem1, Middle_Border_Type *elem2)
{
	return strcmp(elem1->Middle, elem2->Middle);
}
int CompareSecondary(Secondary_Border_Type *elem1, Secondary_Border_Type *elem2)
{
	return strcmp(elem1->Secondary, elem2->Secondary);
}
int CompareUnified(Unified_Border_Type  *elem1, Unified_Border_Type *elem2)
{
	return strcmp(elem1->Unified, elem2->Unified);
}
int CompareMsa(Cmsamsa_Border_Type *elem1, Cmsamsa_Border_Type *elem2)
{
	return strcmp(elem1->Cmsamsa, elem2->Cmsamsa);
}
int ComparePmsa(Pmsa_Border_Type *elem1, Pmsa_Border_Type *elem2)
{
	return strcmp(elem1->Pmsa, elem2->Pmsa);
}
int CompareCdcu(Cdcu_Border_Type *elem1, Cdcu_Border_Type *elem2)
{
	return strcmp(elem1->Cdcu, elem2->Cdcu);
}
int CompareHouse(State_House_Border_Type *elem1, State_House_Border_Type *elem2)
{
	return strcmp(elem1->House,elem2->House);
}
int CompareSenate(State_Senate_Border_Type *elem1, State_Senate_Border_Type *elem2)
{
	return strcmp(elem1->Senate,elem2->Senate);
}
int ComparePoly(Poly_Border_Type *elem1, Poly_Border_Type * elem2)
{
CString el1, el2;
	el1.Format("%s%s",elem1->Polyid,elem1->Cenid);
	el2.Format("%s%s",elem2->Polyid,elem2->Cenid);
	if (el1 > el2)
		return 1;
	if (el1 == el2)
		return 0;
	return -1;
}
int ComparePoly97(Poly_Border_Type97 *elem1, Poly_Border_Type97 * elem2)
{
CString el1, el2;
	el1.Format("%s%s",elem1->Polyid,elem1->Cenid);
	el2.Format("%s%s",elem2->Polyid,elem2->Cenid);
	if (el1 > el2)
		return 1;
	if (el1 == el2)
		return 0;
	return -1;
}

void Get_Shape_Points(char *lineid, int flip)
{             
	long upper, lower, halfway, position;
	int found, seqnum, i, count;
	Geographic_Coordinate *points;	
	CString info;

	lower = 0L;
	upper = Count2-1;   
	found = 0;      
	position = 0L;
	while (upper - lower > 0)
      {             
       //check for match at lower
       if (strcmp(Type2s[lower].Tlid,lineid) == 0)
          {//we have a match           
          position = lower;
          found = 1;
          break;
          }
       //if no match, try upper
       if (strcmp(Type2s[upper].Tlid,lineid) == 0)
          {//we have a match
          position = upper;
          found = 1;
          break;
          }
       //the following could happen if there are no shape points.
       if ((upper - lower) == 1) 
         break;
       //if no match, try halfway   
       halfway = (long)floor((upper + lower) / 2);      
       //check for match    
       if (strcmp(Type2s[halfway].Tlid,lineid) == 0)
          {//we have a match
          position = halfway;
          found = 1;
          break;
          }
       //no match, determine new search range
       if (strcmp(Type2s[halfway].Tlid,lineid) < 0)
          {
          lower = halfway;
          }
       else
          {
          upper = halfway;
          }
       }//close while on upper
   if (found == 0)           
   {   
	   return;
   }
  points = (Geographic_Coordinate *)calloc(MaxShapeRecords*10,sizeof(Geographic_Coordinate));	  
   //we have a match, need to find the first line
   sscanf(Type2s[position].Rtsq,"%d",&seqnum);
   while (seqnum > 1)
   {
     position--;
     seqnum--;
   } 
   if (strcmp(Type2s[position].Tlid,lineid) != 0)
   {
	 info.Format("ERROR - nonmatching Tlid values after sequence adjustment");
	 Ptrdlg->ErrorMessage(info);     
	 MissingFile = -1;
	 return;
   } 
   count  = 0; 
   while (strcmp(Type2s[position].Tlid,lineid) == 0)
   {                	 
		for (i = 0; i < 10; i++)
		{
			if (Type2s[position].Point[i].Longitude == 0.0)  //reached end of current line's shape points
				break;            
			points[count].Longitude = Type2s[position].Point[i].Longitude;
			points[count].Latitude = Type2s[position].Point[i].Latitude;				
			if (points[count].Longitude < CurrentMinX)
				CurrentMinX = points[count].Longitude;
			if (points[count].Longitude > CurrentMaxX)
				CurrentMaxX = points[count].Longitude;
			if (points[count].Latitude < CurrentMinY)
				CurrentMinY = points[count].Latitude;
			if (points[count].Latitude > CurrentMaxY)
				CurrentMaxY = points[count].Latitude;
				
			if (points[count].Longitude < FileMinX)
				FileMinX = points[count].Longitude;
			if (points[count].Longitude > FileMaxX)
				FileMaxX = points[count].Longitude;
			if (points[count].Latitude < FileMinY)
				FileMinY = points[count].Latitude;
			if (points[count].Latitude > FileMaxY)
				FileMaxY = points[count].Latitude;
			count++;                     
		 }          
		 position++;
		 if (position >= Count2)
			break;
     }                    
   
	if (flip == 1)
    {
		for (i = count-1; i >= 0; i--)
			Pts[Npts++] = points[i];
	}
	else
    {
		for (i = 0; i < count; i++)                                      
			Pts[Npts++] = points[i];
	}
	free(points);   
	return;
} 
void Build_Poly_Shape(char *type)
{
	FILE *polyshp, *polyshx, *ptstemp, *headtemp, *partstemp, *boxtemp;
	//FILE *chk;
	CString fname;
	int oldposition, nparts, recnum, sumpts;
	int *partnpts, i;
	shape_poly_t *curpoly;
	shape_header_t *polyshphead;
	shape_record_header_t *rechead;
	shape_index_record_t *curindex;
	CString errmsg;
	static int value;
	//chk = fopen("polychk.txt","w");
	Ptrdlg->m_strProcess.Format("Building polygons");
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	fname.Format("%s%s%s.shp",Outfilepath,Outfiletitle,type);		
	polyshp = fopen(fname,"wb");	
	if (polyshp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	fname.Format("%s%s%s.shx",Outfilepath,Outfiletitle,type);		
    polyshx = fopen(fname,"wb");
	if (polyshx == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}		
	ptstemp = fopen("pts.tmp","rb");
	if (ptstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}		
	headtemp = fopen("head.tmp","rb");
	if (headtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}		
	boxtemp = fopen("box.tmp","rb");
	if (boxtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}		
	partstemp = fopen("parts.tmp","rb");
	if (partstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	polyshphead = Create_Shape_Header(SHP_POLYGON);
	SHP_Write_Header(polyshp,polyshphead);
	SHP_Write_Header(polyshx,polyshphead); 		
	Position = 100; 
	oldposition = Position;
	recnum = 1;
	//CString repval;
	while (fread(&nparts,sizeof(int),1,partstemp) == 1)
	{
		partnpts = (int *)calloc(nparts,sizeof(int));	
		fread(partnpts,sizeof(int),nparts,headtemp);
		//fprintf(chk,"nparts = %d\n", nparts);
		sumpts = 0;
		for (i = 0; i < nparts; i++)
		{		
			sumpts += partnpts[i];
			//fprintf(chk,"partsnpts index %d, value %d\n",i,partnpts[i]);
		}
		rechead =(shape_record_header_t *)calloc(1,sizeof(shape_record_header_t));
		rechead->num = recnum;
		rechead->length = (4 + 32 + 4 + 4 + (4 * nparts) + (16 * sumpts) );			
		SHP_Write_Record_Header(polyshp,rechead);
		free(rechead);
		recnum++;
		curpoly = (shape_poly_t *)calloc(1,sizeof(shape_poly_t));
		curpoly->shapeType = SHP_POLYGON;
		fread(&curpoly->xMin,sizeof(double),1,boxtemp);
		fread(&curpoly->yMin,sizeof(double),1,boxtemp);
		fread(&curpoly->xMax,sizeof(double),1,boxtemp);
		fread(&curpoly->yMax,sizeof(double),1,boxtemp);
		curpoly->numParts = nparts;
		curpoly->numPoints = sumpts;
		curpoly->parts = (int *)calloc(nparts,sizeof(int ));
		curpoly->points = (point_t *)calloc(sumpts,sizeof(point_t));
		sumpts = 0;
		for (i = 0; i < nparts; i++)
		{
			if (i == 0)
				curpoly->parts[0] = 0;
			else
				curpoly->parts[i] = partnpts[i-1]+curpoly->parts[i-1];
			fread(&curpoly->points[sumpts],sizeof(point_t),partnpts[i],ptstemp);
			/*for (int j = 0; j < partnpts[i]; j++)
			{
				fprintf(chk,"part %d x = %lf y = %lf\n",i,curpoly->points[sumpts+j].x,
					curpoly->points[sumpts+j].y);
			}*/
			sumpts += partnpts[i];
		}
		
		free(partnpts);
		SHP_Write_Poly(polyshp,curpoly);		
		free(curpoly->parts);
		free(curpoly->points);
		free(curpoly);
		curindex = (shape_index_record_t *)calloc(1,sizeof(shape_index_record_t));
		curindex->offset = oldposition;
		curindex->length = Size;
		SHP_Write_Index(polyshx,curindex);
		free(curindex);
		oldposition = Position;
	}	
	//fclose(chk);
	polyshphead->fileLen = Position;
	polyshphead->xMin = FileMinX;
	polyshphead->yMin = FileMinY;
	polyshphead->xMax = FileMaxX;
	polyshphead->yMax = FileMaxY;
	rewind(polyshp);
	SHP_Write_Header(polyshp,polyshphead);
	polyshphead->fileLen = IPosition;
	rewind(polyshx);
	SHP_Write_Header(polyshx,polyshphead);
	fclose(polyshx);
	free(polyshphead);
	fclose(polyshp);
	fclose(boxtemp);
	fclose(ptstemp);
	fclose(headtemp);
	fclose(partstemp);		
	unlink("box.tmp");
	unlink("head.tmp");
	unlink("parts.tmp");
	unlink("pts.tmp");	
	
}
//census 2000
/*void Match_Poly_Lines_Tract2000()
{
	int polyid, found, i, nparts, ptcount;
	long num, n, written, curcase;
	Tract00_Border_Type *trt00;
	double  curX, curY;	
    FILE  *dbfout, *ptstemp, *headtemp, *partstemp, *boxtemp; 	
	CString info, fname;	
	char trt00record[32]; //size of fpl dbrecord + 2
	int steppos;
	char msg[100];		
	CString errmsg;

	
	if (Polycounts[7] == 0)
	{
		Ptrdlg->SetDlgItemText(IDC_TRACT00,"No Such Cases");		
		return;
	}
	
	fname.Format("%s%st00.dbf",Outfilepath,Outfiletitle);			
	dbfout = fopen(fname,"wb");
	if (dbfout == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	ptstemp = fopen("pts.tmp","wb");
	if (ptstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	headtemp = fopen("head.tmp","wb");
	if (headtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	boxtemp = fopen("box.tmp","wb");
	if (boxtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	partstemp = fopen("parts.tmp","wb");
	if (partstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	
    
	trt00 = (Tract00_Border_Type *)calloc(Polycounts[7],sizeof(Tract00_Border_Type));
	written = 0;
	for (num = 0; num < CountI; num++)
	{
		if (strcmp(TypeIs[num].Ctbna00l,TypeIs[num].Ctbna00r)== 0)
			continue;		
		
		if (strcmp(TypeIs[num].Ctbna00l,"      ") != 0)
			{//left case	
				sprintf(trt00[written].Id,"%s%s%s",TypeIs[num].State,TypeIs[num].County,TypeIs[num].Ctbna00l);				
				//sprintf(trt00[written].Id,"%6s",TypeIs[num].Ctbna00l);								
				sprintf(trt00[written].Tlid,"%s",TypeIs[num].Tlid);
				trt00[written].Frlong = Type1s[num].Frlong;
				trt00[written].Frlat = Type1s[num].Frlat;
				trt00[written].Tolong = Type1s[num].Tolong;
				trt00[written].Tolat = Type1s[num].Tolat;
				trt00[written].Chosen = 0;
				trt00[written].Flip = 1;
				written++;
			}
		if (strcmp(TypeIs[num].Ctbna00r, "      ") != 0)
			{//rightcase 
			//printf("\nright case");			
				sprintf(trt00[written].Id,"%s%s%s",TypeIs[num].State,TypeIs[num].County,TypeIs[num].Ctbna00r);				
				//sprintf(trt00[written].Id,"%6s",TypeIs[num].Ctbna00r);				
				sprintf(trt00[written].Tlid,"%s",TypeIs[num].Tlid);				
				trt00[written].Frlong = Type1s[num].Frlong;
				trt00[written].Frlat = Type1s[num].Frlat;
				trt00[written].Tolong = Type1s[num].Tolong;
				trt00[written].Tolat = Type1s[num].Tolat;
				trt00[written].Chosen = 0;
				trt00[written].Flip = 0;
				written++;
			}
	}	
	if (written > Polycounts[7])
	{
		Ptrdlg->ErrorMessage("the number of Tract 2000 border lines exceeds the count");				
		MissingFile = -1;
		return;
	}
	
	//time to chain	
	Ptrdlg->m_strProcess.Format("Gathering Tract 2000 Boundary Lines");
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	qsort((void *)trt00,written,sizeof(Tract00_Border_Type),(compfn)CompareTract);
	FileMinX = FileMinY = LARGE;
	FileMaxX = FileMaxY = -LARGE;
	CurrentMinX = CurrentMinY = LARGE;
	CurrentMaxX = CurrentMaxY = -LARGE;
	curcase = 0;
	polyid = 1;
	Npts = 0; 
	nparts = 1;
	ptcount = 0;
	Build_db_Header(dbfout,0,dbTract00);
	Build_db_FieldHeaders(dbfout,dbTract00);	
	char *tname;
	tname = (char *)calloc(12,sizeof(char));
	for (i = 0; i < 11; i++)
	{
		if (trt00[curcase].Id[i] != ' ')
			tname[i] = trt00[curcase].Id[i];
		else
			tname[i] = 0;
	}
	tname[11] = '\0';	
	trt00[curcase].Id[11] = '\0';
	//sprintf(trtrecord," %-8d%-5s%-6s",polyid,tract[curcase].Id,&tract[curcase].Id[5]);
	//sprintf(&trtrecord[20],"%-11s",tname);
	sprintf(trt00record," %-8d",polyid);
	sprintf(&trt00record[9],"%-5s",trt00[curcase].Id);
	sprintf(&trt00record[14],"%-6s",&trt00[curcase].Id[5]);
	sprintf(&trt00record[20],"%-11s",tname);

	
	free(tname);
	
	fwrite(&trt00record,sizeof(trt00record)-1,1,dbfout);
	if (trt00[0].Flip == 0)
	{
		curX = trt00[0].Tolong;
		curY = trt00[0].Tolat;		
		Pts[Npts].Longitude = trt00[curcase].Frlong;
		Pts[Npts].Latitude = trt00[curcase].Frlat;
		Npts++;
		Get_Shape_Points(trt00[curcase].Tlid, trt00[curcase].Flip);
		Pts[Npts].Longitude = trt00[curcase].Tolong;
		Pts[Npts].Latitude = trt00[curcase].Tolat;
		Npts++;
		trt00[curcase].Chosen = 1;		
	}
	else
	{
		curX = trt00[0].Frlong;
		curY = trt00[0].Frlat;		
		Pts[Npts].Longitude = trt00[curcase].Tolong;
		Pts[Npts].Latitude = trt00[curcase].Tolat;
		Npts++;
		Get_Shape_Points(trt00[curcase].Tlid, trt00[curcase].Flip);
		Pts[Npts].Longitude = trt00[curcase].Frlong;
		Pts[Npts].Latitude = trt00[curcase].Frlat;
		Npts++;
		trt00[curcase].Chosen = 1;		
	}
	ptcount += Npts;
	
    fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
	
	if (Pts[0].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < CurrentMinY)
		CurrentMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[0].Latitude;	
	if (Pts[0].Longitude < FileMinX)
		FileMinX = Pts[0].Longitude;
	if (Pts[0].Longitude > FileMaxX)
		FileMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < FileMinY)
		FileMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > FileMaxY)
		FileMaxY = Pts[0].Latitude;

	if (Pts[Npts-1].Longitude < CurrentMinX)
		CurrentMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < CurrentMinY)
		CurrentMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[Npts-1].Latitude;	
	if (Pts[Npts-1].Longitude < FileMinX)
		FileMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > FileMaxX)
		FileMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < FileMinY)
		FileMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > FileMaxY)
		FileMaxY = Pts[Npts-1].Latitude;		
	n = 1;
	steppos = (int)(n*100/written);	
	Ptrdlg->m_Progress.SetPos(steppos);
    while (n < written)
	{
		//printf("\n Have written %ld of %ld fpl boundary lines",n, written);
		sprintf(msg,"processed %d of %d records",n,written);
		Ptrdlg->SetDlgItemText(IDC_TRACT00,msg);		
		found = 0;
		for (i = 1; i < written; i++)
         {
			Npts = 0;
			if (trt00[i].Chosen != 0)
				continue;
			if (trt00[i].Flip == 0)
			{
				if ((trt00[i].Frlong == curX) && (trt00[i].Frlat == curY))
				{                          
					if (strcmp(trt00[i].Id,trt00[curcase].Id) != 0)
						continue;	            
					Get_Shape_Points(trt00[i].Tlid,trt00[i].Flip);
					Pts[Npts].Longitude = trt00[i].Tolong;
					Pts[Npts].Latitude = trt00[i].Tolat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					trt00[i].Chosen = 1;            
					found = 1;                      
					curX = trt00[i].Tolong;
					curY = trt00[i].Tolat;                
					curcase = i;
					break;
				}
			}
			else
			{
				if ((trt00[i].Tolong == curX) && (trt00[i].Tolat == curY))
				{
					if (strcmp(trt00[i].Id,trt00[curcase].Id) != 0)
						continue;	            
					Get_Shape_Points(trt00[i].Tlid,trt00[i].Flip);
					Pts[Npts].Longitude = trt00[i].Frlong;
					Pts[Npts].Latitude = trt00[i].Frlat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = trt00[i].Frlong;
					curY = trt00[i].Frlat;                        
					trt00[i].Chosen = 1;	
					found = 1;          
					curcase = i;
					break;
				}
			}
        }//close for loop
		if (found == 0) //initialize new case, eg, new ring or new poly
		{			
			fwrite(&ptcount,sizeof(int),1,headtemp);
			ptcount = 0;
			for (i = 0; i < written; i++) //check for new ring in poly
            {                    
         		if (trt00[i].Chosen != 0)
					continue;             		
				if (strcmp(trt00[i].Id, trt00[curcase].Id) != 0)
					continue;
				//if we get here it is a new ring in current poly
				found = 1;
				nparts++;
				Npts = 0;
				if (trt00[i].Flip == 0)
				{
					Pts[Npts].Longitude = trt00[i].Frlong;
					Pts[Npts].Latitude = trt00[i].Frlat;
					Npts++;
					Get_Shape_Points(trt00[i].Tlid,trt00[i].Flip);
					Pts[Npts].Longitude = trt00[i].Tolong;
					Pts[Npts].Latitude = trt00[i].Tolat;
					Npts++;			
    				n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					trt00[i].Chosen = 1;
    		   		curX = trt00[i].Tolong;
    				curY = trt00[i].Tolat;
					curcase = i;
					break;
				}
				else
				{
					Pts[Npts].Longitude = trt00[i].Tolong;
					Pts[Npts].Latitude = trt00[i].Tolat;
					Npts++;
					Get_Shape_Points(trt00[i].Tlid,trt00[i].Flip);
					Pts[Npts].Longitude = trt00[i].Frlong;
					Pts[Npts].Latitude = trt00[i].Frlat;
					Npts++;			
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					trt00[i].Chosen = 1;
    		   		curX = trt00[i].Frlong;
    				curY = trt00[i].Frlat;
					curcase = i;
					break;
				}
    		}
    	}
		if (found == 0) // new poly, first ring
		{
			
			fwrite(&nparts,sizeof(int),1,partstemp);
			nparts = 1;
			fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
			CurrentMinX = CurrentMinY = LARGE;
			CurrentMaxX = CurrentMaxY = -LARGE;

			for (i = 0; i < written; i++)//first check for new ring in current poly
            {                    
         		if (trt00[i].Chosen != 0)
					continue;             
				polyid++;				
				tname = (char *)calloc(12,sizeof(char));
				for (int j = 0; j < 11; j++)
				{
					if (trt00[i].Id[j] != ' ')
						tname[j] = trt00[i].Id[j];
					else
						tname[j] = 0;
				}
				tname[11] = '\0';
				trt00[i].Id[11] = '\0';
				sprintf(trt00record," %-8d",polyid);
				sprintf(&trt00record[9],"%-5s",trt00[i].Id);
				sprintf(&trt00record[14],"%-6s",&trt00[i].Id[5]);
				sprintf(&trt00record[20],"%-11s",tname);
				fwrite(&trt00record,sizeof(trt00record)-1,1,dbfout);    		
				free(tname);				
				Npts = 0;
				if (trt00[i].Flip == 0)
				{
					Pts[Npts].Longitude = trt00[i].Frlong;
					Pts[Npts].Latitude = trt00[i].Frlat;
					Npts++;
					Get_Shape_Points(trt00[i].Tlid,trt00[i].Flip);
					Pts[Npts].Longitude = trt00[i].Tolong;
					Pts[Npts].Latitude = trt00[i].Tolat;
					Npts++;					
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					trt00[i].Chosen = 1;            
					found = 1;                      
					curX = trt00[i].Tolong;
					curY = trt00[i].Tolat;                
					curcase = i;
					break;					
				}
				else
				{
					Pts[Npts].Longitude = trt00[i].Tolong;
					Pts[Npts].Latitude = trt00[i].Tolat;
					Npts++;
					Get_Shape_Points(trt00[i].Tlid,trt00[i].Flip);
					Pts[Npts].Longitude = trt00[i].Frlong;
					Pts[Npts].Latitude = trt00[i].Frlat;
					Npts++;				
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = trt00[i].Frlong;
					curY = trt00[i].Frlat;                        
					trt00[i].Chosen = 1;		
					found = 1;          
					curcase = i;	
					break;					
				}	
			}
		}
		//by now found should be 1
		if (found == 0)
		{
			info.Format("ERROR - found is zero");
			Ptrdlg->ErrorMessage(info);									
			MissingFile = -1;
			return;
		}
		ptcount += Npts;
		fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
		if (Pts[0].Longitude < CurrentMinX)
			CurrentMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < CurrentMinY)
			CurrentMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[0].Latitude;	
		if (Pts[0].Longitude < FileMinX)
			FileMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > FileMaxX)
			FileMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < FileMinY)
			FileMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > FileMaxY)
			FileMaxY = Pts[0].Latitude;

		if (Pts[Npts-1].Longitude < CurrentMinX)
			CurrentMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < CurrentMinY)
			CurrentMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[Npts-1].Latitude;	
		if (Pts[Npts-1].Longitude < FileMinX)
			FileMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > FileMaxX)
			FileMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < FileMinY)
			FileMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > FileMaxY)
			FileMaxY = Pts[Npts-1].Latitude;		
	}//close while loop
	fwrite(&ptcount,sizeof(int),1,headtemp);
	fwrite(&nparts,sizeof(int),1,partstemp);
	fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
	fclose(boxtemp);
	fclose(headtemp);
	fclose(ptstemp);
	fclose(partstemp);
	sprintf(msg,"processed %d of %d records",n,written);
	Ptrdlg->SetDlgItemText(IDC_TRACT00,msg);		
	//printf("\n Have written %ld of %ld fpl boundary lines",n, written);
	write_eof(dbfout);
	rewind(dbfout);
	Build_db_Header(dbfout,polyid,dbTract00);
	Build_Poly_Shape("t00");
	Ptrdlg->m_strAnrc.Format("%d Tract 2000",polyid);
	Ptrdlg->SetDlgItemText(IDC_TRACT00,Ptrdlg->m_strAnrc);
    fclose(dbfout);
	free(trt00);
	fprintf(LOG,"Wrote %d Tract 2000 polygons\n", polyid);		
}*/
/*
void Match_Poly_Lines_Block2000()
{
	int polyid, found, i, nparts, ptcount;
	long num, n, written, curcase;
	Block00_Border_Type *blk00;
	double  curX, curY;	
    FILE  *dbfout, *ptstemp, *headtemp, *partstemp, *boxtemp; 	
	CString info, fname;	
	char blk00record[40]; //size of blk00 dbrecord + 2
	int steppos;
	char msg[100];		
	CString errmsg;
	CString repval;
	
	if (Polycounts[8] == 0)
	{
		Ptrdlg->SetDlgItemText(IDC_BLOCK00,"No Such Cases");		
		return;
	}
	
	fname.Format("%s%sb00.dbf",Outfilepath,Outfiletitle);			
	dbfout = fopen(fname,"wb");
	if (dbfout == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	ptstemp = fopen("pts.tmp","wb");
	if (ptstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	headtemp = fopen("head.tmp","wb");
	if (headtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	boxtemp = fopen("box.tmp","wb");
	if (boxtemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	partstemp = fopen("parts.tmp","wb");
	if (partstemp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	
    
	blk00 = (Block00_Border_Type *)calloc(Polycounts[8],sizeof(Block00_Border_Type));
	
	written = 0;
	
	for (num = 0; num < CountI; num++)
	{
		
		if ((strcmp(TypeIs[num].Blk00l,TypeIs[num].Blk00r)== 0) &&
			(strcmp(TypeIs[num].Ctbna00l,TypeIs[num].Ctbna00r) == 0))
			continue;		
	
		if (strcmp(TypeIs[num].Blk00l,"    ") != 0)
			{//left case	
				sprintf(blk00[written].Id,"%s%s%s%s",TypeIs[num].State,TypeIs[num].County,
					TypeIs[num].Ctbna00l,TypeIs[num].Blk00l);				
				//sprintf(blk00[written].Id,"%6s",TypeIs[num].Ctbna00l);								
				sprintf(blk00[written].Tlid,"%s",TypeIs[num].Tlid);
				blk00[written].Frlong = Type1s[num].Frlong;
				blk00[written].Frlat = Type1s[num].Frlat;
				blk00[written].Tolong = Type1s[num].Tolong;
				blk00[written].Tolat = Type1s[num].Tolat;
				blk00[written].Chosen = 0;
				blk00[written].Flip = 1;
				written++;
			}
		if (strcmp(TypeIs[num].Blk00r, "    ") != 0)
			{//rightcase 
			//printf("\nright case");			
				sprintf(blk00[written].Id,"%s%s%s%s",TypeIs[num].State,TypeIs[num].County,
					TypeIs[num].Ctbna00r, TypeIs[num].Blk00r);				
				//sprintf(blk00[written].Id,"%6s",TypeIs[num].Ctbna00r);				
				sprintf(blk00[written].Tlid,"%s",TypeIs[num].Tlid);				
				blk00[written].Frlong = Type1s[num].Frlong;
				blk00[written].Frlat = Type1s[num].Frlat;
				blk00[written].Tolong = Type1s[num].Tolong;
				blk00[written].Tolat = Type1s[num].Tolat;
				blk00[written].Chosen = 0;
				blk00[written].Flip = 0;
				written++;
			}
	}
	
	if (written > Polycounts[8])
	{
		Ptrdlg->ErrorMessage("the number of Block 2000 border lines exceeds the count");				
		MissingFile = -1;
		return;
	}
	
	//time to chain	
	Ptrdlg->m_strProcess.Format("Gathering Block 2000 Boundary Lines");
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	
	qsort((void *)blk00,written,sizeof(Block00_Border_Type),(compfn)CompareBlock);
	FileMinX = FileMinY = LARGE;
	FileMaxX = FileMaxY = -LARGE;
	CurrentMinX = CurrentMinY = LARGE;
	CurrentMaxX = CurrentMaxY = -LARGE;
	curcase = 0;
	polyid = 1;
	Npts = 0; 
	nparts = 1;
	ptcount = 0;
	Build_db_Header(dbfout,0,dbBlock00);
	Build_db_FieldHeaders(dbfout,dbBlock00);	
	char *bname;
	bname = (char *)calloc(16,sizeof(char));
	for (i = 0; i < 15; i++)
	{
		if (blk00[curcase].Id[i] != ' ')
			bname[i] = blk00[curcase].Id[i];
		else
			bname[i] = 0;
	}
	bname[15] = '\0';	
	blk00[curcase].Id[15] = '\0';
	//sprintf(trtrecord," %-8d%-5s%-6s",polyid,tract[curcase].Id,&tract[curcase].Id[5]);
	//sprintf(&trtrecord[20],"%-11s",tname);
	sprintf(blk00record," %-8d",polyid);
	sprintf(&blk00record[9],"%-5s",blk00[curcase].Id);
	sprintf(&blk00record[14],"%-6s",&blk00[curcase].Id[5]);
	sprintf(&blk00record[20],"%-4s",&blk00[curcase].Id[11]);
	sprintf(&blk00record[24],"%-15s",bname);

	
	free(bname);
	
	fwrite(&blk00record,sizeof(blk00record)-1,1,dbfout);
	if (blk00[0].Flip == 0)
	{
		curX = blk00[0].Tolong;
		curY = blk00[0].Tolat;		
		Pts[Npts].Longitude = blk00[curcase].Frlong;
		Pts[Npts].Latitude = blk00[curcase].Frlat;
		Npts++;
		Get_Shape_Points(blk00[curcase].Tlid, blk00[curcase].Flip);
		Pts[Npts].Longitude = blk00[curcase].Tolong;
		Pts[Npts].Latitude = blk00[curcase].Tolat;
		Npts++;
		blk00[curcase].Chosen = 1;		
	}
	else
	{
		curX = blk00[0].Frlong;
		curY = blk00[0].Frlat;		
		Pts[Npts].Longitude = blk00[curcase].Tolong;
		Pts[Npts].Latitude = blk00[curcase].Tolat;
		Npts++;
		Get_Shape_Points(blk00[curcase].Tlid, blk00[curcase].Flip);
		Pts[Npts].Longitude = blk00[curcase].Frlong;
		Pts[Npts].Latitude = blk00[curcase].Frlat;
		Npts++;
		blk00[curcase].Chosen = 1;		
	}
	ptcount += Npts;
	
    fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
	
	if (Pts[0].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < CurrentMinY)
		CurrentMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[0].Latitude;	
	if (Pts[0].Longitude < FileMinX)
		FileMinX = Pts[0].Longitude;
	if (Pts[0].Longitude > FileMaxX)
		FileMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < FileMinY)
		FileMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > FileMaxY)
		FileMaxY = Pts[0].Latitude;

	if (Pts[Npts-1].Longitude < CurrentMinX)
		CurrentMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < CurrentMinY)
		CurrentMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[Npts-1].Latitude;	
	if (Pts[Npts-1].Longitude < FileMinX)
		FileMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > FileMaxX)
		FileMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < FileMinY)
		FileMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > FileMaxY)
		FileMaxY = Pts[Npts-1].Latitude;		
	n = 1;
	steppos = (int)(n*100/written);	
	Ptrdlg->m_Progress.SetPos(steppos);
    while (n < written)
	{
		//printf("\n Have written %ld of %ld fpl boundary lines",n, written);
		sprintf(msg,"processed %d of %d records",n,written);
		Ptrdlg->SetDlgItemText(IDC_BLOCK00,msg);		
		found = 0;
		for (i = 1; i < written; i++)
         {
			Npts = 0;
			if (blk00[i].Chosen != 0)
				continue;
			if (blk00[i].Flip == 0)
			{
				if ((blk00[i].Frlong == curX) && (blk00[i].Frlat == curY))
				{                          
					if (strcmp(blk00[i].Id,blk00[curcase].Id) != 0)
						continue;	            
					Get_Shape_Points(blk00[i].Tlid,blk00[i].Flip);
					Pts[Npts].Longitude = blk00[i].Tolong;
					Pts[Npts].Latitude = blk00[i].Tolat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					blk00[i].Chosen = 1;            
					found = 1;                      
					curX = blk00[i].Tolong;
					curY = blk00[i].Tolat;                
					curcase = i;
					break;
				}
			}
			else
			{
				if ((blk00[i].Tolong == curX) && (blk00[i].Tolat == curY))
				{
					if (strcmp(blk00[i].Id,blk00[curcase].Id) != 0)
						continue;	            
					Get_Shape_Points(blk00[i].Tlid,blk00[i].Flip);
					Pts[Npts].Longitude = blk00[i].Frlong;
					Pts[Npts].Latitude = blk00[i].Frlat;
					Npts++;
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = blk00[i].Frlong;
					curY = blk00[i].Frlat;                        
					blk00[i].Chosen = 1;	
					found = 1;          
					curcase = i;
					break;
				}
			}
        }//close for loop
		if (found == 0) //initialize new case, eg, new ring or new poly
		{			
			fwrite(&ptcount,sizeof(int),1,headtemp);
			ptcount = 0;
			for (i = 0; i < written; i++) //check for new ring in poly
            {                    
         		if (blk00[i].Chosen != 0)
					continue;             		
				if (strcmp(blk00[i].Id, blk00[curcase].Id) != 0)
					continue;
				//if we get here it is a new ring in current poly
				found = 1;
				nparts++;
				Npts = 0;
				if (blk00[i].Flip == 0)
				{
					Pts[Npts].Longitude = blk00[i].Frlong;
					Pts[Npts].Latitude = blk00[i].Frlat;
					Npts++;
					Get_Shape_Points(blk00[i].Tlid,blk00[i].Flip);
					Pts[Npts].Longitude = blk00[i].Tolong;
					Pts[Npts].Latitude = blk00[i].Tolat;
					Npts++;			
    				n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					blk00[i].Chosen = 1;
    		   		curX = blk00[i].Tolong;
    				curY = blk00[i].Tolat;
					curcase = i;
					break;
				}
				else
				{
					Pts[Npts].Longitude = blk00[i].Tolong;
					Pts[Npts].Latitude = blk00[i].Tolat;
					Npts++;
					Get_Shape_Points(blk00[i].Tlid,blk00[i].Flip);
					Pts[Npts].Longitude = blk00[i].Frlong;
					Pts[Npts].Latitude = blk00[i].Frlat;
					Npts++;			
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					blk00[i].Chosen = 1;
    		   		curX = blk00[i].Frlong;
    				curY = blk00[i].Frlat;
					curcase = i;
					break;
				}
    		}
    	}
		if (found == 0) // new poly, first ring
		{
			
			fwrite(&nparts,sizeof(int),1,partstemp);
			nparts = 1;
			fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
			CurrentMinX = CurrentMinY = LARGE;
			CurrentMaxX = CurrentMaxY = -LARGE;

			for (i = 0; i < written; i++)//first check for new ring in current poly
            {                    
         		if (blk00[i].Chosen != 0)
					continue;             
				polyid++;				
				bname = (char *)calloc(16,sizeof(char));
				for (int j = 0; j < 15; j++)
				{
					if (blk00[i].Id[j] != ' ')
						bname[j] = blk00[i].Id[j];
					else
						bname[j] = 0;
				}
				bname[15] = '\0';
				blk00[i].Id[15] = '\0';
				sprintf(blk00record," %-8d",polyid);
				sprintf(&blk00record[9],"%-5s",blk00[i].Id);
				sprintf(&blk00record[14],"%-6s",&blk00[i].Id[5]);
				sprintf(&blk00record[20],"%-4s",&blk00[i].Id[11]);
				sprintf(&blk00record[24],"%-15s",bname);
				free(bname);
				fwrite(&blk00record,sizeof(blk00record)-1,1,dbfout);
				Npts = 0;
				if (blk00[i].Flip == 0)
				{
					Pts[Npts].Longitude = blk00[i].Frlong;
					Pts[Npts].Latitude = blk00[i].Frlat;
					Npts++;
					Get_Shape_Points(blk00[i].Tlid,blk00[i].Flip);
					Pts[Npts].Longitude = blk00[i].Tolong;
					Pts[Npts].Latitude = blk00[i].Tolat;
					Npts++;					
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					blk00[i].Chosen = 1;            
					found = 1;                      
					curX = blk00[i].Tolong;
					curY = blk00[i].Tolat;                
					curcase = i;
					break;					
				}
				else
				{
					Pts[Npts].Longitude = blk00[i].Tolong;
					Pts[Npts].Latitude = blk00[i].Tolat;
					Npts++;
					Get_Shape_Points(blk00[i].Tlid,blk00[i].Flip);
					Pts[Npts].Longitude = blk00[i].Frlong;
					Pts[Npts].Latitude = blk00[i].Frlat;
					Npts++;				
					n++;
					steppos = (int)(n*100/written);	
					Ptrdlg->m_Progress.SetPos(steppos);
					curX = blk00[i].Frlong;
					curY = blk00[i].Frlat;                        
					blk00[i].Chosen = 1;		
					found = 1;          
					curcase = i;	
					break;					
				}	
			}
		}
		//by now found should be 1
		if (found == 0)
		{
			info.Format("ERROR - found is zero");
			Ptrdlg->ErrorMessage(info);									
			MissingFile = -1;
			return;
		}
		ptcount += Npts;
		fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
		if (Pts[0].Longitude < CurrentMinX)
			CurrentMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < CurrentMinY)
			CurrentMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[0].Latitude;	
		if (Pts[0].Longitude < FileMinX)
			FileMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > FileMaxX)
			FileMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < FileMinY)
			FileMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > FileMaxY)
			FileMaxY = Pts[0].Latitude;

		if (Pts[Npts-1].Longitude < CurrentMinX)
			CurrentMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < CurrentMinY)
			CurrentMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[Npts-1].Latitude;	
		if (Pts[Npts-1].Longitude < FileMinX)
			FileMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > FileMaxX)
			FileMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < FileMinY)
			FileMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > FileMaxY)
			FileMaxY = Pts[Npts-1].Latitude;		
	}//close while loop
	fwrite(&ptcount,sizeof(int),1,headtemp);
	fwrite(&nparts,sizeof(int),1,partstemp);
	fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
	fclose(boxtemp);
	fclose(headtemp);
	fclose(ptstemp);
	fclose(partstemp);
	sprintf(msg,"processed %d of %d records",n,written);
	Ptrdlg->SetDlgItemText(IDC_BLOCK00,msg);		
	//printf("\n Have written %ld of %ld fpl boundary lines",n, written);
	write_eof(dbfout);
	rewind(dbfout);
	Build_db_Header(dbfout,polyid,dbBlock00);
	Build_Poly_Shape("b00");
	Ptrdlg->m_strAnrc.Format("%d Block 2000",polyid);
	Ptrdlg->SetDlgItemText(IDC_BLOCK00,Ptrdlg->m_strAnrc);
    fclose(dbfout);
	free(blk00);
	fprintf(LOG,"Wrote %d Block 2000 polygons\n", polyid);		
}
*/
void Write_Line_Update(int i, int j, int k)
{
	switch (i)
	{
	case 0:
		if ((j == -1) && (k == -1))
		{
			Ptrdlg->SetDlgItemText(IDC_TYPEA,"No Such Cases");			
		}
		else
		{
			if (k == -1)
			{
				sprintf(MsgA,"%d Nodes",j);
				Ptrdlg->SetDlgItemText(IDC_TYPEA,MsgA);				
			}
			else
			{
				sprintf(MsgA,"%d Nodes, %d Lines", j, k);
				Ptrdlg->SetDlgItemText(IDC_TYPEA,MsgA);			
			}
		}
		break;
	case 1:
		if ((j == -1) && (k == -1))
		{
			Ptrdlg->SetDlgItemText(IDC_TYPEB,"No Such Cases");			
		}
		else
		{
			if (k == -1)
			{
				sprintf(MsgB,"%d Nodes",j);
				Ptrdlg->SetDlgItemText(IDC_TYPEB,MsgB);				
			}
			else
			{
				sprintf(MsgB,"%d Nodes, %d Lines", j, k);
				Ptrdlg->SetDlgItemText(IDC_TYPEB,MsgB);			
			}
		}
		break;
	case 2:
		if ((j == -1) && (k == -1))
		{
			Ptrdlg->SetDlgItemText(IDC_TYPEC,"No Such Cases");			
		}
		else
		{
			if (k == -1)
			{
				sprintf(MsgC,"%d Nodes",j);
				Ptrdlg->SetDlgItemText(IDC_TYPEC,MsgC);				
			}
			else
			{
				sprintf(MsgC,"%d Nodes, %d Lines", j, k);
				Ptrdlg->SetDlgItemText(IDC_TYPEC,MsgC);			
			}
		}
		break;
	case 3:
		if ((j == -1) && (k == -1))
		{
			Ptrdlg->SetDlgItemText(IDC_TYPED,"No Such Cases");			
		}
		else
		{
			if (k == -1)
			{
				sprintf(MsgD,"%d Nodes",j);
				Ptrdlg->SetDlgItemText(IDC_TYPED,MsgD);				
			}
			else
			{
				sprintf(MsgD,"%d Nodes, %d Lines", j, k);
				Ptrdlg->SetDlgItemText(IDC_TYPED,MsgD);			
			}
		}
		break;
	case 4:
		if ((j == -1) && (k == -1))
		{
			Ptrdlg->SetDlgItemText(IDC_TYPEE,"No Such Cases");			
		}
		else
		{
			if (k == -1)
			{
				sprintf(MsgE,"%d Nodes",j);
				Ptrdlg->SetDlgItemText(IDC_TYPEE,MsgE);				
			}
			else
			{
				sprintf(MsgE,"%d Nodes, %d Lines", j, k);
				Ptrdlg->SetDlgItemText(IDC_TYPEE,MsgE);			
			}
		}
		break;
	case 5:
		if ((j == -1) && (k == -1))
		{
			Ptrdlg->SetDlgItemText(IDC_TYPEF,"No Such Cases");			
		}
		else
		{
			if (k == -1)
			{
				sprintf(MsgF,"%d Nodes",j);
				Ptrdlg->SetDlgItemText(IDC_TYPEF,MsgF);				
			}
			else
			{
				sprintf(MsgF,"%d Nodes, %d Lines", j, k);
				Ptrdlg->SetDlgItemText(IDC_TYPEF,MsgF);			
			}
		}
		break;
	case 6:
		if ((j == -1) && (k == -1))
		{
			Ptrdlg->SetDlgItemText(IDC_TYPEH,"No Such Cases");			
		}
		else
		{
			if (k == -1)
			{
				sprintf(MsgH,"%d Nodes",j);
				Ptrdlg->SetDlgItemText(IDC_TYPEH,MsgH);				
			}
			else
			{
				sprintf(MsgH,"%d Nodes, %d Lines", j, k);
				Ptrdlg->SetDlgItemText(IDC_TYPEH,MsgH);			
			}
		}
		break;
	case 7:
		if ((j == -1) && (k == -1))
		{
			Ptrdlg->SetDlgItemText(IDC_TYPEX,"No Such Cases");			
		}
		else
		{
			if (k == -1)
			{
				sprintf(MsgX,"%d Nodes",j);
				Ptrdlg->SetDlgItemText(IDC_TYPEX,MsgX);				
			}
			else
			{
				sprintf(MsgX,"%d Nodes, %d Lines", j, k);
				Ptrdlg->SetDlgItemText(IDC_TYPEX,MsgX);			
			}
		}
		break;
	default:
		break;
	}

}
double Great_Circle_Distance(Geographic_Coordinate *p1, Geographic_Coordinate *p2)
{
	double			lon1 = RADIAN (p1->Longitude);
	double			lat1 = RADIAN (p1->Latitude);
	double			lon2 = RADIAN (p2->Longitude);
	double			lat2 = RADIAN (p2->Latitude);
	double			y;

	y = pow (sin ((lat1 - lat2) / 2.0), 2.0) +
		cos (lat1) * cos (lat2) *
		pow (sin ((lon1 - lon2) / 2.0), 2.0);
	y = pow (y, 0.5);
	y = asin (y) * 2.0 * RAD;
	y /= STATUS_MILE;
	return (y);
}
char * Get_TypeC_Name(int j, char *s, char *t)
{
	long num;
	int val;
	CString curcase;
	CString curcounty;
	CString repval;
	switch (j)
	{
	case 0: //state name
		for (num = 0; num < CountC; num++)
		{
			sscanf(TypeCs[num].Lasad,"%d",&val);
			if ((val == 1) && (strncmp(TypeCs[num].State,t,2) == 0))
				return TypeCs[num].Name;
		}
		break;
	case 1:
		for (num = 0; num < CountC; num++)
		{
			curcase.Format("%2s%3s",TypeCs[num].State,TypeCs[num].County);
			sscanf(TypeCs[num].Lasad,"%d",&val);
			if ((val >= 4) && (val <= 15))
			{
				if (strncmp(curcase,t,5) == 0)
					return TypeCs[num].Name;
			}
		}
		break;
	case 2: //fmcd
		for (num = 0; num < CountC; num++)
		{
			sscanf(TypeCs[num].Lasad,"%d",&val);
			curcase.Format("%2s%3s",TypeCs[num].State,TypeCs[num].County);
			if ((val >= 19) && (val <= 49))
				if ((strncmp(s,TypeCs[num].Fips,5) == 0) && (strncmp(curcase,t,5) == 0))
					return TypeCs[num].Name;
		}
		break;
	case 3: //fpl
		for (num = 0; num < CountC; num++)
		{
			sscanf(TypeCs[num].Lasad,"%d",&val);
			if ((val >= 55) && (val <= 62))
				if (strncmp(s,TypeCs[num].Fips,5) == 0)
					return TypeCs[num].Name;
		}
		break;
	case 4: //air
		for (num = 0; num < CountC; num++)
		{
			if (strncmp(s,TypeCs[num].Air,4) == 0)
					return TypeCs[num].Name;
		}
		break;
	case 5: 
		//changed for TIGER 97 -june 19
		if (TigerVersion < 97)
		{
			for (num = 0; num < CountC; num++)
			{
				if (strncmp(s,TypeCs[num].Anrc,2) == 0)
						return TypeCs[num].Name;
			}
			break;
		}
		else
			break;
	case 6: //votind districts -- because of different lengths we need to trim
		//the typeC values
		
		for (num = 0; num < CountC; num++)
		{
			curcase = TypeCs[num].Vtd;			
			curcase.TrimLeft();
			curcounty.Format("%2s%3s",TypeCs[num].State,TypeCs[num].County);
			if ((strncmp(s,curcase,4) == 0) && (strncmp(curcounty,t,5) == 0))
				return TypeCs[num].Name;
		}
		break;
	case 7: //urban areas -new june 19
		for (num = 0; num < CountC; num++)
		{
			if (strncmp(s,TypeCs[num].Ua,4) == 0)
			{				
				return TypeCs[num].Name;
			}
		}
		break;
	case 8: //new cmasmsa - new june 19
		if (TigerVersion < 97)
		{
			for (num = 0; num < CountC; num++)
			{
				curcase = TypeCs[num].Cmsamsa;
				curcase.TrimLeft();
				if (strncmp(s,curcase,4) == 0)
					return TypeCs[num].Name;
			}
		}
		else
		{ //Tiger 97 case
			for (num = 0; num < CountC; num++)
			{	
				
				int lasad;
				lasad = atoi(TypeCs[num].Lasad);
				if (TypeCs[num].Entity == 'J') 
					if ((lasad == 71) || (lasad == 72))					
					{
						curcase = TypeCs[num].Ma;
						curcase.TrimLeft();						
						if (strncmp(s,curcase,4) == 0)
							return TypeCs[num].Name;
					}
			}
		}
		break;
	case 9:
		if (TigerVersion < 97)
		{
			for (num = 0; num < CountC; num++)
			{
				curcase = TypeCs[num].Pmsa;
				curcase.TrimLeft();
				if (strncmp(s,curcase,4) == 0)
					return TypeCs[num].Name;
			}
		}
		else
		{ //Tiger 97 case
			for (num = 0; num < CountC; num++)
			{	
				int lasad;
				lasad = atoi(TypeCs[num].Lasad);
				if (TypeCs[num].Entity == 'J') 
					if (lasad == 73)				
					{
						curcase = TypeCs[num].Ma;
						curcase.TrimLeft();
						if (strncmp(s,curcase,4) == 0)
							return TypeCs[num].Name;
					}
			}
		}
		break;
	default:
		break;
	}
	return "";
}
int Get_Kgl(char *cenid, char * poly)
{
	int upper, lower, halfway, position;
	lower = 0;
	upper = Count9-1;   

	position = 0;
	CString msg;
	CString current, searchval;	
	searchval.Format("%s%s",cenid,poly);
	if (Count9 == 1)
	{
		current.Format("%s%s",Type9s[lower].Cenid,Type9s[lower].Polyid);
		if (current == searchval)
			return 0;
		else
			return -1;
	}
	while (upper - lower > 0)
      {             
       //check for match at lower
		current.Format("%s%s",Type9s[lower].Cenid,Type9s[lower].Polyid);
       //if (strcmp(poly,Type9s[lower].Polyid) == 0)
		if (current == searchval)
          {//we have a match           
          return lower;		   
          }
       //if no match, try upper
		current.Format("%s%s",Type9s[upper].Cenid,Type9s[upper].Polyid);
		if (current == searchval)
       //if (strcmp(poly,Type9s[upper].Polyid) == 0)
          {//we have a match
		   return upper;          
          }
       //the following could happen if there is no match
       if ((upper - lower) == 1) 
         return -1;
       //if no match, try halfway   
       halfway = (long)floor((upper + lower) / 2);      
       //check for match    
	   current.Format("%s%s",Type9s[halfway].Cenid,Type9s[halfway].Polyid);
       //if (strcmp(poly,Type9s[halfway].Polyid) == 0)
	   if (current == searchval)
          {//we have a match
		   return halfway;          
          }
       //no match, determine new search range
       //if (strcmp(Type9s[halfway].Polyid,poly) < 0)
	   if (current < searchval)
          {
          lower = halfway;
          }
       else
          {
          upper = halfway;
          }
       }//close while on upper - lower
	return -1;
}
int Get_Water(char *cenid, char * poly)
{
	int upper, lower, halfway, position;
	lower = 0;
	upper = CountS-1;   

	position = 0;
	CString msg;
	CString current, searchval;	
	searchval.Format("%s%s",cenid,poly);
	if (CountS == 1)
	{
		current.Format("%s%s",TypeSs[lower].Cenid,TypeSs[lower].Polyid);
		if (current == searchval)
			return 0;
		else
			return -1;
	}
	while (upper - lower > 0)
      {             
       //check for match at lower
		current.Format("%s%s",TypeSs[lower].Cenid,TypeSs[lower].Polyid);
       //if (strcmp(poly,Type9s[lower].Polyid) == 0)
		if (current == searchval)
          {//we have a match           
          return lower;		   
          }
       //if no match, try upper
		current.Format("%s%s",TypeSs[upper].Cenid,TypeSs[upper].Polyid);
		if (current == searchval)
       //if (strcmp(poly,Type9s[upper].Polyid) == 0)
          {//we have a match
		   return upper;          
          }
       //the following could happen if there is no match
       if ((upper - lower) == 1) 
         return -1;
       //if no match, try halfway   
       halfway = (long)floor((upper + lower) / 2);      
       //check for match    
	   current.Format("%s%s",TypeSs[halfway].Cenid,TypeSs[halfway].Polyid);
       //if (strcmp(poly,Type9s[halfway].Polyid) == 0)
	   if (current == searchval)
          {//we have a match
		   return halfway;          
          }
       //no match, determine new search range
       //if (strcmp(Type9s[halfway].Polyid,poly) < 0)
	   if (current < searchval)
          {
          lower = halfway;
          }
       else
          {
          upper = halfway;
          }
       }//close while on upper - lower
	return -1;
}

int Get_Feature(char *feat)
{
	int upper, lower, halfway, position;
	CString repval;
	lower = 0;
	upper = Count5-1;   

	position = 0;
	CString msg;
	
	
	if (Count5 == 1)
	{
		if (strcmp(feat,Type5s[lower].Feat) == 0)
			return lower;		   
        else
			return -1;
	}
	while (upper - lower > 0)
      {            	
       //check for match at lower
	
	   if (strcmp(feat,Type5s[lower].Feat) == 0)
          {//we have a match           
          return lower;		   
          }
       //if no match, try upper
	   
       if (strcmp(feat,Type5s[upper].Feat) == 0)
          {//we have a match
		   return upper;          
          }
       //the following could happen if there is no match
       if ((upper - lower) == 1) 
         return -1;
       //if no match, try halfway
	   
       halfway = (int)floor((upper + lower) / 2);      
       //check for match
	   
       if (strcmp(feat,Type5s[halfway].Feat) == 0)
          {//we have a match
		   return halfway;          
          }
       //no match, determine new search range
       if (strcmp(Type5s[halfway].Feat,feat) < 0)
          {
          lower = halfway;
          }
       else
          {
          upper = halfway;
          }
       }//close while on upper - lower
	return -1;
}
int Get_Land(char *cenid, char *poly)
{
	int upper, lower, halfway, position;
	lower = 0;
	upper = Count8-1;   

	position = 0;
	CString msg;
	CString current, searchval;	
	searchval.Format("%s%s",cenid,poly);
	if (Count8 == 1)
	{
		current.Format("%s%s",Type8s[lower].Cenid,Type8s[lower].Polyid);
		if (searchval == current)
			return 0;
		else
			return -1;
	}
	while (upper - lower > 0)
      {             
       //check for match at lower
		current.Format("%s%s",Type8s[lower].Cenid,Type8s[lower].Polyid);
       //if (strcmp(poly,Type8s[lower].Polyid) == 0)
		if (searchval == current)
          {//we have a match           
          return lower;		   
          }
       //if no match, try upper
		current.Format("%s%s",Type8s[upper].Cenid,Type8s[upper].Polyid);
       //if (strcmp(poly,Type8s[upper].Polyid) == 0)
		if (searchval == current)
          {//we have a match
		   return upper;          
          }
       //the following could happen if there is no match
       if ((upper - lower) == 1) 
         return -1;
       //if no match, try halfway   
       halfway = (long)floor((upper + lower) / 2);      
       //check for match    
		current.Format("%s%s",Type8s[halfway].Cenid,Type8s[halfway].Polyid);
       //if (strcmp(poly,Type8s[halfway].Polyid) == 0)
		if (searchval == current)
          {//we have a match
		   return halfway;          
          }
       //no match, determine new search range
       //if (strcmp(Type8s[halfway].Polyid,poly) < 0)
		if (current < searchval)
          {
          lower = halfway;
          }
       else
          {
          upper = halfway;
          }
       }//close while on upper - lower
	return -1;
}
int Get_Taz(char * cenid, char *poly)
{
	int upper, lower, halfway, position;
	lower = 0;
	upper = CountA-1;   
	CString current, searchval;	
	position = 0;
	CString msg;
	searchval.Format("%s%s",cenid,poly);
	if (CountA == 1)
	{
		current.Format("%s%s",TypeAs[lower].Cenid,TypeAs[lower].Polyid);
       	if (current == searchval)
			return 0;		   
		else
			return -1;
	}
	while (upper - lower > 0)
      { 
		current.Format("%s%s",TypeAs[lower].Cenid,TypeAs[lower].Polyid);
       //check for match at lower
       //if ((strcmp(poly,TypeAs[lower].Polyid) == 0) && (strcmp(cenid,TypsAs[lower].Cenid) == 0))
		if (current == searchval)
          {//we have a match           		   
          return lower;		   
          }
		current.Format("%s%s",TypeAs[upper].Cenid,TypeAs[upper].Polyid);
       //if no match, try upper
       //if ((strcmp(poly,TypeAs[upper].Polyid) == 0) && (strcmp(cenid,TypeAs[upper].Cenid) == 0))
		if (current == searchval)
          {//we have a match
		   return upper;          
          }
       //the following could happen if there is no match
       if ((upper - lower) == 1) 
         return -1;
       //if no match, try halfway   
       halfway = (long)floor((upper + lower) / 2);      
       //check for match    
	   current.Format("%s%s",TypeAs[halfway].Cenid,TypeAs[halfway].Polyid);
       //if ((strcmp(poly,TypeAs[halfway].Polyid) == 0)&&(strcmp(cenid,TypeAs[halfway].Cenid) == 0))
	   if (current == searchval)
          {//we have a match
		   return halfway;          
          }
       //no match, determine new search range
       //if (strcmp(TypeAs[halfway].Polyid,poly) < 0)
	   if (current < searchval)
          {
          lower = halfway;
          }
       else
          {
          upper = halfway;
          }
       }//close while on upper - lower
	return -1;
}

int Get_Land7(int curval)
{
	int upper, lower, halfway, position;
	lower = 0;
	upper = Count7-1;   

	position = 0;
	CString msg;
	if (Count7 == 1)
	{
		if (curval == Type7s[lower].Land)
			return 0;
		else
			return -1;
	}
	while (upper - lower > 0)
      {             
       //check for match at lower
       if (curval == Type7s[lower].Land)
          {//we have a match           
          return lower;		   
          }
       //if no match, try upper
       if (curval == Type7s[upper].Land)
          {//we have a match
		   return upper;          
          }
       //the following should not happen
       if ((upper - lower) == 1) 
         return -1;
       //if no match, try halfway   
       halfway = (long)floor((upper + lower) / 2);      
       //check for match    
       if (curval == Type7s[halfway].Land)
          {//we have a match
		   return halfway;          
          }
       //no match, determine new search range
       if (Type7s[halfway].Land < curval)
          {
          lower = halfway;
          }
       else
          {
          upper = halfway;
          }
       }//close while on upper - lower
	return -1;
}
void Build_Landmark_Nodes()
{
	int i;
	CString fname;
	char noderec[43];	
	FILE  *ndeatt;
//	char msg[50];
	//shape stuff
	FILE  *nodeshp, *nodeshx;
	shape_header_t  *nodeshphead;
	shape_record_header_t *rechead;
	shape_point_t *curnode;
	//int nparts; //always is one
	int oldposition;
	shape_index_record_t *curindex;	
	CString errmsg;	
	Landmark_Node_Type node;    
	
	if (Count7 == 0)
	{
		Ptrdlg->SetDlgItemText(IDC_LANDPTS,"No Such Cases");		
		return;
	}
	int count = 0;		
	for (i = 0; i < Count7; i++)
	{
		if (strcmp(Type7s[i].Lalong,"          ") == 0)
			continue;		
		if (count == 0)
		{ // first one, initialize files
			fname.Format("%s%slpt.shp",Outfilepath,Outfiletitle);				
			nodeshp = fopen(fname,"wb");
			if (nodeshp == NULL)
			{
				errmsg.Format("Could not open file %s",fname);
				Ptrdlg->ErrorMessage(errmsg);
				MissingFile = -1; return;
			}
			fname.Format("%s%slpt.shx",Outfilepath,Outfiletitle);				
			nodeshx = fopen(fname,"wb");
			if (nodeshx == NULL)
			{
				errmsg.Format("Could not open file %s",fname);
				Ptrdlg->ErrorMessage(errmsg);
				MissingFile = -1; return;
			}
			fname.Format("%s%slpt.dbf",Outfilepath,Outfiletitle);				
			ndeatt = fopen(fname,"wb");	
			if (ndeatt == NULL)
			{
				errmsg.Format("Could not open file %s",fname);
				Ptrdlg->ErrorMessage(errmsg);
				MissingFile = -1; return;
			}
			Build_db_Header(ndeatt,0L,dbLandmarkNode);
			Build_db_FieldHeaders(ndeatt,dbLandmarkNode);
			nodeshphead = Create_Shape_Header(SHP_POINT);
			SHP_Write_Header(nodeshp,nodeshphead);
			SHP_Write_Header(nodeshx,nodeshphead); 
			Position = 100; 
			oldposition = Position;
			FileMinX = FileMinY = LARGE;
			FileMaxX = FileMaxY = -LARGE;
		}
		count++;
		Nscanf(Type7s[i].Lalong,10,"%lf",&node.Longitude);
		Nscanf(Type7s[i].Lalat,9,"%lf",&node.Latitude);
		node.Longitude /= 1000000;
		node.Latitude /= 1000000;
		//we now have what we need to write the node shape entry
		curnode = (shape_point_t *)calloc(1,sizeof(shape_point_t));
		curnode->shapeType = 1;
		curnode->x = node.Longitude;
		curnode->y = node.Latitude;
		rechead =(shape_record_header_t *)calloc(1,sizeof(shape_record_header_t));
		rechead->num = count;
		rechead->length = SHPPOINTSIZE/2;
		SHP_Write_Record_Header(nodeshp,rechead);
		free(rechead);
		SHP_Write_Point(nodeshp,curnode);
		curindex = (shape_index_record_t *)calloc(1,sizeof(shape_index_record_t));
		curindex->offset = oldposition;
		curindex->length = Size;
		SHP_Write_Index(nodeshx,curindex);
		free(curindex);
		oldposition = Position;
		if (node.Longitude < FileMinX)
			FileMinX = node.Longitude;
		if (node.Longitude > FileMaxX)
			FileMaxX = node.Longitude;
		if (node.Latitude < FileMinY)
			FileMinY = node.Latitude;
		if (node.Latitude > FileMaxY)
			FileMaxY = node.Latitude;
		//sprintf(noderec," %-8d%-3s%-30s",count,Type7s[i].Cfcc,Type7s[i].Laname);		
		sprintf(noderec," %-8d",count);
		sprintf(&noderec[9],"%-3s",Type7s[i].Cfcc);
		sprintf(&noderec[12],"%-30s",Type7s[i].Laname);
		fwrite(noderec,sizeof(noderec)-1,1,ndeatt);
		Ptrdlg->m_strLandpts.Format("%d Landmark Points",count);
		Ptrdlg->SetDlgItemText(IDC_LANDPTS,Ptrdlg->m_strLandpts);
    
	}
	fprintf(LOG,"Wrote %d Landmark nodes to shape %s%slpt\n", count,Outfilepath,Outfiletitle);		
	if (count == 0)
	{
		Ptrdlg->SetDlgItemText(IDC_LANDPTS,"No Such Cases");		
		return;
	}
	if (count > 0)
	{
		write_eof(ndeatt);
		//rewind and rewrite node shape header, and index file
		rewind(nodeshp);
		nodeshphead->fileLen = Position;
		nodeshphead->xMin = FileMinX;
		nodeshphead->yMin = FileMinY;
		nodeshphead->xMax = FileMaxX;
		nodeshphead->yMax = FileMaxY;		
		//AfxMessageBox("here1");
		SHP_Write_Header(nodeshp,nodeshphead);
		nodeshphead->fileLen = IPosition;
		rewind(nodeshx);
		SHP_Write_Header(nodeshx,nodeshphead);
		free(nodeshphead);
		fclose(nodeshx);
		fclose(nodeshp);        
		rewind(ndeatt);
		Build_db_Header(ndeatt,count,dbLandmarkNode);
		fclose(ndeatt);		
	}
}
void Write_Alternate_Fenames()
{
	int i, indexval;
	FILE *dbfout;
	char altrecord[50];
	CString fname, errmsg;
	int count;
	fname.Format("%s%salt.dbf",Outfilepath,Outfiletitle);			
	dbfout = fopen(fname,"wb");
	if (dbfout == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = 2; return;
	}
	
	Build_db_Header(dbfout,0,dbAltnames);
	Build_db_FieldHeaders(dbfout,dbAltnames);
    count = 0;
	for (i = 0; i < Count4; i++)
	{
		indexval = atoi(Type4s[i].Feat1);
		if ((indexval > 0) && (indexval <= Count5))
			indexval--;
		else
			continue;
		sprintf(altrecord," %-10s%-2s%-30s%-4s%-2s\n",Type4s[i].Tlid, Type5s[indexval].Fedirp, Type5s[indexval].Fename,
			Type5s[indexval].Fetype, Type5s[indexval].Fedirs);
		count++;
		fwrite(&altrecord,sizeof(altrecord)-1,1,dbfout);
		indexval = atoi(Type4s[i].Feat2);
		if ((indexval > 0) && (indexval <= Count5))
			indexval--;
		else
			continue;
		sprintf(altrecord," %-10s%-2s%-30s%-4s%-2s\n",Type4s[i].Tlid, Type5s[indexval].Fedirp, Type5s[indexval].Fename,
			Type5s[indexval].Fetype, Type5s[indexval].Fedirs);
		count++;
		fwrite(&altrecord,sizeof(altrecord)-1,1,dbfout);
		indexval = atoi(Type4s[i].Feat3);
		if ((indexval > 0) && (indexval <= Count5))
			indexval--;
		else
			continue;
		sprintf(altrecord," %-10s%-2s%-30s%-4s%-2s\n",Type4s[i].Tlid, Type5s[indexval].Fedirp, Type5s[indexval].Fename,
			Type5s[indexval].Fetype, Type5s[indexval].Fedirs);
		count++;
		fwrite(&altrecord,sizeof(altrecord)-1,1,dbfout);
		indexval = atoi(Type4s[i].Feat4);
		if ((indexval > 0) && (indexval <= Count5))
			indexval--;
		else
			continue;
		sprintf(altrecord," %-10s%-2s%-30s%-4s%-2s\n",Type4s[i].Tlid, Type5s[indexval].Fedirp, Type5s[indexval].Fename,
			Type5s[indexval].Fetype, Type5s[indexval].Fedirs);
		count++;
		fwrite(&altrecord,sizeof(altrecord)-1,1,dbfout);
		indexval = atoi(Type4s[i].Feat5);
		if ((indexval > 0) && (indexval <= Count5))
			indexval--;
		else
			continue;
		sprintf(altrecord," %-10s%-2s%-30s%-4s%-2s\n",Type4s[i].Tlid, Type5s[indexval].Fedirp, Type5s[indexval].Fename,
			Type5s[indexval].Fetype, Type5s[indexval].Fedirs);
		count++;
		fwrite(&altrecord,sizeof(altrecord)-1,1,dbfout);
	}
	write_eof(dbfout);
	rewind(dbfout);
	Build_db_Header(dbfout,count,dbAltnames);
	fclose(dbfout);
	fprintf(LOG,"Wrote %d Alternate Feature Name records to file %s\n",count, fname);
}
void Write_Additional_Addresses(void)
{	
	int i;
	FILE *dbfout;
	char add2record[66];
	CString fname, errmsg;
	int count;
	
	fname.Format("%s%sadd2.dbf",Outfilepath,Outfiletitle);			
	dbfout = fopen(fname,"wb");
	if (dbfout == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	Build_db_Header(dbfout,0,dbAltaddresses);
	Build_db_FieldHeaders(dbfout,dbAltaddresses);
    count = 0;
	for (i = 0; i < Count6; i++)
	{
		sprintf(add2record," %-10s%-11s%-11s%-11s%-11s%-5s%-5s%",Type6s[i].Tlid,
			Type6s[i].Fraddl,Type6s[i].Toaddl,Type6s[i].Fraddr,Type6s[i].Toaddr,
			Type6s[i].Zipl,Type6s[i].Zipr);
		count++;
		fwrite(&add2record,sizeof(add2record)-1,1,dbfout);
	}	
	write_eof(dbfout);
	rewind(dbfout);
	Build_db_Header(dbfout,count,dbAltaddresses);	
	fclose(dbfout);
	fprintf(LOG,"Wrote %d Additional Address Information records to file %s\n",count, fname);
}
void Write_Additional_Zips(void)
{
	int i;
	FILE *dbfout;
	char zip4record[20];
	CString fname, errmsg;
	int count;
	
	fname.Format("%s%szip.dbf",Outfilepath,Outfiletitle);			
	dbfout = fopen(fname,"wb");
	
	if (dbfout == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}	
	Build_db_Header(dbfout,0,dbZip4s);
	Build_db_FieldHeaders(dbfout,dbZip4s);
    count = 0;
	for (i = 0; i < CountZ; i++)
	{
		sprintf(zip4record," %-10s%-4s%-4s%",TypeZs[i].Tlid,			
			TypeZs[i].Zip4l,TypeZs[i].Zip4r);
		count++;
		fwrite(&zip4record,sizeof(zip4record)-1,1,dbfout);
	}	
	write_eof(dbfout);
	rewind(dbfout);
	Build_db_Header(dbfout,count,dbZip4s);	
	fclose(dbfout);	
	fprintf(LOG,"Wrote %d Zip+4 records to file %s\n",count, fname);
}