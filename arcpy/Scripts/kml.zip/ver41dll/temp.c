void Build_Poly_Centroids()
{
	int i;
	FILE *nodeshp, *nodeshx, *ndeatt;
	shape_header_t *nodeshphead;
	shape_record_header_t *rechead;	
	shape_point_t *curnode;
	CString fname;
	int oldposition;
	char noderec[38];

	//end of declarations
    Ptrdlg->m_strLayer.Format("Polygon Centers");		
	Ptrdlg->SetDlgItemText(IDC_LAYER,Ptrdlg->m_strLayer);
	fname.Format("%s%scen.dbf",Outfilepath,Outfiletitle);				
	ndeatt = fopen(fname,"wb");			
	if (ndeatt == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	fname.Format("%s%scen.shp",Outfilepath,Outfiletitle);				
	nodeshp = fopen(fname,"wb");
	
	if (nodeshp == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	fname.Format("%s%scen.shx",Outfilepath,Outfiletitle);				
	nodeshx = fopen(fname,"wb");
	
	if (nodeshx == NULL)
	{
		errmsg.Format("Could not open file %s",fname);
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	Build_db_Header(ndeatt,CountP,dbCentroids);
	Build_db_FieldHeaders(ndeatt,dbCentroids);
	nodeshphead = Create_Shape_Header(SHP_POINT);
	SHP_Write_Header(nodeshp,nodeshphead);
    SHP_Write_Header(nodeshx,nodeshphead); 
	Position = 100; 
	oldposition = Position;
	FileMinX = FileMinY = LARGE;
	FileMaxX = FileMaxY = -LARGE;
		
	for (i = 0; i < CountP; i++)
	{
		sprintf(noderec," %-10s",TypePs[i].Polyid);
		sprintf(&noderec[11],"%-5s",TypePs[i].Cenid);
		sprintf(&noderec[16],"%11.6lf",TypePs[i].Centroid.Longitude);
		sprintf(&noderec[27],"%10.6lf",TypePs[i].Centroid.Latitude);
		fwrite(noderec,sizeof(noderec)-1,1,ndeatt);
		curnode = (shape_point_t *)calloc(1,sizeof(shape_point_t));
		curnode->shapeType = 1;
		curnode->x = TypePs[i].Centroid.Longitude;
		curnode->y = TypePs[i].Centroid.Latitude);
		rechead =(shape_record_header_t *)calloc(1,sizeof(shape_record_header_t));
		rechead->num = i+1;
		rechead->length = SHPPOINTSIZE/2;
		SHP_Write_Record_Header(nodeshp,rechead);
		free(rechead);
		SHP_Write_Point(nodeshp,curnode);
		free(curnode);		
		curindex = (shape_index_record_t *)calloc(1,sizeof(shape_index_record_t));
		curindex->offset = oldposition;
		curindex->length = Size;
		SHP_Write_Index(nodeshx,curindex);
		free(curindex);
		oldposition = Position;
		if (TypePs[i].Centroid.Longitude < FileMinX)
			FileMinX = TypePs[i].Centroid.Longitude;
		if (TypePs[i].Centroid.Longitude > FileMaxX)
			FileMaxX = TypePs[i].Centroid.Longitude;
		if (TypePs[i].Centroid.Latitude < FileMinY)
			FileMinY = TypePs[i].Centroid.Latitude;
		if (TypePs[i].Centroid.Latitude > FileMaxY)
			FileMaxY = TypePs[i].Centroid.Latitude;

	}
	fprintf(LOG,"Wrote %d Polygon Centroids to shape %s%scen \n", CountP,
			Outfilepath,Outfiletitle);		
		
	write_eof(ndeatt);
	//rewind and rewrite node shape header, and index file
	rewind(nodeshp);
	nodeshphead->fileLen = Position;
	nodeshphead->xMin = FileMinX;
	nodeshphead->yMin = FileMinY;
	nodeshphead->xMax = FileMaxX;
	nodeshphead->yMax = FileMaxY;		
	
	SHP_Write_Header(nodeshp,nodeshphead);
	nodeshphead->fileLen = IPosition;
	rewind(nodeshx);
	SHP_Write_Header(nodeshx,nodeshphead);
	free(nodeshphead);
	fclose(nodeshx);
		
	fclose(nodeshp);        
		
	//rewind(ndeatt);
	//Build_db_Header(ndeatt,CountP,dbCentroids);
	fclose(ndeatt);	

}


void Match_Poly_Lines_All100()
{
	int polyid, found, i, nparts, ptcount;
	long num, n, written, curcase;
	Poly_Border_Type100 *poly;
	double  curX, curY;	
    FILE  *dbftmp, *ptstemp, *headtemp, *partstemp, *boxtemp; 
	CString info, fname, errmsg;	
	char polyrecord[197]; //Tiger99
	int steppos;
//	char msg[100];
	long maxpolys;
	int bval;
//	int tazid;
	Ptrdlg->m_strProcess.Format("");		
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	Ptrdlg->m_Progress.SetPos(0);		
	Ptrdlg->m_strLayer.Format("");		
	Ptrdlg->SetDlgItemText(IDC_LAYER,Ptrdlg->m_strLayer);
	if ((AllACount == 0) && (AllSCount == 0))
	{
		errmsg.Format("No polygons to process");
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;		
	}	
	Ptrdlg->m_strProcess.Format("Gathering Boundary Lines");
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	Ptrdlg->m_Progress.SetPos(0);

	dbftmp = fopen("dbf.tmp","wb");
	if (dbftmp == NULL)
	{
		errmsg.Format("Could not open file dbf.tmp");
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}

	ptstemp = fopen("pts.tmp","wb");
	if (ptstemp == NULL)
	{
		errmsg.Format("Could not open file pts.tmp");
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	headtemp = fopen("head.tmp","wb");
	if (headtemp == NULL)
	{
		errmsg.Format("Could not open file head.tmp");
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	boxtemp = fopen("box.tmp","wb");
	if (boxtemp == NULL)
	{
		errmsg.Format("Could not open file box.tmp");
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	partstemp = fopen("parts.tmp","wb");
	if (partstemp == NULL)
	{
		errmsg.Format("Could not open file parts.tmp");
		Ptrdlg->ErrorMessage(errmsg);
		MissingFile = -1; return;
	}
	if (AllACount > AllSCount){
		poly = (Poly_Border_Type00 *)calloc(AllACount,sizeof(Poly_Border_Type00));	
		maxpolys = AllACount;
	}
	else{
		poly = (Poly_Border_Type00 *)calloc(AllSCount,sizeof(Poly_Border_Type00));	
		maxpolys = AllSCount;
	}
	written = 0;
	Ptrdlg->m_strLayer.Format("All Polygons");
	Ptrdlg->SetDlgItemText(IDC_LAYER,Ptrdlg->m_strLayer);	
	int aindexl, aindexr, sindexl, sindexr;
	for (num = 0; num < CountI; num++)
	{
		aindexl = TypeIAIndex[num].indexl;
		aindexr = TypeIAIndex[num].indexr;
		sindexl = TypeISIndex[num].indexl;
		sindexr = TypeISIndex[num].indexr;	

		steppos = (int)(num*100/CountI);	
		Ptrdlg->m_Progress.SetPos(steppos);	

//		fprintf(LOG,"left %s right %s\n",TypeIs[num].Polyidl, TypeIs[num].Polyidr);
		if ((strcmp(TypeIs[num].Polyidl,TypeIs[num].Polyidr)== 0)  &&
			(strcmp(TypeIs[num].Cenidl,TypeIs[num].Cenidr) == 0))
			continue;		
		if ((strcmp(TypeIs[num].Polyidl,"          ") != 0) &&
			((aindexl >= 0) || (sindexl >= 0)))
			{//left case				
				sprintf(poly[written].Polyid,"%s",TypeIs[num].Polyidl);
				sprintf(poly[written].Cenid,"%s",TypeIs[num].Cenidl);
				if (sindexl >= 0)
				{
					sprintf(poly[written].StateFile,"%2s",TypeSs[sindexl].State);				
					sprintf(poly[written].CountyFile,"%3s",TypeSs[sindexl].County);
					poly[written].Waterflag = TypeSs[sindexl].Water; //int
					sprintf(poly[written].Cmsamsa,"%4s",TypeSs[sindexl].Cmsamsa);
					sprintf(poly[written].Pmsa,"%4s",TypeSs[sindexl].Pmsa);
					sprintf(poly[written].AIANHH,"%5s",TypeSs[sindexl].Fair);
					sprintf(poly[written].AIANHHCE,"%4s",TypeSs[sindexl].Air);
					poly[written].Trust = TypeSs[sindexl].Trust; //char
					sprintf(poly[written].State00,"%2s",TypeSs[sindexl].Statecu);
					sprintf(poly[written].County00,"%3s",TypeSs[sindexl].Countycu);
					sprintf(poly[written].Concit,"%5s",TypeSs[sindexl].Fccity);	
					sprintf(poly[written].Cousub,"%5s",TypeSs[sindexl].Fmcd);
					sprintf(poly[written].Submcd,"%5s",TypeSs[sindexl].Fsmcd);
					sprintf(poly[written].Place,"%5s",TypeSs[sindexl].Fpl);
					sprintf(poly[written].Tract,"%6s",TypeSs[sindexl].Ctbna00);
					sprintf(poly[written].Block,"%4s",TypeSs[sindexl].Blk00);
					sprintf(poly[written].Cdcu,"%2s",TypeSs[sindexl].Cdcu);
					sprintf(poly[written].Sldu,"%6s",TypeSs[sindexl].Stsenate);
					sprintf(poly[written].Sldl,"%6s",TypeSs[sindexl].Sthouse);
					sprintf(poly[written].Uga,"%5s",TypeSs[sindexl].Uga);
					poly[written].Blkgrp = TypeSs[sindexl].Blkgrp; //char
					sprintf(poly[written].Vtd,"%6s",TypeSs[sindexl].Vtd00);
					sprintf(poly[written].Statecol,"%2s",TypeSs[sindexl].Statecol);
					sprintf(poly[written].Councol,"%3s",&TypeSs[sindexl].Councol);
					sprintf(poly[written].Blkcol,"%5s",TypeSs[sindexl].Blkcol);
					poly[written].Blksufcol = TypeSs[sindexl].Blksufcol; //char
					sprintf(poly[written].Zcta,"%5s",TypeSs[sindexl].Zcta);
				}
				else
				{
					sprintf(poly[written].StateFile,"  ");
					sprintf(poly[written].CountyFile,"   ");
					poly[written].Waterflag = 0;
					sprintf(poly[written].Cmsamsa,"    ");
					sprintf(poly[written].Pmsa,"    ");
					sprintf(poly[written].AIANHH,"     ");
					sprintf(poly[written].AIANHHCE,"    ");
					poly[written].Trust = ' ';
					sprintf(poly[written].State00,"  ");
					sprintf(poly[written].County00,"   ");
					sprintf(poly[written].Concit,"     ");
					sprintf(poly[written].Cousub,"     ");
					sprintf(poly[written].Submcd,"     ");
					sprintf(poly[written].Place,"     ");
					sprintf(poly[written].Tract,"      ");
					sprintf(poly[written].Block,"    ");
					sprintf(poly[written].Cdcu,"  ");
					sprintf(poly[written].Sldu,"      ");
					sprintf(poly[written].Sldl,"      ");
					sprintf(poly[written].Uga,"     ");
					poly[written].Blkgrp = ' ';
					sprintf(poly[written].Vtd,"      ");
					sprintf(poly[written].Statecol,"  ");
					sprintf(poly[written].Councol,"   ");
					sprintf(poly[written].Blkcol,"     ");
					poly[written].Blksufcol = ' ';
					sprintf(poly[written].Zcta,"     ");

				}
				if (aindexl >= 0)
				{
					fseek(atemp,(long)aindexl*sizeof(RecordTypeA),0);
					if (fread(&TypeAs,sizeof(RecordTypeA),1,atemp) != 1)
					{
						errmsg.Format("\nCannot read from temp file");
						Ptrdlg->ErrorMessage(errmsg);
						MissingFile = -1; return;			
					}	
					sprintf(poly[written].AIANHH90,"%5s",TypeAs.Fair);
					sprintf(poly[written].Cousub90,"%5s",TypeAs.Fmcd);
					sprintf(poly[written].Place90,"%5s",TypeAs.Fpl);
					sprintf(poly[written].Tract90,"%6s",TypeAs.Ctbna90);
					sprintf(poly[written].Block90,"%4s",TypeAs.Blk90);
					sprintf(poly[written].Cd106,"%2s",TypeAs.Cd106);
					sprintf(poly[written].Cd108,"%2s",TypeAs.Cd108);
					sprintf(poly[written].Sdelm,"%5s",TypeAs.Sdelm);					
					sprintf(poly[written].Sdsec,"%5s",TypeAs.Sdsec);
					sprintf(poly[written].Sduni,"%5s",TypeAs.Sduni);
					sprintf(poly[written].Taz,"%6s",TypeAs.Taz);
					sprintf(poly[written].Ua90,"%5s",TypeAs.Ua90);
					poly[written].UR90 = TypeAs.Urbflag;
					sprintf(poly[written].State90,"%2s",TypeAs.State90);
					sprintf(poly[written].Coun90,"%3s",TypeAs.County90);
					sprintf(poly[written].AIANHHCE90,"%4s",TypeAs.Air90);
				}
				else
				{
					sprintf(poly[written].AIANHH90,"     ");
					sprintf(poly[written].Cousub90,"     ");
					sprintf(poly[written].Place90,"     ");
					sprintf(poly[written].Tract90,"      ");
					sprintf(poly[written].Block90,"    ");
					sprintf(poly[written].Cd106,"  ");
					sprintf(poly[written].Cd108,"  ");
					sprintf(poly[written].Sdelm,"     ");					
					sprintf(poly[written].Sdsec,"     ");
					sprintf(poly[written].Sduni,"     ");
					sprintf(poly[written].Taz,"      ");
					sprintf(poly[written].Ua90,"     ");
					poly[written].UR90 = ' ';
					sprintf(poly[written].State90,"  ");
					sprintf(poly[written].Coun90,"   ");
					sprintf(poly[written].AIANHHCE90,"    ");
				}
				//now do type3s				
				sprintf(poly[written].Anrccu,"%3s",Type3s[num].Anrccul);
				sprintf(poly[written].Aits,"%5s",Type3s[num].Aitsl);
				sprintf(poly[written].Aitsce,"%3s",Type3s[num].Aitscel);
				//now finish off left record
				sprintf(poly[written].Tlid,"%s",TypeIs[num].Tlid);				
				poly[written].Frlong = Type1s[num].Frlong;
				poly[written].Frlat = Type1s[num].Frlat;
				poly[written].Tolong = Type1s[num].Tolong;
				poly[written].Tolat = Type1s[num].Tolat;
				poly[written].Chosen = 0;
				poly[written].Flip = 1;
				written++;
				
			}
		if ((strcmp(TypeIs[num].Polyidr, "          ") != 0) &&
			((aindexr >= 0) || (sindexr >= 0)))
			{//rightcase 
				sprintf(poly[written].Polyid,"%s",TypeIs[num].Polyidr);
				sprintf(poly[written].Cenid,"%s",TypeIs[num].Cenidr);
				if (sindexr >= 0)
				{
					sprintf(poly[written].StateFile,"%2s",TypeSs[sindexr].State);				
					sprintf(poly[written].CountyFile,"%3s",TypeSs[sindexr].County);
					poly[written].Waterflag = TypeSs[sindexr].Water; //int
					sprintf(poly[written].Cmsamsa,"%4s",TypeSs[sindexr].Cmsamsa);
					sprintf(poly[written].Pmsa,"%4s",TypeSs[sindexr].Pmsa);
					sprintf(poly[written].AIANHH,"%5s",TypeSs[sindexr].Fair);
					sprintf(poly[written].AIANHHCE,"%4s",TypeSs[sindexr].Air);
					poly[written].Trust = TypeSs[sindexr].Trust; //char
					sprintf(poly[written].State00,"%2s",TypeSs[sindexr].Statecu);
					sprintf(poly[written].County00,"%3s",TypeSs[sindexr].Countycu);
					sprintf(poly[written].Concit,"%5s",TypeSs[sindexr].Fccity);	
					sprintf(poly[written].Cousub,"%5s",TypeSs[sindexr].Fmcd);
					sprintf(poly[written].Submcd,"%5s",TypeSs[sindexr].Fsmcd);
					sprintf(poly[written].Place,"%5s",TypeSs[sindexr].Fpl);
					sprintf(poly[written].Tract,"%6s",TypeSs[sindexr].Ctbna00);
					sprintf(poly[written].Block,"%4s",TypeSs[sindexr].Blk00);
					sprintf(poly[written].Cdcu,"%2s",TypeSs[sindexr].Cdcu);
					sprintf(poly[written].Sldu,"%6s",TypeSs[sindexr].Stsenate);
					sprintf(poly[written].Sldl,"%6s",TypeSs[sindexr].Sthouse);
					sprintf(poly[written].Uga,"%5s",TypeSs[sindexr].Uga);
					poly[written].Blkgrp = TypeSs[sindexr].Blkgrp; //char
					sprintf(poly[written].Vtd,"%6s",TypeSs[sindexr].Vtd00);
					sprintf(poly[written].Statecol,"%2s",TypeSs[sindexr].Statecol);
					sprintf(poly[written].Councol,"%3s",&TypeSs[sindexr].Councol);
					sprintf(poly[written].Blkcol,"%5s",TypeSs[sindexr].Blkcol);
					poly[written].Blksufcol = TypeSs[sindexr].Blksufcol; //char
					sprintf(poly[written].Zcta,"%5s",TypeSs[sindexr].Zcta);
				}
				else
				{
					sprintf(poly[written].StateFile,"  ");
					sprintf(poly[written].CountyFile,"   ");
					poly[written].Waterflag = 0;
					sprintf(poly[written].Cmsamsa,"    ");
					sprintf(poly[written].Pmsa,"    ");
					sprintf(poly[written].AIANHH,"     ");
					sprintf(poly[written].AIANHHCE,"    ");
					poly[written].Trust = ' ';
					sprintf(poly[written].State00,"  ");
					sprintf(poly[written].County00,"   ");
					sprintf(poly[written].Concit,"     ");
					sprintf(poly[written].Cousub,"     ");
					sprintf(poly[written].Submcd,"     ");
					sprintf(poly[written].Place,"     ");
					sprintf(poly[written].Tract,"      ");
					sprintf(poly[written].Block,"    ");
					sprintf(poly[written].Cdcu,"  ");
					sprintf(poly[written].Sldu,"      ");
					sprintf(poly[written].Sldl,"      ");
					sprintf(poly[written].Uga,"     ");
					poly[written].Blkgrp = ' ';
					sprintf(poly[written].Vtd,"      ");
					sprintf(poly[written].Statecol,"  ");
					sprintf(poly[written].Councol,"   ");
					sprintf(poly[written].Blkcol,"     ");
					poly[written].Blksufcol = ' ';
					sprintf(poly[written].Zcta,"     ");

				}
				if (aindexr >= 0)
				{
					fseek(atemp,(long)aindexr*sizeof(RecordTypeA),0);
					if (fread(&TypeAs,sizeof(RecordTypeA),1,atemp) != 1)
					{
						errmsg.Format("\nCannot read from temp file");
						Ptrdlg->ErrorMessage(errmsg);
						MissingFile = -1; return;			
					}	
					sprintf(poly[written].AIANHH90,"%5s",TypeAs.Fair);
					sprintf(poly[written].Cousub90,"%5s",TypeAs.Fmcd);
					sprintf(poly[written].Place90,"%5s",TypeAs.Fpl);
					sprintf(poly[written].Tract90,"%6s",TypeAs.Ctbna90);
					sprintf(poly[written].Block90,"%4s",TypeAs.Blk90);
					sprintf(poly[written].Cd106,"%2s",TypeAs.Cd106);
					sprintf(poly[written].Cd108,"%2s",TypeAs.Cd108);
					sprintf(poly[written].Sdelm,"%5s",TypeAs.Sdelm);					
					sprintf(poly[written].Sdsec,"%5s",TypeAs.Sdsec);
					sprintf(poly[written].Sduni,"%5s",TypeAs.Sduni);
					sprintf(poly[written].Taz,"%6s",TypeAs.Taz);
					sprintf(poly[written].Ua90,"%5s",TypeAs.Ua90);
					poly[written].UR90 = TypeAs.Urbflag;
					sprintf(poly[written].State90,"%2s",TypeAs.State90);
					sprintf(poly[written].Coun90,"%3s",TypeAs.County90);
					sprintf(poly[written].AIANHHCE90,"%4s",TypeAs.Air90);
				}
				else
				{
					sprintf(poly[written].AIANHH90,"     ");
					sprintf(poly[written].Cousub90,"     ");
					sprintf(poly[written].Place90,"     ");
					sprintf(poly[written].Tract90,"      ");
					sprintf(poly[written].Block90,"    ");
					sprintf(poly[written].Cd106,"  ");
					sprintf(poly[written].Cd108,"  ");
					sprintf(poly[written].Sdelm,"     ");					
					sprintf(poly[written].Sdsec,"     ");
					sprintf(poly[written].Sduni,"     ");
					sprintf(poly[written].Taz,"      ");
					sprintf(poly[written].Ua90,"     ");
					poly[written].UR90 = ' ';
					sprintf(poly[written].State90,"  ");
					sprintf(poly[written].Coun90,"   ");
					sprintf(poly[written].AIANHHCE90,"    ");
				}
				//now do type3s				
				sprintf(poly[written].Anrccu,"%3s",Type3s[num].Anrccur;
				sprintf(poly[written].Aits,"%5s",Type3s[num].Aitsr;
				sprintf(poly[written].Aitsce,"%3s",Type3s[num].Aitscer;
				//now finish off left record
			
				sprintf(poly[written].Tlid,"%s",TypeIs[num].Tlid);				
				poly[written].Frlong = Type1s[num].Frlong;
				poly[written].Frlat = Type1s[num].Frlat;
				poly[written].Tolong = Type1s[num].Tolong;
				poly[written].Tolat = Type1s[num].Tolat;
				poly[written].Chosen = 0;
				poly[written].Flip = 0;
				written++;
				
			}
	}	
	if (written > maxpolys)
	{
		Ptrdlg->ErrorMessage("the number of polygon border lines exceeds the count");				
		MissingFile = -1;
		return;
	}
	
	Ptrdlg->m_strProcess.Format("Sorting Polygon Boundaries");
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	Ptrdlg->m_Progress.SetPos(0);
	qsort((void *)poly,written,sizeof(Poly_Border_Type100),(compfn)ComparePoly100);	

	FileMinX = FileMinY = LARGE;
	FileMaxX = FileMaxY = -LARGE;
	CurrentMinX = CurrentMinY = LARGE;
	CurrentMaxX = CurrentMaxY = -LARGE;
	curcase = 0;
	polyid = 1;
	Npts = 0; 
	nparts = 1;
	ptcount = 0;
	sprintf(polyrecord," %-10s",poly[curcase].Polyid);
	sprintf(&polyrecord[11],"%-5s",poly[curcase].Cenid);
	sprintf(&polyrecord[16],"%-2s",poly[curcase].State);
	sprintf(&polyrecord[18],"%-3s",poly[curcase].County);
	sprintf(&polyrecord[21],"%1d",poly[curcase].Waterflag);
	sprintf(&polyrecord[22],"%-4s",poly[curcase].Cmsamsa);
	sprintf(&polyrecord[26],"%-4s",poly[curcase].Pmsa);
	sprintf(&polyrecord[30],"%-5s",poly[curcase].Fair);
	sprintf(&polyrecord[35],"%-5s",poly[curcase].Air);
	sprintf(&polyrecord[40],"%c",poly[curcase].Trust);
	sprintf(&polyrecord[41],"%-2s",poly[curcase].State00);
	sprintf(&polyrecord[43],"%-3s",poly[curcase].County00);
	sprintf(&polyrecord[46],"%-5s",poly[curcase].Concit);
	sprintf(&polyrecord[51],"%-5s",poly[curcase].Cousub);
	sprintf(&polyrecord[56],"%-5s",poly[curcase].Submcd);
	sprintf(&polyrecord[61],"%-5s",poly[curcase].Place);
	sprintf(&polyrecord[66],"%-6s",poly[curcase].Tract);
	sprintf(&polyrecord[72],"%-4s",poly[curcase].Block);
	sprintf(&polyrecord[76],"%-2s",poly[curcase].Cdcu);
	sprintf(&polyrecord[78],"%-6s",poly[curcase].Sldu);
	sprintf(&polyrecord[84],"%-6s",poly[curcase].Sldl);
	sprintf(&polyrecord[90],"%-5s",poly[curcase].Uga);
	sprintf(&polyrecord[95],"%c",poly[curcase].Blkgrp);
	sprintf(&polyrecord[96],"%-6s",poly[curcase].Vtd);
	sprintf(&polyrecord[102],"%-2s",poly[curcase].Statecol);
	sprintf(&polyrecord[104],"%-3s",poly[curcase].Councol);
	sprintf(&polyrecord[107],"%-5s",poly[curcase].Blkcol);
	sprintf(&polyrecord[112],"%c",poly[curcase].Blksufcol);
	sprintf(&polyrecord[113],"%-5s",poly[curcase].Zcta);
	sprintf(&polyrecord[118],"%-5s",poly[curcase].AIANHH90);
	sprintf(&polyrecord[123],"%-5s",poly[curcase].Cousub90);
	sprintf(&polyrecord[128],"%-5s",poly[curcase].Place90);
	sprintf(&polyrecord[133],"%-6s",poly[curcase].Tract90);
	sprintf(&polyrecord[139],"%-4s",poly[curcase].Block90);
	sprintf(&polyrecord[143],"%-2s",poly[curcase].Cd106);
	sprintf(&polyrecord[145],"%-2s",poly[curcase].Cd108);
	sprintf(&polyrecord[147],"%-5s",poly[curcase].Sdelm);
	sprintf(&polyrecord[152],"%-5s",poly[curcase].Sdsec);
	sprintf(&polyrecord[157],"%-5s",poly[curcase].Sduni);
	sprintf(&polyrecord[162],"%-6s",poly[curcase].Taz);
	sprintf(&polyrecord[168],"%-5s",poly[curcase].Ua90);
	sprintf(&polyrecord[173],"%c",poly[curcase].UR90);
	sprintf(&polyrecord[174],"%-2s",poly[curcase].State90);
	sprintf(&polyrecord[176],"%-3s",poly[curcase].Coun90);
	sprintf(&polyrecord[179],"%-4s",poly[curcase].AIANHHCE90);
	sprintf(&polyrecord[183],"%-5s",poly[curcase].Anrccu);
	sprintf(&polyrecord[188],"%-3s",poly[curcase].Aitsce);
	sprintf(&polyrecord[191],"%-5s",poly[curcase].Aitsce);
	fwrite(&polyrecord,sizeof(polyrecord)-1,1,dbftmp);
	if (poly[0].Flip == 0)
	{
		curX = poly[0].Tolong;
		curY = poly[0].Tolat;		
		Pts[Npts].Longitude = poly[curcase].Frlong;
		Pts[Npts].Latitude = poly[curcase].Frlat;
		Npts++;
		Get_Shape_Points(poly[curcase].Tlid, poly[curcase].Flip);
		Pts[Npts].Longitude = poly[curcase].Tolong;
		Pts[Npts].Latitude = poly[curcase].Tolat;
		Npts++;
		poly[curcase].Chosen = 1;		
	}
	else
	{
		curX = poly[0].Frlong;
		curY = poly[0].Frlat;		
		Pts[Npts].Longitude = poly[curcase].Tolong;
		Pts[Npts].Latitude = poly[curcase].Tolat;
		Npts++;
		Get_Shape_Points(poly[curcase].Tlid, poly[curcase].Flip);
		Pts[Npts].Longitude = poly[curcase].Frlong;
		Pts[Npts].Latitude = poly[curcase].Frlat;
		Npts++;
		poly[curcase].Chosen = 1;		
	}
	ptcount += Npts;
	
    fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
	
	if (Pts[0].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < CurrentMinY)
		CurrentMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[0].Latitude;	
	if (Pts[0].Longitude < FileMinX)
		FileMinX = Pts[0].Longitude;
	if (Pts[0].Longitude > FileMaxX)
		FileMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < FileMinY)
		FileMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > FileMaxY)
		FileMaxY = Pts[0].Latitude;

	if (Pts[Npts-1].Longitude < CurrentMinX)
		CurrentMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < CurrentMinY)
		CurrentMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[Npts-1].Latitude;	
	if (Pts[Npts-1].Longitude < FileMinX)
		FileMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > FileMaxX)
		FileMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < FileMinY)
		FileMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > FileMaxY)
		FileMaxY = Pts[Npts-1].Latitude;		
	n = 1;
//	steppos = (int)(n*100/written);	
//	Ptrdlg->m_Progress.SetPos(steppos);	
	Ptrdlg->m_strProcess.Format("Building Polygons");
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	steppos = (int)(n*100/written);	
	Ptrdlg->m_Progress.SetPos(steppos);	
	bval = 1;
	CString el1, el2;
    while (n < written)
	{		
		found = 0;
		while (bval > 1)
		{
			el1.Format("%s%s",poly[bval].Polyid,poly[bval].Cenid);
			el2.Format("%s%s",poly[curcase].Polyid,poly[curcase].Cenid);
			if (strcmp(el1, el2) >= 0)
				bval--;
			else
				break;			
		}
		for (i = bval; i < written; i++)
         {
			Npts = 0;
			if (poly[i].Chosen != 0)
				continue;
			el1.Format("%s%s",poly[i].Polyid,poly[i].Cenid);
			el2.Format("%s%s",poly[curcase].Polyid,poly[curcase].Cenid);
			if (strcmp(el1,el2) > 0)
			{
				bval = i;
				break;
			}
			if (strcmp(poly[i].Polyid,poly[curcase].Polyid) != 0)
				continue;	            
			if (strcmp(poly[i].Cenid,poly[curcase].Cenid) != 0)
				continue;
	
			if (poly[i].Flip == 0)
			{
				if ((poly[i].Frlong == curX) && (poly[i].Frlat == curY))
				{                          
					Get_Shape_Points(poly[i].Tlid,poly[i].Flip);
					Pts[Npts].Longitude = poly[i].Tolong;
					Pts[Npts].Latitude = poly[i].Tolat;
					Npts++;
					n++;
					//steppos = (int)(n*100/written);	
					//Ptrdlg->m_Progress.SetPos(steppos);
					poly[i].Chosen = 1;            
					found = 1;                      
					curX = poly[i].Tolong;
					curY = poly[i].Tolat;                
					curcase = i;
					break;
				}
			}
			else
			{
				if ((poly[i].Tolong == curX) && (poly[i].Tolat == curY))
				{
		//			if (strcmp(poly[i].Polyid,poly[curcase].Polyid) != 0)
		//				continue;	            
		//			if (strcmp(poly[i].Cenid,poly[curcase].Cenid) != 0)
		//				continue;
					Get_Shape_Points(poly[i].Tlid,poly[i].Flip);
					Pts[Npts].Longitude = poly[i].Frlong;
					Pts[Npts].Latitude = poly[i].Frlat;
					Npts++;
					n++;
					//steppos = (int)(n*100/written);	
					//Ptrdlg->m_Progress.SetPos(steppos);
					curX = poly[i].Frlong;
					curY = poly[i].Frlat;                        
					poly[i].Chosen = 1;	
					found = 1;          
					curcase = i;
					break;
				}
			}
        }//close for loop
		if (found == 0) //initialize new case, eg, new ring or new poly
		{			
			fwrite(&ptcount,sizeof(int),1,headtemp);
			ptcount = 0;
			while (bval > 1)
			{
				el1.Format("%s%s",poly[bval].Polyid,poly[bval].Cenid);
				el2.Format("%s%s",poly[curcase].Polyid,poly[curcase].Cenid);
				if (strcmp(el1, el2) >= 0)
					bval--;
				else
					break;			
			}
			for (i = bval; i < written; i++) //check for new ring in poly
            {                    
         		if (poly[i].Chosen != 0)
					continue;    
				el1.Format("%s%s",poly[i].Polyid,poly[i].Cenid);
				el2.Format("%s%s",poly[curcase].Polyid,poly[curcase].Cenid);
				if (strcmp(el1, el2) > 0)
					break;
				if (strcmp(poly[i].Polyid,poly[curcase].Polyid) != 0)
					continue;	            
				if (strcmp(poly[i].Cenid,poly[curcase].Cenid) != 0)
					continue;
				//if we get here it is a new ring in current poly
				found = 1;
				nparts++;
				Npts = 0;
				if (poly[i].Flip == 0)
				{
					Pts[Npts].Longitude = poly[i].Frlong;
					Pts[Npts].Latitude = poly[i].Frlat;
					Npts++;
					Get_Shape_Points(poly[i].Tlid,poly[i].Flip);
					Pts[Npts].Longitude = poly[i].Tolong;
					Pts[Npts].Latitude = poly[i].Tolat;
					Npts++;			
    				n++;
					//steppos = (int)(n*100/written);	
					//Ptrdlg->m_Progress.SetPos(steppos);
					poly[i].Chosen = 1;
    		   		curX = poly[i].Tolong;
    				curY = poly[i].Tolat;
					curcase = i;
					break;
				}
				else
				{
					Pts[Npts].Longitude = poly[i].Tolong;
					Pts[Npts].Latitude = poly[i].Tolat;
					Npts++;
					Get_Shape_Points(poly[i].Tlid,poly[i].Flip);
					Pts[Npts].Longitude = poly[i].Frlong;
					Pts[Npts].Latitude = poly[i].Frlat;
					Npts++;			
					n++;
					//steppos = (int)(n*100/written);	
					//Ptrdlg->m_Progress.SetPos(steppos);
					poly[i].Chosen = 1;
    		   		curX = poly[i].Frlong;
    				curY = poly[i].Frlat;
					curcase = i;
					break;
				}
    		}
    	}
		if (found == 0) // new poly, first ring
		{
			
			fwrite(&nparts,sizeof(int),1,partstemp);
			nparts = 1;
			fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
			CurrentMinX = CurrentMinY = LARGE;
			CurrentMaxX = CurrentMaxY = -LARGE;
			while (bval > 1)
			{
				el1.Format("%s%s",poly[bval].Polyid,poly[bval].Cenid);
				el2.Format("%s%s",poly[curcase].Polyid,poly[curcase].Cenid);
				if (strcmp(el1, el2) >= 0)
					bval--;
				else
					break;			
			}
			for (i = bval; i < written; i++)//first check for new ring in current poly
            {                    
         		if (poly[i].Chosen != 0)
					continue;             
				polyid++;
				//sprintf(tazrecord," %-8d%-5s%-6s",polyid,taz[i].County,taz[i].Taz);					
				//sprintf(&tazrecord[20],"%-4s",taz[i].Ctpp);	
				sprintf(polyrecord," %-10s",poly[i].Polyid);
				sprintf(&polyrecord[11],"%-5s",poly[i].Cenid);
				sprintf(&polyrecord[16],"%-2s",poly[i].State);
				sprintf(&polyrecord[18],"%-3s",poly[i].County);
				sprintf(&polyrecord[21],"%1d",poly[i].Waterflag);
				sprintf(&polyrecord[22],"%-4s",poly[i].Cmsamsa);
				sprintf(&polyrecord[26],"%-4s",poly[i].Pmsa);
				sprintf(&polyrecord[30],"%-5s",poly[i].Fair);
				sprintf(&polyrecord[35],"%-5s",poly[i].Air);
				sprintf(&polyrecord[40],"%c",poly[i].Trust);
				sprintf(&polyrecord[41],"%-2s",poly[i].State00);
				sprintf(&polyrecord[43],"%-3s",poly[i].County00);
				sprintf(&polyrecord[46],"%-5s",poly[i].Concit);
				sprintf(&polyrecord[51],"%-5s",poly[i].Cousub);
				sprintf(&polyrecord[56],"%-5s",poly[i].Submcd);
				sprintf(&polyrecord[61],"%-5s",poly[i].Place);
				sprintf(&polyrecord[66],"%-6s",poly[i].Tract);
				sprintf(&polyrecord[72],"%-4s",poly[i].Block);
				sprintf(&polyrecord[76],"%-2s",poly[i].Cdcu);
				sprintf(&polyrecord[78],"%-6s",poly[i].Sldu);
				sprintf(&polyrecord[84],"%-6s",poly[i].Sldl);
				sprintf(&polyrecord[90],"%-5s",poly[i].Uga);
				sprintf(&polyrecord[95],"%c",poly[i].Blkgrp);
				sprintf(&polyrecord[96],"%-6s",poly[i].Vtd);
				sprintf(&polyrecord[102],"%-2s",poly[i].Statecol);
				sprintf(&polyrecord[104],"%-3s",poly[i].Councol);
				sprintf(&polyrecord[107],"%-5s",poly[i].Blkcol);
				sprintf(&polyrecord[112],"%c",poly[i].Blksufcol);
				sprintf(&polyrecord[113],"%-5s",poly[i].Zcta);
				sprintf(&polyrecord[118],"%-5s",poly[i].AIANHH90);
				sprintf(&polyrecord[123],"%-5s",poly[i].Cousub90);
				sprintf(&polyrecord[128],"%-5s",poly[i].Place90);
				sprintf(&polyrecord[133],"%-6s",poly[i].Tract90);
				sprintf(&polyrecord[139],"%-4s",poly[i].Block90);
				sprintf(&polyrecord[143],"%-2s",poly[i].Cd106);
				sprintf(&polyrecord[145],"%-2s",poly[i].Cd108);
				sprintf(&polyrecord[147],"%-5s",poly[i].Sdelm);
				sprintf(&polyrecord[152],"%-5s",poly[i].Sdsec);
				sprintf(&polyrecord[157],"%-5s",poly[i].Sduni);
				sprintf(&polyrecord[162],"%-6s",poly[i].Taz);
				sprintf(&polyrecord[168],"%-5s",poly[i].Ua90);
				sprintf(&polyrecord[173],"%c",poly[i].UR90);
				sprintf(&polyrecord[174],"%-2s",poly[i].State90);
				sprintf(&polyrecord[176],"%-3s",poly[i].Coun90);
				sprintf(&polyrecord[179],"%-4s",poly[i].AIANHHCE90);
				sprintf(&polyrecord[183],"%-5s",poly[i].Anrccu);
				sprintf(&polyrecord[188],"%-3s",poly[i].Aitsce);
				sprintf(&polyrecord[191],"%-5s",poly[i].Aitsce);
				fwrite(&polyrecord,sizeof(polyrecord)-1,1,dbftmp);    		
				Npts = 0;
				if (poly[i].Flip == 0)
				{
					Pts[Npts].Longitude = poly[i].Frlong;
					Pts[Npts].Latitude = poly[i].Frlat;
					Npts++;
					Get_Shape_Points(poly[i].Tlid,poly[i].Flip);
					Pts[Npts].Longitude = poly[i].Tolong;
					Pts[Npts].Latitude = poly[i].Tolat;
					Npts++;					
					n++;
					//steppos = (int)(n*100/written);	
					//Ptrdlg->m_Progress.SetPos(steppos);
					poly[i].Chosen = 1;            
					found = 1;                      
					curX = poly[i].Tolong;
					curY = poly[i].Tolat;                
					curcase = i;
					break;					
				}
				else
				{
					Pts[Npts].Longitude = poly[i].Tolong;
					Pts[Npts].Latitude = poly[i].Tolat;
					Npts++;
					Get_Shape_Points(poly[i].Tlid,poly[i].Flip);
					Pts[Npts].Longitude = poly[i].Frlong;
					Pts[Npts].Latitude = poly[i].Frlat;
					Npts++;				
					n++;
//					steppos = (int)(n*100/written);	
//					Ptrdlg->m_Progress.SetPos(steppos);
					curX = poly[i].Frlong;
					curY = poly[i].Frlat;                        
					poly[i].Chosen = 1;		
					found = 1;          
					curcase = i;	
					break;					
				}	
			}
		}
		//by now found should be 1
		if (found == 0)
		{
			info.Format("ERROR - found is zero");
			Ptrdlg->ErrorMessage(info);									
			MissingFile = -1;
			return;
		}
		ptcount += Npts;
		fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
		if (Pts[0].Longitude < CurrentMinX)
			CurrentMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < CurrentMinY)
			CurrentMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[0].Latitude;	
		if (Pts[0].Longitude < FileMinX)
			FileMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > FileMaxX)
			FileMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < FileMinY)
			FileMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > FileMaxY)
			FileMaxY = Pts[0].Latitude;

		if (Pts[Npts-1].Longitude < CurrentMinX)
			CurrentMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < CurrentMinY)
			CurrentMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[Npts-1].Latitude;	
		if (Pts[Npts-1].Longitude < FileMinX)
			FileMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > FileMaxX)
			FileMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < FileMinY)
			FileMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > FileMaxY)
			FileMaxY = Pts[Npts-1].Latitude;	
		steppos = (int)(n*100/written);	
		Ptrdlg->m_Progress.SetPos(steppos);	

	}//close while loop
	fwrite(&ptcount,sizeof(int),1,headtemp);
	fwrite(&nparts,sizeof(int),1,partstemp);
	fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
	fclose(boxtemp);
	fclose(headtemp);
	fclose(ptstemp);
	fclose(partstemp);
	fclose(dbftmp);
	Ptrdlg->m_Progress.SetPos(0);
	polyid = Build_Poly_Shape2("all", dbPolys100,sizeof(polyrecord)-1);
	free(poly);	
	Ptrdlg->m_strProcess.Format("");		
	Ptrdlg->SetDlgItemText(IDC_PROCESS,Ptrdlg->m_strProcess);
	Ptrdlg->m_Progress.SetPos(0);		
	Ptrdlg->m_strLayer.Format("");		
	Ptrdlg->SetDlgItemText(IDC_LAYER,Ptrdlg->m_strLayer);
}

