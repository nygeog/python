#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <malloc.h>
#include <string.h>
#include <math.h>
#include "tgr2shp.h"
#include "dbase.h"
#include "shape.h"

#define BUFFLEN 250                     

char Fipscode[6];
RecordType1  *Type1s;
RecordType2  *Type2s;
RecordType3  *Type3s;
//Node_type *Nodes;	
FILE *in;
long Count1, Count2, Count3;
long Counts[8], Polycounts[4];
/*County_Border_Type *County;
Tract_Border_Type  *Tract;
BlockGroup_Border_Type *Group;                          
Block_Border_Type  *Block;	
*/
char	Record[BUFFLEN];
long num;
int MaxShapeRecords;
double CurrentMinX,CurrentMinY,CurrentMaxX,CurrentMaxY;
double FileMinX,FileMinY,FileMaxX,FileMaxY;
int Npts;
Geographic_Coordinate *Pts;
void Parse_Type1_Record(long);
void Parse_Type2_Record(long);
void Parse_Type3_Record(long);
void Nscanf(char *, int, const char *, void *);
void Ascanf(char *, int, char *);
typedef int (*compfn)(const void*, const void*);
int  Compare1(RecordType1 *, RecordType1 *);
int  Compare1A(RecordType1 *, RecordType1 *);
int  Compare2(RecordType2 *, RecordType2 *);
int  CompareNodes(Node_type *, Node_type *);
int  Compare3(RecordType3 *, RecordType3 *);
int  CompareTract(Tract_Border_Type *, Tract_Border_Type *);
int  CompareGroup(BlockGroup_Border_Type *, BlockGroup_Border_Type *);
int  CompareBlock(Block_Border_Type *, Block_Border_Type *);
void main(void);
void Get_Type1(void);
void Get_Type2(void);
void Get_Type3(void);
void Build_Lines_And_Nodes(void);
void Get_Shape_Points(char *, int);
void Match_Poly_Lines_County(void);
void Match_Poly_Lines_Tract(void);
void Match_Poly_Lines_Group(void);
void Match_Poly_Lines_Block(void);
void Build_Poly_Shape(char *);

extern shape_header_t * Create_Shape_Header(int);
extern int SHP_Write_Header(FILE*, shape_header_t*);
extern int SHP_Write_Record_Header(FILE* , shape_record_header_t* );
extern int SHP_Write_Arc(FILE*,shape_arc_t *);
extern int SHP_Write_Index(FILE*, shape_index_record_t* );
extern int SHP_Write_Point(FILE*, shape_point_t *);
extern int SHP_Write_Poly(FILE *, shape_poly_t *);

void main()
{

	float x;
	int	  i;

	x = 0.0;
	printf("\nEnter the 5 digit state-county fipscode...");
	scanf("%s",Fipscode);
	if (strlen(Fipscode) != 5)
	{
		printf("\nERROR-The fipscode you entered is not 5 characters long.");
		printf("\nPlease check that there are no leading or trailing blanks.\n");
		exit(1);
	}
	for (i = 0; i < 5; i++)
	{
		//printf("%c",Fipscode[i]);
		if (Fipscode[i] == ' ')
		{
			printf("\nERROR-The fipscode you entered contains imbedded blanks.");		
			printf("\nThese could be leading blanks\n");
			exit(1);
		}
	}	
	Get_Type1();
	Get_Type2();
	//we need the following array to collect point information for shape files
	Pts = (Geographic_Coordinate *)calloc(MaxShapeRecords*10+2,sizeof(Geographic_Coordinate));	
	Build_Lines_And_Nodes();
	//this finishes the line sections.  Now it is time to do polys
	//first we will resort the type1 records
	printf("\nResorting type 1 records");
	qsort((void *)Type1s,Count1,sizeof(RecordType1),(compfn)Compare1);
	//now get type3 records
	Get_Type3();
	Match_Poly_Lines_County();
	Match_Poly_Lines_Tract();
	Match_Poly_Lines_Group();
	Match_Poly_Lines_Block();	
	free(Pts);
	free(Type1s);
	free(Type2s);
	free(Type3s);
}
void Get_Type1()
{
	int i;
/*This sections reads and sorts all type 1 records.  
The records are sorted on Cfcc type (primary key) and Tlid (secondary key).
After the records are sorted, we move to record type2*/
	char fname[13];
	sprintf(fname,"tgr%s.bw1",Fipscode);
	in = fopen(fname,"r");	
	if (in == NULL)
	{
		printf("\nERROR - cannot open type 1 tiger file %s\n",fname);
		exit(1);
	}
		
	Count1 = 0;
	printf("\nScanning record type 1 file");
	while (fgets(Record, (BUFFLEN - 1), in) != NULL)
		{
		Count1++;
		}
	Type1s = (RecordType1 *)calloc(Count1, sizeof(RecordType1));
	if (Type1s == NULL)
	{
		printf("\nMEMORY ALLOCATION ERROR");
		exit(1);
	}
	rewind(in);
	for (i = 0; i < 8; i++)
		Counts[i] = 0L;
	//CountA = CountB = CountC = CountD = CountE = CountF = CountH = CountX = 0; 
    printf("\nBuilding type 1 array");
    for (num = 0; num < Count1; num++)
	{
		if (fgets(Record, (BUFFLEN - 1), in) == NULL)
		{
			printf("\nERROR reading type 1 records");
			exit(1);
		}
		Parse_Type1_Record(num);
		switch(Type1s[num].Cfcc[0])
		{
		case 'A':
			Counts[0]++;
			break;
		case 'B':
			Counts[1]++;
			break;
		case 'C':
			Counts[2]++;
			break;
		case 'D':
			Counts[3]++;
			break;
		case 'E':
			Counts[4]++;
			break;
		case 'F':
			Counts[5]++;
			break;
		case 'H':
			Counts[6]++;
			break;
		case 'X':
			Counts[7]++;
			break;
		default:
			Counts[7]++;
			Type1s[num].Cfcc[0] = 'X';
			break;
		}		
	}
	fclose(in);
	printf("\nThe following number of line types were found:\n");
	for (i = 0; i < 8; i++)
		printf(" Type %c = %ld\n",Types[i],Counts[i]);
	printf("Total number is %ld",Count1);
	printf("\nSorting type1 array");
	qsort((void *)Type1s,Count1,sizeof(RecordType1),(compfn)Compare1A);	
	return;
}
void Get_Type2()
{
/*This section reads and sorts type 2 reocrds. The sort is on Tlid
(primary key) and Rtsq (seondary key)
*/
	char fname[13];
//	int i;

	sprintf(fname,"tgr%s.bw2",Fipscode);
	if ((in = fopen(fname,"r")) == NULL)
	{
		printf("\nERROR-cannot open type 2 tiger file %s\n",fname);
		exit(1);
	}
    Count2 = 0;
	printf("\nScanning record type 2 file");
	while (fgets(Record, (BUFFLEN - 1), in) != NULL)
	{                       
		Count2++;
	}
	rewind(in);
	printf("\nThe number of type 2 (shape point) records is %ld",Count2);
	Type2s = (RecordType2 *)calloc(Count2, sizeof(RecordType2));
	if (Type2s == NULL)
	{
		printf("\nMEMORY ALLOCATION ERROR");
		exit(1);
	}
	printf("\nBuilding type 2 array");
	MaxShapeRecords = 0;
	for (num = 0; num < Count2; num++)
	{
		if (fgets(Record, (BUFFLEN - 1), in) == NULL)
		{
			printf("\nERROR reading type 2 records");
			exit(1);
		}
       Parse_Type2_Record(num);
	   if (atoi(Type2s[num].Rtsq) > MaxShapeRecords)
		   MaxShapeRecords = atoi(Type2s[num].Rtsq);
    }  
    fclose(in);
	printf("\nMax Shape Records is %d",MaxShapeRecords);
	printf("\nSorting type 2 array");
   	qsort((void *)Type2s,Count2,sizeof(RecordType2),(compfn)Compare2);
/*	chk = fopen("check.txt","w");
	for (i = 0; i < Count2; i++)
		fprintf(chk,"%s %s",Type2s[i].Tlid,Type2s[i].Rtsq);
	fclose(chk);
	exit(0);
*/
	return;
}
void Get_Type3()
{
/*This sections reads and sorts all type 3 records.  
The records are sorted on Tlid */
	int i;
	char fname[13];
	for (i = 0; i < 4; i++)
		Polycounts[i] = 0;
	sprintf(fname,"tgr%s.bw3",Fipscode);
	in = fopen(fname,"r");	
	if (in == NULL)
	{
		printf("\nERROR - cannot open type 3 tiger file %s\n", fname);
		exit(1);
	}		
	Count3 = 0;
	printf("\nScanning record type 3 file");
	while (fgets(Record, (BUFFLEN - 1), in) != NULL)
		{
		Count3++;
		}
	if (Count3 != Count1)
	{
		printf("\nTIGER ERROR-There is not a one-to one correspondence between");
		printf("\ntype 1 records and type 3 records.  This is an error in TIGER");
		exit(1);
	}
	Type3s = (RecordType3 *)calloc(Count3, sizeof(RecordType3));
	if (Type3s == NULL)
	{
		printf("\nMEMORY ALLOCATION ERROR");
		exit(1);
	}
	rewind(in);
    for (num = 0; num < Count3; num++)
	{
		if (fgets(Record, (BUFFLEN - 1), in) == NULL)
		{
			printf("\nERROR reading type 3 records");
			exit(1);
		}
		Parse_Type3_Record(num);
		for (i = 0; i < 4; i++)
			Type3s[num].BorderType[i] = 0;
		if (strcmp(Type3s[num].State90l,Type3s[num].State90r) != 0)
		{
			if ((strcmp(Type3s[num].State90l,"  ") == 0) ||
				(strcmp(Type3s[num].State90r,"  ") == 0))
			{
				for (i = 0; i < 4; i++)
				{
					Type3s[num].BorderType[i] = 1;				
					Polycounts[i]++;
				}
			}
			else //this should not happen
			{
				for (i = 0; i < 4; i++)
				{
					Type3s[num].BorderType[i] = 1;
					Polycounts[i] += 2;
				}
			}
		}
		else 
		{
			if (strcmp(Type3s[num].Coun90l,Type3s[num].Coun90r) != 0)
			{//this should not happen
				for (i = 0; i < 4; i++)
				{
					Type3s[num].BorderType[i] = 1;				
					Polycounts[i] += 2;
				}
			}
			else
			{
				if (strcmp(Type3s[num].Ctbnal,Type3s[num].Ctbnar) != 0)                 
				{
					for (i = 1; i < 4; i++)
					{
						Type3s[num].BorderType[i] = 1;				
						Polycounts[i] += 2;
					}
				}
				else
				{
					if (Type3s[num].Blk90l[0] != Type3s[num].Blk90r[0])
					{
						for (i = 2; i < 4; i++)
						{
							Type3s[num].BorderType[i] = 1;				
							Polycounts[i] += 2;
						}
					}
					else
					{
						if (strcmp(Type3s[num].Blk90l,Type3s[num].Blk90r) != 0)
						{
							Type3s[num].BorderType[3] = 1;
							Polycounts[3] += 2;
						}
					}
				}
			}
		}
	}
	fclose(in);
	for (i = 0; i < 4; i++)
		printf("\n i = %d num of lines = %ld",i,Polycounts[i]);
	printf("\nSorting type 3 array");
   	qsort((void *)Type3s,Count3,sizeof(RecordType3),(compfn)Compare3);
	/*for (num = 0; num < Count3; num++)
		printf("\n%ld %s %s",num, Type1s[num].Tlid, Type3s[num].Tlid);	
	*/
	return;
}
void Build_Lines_And_Nodes()
{
/*This section builds a node list for each node used of a given type
After the node list is built, it is sorted and packed, then used to 
write the line type files*/

	int i, found, m;
	long num, base, j, numunique, k;
	long upper, lower, halfway, idnum;
	char fname[13];
	char noderec[10]; //9 is size of a node record
	char linkrec[123]; //122 is size of a link record
	FILE  *linkndes, *ndeatt;
	//shape stuff
	FILE *linkshp, *linkshx, *nodeshp, *nodeshx;
	shape_header_t *arcshphead, *nodeshphead;
	shape_record_header_t *rechead;
	shape_arc_t *curarc;
	shape_point_t *curnode;
	int nparts; //always is one
	int oldposition;
	shape_index_record_t *curindex;
	
	Node_type *packed, *nodes;
    
	base = 0L;
	for (i = 0; i < 8; i++)
	{
		if (Counts[i] == 0)
			continue;
		nodes = (Node_type *)calloc(Counts[i]*2,sizeof(Node_type));
		packed = (Node_type *)calloc(Counts[i]*2,sizeof(Node_type));
		if (i == 0)
			base = 0;
		else
			base += Counts[i-1];
		num = 0;
		//create an array of nodes for the current line type
		for (j = base; j < base + Counts[i]; j++)
		{
			nodes[num].Longitude = Type1s[j].Frlong;
			nodes[num].Latitude = Type1s[j].Frlat;
			strcpy(nodes[num].Tlid,Type1s[j].Tlid);
			nodes[num].Toflag = 0;
			packed[num] = nodes[num];			
			num++;
   			nodes[num].Longitude = Type1s[j].Tolong;
			nodes[num].Latitude = Type1s[j].Tolat;
			strcpy(nodes[num].Tlid,Type1s[j].Tlid);
			nodes[num].Toflag = 1;
			packed[num] = nodes[num];			
			num++;
		}		
		printf("\nSorting nodes of line type %c by location",Types[i]);
		qsort((void *)packed,2*Counts[i],sizeof(Node_type),(compfn)CompareNodes);
		sprintf(fname,"lk%s%c.shp",Fipscode,Types[i]);
		linkshp = fopen(fname,"wb");
		sprintf(fname,"lk%s%c.shx",Fipscode,Types[i]);
		linkshx = fopen(fname,"wb");
		sprintf(fname,"lk%s%c.dbf",Fipscode,Types[i]);
		linkndes = fopen(fname,"wb");		
		sprintf(fname,"nd%s%c.dbf",Fipscode,Types[i]);
		ndeatt = fopen(fname,"wb");	
		sprintf(fname,"nd%s%c.shp",Fipscode,Types[i]);
		nodeshp = fopen(fname,"wb");
		sprintf(fname,"nd%s%c.shx",Fipscode,Types[i]);
		nodeshx = fopen(fname,"wb");
		Build_db_Header(ndeatt,0L,dbNodes);
		Build_db_FieldHeaders(ndeatt,dbNodes);
		nodeshphead = Create_Shape_Header(SHP_POINT);
	    SHP_Write_Header(nodeshp,nodeshphead);
        SHP_Write_Header(nodeshx,nodeshphead); 
		Position = 100; 
		oldposition = Position;
		FileMinX = FileMinY = LARGE;
		FileMaxX = FileMaxY = -LARGE;
		Build_db_Header(linkndes,Counts[i],dbLinks);
		Build_db_FieldHeaders(linkndes,dbLinks);
		numunique = 0;
		curnode = (shape_point_t *)calloc(1,sizeof(shape_point_t));
		curnode->shapeType = 1;
		curnode->x = packed[numunique].Longitude;
		curnode->y = packed[numunique].Latitude;
		rechead =(shape_record_header_t *)calloc(1,sizeof(shape_record_header_t));
		rechead->num = numunique+1;
		rechead->length = SHPPOINTSIZE/2;
		SHP_Write_Record_Header(nodeshp,rechead);
		free(rechead);
		SHP_Write_Point(nodeshp,curnode);
		curindex = (shape_index_record_t *)calloc(1,sizeof(shape_index_record_t));
		curindex->offset = oldposition;
		curindex->length = Size;
		SHP_Write_Index(nodeshx,curindex);
		free(curindex);
		oldposition = Position;
		if (packed[numunique].Longitude < FileMinX)
			FileMinX = packed[numunique].Longitude;
		if (packed[numunique].Longitude > FileMaxX)
			FileMaxX = packed[numunique].Longitude;
		if (packed[numunique].Latitude < FileMinY)
			FileMinY = packed[numunique].Latitude;
		if (packed[numunique].Latitude > FileMaxY)
			FileMaxY = packed[numunique].Latitude;
		sprintf(noderec," %-8ld",numunique+1);
		fwrite(noderec,sizeof(noderec)-1,1,ndeatt);
		numunique++;
		//restructure array so first numunique elements are unique
		for (j = 1; j < num; j++)
		{
			if ((packed[j-1].Longitude == packed[j].Longitude) && 
				(packed[j-1].Latitude == packed[j].Latitude))
				continue;
			//if we get here we have a unique case
			packed[numunique] = packed[j];
			sprintf(noderec," %-8ld",numunique+1);
			fwrite(noderec,sizeof(noderec)-1,1,ndeatt);
			curnode->x = packed[numunique].Longitude;
			curnode->y = packed[numunique].Latitude;
			rechead =(shape_record_header_t *)calloc(1,sizeof(shape_record_header_t));
			rechead->num = numunique+1;
			rechead->length = SHPPOINTSIZE/2;
			SHP_Write_Record_Header(nodeshp,rechead);
			free(rechead);
			SHP_Write_Point(nodeshp,curnode);
			curindex = (shape_index_record_t *)calloc(1,sizeof(shape_index_record_t));
			curindex->offset = oldposition;
			curindex->length = Size;
			SHP_Write_Index(nodeshx,curindex);
			free(curindex);
			oldposition = Position;
			if (packed[numunique].Longitude < FileMinX)
			FileMinX = packed[numunique].Longitude;
			if (packed[numunique].Longitude > FileMaxX)
				FileMaxX = packed[numunique].Longitude;
			if (packed[numunique].Latitude < FileMinY)
				FileMinY = packed[numunique].Latitude;
			if (packed[numunique].Latitude > FileMaxY)
				FileMaxY = packed[numunique].Latitude;
			numunique++;
		}
		free(curnode);
		printf("\nThe number of unique nodes for line type %c is %ld",
			Types[i],numunique);
		write_eof(ndeatt);
		//rewind and rewrite node shape header, and index file
		rewind(nodeshp);
		nodeshphead->fileLen = Position;
		nodeshphead->xMin = FileMinX;
		nodeshphead->yMin = FileMinY;
		nodeshphead->xMax = FileMaxX;
		nodeshphead->yMax = FileMaxY;		
		SHP_Write_Header(nodeshp,nodeshphead);
		nodeshphead->fileLen = IPosition;
		rewind(nodeshx);
		SHP_Write_Header(nodeshx,nodeshphead);
		free(nodeshphead);
		fclose(nodeshx);
		fclose(nodeshp);        
		rewind(ndeatt);
		Build_db_Header(ndeatt,numunique,dbNodes);
		//match node and links
		printf("\n writing shapes for lines of type %c",Types[i]);
		FileMinX = FileMinY = LARGE;
		FileMaxX = FileMaxY = -LARGE;
		arcshphead = Create_Shape_Header(SHP_ARC);
	    SHP_Write_Header(linkshp,arcshphead);
        SHP_Write_Header(linkshx,arcshphead); 
		Position = 100; 
		oldposition = Position;
		//the next loop is for every line of the present type
		for (j = base; j < base + Counts[i]; j++)
		{
			Npts = 0;
			CurrentMinX = CurrentMinY = LARGE;
			CurrentMaxX = CurrentMaxY = -LARGE;
			for (k = (j-base)*2; k < (j-base)*2 + 2; k++)
			{
				if (strcmp(Type1s[j].Tlid,nodes[k].Tlid) != 0)
				{
					printf("\nERROR-nonmatching Tlid values in the link file %s and the node file %s",
						Type1s[j].Tlid, nodes[k].Tlid);
					printf("\n link number %ld node number %ld",j,k);
					exit(1);
				}
				upper = numunique - 1;
				lower = 0;
				found = 0;
				while (upper - lower > 0)
				{			
					if (nodes[k].Longitude == packed[lower].Longitude)
					{
						if (nodes[k].Latitude == packed[lower].Latitude)
						{
							//we have a match   
							found = 1;
							idnum = lower+1;
							break;
						}
					}
					if (nodes[k].Longitude == packed[upper].Longitude)
					{
						if (nodes[k].Latitude == packed[upper].Latitude)
						{
							//we have a match   
							found = 1;
							idnum = upper+1;
							break;
						}
					}
					//the following should never happen
					if ((upper - lower) == 1) 
					{//ERROR no match found
						printf("\nERROR - no match found for %s for direction %d",nodes[k].Tlid, nodes[k].Toflag);
						printf("\nsearch values %lf %lf",nodes[k].Longitude,nodes[k].Latitude);
						printf("\nupper %ld %lf %lf", upper,packed[upper].Longitude, packed[upper].Latitude);
						printf("\nlower %ld %lf %lf", lower,packed[lower].Longitude, packed[lower].Latitude);
						exit(1);
					}
					halfway = (long)floor((upper + lower) / 2);      
					if (nodes[k].Longitude == packed[halfway].Longitude)
					{
						if (nodes[k].Latitude == packed[halfway].Latitude)
						{
							//we have a match   
							found = 1;
							idnum = halfway+1;
							break;
						}
					}
					if (packed[halfway].Longitude == nodes[k].Longitude)
					{
						if (packed[halfway].Latitude < nodes[k].Latitude)
						{                 
							lower = halfway;  
						}
						else
						{
							upper = halfway;                    
						}
					}                                      
					else 
					{           
						if (packed[halfway].Longitude < nodes[k].Longitude)
						{
							lower = halfway;      
						} 
						else
           				{
							upper = halfway;                            
						}                              
					}
				}//while upper and lower
				//need to check for a found value
				if (found == 0)
				{
					printf("\n ERROR node %lf %lf %s %d was not found",nodes[k].Longitude, nodes[k].Latitude,
						nodes[k].Tlid, nodes[k].Toflag);
					exit(1);
				}
				//we have found a case, time to update max and min values

				if (nodes[k].Longitude < CurrentMinX)
					CurrentMinX = nodes[k].Longitude;
				if (nodes[k].Longitude > CurrentMaxX)
					CurrentMaxX = nodes[k].Longitude;
				if (nodes[k].Latitude < CurrentMinY)
					CurrentMinY = nodes[k].Latitude;
				if (nodes[k].Latitude > CurrentMaxY)
					CurrentMaxY = nodes[k].Latitude;
				
				if (nodes[k].Longitude < FileMinX)
					FileMinX = nodes[k].Longitude;
				if (nodes[k].Longitude > FileMaxX)
					FileMaxX = nodes[k].Longitude;
				if (nodes[k].Latitude < FileMinY)
					FileMinY = nodes[k].Latitude;
				if (nodes[k].Latitude > FileMaxY)
					FileMaxY = nodes[k].Latitude;

				//we have found a case, time to write           
				if (nodes[k].Toflag == 0L)
				{
			
					sprintf(linkrec," %-10s%-8ld",nodes[k].Tlid,idnum);
					Pts[Npts].Longitude = nodes[k].Longitude;
					Pts[Npts].Latitude = nodes[k].Latitude;
					Npts++;
					Get_Shape_Points(nodes[k].Tlid,0);
				}
				else
				{
					sprintf(&linkrec[19],"%-8ld%-2s%-30s%-4s%-2s%-3s%-11s%-11s%-11s%-11s%-5s%-5s",
					idnum,Type1s[j].Fedirp,Type1s[j].Fename,Type1s[j].Fetype,
					Type1s[j].Fedirs, Type1s[j].Cfcc,Type1s[j].Fraddl, Type1s[j].Toaddl, Type1s[j].Fraddr, 
					Type1s[j].Toaddr,Type1s[j].Zipl,Type1s[j].Zipr);
					fwrite(&linkrec,sizeof(linkrec)-1,1,linkndes);
					Pts[Npts].Longitude = nodes[k].Longitude;
					Pts[Npts].Latitude = nodes[k].Latitude;
					Npts++;
				}
			}//for on k
			//time to write arc stuff to shape file
			
			rechead =(shape_record_header_t *)calloc(1,sizeof(shape_record_header_t));
			rechead->num = (int)(j - base + 1);
			nparts = 1;
			rechead->length = (4 + 32 + 4 + 4 + (4 * nparts) + (16 * Npts) );			
			SHP_Write_Record_Header(linkshp,rechead);
			free(rechead);
			curarc = (shape_arc_t *)calloc(1,sizeof(shape_arc_t));
			curarc->shapeType = SHP_ARC;
			curarc->xMin = CurrentMinX;
			curarc->yMin = CurrentMinY;
			curarc->xMax = CurrentMaxX;
			curarc->yMax = CurrentMaxY;
			curarc->numParts = nparts;
			curarc->numPoints = Npts;
			curarc->parts = (int *)calloc(nparts,sizeof(int ));
			curarc->points = (point_t *)calloc(Npts,sizeof(point_t));
			curarc->parts[0] = 0;
			for (m = 0; m < Npts; m++)
			{
				curarc->points[m].x = Pts[m].Longitude;
				curarc->points[m].y = Pts[m].Latitude;
			}		   
			SHP_Write_Arc(linkshp,curarc);
			free(curarc->parts);
			free(curarc->points);
			free(curarc);
			curindex = (shape_index_record_t *)calloc(1,sizeof(shape_index_record_t));
			curindex->offset = oldposition;
			curindex->length = Size;
			SHP_Write_Index(linkshx,curindex);
			free(curindex);
			oldposition = Position;
		}//for on j
		//time to rewind and rebuild file header
		arcshphead->fileLen = Position;
		arcshphead->xMin = FileMinX;
		arcshphead->yMin = FileMinY;
		arcshphead->xMax = FileMaxX;
		arcshphead->yMax = FileMaxY;
		rewind(linkshp);
		SHP_Write_Header(linkshp,arcshphead);
		arcshphead->fileLen = IPosition;
		rewind(linkshx);
		SHP_Write_Header(linkshx,arcshphead);
		free(arcshphead);
		fclose(linkshp);
		fclose(linkshx);

		fclose(ndeatt);
		write_eof(linkndes);
		fclose(linkndes);
		free(nodes);		
		free(packed);
	}//for on i	
}
void Match_Poly_Lines_County()
{
	int polyid, found, i, nparts, ptcount;
	long num, n, written, curcase;
	County_Border_Type *county;
	double  curX, curY;	
    FILE  *dbfout, *ptstemp, *headtemp, *partstemp, *boxtemp;
	char fname[14];
	char  ctyrecord[15]; //14 is the size of county record

	if (Polycounts[0] == 0)
		return;
	
//	genout = fopen("county.gen","w");
	sprintf(fname,"cty%s.dbf",Fipscode);
    dbfout = fopen(fname,"wb");
	ptstemp = fopen("pts.tmp","wb");
	headtemp = fopen("head.tmp","wb");
	boxtemp = fopen("box.tmp","wb");
	partstemp = fopen("parts.tmp","wb");
	
	county = (County_Border_Type *)calloc(Polycounts[0],sizeof(County_Border_Type));
	written = 0;
	for (num = 0; num < Count3; num++)
	{
		if (Type3s[num].BorderType[0] == 0)
			continue;
		//we know it is a border type 0 line
		//county boundaries are a special case
		if (strcmp(Type3s[num].State90l,"  ") != 0)
		{//left case
			sprintf(county[written].Id,"%s%s",Type3s[num].State90l,Type3s[num].Coun90l);
			sprintf(county[written].Tlid,"%s",Type3s[num].Tlid);
			county[written].Frlong = Type1s[num].Frlong;
			county[written].Frlat = Type1s[num].Frlat;
			county[written].Tolong = Type1s[num].Tolong;
			county[written].Tolat = Type1s[num].Tolat;
			county[written].Chosen = 0;
			//set flip = 1 to get county on the right
			county[written].Flip = 1;
			written++;
		}
		else
		{//rightcase
			sprintf(county[written].Id,"%s%s",Type3s[num].State90r,Type3s[num].Coun90r);
			sprintf(county[written].Tlid,"%s",Type3s[num].Tlid);
			county[written].Frlong = Type1s[num].Frlong;
			county[written].Frlat = Type1s[num].Frlat;
			county[written].Tolong = Type1s[num].Tolong;
			county[written].Tolat = Type1s[num].Tolat;
			county[written].Chosen = 0;
			county[written].Flip = 0;
			written++;
		}
		if (written > Polycounts[0])
		{
			printf("\nthe number of county border lines exceeds the count");
			exit(1);
		}
	}
	FileMinX = FileMinY = LARGE;
	FileMaxX = FileMaxY = -LARGE;
	CurrentMinX = CurrentMinY = LARGE;
	CurrentMaxX = CurrentMaxY = -LARGE;
	curcase = 0; // counter on line being processed
	polyid = 1; //counter on polygon being processed
	Npts = 0; //counter on points in poly ring being processed
	nparts = 1; // part of polygon (ring counter) being processed
	ptcount = 0; //counts the points in the current ring
	Build_db_Header(dbfout,0,dbCounty);
	Build_db_FieldHeaders(dbfout,dbCounty);
	sprintf(ctyrecord," %-8d%-5s",polyid,county[curcase].Id);
	fwrite(&ctyrecord,sizeof(ctyrecord)-1,1,dbfout);
	if (county[0].Flip == 0)
	{
		curX = county[curcase].Tolong;
		curY = county[curcase].Tolat;
		Pts[Npts].Longitude = county[curcase].Frlong;
		Pts[Npts].Latitude = county[curcase].Frlat;
		Npts++;
		Get_Shape_Points(county[curcase].Tlid,county[curcase].Flip);
		Pts[Npts].Longitude = county[curcase].Tolong;
		Pts[Npts].Latitude = county[curcase].Tolat;
		Npts++;
		county[curcase].Chosen = 1;	
	}
	else
	{
		curX = county[curcase].Frlong;
		curY = county[curcase].Frlat;
		Pts[Npts].Longitude = county[0].Tolong;
		Pts[Npts].Latitude = county[0].Tolat;
		Npts++;
		Get_Shape_Points(county[curcase].Tlid,county[curcase].Flip);
		Pts[Npts].Longitude = county[curcase].Frlong;
		Pts[Npts].Latitude = county[curcase].Frlat;
		Npts++;
		county[curcase].Chosen = 1;	
	}
	ptcount += Npts;	
	fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
	if (Pts[0].Longitude < CurrentMinX)
		CurrentMinX = Pts[0].Longitude;
	if (Pts[0].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < CurrentMinY)
		CurrentMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[0].Latitude;	
	if (Pts[0].Longitude < FileMinX)
		FileMinX = Pts[0].Longitude;
	if (Pts[0].Longitude > FileMaxX)
		FileMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < FileMinY)
		FileMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > FileMaxY)
		FileMaxY = Pts[0].Latitude;

	if (Pts[Npts-1].Longitude < CurrentMinX)
		CurrentMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < CurrentMinY)
		CurrentMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[Npts-1].Latitude;	
	if (Pts[Npts-1].Longitude < FileMinX)
		FileMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > FileMaxX)
		FileMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < FileMinY)
		FileMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > FileMaxY)
		FileMaxY = Pts[Npts-1].Latitude;
	n = 1;
    while (n < written)
	{
		printf("\n Have written %ld of %ld county boundary lines",n, written);
		found = 0;
		for (i = 1; i < written; i++)
        {
			Npts = 0;
			if (county[i].Chosen != 0)
				continue;
			if (county[i].Flip == 0)
			{
				 if ((county[i].Frlong == curX) && (county[i].Frlat == curY))
					{                          
					if (strcmp(county[i].Id,county[curcase].Id) != 0)
					  continue;
					Get_Shape_Points(county[i].Tlid,county[i].Flip);
					Pts[Npts].Longitude = county[i].Tolong;
					Pts[Npts].Latitude = county[i].Tolat;
					Npts++;
					n++;
					county[i].Chosen = 1;            
					found = 1;                      
					curX = county[i].Tolong;
					curY = county[i].Tolat;                
					curcase = i;
					break;
					}
			}
			else
			{
				if ((county[i].Tolong == curX) && (county[i].Tolat == curY))
					{
					if (strcmp(county[i].Id,county[curcase].Id) != 0)
					  continue;	            
					Get_Shape_Points(county[i].Tlid,county[i].Flip);
					Pts[Npts].Longitude = county[i].Frlong;
					Pts[Npts].Latitude = county[i].Frlat;
					Npts++;				
					n++;
					curX = county[i].Frlong;
					curY = county[i].Frlat;                        
					county[i].Chosen = 1;		
					found = 1;          
					curcase = i;
					break;
					}
			}
        }//close for loop
		
		if (found == 0) //initialize new case, eg, new ring in current poly
			// or new polyid
        {
			fwrite(&ptcount,sizeof(int),1,headtemp);
			ptcount = 0;
			for (i = 0; i < written; i++)//first check for new ring in current poly
            {                    
         		if (county[i].Chosen != 0)
					continue;             
				if (strcmp(county[i].Id,county[curcase].Id) != 0)
					continue;
				//if we get here we have a new ring of the current polygon
				found = 1;
				nparts++;				
				Npts = 0;				
				if (county[i].Flip == 0)
				{
					Pts[Npts].Longitude = county[i].Frlong;
					Pts[Npts].Latitude = county[i].Frlat;
					Npts++;
					Get_Shape_Points(county[i].Tlid,county[i].Flip);
					Pts[Npts].Longitude = county[i].Tolong;
					Pts[Npts].Latitude = county[i].Tolat;
					Npts++;
					n++;
					county[i].Chosen = 1;            
					found = 1;                      
					curX = county[i].Tolong;
					curY = county[i].Tolat;                
					curcase = i;
					break;					
				}
				else
				{
					Pts[Npts].Longitude = county[i].Tolong;
					Pts[Npts].Latitude = county[i].Tolat;
					Npts++;
					Get_Shape_Points(county[i].Tlid,county[i].Flip);
					Pts[Npts].Longitude = county[i].Frlong;
					Pts[Npts].Latitude = county[i].Frlat;
					Npts++;				
					n++;
					curX = county[i].Frlong;
					curY = county[i].Frlat;                        
					county[i].Chosen = 1;		
					found = 1;          
					curcase = i;
					break;					
				}	
			}//close on for loop on i
		}//close one if on found
        if (found == 0) // new polygon, first ring
		{
			fwrite(&nparts,sizeof(int),1,partstemp);
			fwrite(&ptcount,sizeof(int),1,headtemp);
			nparts = 1;
			fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
			for (i = 0; i < written; i++)//first check for new ring in current poly
            {                    
         		if (county[i].Chosen != 0)
					continue;             
				polyid++;
				sprintf(ctyrecord," %-8d%-5s",polyid,county[i].Id);
				fwrite(&ctyrecord,sizeof(ctyrecord)-1,1,dbfout);    		
				Npts = 0;
				if (county[i].Flip == 0)
				{
					Pts[Npts].Longitude = county[i].Frlong;
					Pts[Npts].Latitude = county[i].Frlat;
					Npts++;
					Get_Shape_Points(county[i].Tlid,county[i].Flip);
					Pts[Npts].Longitude = county[i].Tolong;
					Pts[Npts].Latitude = county[i].Tolat;
					Npts++;
					n++;
					county[i].Chosen = 1;            
					found = 1;                      
					curX = county[i].Tolong;
					curY = county[i].Tolat;                
					curcase = i;
					break;					
				}
				else
				{
					Pts[Npts].Longitude = county[i].Tolong;
					Pts[Npts].Latitude = county[i].Tolat;
					Npts++;
					Get_Shape_Points(county[i].Tlid,county[i].Flip);
					Pts[Npts].Longitude = county[i].Frlong;
					Pts[Npts].Latitude = county[i].Frlat;
					Npts++;				
					n++;
					curX = county[i].Frlong;
					curY = county[i].Frlat;                        
					county[i].Chosen = 1;		
					found = 1;          
					curcase = i;	
					break;					
				}	
			}
		}
		//by now found should be 1
		if (found == 0)
		{
			printf("ERROR - found is zero");
			exit(1);
		}
		ptcount += Npts;
		fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
		if (Pts[0].Longitude < CurrentMinX)
		CurrentMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < CurrentMinY)
			CurrentMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[0].Latitude;	
		if (Pts[0].Longitude < FileMinX)
			FileMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > FileMaxX)
			FileMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < FileMinY)
			FileMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > FileMaxY)
			FileMaxY = Pts[0].Latitude;

		if (Pts[Npts-1].Longitude < CurrentMinX)
			CurrentMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < CurrentMinY)
			CurrentMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[Npts-1].Latitude;	
		if (Pts[Npts-1].Longitude < FileMinX)
			FileMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > FileMaxX)
			FileMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < FileMinY)
			FileMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > FileMaxY)
			FileMaxY = Pts[Npts-1].Latitude;		
	}//close while loop
	fwrite(&ptcount,sizeof(int),1,headtemp);
	fwrite(&nparts,sizeof(int),1,partstemp);
	fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
	fclose(boxtemp);
	fclose(headtemp);
	fclose(ptstemp);
	fclose(partstemp);
	printf("\n Have written %ld of %ld county boundary lines",n, written);
	write_eof(dbfout);
	rewind(dbfout);
	Build_db_Header(dbfout,polyid,dbCounty);
	fclose(dbfout);
	free(county);
	Build_Poly_Shape("cty");	
}

void Match_Poly_Lines_Tract()
{
	int polyid, found, i, nparts, ptcount;
	long num, n, written, curcase;
	Tract_Border_Type *tract;
	double  curX, curY;	
    FILE  *dbfout, *ptstemp, *headtemp, *partstemp, *boxtemp; 
	char fname[14];
	char trtrecord[21]; //size of tract dbrecord + 1

	if (Polycounts[1] == 0)
		return;
	
	sprintf(fname,"trt%s.dbf",Fipscode);
    dbfout = fopen(fname,"wb");
	ptstemp = fopen("pts.tmp","wb");
	headtemp = fopen("head.tmp","wb");
	boxtemp = fopen("box.tmp","wb");
	partstemp = fopen("parts.tmp","wb");

	tract = (Tract_Border_Type *)calloc(Polycounts[1],sizeof(Tract_Border_Type));
	written = 0;
	for (num = 0; num < Count3; num++)
	{
		if (Type3s[num].BorderType[1] == 0)
			continue;
		//we know it is a border type 1 line		
		if (strcmp(Type3s[num].State90l,Type3s[num].State90r) != 0)
		{//county-tract boundaries are a special case
			if (strcmp(Type3s[num].State90l,"  ") != 0)
			{//left case
				sprintf(tract[written].Id,"%s%s%s",Type3s[num].State90l,Type3s[num].Coun90l,Type3s[num].Ctbnal);
				sprintf(tract[written].Tlid,"%s",Type3s[num].Tlid);
				tract[written].Frlong = Type1s[num].Frlong;
				tract[written].Frlat = Type1s[num].Frlat;
				tract[written].Tolong = Type1s[num].Tolong;
				tract[written].Tolat = Type1s[num].Tolat;
				tract[written].Chosen = 0;
				tract[written].Flip = 1;
				written++;
			}
			else
			{//rightcase of county-tract
				sprintf(tract[written].Id,"%s%s%s",Type3s[num].State90r,Type3s[num].Coun90r,Type3s[num].Ctbnar);
				sprintf(tract[written].Tlid,"%s",Type3s[num].Tlid);
				tract[written].Frlong = Type1s[num].Frlong;
				tract[written].Frlat = Type1s[num].Frlat;
				tract[written].Tolong = Type1s[num].Tolong;
				tract[written].Tolat = Type1s[num].Tolat;
				tract[written].Chosen = 0;
				tract[written].Flip = 0;
				written++;
			}
		}
		else //internal tract line, has both left and right
		{//do lefts
			sprintf(tract[written].Id,"%s%s%s",Type3s[num].State90l,Type3s[num].Coun90l,Type3s[num].Ctbnal);
			sprintf(tract[written].Tlid,"%s",Type3s[num].Tlid);
			tract[written].Frlong = Type1s[num].Frlong;
			tract[written].Frlat = Type1s[num].Frlat;
			tract[written].Tolong = Type1s[num].Tolong;
			tract[written].Tolat = Type1s[num].Tolat;
			tract[written].Chosen = 0;
			tract[written].Flip = 1;
			written++;
			// do rights
			sprintf(tract[written].Id,"%s%s%s",Type3s[num].State90r,Type3s[num].Coun90r,Type3s[num].Ctbnar);
			sprintf(tract[written].Tlid,"%s",Type3s[num].Tlid);
			tract[written].Frlong = Type1s[num].Frlong;
			tract[written].Frlat = Type1s[num].Frlat;
			tract[written].Tolong = Type1s[num].Tolong;
			tract[written].Tolat = Type1s[num].Tolat;
			tract[written].Chosen = 0;
			tract[written].Flip = 0;
			written++;
		}
		if (written > Polycounts[1])
		{
			printf("\nthe number of county border lines exceeds the count");
			exit(1);
		}
	}
	//time to chain
	printf("\nsorting tract lines by tract id");
	qsort((void *)tract,Polycounts[1],sizeof(Tract_Border_Type),(compfn)CompareTract);
	FileMinX = FileMinY = LARGE;
	FileMaxX = FileMaxY = -LARGE;
	CurrentMinX = CurrentMinY = LARGE;
	CurrentMaxX = CurrentMaxY = LARGE;
	curcase = 0;
	polyid = 1;
	Npts = 0; 
	nparts = 1;
	ptcount = 0;
	Build_db_Header(dbfout,0,dbTract);
	Build_db_FieldHeaders(dbfout,dbTract);
    sprintf(trtrecord," %-8d%-11s",polyid,tract[curcase].Id);
	fwrite(&trtrecord,sizeof(trtrecord)-1,1,dbfout);
	if (tract[0].Flip == 0)
	{
		curX = tract[0].Tolong;
		curY = tract[0].Tolat;		
		Pts[Npts].Longitude = tract[curcase].Frlong;
		Pts[Npts].Latitude = tract[curcase].Frlat;
		Npts++;
		Get_Shape_Points(tract[curcase].Tlid, tract[curcase].Flip);
		Pts[Npts].Longitude = tract[curcase].Tolong;
		Pts[Npts].Latitude = tract[curcase].Tolat;
		Npts++;
		tract[curcase].Chosen = 1;		
	}
	else
	{
		curX = tract[0].Frlong;
		curY = tract[0].Frlat;		
		Pts[Npts].Longitude = tract[curcase].Tolong;
		Pts[Npts].Latitude = tract[curcase].Tolat;
		Npts++;
		Get_Shape_Points(tract[curcase].Tlid, tract[curcase].Flip);
		Pts[Npts].Longitude = tract[curcase].Frlong;
		Pts[Npts].Latitude = tract[curcase].Frlat;
		Npts++;
		tract[curcase].Chosen = 1;		
	}
	ptcount += Npts;
	
    fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
	
	if (Pts[0].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < CurrentMinY)
		CurrentMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[0].Latitude;	
	if (Pts[0].Longitude < FileMinX)
		FileMinX = Pts[0].Longitude;
	if (Pts[0].Longitude > FileMaxX)
		FileMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < FileMinY)
		FileMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > FileMaxY)
		FileMaxY = Pts[0].Latitude;

	if (Pts[Npts-1].Longitude < CurrentMinX)
		CurrentMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < CurrentMinY)
		CurrentMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[Npts-1].Latitude;	
	if (Pts[Npts-1].Longitude < FileMinX)
		FileMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > FileMaxX)
		FileMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < FileMinY)
		FileMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > FileMaxY)
		FileMaxY = Pts[Npts-1].Latitude;		
	n = 1;
    while (n < written)
	{
		printf("\n Have written %ld of %ld tract boundary lines",n, written);
		found = 0;
		for (i = 1; i < written; i++)
         {
			Npts = 0;
			if (tract[i].Chosen != 0)
				continue;
			if (tract[i].Flip == 0)
			{
				if ((tract[i].Frlong == curX) && (tract[i].Frlat == curY))
				{                          
					if (strcmp(tract[i].Id,tract[curcase].Id) != 0)
						continue;	            
					Get_Shape_Points(tract[i].Tlid,tract[i].Flip);
					Pts[Npts].Longitude = tract[i].Tolong;
					Pts[Npts].Latitude = tract[i].Tolat;
					Npts++;
					n++;
					tract[i].Chosen = 1;            
					found = 1;                      
					curX = tract[i].Tolong;
					curY = tract[i].Tolat;                
					curcase = i;
					break;
				}
			}
			else
			{
				if ((tract[i].Tolong == curX) && (tract[i].Tolat == curY))
				{
					if (strcmp(tract[i].Id,tract[curcase].Id) != 0)
						continue;	            
					Get_Shape_Points(tract[i].Tlid,tract[i].Flip);
					Pts[Npts].Longitude = tract[i].Frlong;
					Pts[Npts].Latitude = tract[i].Frlat;
					Npts++;
					n++;
					curX = tract[i].Frlong;
					curY = tract[i].Frlat;                        
					tract[i].Chosen = 1;	
					found = 1;          
					curcase = i;
					break;
				}
			}
        }//close for loop
		if (found == 0) //initialize new case, eg, new ring or new poly
		{			
			fwrite(&ptcount,sizeof(int),1,headtemp);
			ptcount = 0;
			for (i = 0; i < written; i++) //check for new ring in poly
            {                    
         		if (tract[i].Chosen != 0)
					continue;             		
				if (strcmp(tract[i].Id, tract[curcase].Id) != 0)
					continue;
				//if we get here it is a new ring in current poly
				found = 1;
				nparts++;
				Npts = 0;
				if (tract[i].Flip == 0)
				{
					Pts[Npts].Longitude = tract[i].Frlong;
					Pts[Npts].Latitude = tract[i].Frlat;
					Npts++;
					Get_Shape_Points(tract[i].Tlid,tract[i].Flip);
					Pts[Npts].Longitude = tract[i].Tolong;
					Pts[Npts].Latitude = tract[i].Tolat;
					Npts++;			
    				n++;
					tract[i].Chosen = 1;
    		   		curX = tract[i].Tolong;
    				curY = tract[i].Tolat;
					curcase = i;
					break;
				}
				else
				{
					Pts[Npts].Longitude = tract[i].Tolong;
					Pts[Npts].Latitude = tract[i].Tolat;
					Npts++;
					Get_Shape_Points(tract[i].Tlid,tract[i].Flip);
					Pts[Npts].Longitude = tract[i].Frlong;
					Pts[Npts].Latitude = tract[i].Frlat;
					Npts++;			
					n++;
					tract[i].Chosen = 1;
    		   		curX = tract[i].Frlong;
    				curY = tract[i].Frlat;
					curcase = i;
					break;
				}
    		}
    	}
		if (found == 0) // new poly, first ring
		{
			
			fwrite(&nparts,sizeof(int),1,partstemp);
			nparts = 1;
			fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
			for (i = 0; i < written; i++)//first check for new ring in current poly
            {                    
         		if (tract[i].Chosen != 0)
					continue;             
				polyid++;
				sprintf(trtrecord," %-8d%-11s",polyid,tract[i].Id);
				fwrite(&trtrecord,sizeof(trtrecord)-1,1,dbfout);    		
				Npts = 0;
				if (tract[i].Flip == 0)
				{
					Pts[Npts].Longitude = tract[i].Frlong;
					Pts[Npts].Latitude = tract[i].Frlat;
					Npts++;
					Get_Shape_Points(tract[i].Tlid,tract[i].Flip);
					Pts[Npts].Longitude = tract[i].Tolong;
					Pts[Npts].Latitude = tract[i].Tolat;
					Npts++;					
					n++;
					tract[i].Chosen = 1;            
					found = 1;                      
					curX = tract[i].Tolong;
					curY = tract[i].Tolat;                
					curcase = i;
					break;					
				}
				else
				{
					Pts[Npts].Longitude = tract[i].Tolong;
					Pts[Npts].Latitude = tract[i].Tolat;
					Npts++;
					Get_Shape_Points(tract[i].Tlid,tract[i].Flip);
					Pts[Npts].Longitude = tract[i].Frlong;
					Pts[Npts].Latitude = tract[i].Frlat;
					Npts++;				
					n++;
					curX = tract[i].Frlong;
					curY = tract[i].Frlat;                        
					tract[i].Chosen = 1;		
					found = 1;          
					curcase = i;	
					break;					
				}	
			}
		}
		//by now found should be 1
		if (found == 0)
		{
			printf("ERROR - found is zero");
			exit(1);
		}
		ptcount += Npts;
		fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
		if (Pts[0].Longitude < CurrentMinX)
			CurrentMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < CurrentMinY)
			CurrentMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[0].Latitude;	
		if (Pts[0].Longitude < FileMinX)
			FileMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > FileMaxX)
			FileMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < FileMinY)
			FileMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > FileMaxY)
			FileMaxY = Pts[0].Latitude;

		if (Pts[Npts-1].Longitude < CurrentMinX)
			CurrentMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < CurrentMinY)
			CurrentMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[Npts-1].Latitude;	
		if (Pts[Npts-1].Longitude < FileMinX)
			FileMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > FileMaxX)
			FileMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < FileMinY)
			FileMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > FileMaxY)
			FileMaxY = Pts[Npts-1].Latitude;		
	}//close while loop
	fwrite(&ptcount,sizeof(int),1,headtemp);
	fwrite(&nparts,sizeof(int),1,partstemp);
	fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
	fclose(boxtemp);
	fclose(headtemp);
	fclose(ptstemp);
	fclose(partstemp);
	printf("\n Have written %ld of %ld tract boundary lines",n, written);
	write_eof(dbfout);
	rewind(dbfout);
	Build_db_Header(dbfout,polyid,dbTract);
	Build_Poly_Shape("trt");
    fclose(dbfout);
	free(tract);
}
void Match_Poly_Lines_Group()
{
	int polyid, found, i, nparts, ptcount;
	long num, n, written, curcase;
	BlockGroup_Border_Type *group;
	double  curX, curY;	
    FILE  *dbfout, *ptstemp, *headtemp, *partstemp, *boxtemp;
	char fname[14];
	char grprecord[22]; //22 is size of group record
	if (Polycounts[2] == 0)
		return;
	
	sprintf(fname,"grp%s.dbf",Fipscode);
    dbfout = fopen(fname,"wb");
	ptstemp = fopen("pts.tmp","wb");
	headtemp = fopen("head.tmp","wb");
	boxtemp = fopen("box.tmp","wb");
	partstemp = fopen("parts.tmp","wb");

	group = (BlockGroup_Border_Type *)calloc(Polycounts[2],sizeof(BlockGroup_Border_Type));
	written = 0;
	for (num = 0; num < Count3; num++)
	{
		if (Type3s[num].BorderType[2] == 0)
			continue;
		//we know it is a border type 1 line		
		if (strcmp(Type3s[num].State90l,Type3s[num].State90r) != 0)
		{//county-group boundaries are a special case
			if (strcmp(Type3s[num].State90l,"  ") != 0)
			{//left case
				sprintf(group[written].Id,"%s%s%s%c",Type3s[num].State90l,Type3s[num].Coun90l,Type3s[num].Ctbnal,Type3s[num].Blk90l[0]);
				sprintf(group[written].Tlid,"%s",Type3s[num].Tlid);
				group[written].Frlong = Type1s[num].Frlong;
				group[written].Frlat = Type1s[num].Frlat;
				group[written].Tolong = Type1s[num].Tolong;
				group[written].Tolat = Type1s[num].Tolat;
				group[written].Chosen = 0;
				group[written].Flip = 1;
				written++;
			}
			else
			{//rightcase of county-group
				sprintf(group[written].Id,"%s%s%s%c",Type3s[num].State90r,Type3s[num].Coun90r,Type3s[num].Ctbnar,Type3s[num].Blk90r[0]);
				sprintf(group[written].Tlid,"%s",Type3s[num].Tlid);
				group[written].Frlong = Type1s[num].Frlong;
				group[written].Frlat = Type1s[num].Frlat;
				group[written].Tolong = Type1s[num].Tolong;
				group[written].Tolat = Type1s[num].Tolat;
				group[written].Chosen = 0;
				group[written].Flip = 0;
				written++;
			}
		}
		else //internal group line, has both left and right
		{//do lefts
			sprintf(group[written].Id,"%s%s%s%c",Type3s[num].State90l,Type3s[num].Coun90l,Type3s[num].Ctbnal,Type3s[num].Blk90l[0]);
			sprintf(group[written].Tlid,"%s",Type3s[num].Tlid);
			group[written].Frlong = Type1s[num].Frlong;
			group[written].Frlat = Type1s[num].Frlat;
			group[written].Tolong = Type1s[num].Tolong;
			group[written].Tolat = Type1s[num].Tolat;
			group[written].Chosen = 0;
			group[written].Flip = 1;
			written++;
			//now do rights
			sprintf(group[written].Id,"%s%s%s%c",Type3s[num].State90r,Type3s[num].Coun90r,Type3s[num].Ctbnar,Type3s[num].Blk90r[0]);
			sprintf(group[written].Tlid,"%s",Type3s[num].Tlid);
			group[written].Frlong = Type1s[num].Frlong;
			group[written].Frlat = Type1s[num].Frlat;
			group[written].Tolong = Type1s[num].Tolong;
			group[written].Tolat = Type1s[num].Tolat;
			group[written].Chosen = 0;
			group[written].Flip = 0;
			written++;
		}
		if (written > Polycounts[2])
		{
			printf("\nthe number of county border lines exceeds the count");
			exit(1);
		}
	}
	//time to chain
	printf("\nsorting block group lines by group id");
	qsort((void *)group,Polycounts[2],sizeof(BlockGroup_Border_Type),(compfn)CompareGroup);
	FileMinX = FileMinY = LARGE;
	FileMaxX = FileMaxY = -LARGE;
	CurrentMinX = CurrentMinY = LARGE;
	CurrentMaxX = CurrentMaxY = LARGE;
	curcase = 0;
	polyid = 1;
	Npts = 0; 
	nparts = 1;
	ptcount = 0;
	Build_db_Header(dbfout,0,dbGroup);
	Build_db_FieldHeaders(dbfout,dbGroup);
    sprintf(grprecord," %-8d%-12s",polyid,group[curcase].Id);
	fwrite(&grprecord,sizeof(grprecord)-1,1,dbfout);
	if (group[0].Flip == 0)
	{
		curX = group[curcase].Tolong;
		curY = group[curcase].Tolat;
		Pts[Npts].Longitude = group[curcase].Frlong;
		Pts[Npts].Latitude = group[curcase].Frlat;
		Npts++;	
		Get_Shape_Points(group[curcase].Tlid,group[curcase].Flip);
		Pts[Npts].Longitude = group[curcase].Tolong;
		Pts[Npts].Latitude = group[curcase].Tolat;
		Npts++;	
		group[curcase].Chosen = 1;
	}
	else
	{
		curX = group[curcase].Frlong;
		curY = group[curcase].Frlat;
		Pts[Npts].Longitude = group[curcase].Frlong;
		Pts[Npts].Latitude = group[curcase].Frlat;
		Npts++;	
		Get_Shape_Points(group[curcase].Tlid,group[curcase].Flip);
		Pts[Npts].Longitude = group[curcase].Frlong;
		Pts[Npts].Latitude = group[curcase].Frlat;
		Npts++;	
		group[curcase].Chosen = 1;
	}
	ptcount += Npts;
	fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);	
	if (Pts[0].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < CurrentMinY)
		CurrentMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[0].Latitude;	
	if (Pts[0].Longitude < FileMinX)
		FileMinX = Pts[0].Longitude;
	if (Pts[0].Longitude > FileMaxX)
		FileMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < FileMinY)
		FileMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > FileMaxY)
		FileMaxY = Pts[0].Latitude;

	if (Pts[Npts-1].Longitude < CurrentMinX)
		CurrentMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < CurrentMinY)
		CurrentMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[Npts-1].Latitude;	
	if (Pts[Npts-1].Longitude < FileMinX)
		FileMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > FileMaxX)
		FileMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < FileMinY)
		FileMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > FileMaxY)
		FileMaxY = Pts[Npts-1].Latitude;		
	n = 1;
    while (n < written)
	{
		printf("\n Have written %ld of %ld block group boundary lines",n, written);
		found = 0;
		for (i = 1; i < written; i++)
			{
			Npts = 0;
			if (group[i].Chosen != 0)
				continue;
			if (group[i].Flip == 0)
			{
				if ((group[i].Frlong == curX) && (group[i].Frlat == curY))
				{                          
					if (strcmp(group[i].Id,group[curcase].Id) != 0)
						continue;	            
					Get_Shape_Points(group[i].Tlid,group[i].Flip);
					Pts[Npts].Longitude = group[i].Tolong;
					Pts[Npts].Latitude = group[i].Tolat;
					Npts++;
					n++;
					group[i].Chosen = 1;            
					found = 1;                      
					curX = group[i].Tolong;
					curY = group[i].Tolat;                
					curcase = i;
					break;
				}
			}
			else
			{
				if ((group[i].Tolong == curX) && (group[i].Tolat == curY))
				{
					if (strcmp(group[i].Id,group[curcase].Id) != 0)
						continue;	            
					Get_Shape_Points(group[i].Tlid,group[i].Flip);
					Pts[Npts].Longitude = group[i].Frlong;
					Pts[Npts].Latitude = group[i].Frlat;
					Npts++;
					n++;
					curX = group[i].Frlong;
					curY = group[i].Frlat;                        
					group[i].Chosen = 1;
					found = 1;          
					curcase = i;
					break;
				}
			}
        }//close for loop
		if (found == 0) //initialize new ring or new poly
        {
			fwrite(&ptcount,sizeof(int),1,headtemp);
			ptcount = 0;
			for (i = 0; i < written; i++)
            {                    
	         	if (group[i].Chosen != 0)
		           continue;             		
				if (strcmp(group[i].Id,group[curcase].Id) != 0)
					continue;
				//if we get here we have a new ring in current polygon
			    found = 1;
				nparts++;
				Npts = 0;
				if (group[i].Flip == 0)
				{
					Pts[Npts].Longitude = group[i].Frlong;
					Pts[Npts].Latitude = group[i].Frlat;
					Npts++;
		    		Get_Shape_Points(group[i].Tlid,group[i].Flip);
					Pts[Npts].Longitude = group[i].Tolong;
					Pts[Npts].Latitude = group[i].Tolat;
					Npts++;
    				n++;    
    				group[i].Chosen = 1;
					found = 1;
		    		curX = group[i].Tolong;
    				curY = group[i].Tolat;
					curcase = i;
					break;
				}
				else
				{
					Pts[Npts].Longitude = group[i].Tolong;
					Pts[Npts].Latitude = group[i].Tolat;
					Npts++;
		    		Get_Shape_Points(group[i].Tlid,group[i].Flip);
					Pts[Npts].Longitude = group[i].Frlong;
					Pts[Npts].Latitude = group[i].Frlat;
					Npts++;
    				n++;    
    				group[i].Chosen = 1;
					found = 1;
		    		curX = group[i].Frlong;
    				curY = group[i].Frlat;
					curcase = i;
					break;
				}
    		}//close i on for
    	}//close if on found		
		if (found == 0) //new poly, first ring
		{
			fwrite(&nparts,sizeof(int),1,partstemp);
			nparts = 1;
			fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
			for (i = 0; i < written; i++)
			{
				if (group[i].Chosen != 0)
					continue;
				polyid++;
				sprintf(grprecord," %-8d%-12s",polyid,group[i].Id);
				fwrite(&grprecord,sizeof(grprecord)-1,1,dbfout);
				Npts = 0;
				if (group[i].Flip == 0)
				{
					Pts[Npts].Longitude = group[i].Frlong;
					Pts[Npts].Latitude = group[i].Frlat;
					Npts++;
		    		Get_Shape_Points(group[i].Tlid,group[i].Flip);
					Pts[Npts].Longitude = group[i].Tolong;
					Pts[Npts].Latitude = group[i].Tolat;
					Npts++;
    				n++;    
    				group[i].Chosen = 1;
					found = 1;
		    		curX = group[i].Tolong;
    				curY = group[i].Tolat;
					curcase = i;
					break;
				}
				else
				{
					Pts[Npts].Longitude = group[i].Tolong;
					Pts[Npts].Latitude = group[i].Tolat;
					Npts++;
		    		Get_Shape_Points(group[i].Tlid,group[i].Flip);
					Pts[Npts].Longitude = group[i].Frlong;
					Pts[Npts].Latitude = group[i].Frlat;
					Npts++;
    				n++;    
    				group[i].Chosen = 1;
					found = 1;
		    		curX = group[i].Frlong;
    				curY = group[i].Frlat;
					curcase = i;
					break;
				}
			}
		}
		//by now found should be 1
		if (found == 0)
		{
			printf("ERROR - found is zero");
			exit(1);
		}
		ptcount += Npts;
	
		fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
		if (Pts[0].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < CurrentMinY)
			CurrentMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[0].Latitude;	
		if (Pts[0].Longitude < FileMinX)
			FileMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > FileMaxX)
			FileMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < FileMinY)
			FileMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > FileMaxY)
			FileMaxY = Pts[0].Latitude;

		if (Pts[Npts-1].Longitude < CurrentMinX)
			CurrentMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < CurrentMinY)
			CurrentMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[Npts-1].Latitude;	
		if (Pts[Npts-1].Longitude < FileMinX)
			FileMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > FileMaxX)
			FileMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < FileMinY)
			FileMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > FileMaxY)
			FileMaxY = Pts[Npts-1].Latitude;		
	}//close while
	fwrite(&ptcount,sizeof(int),1,headtemp);
	fwrite(&nparts,sizeof(int),1,partstemp);
	fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
	fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
	fclose(boxtemp);
	fclose(headtemp);
	fclose(ptstemp);
	fclose(partstemp);
	printf("\n Have written %ld of %ld block group boundary lines",n, written);
	write_eof(dbfout);
	rewind(dbfout);
	Build_db_Header(dbfout,polyid,dbGroup);
    fclose(dbfout);
	free(group);
	Build_Poly_Shape("grp");	
}
void Match_Poly_Lines_Block()
{
	int polyid, found, i, nparts, ptcount;
	long num, n, written, curcase;
	Block_Border_Type *block;
	double  curX, curY;	
    FILE  *genout, *dbfout;
	FILE  *ptstemp, *headtemp, *partstemp, *boxtemp;
	char fname[14];
	char blkrecord[25];
	if (Polycounts[3] == 0)
		return;
	
	genout = fopen("block.gen","w");
	sprintf(fname,"blk%s.dbf",Fipscode);
    dbfout = fopen(fname,"wb");
	ptstemp = fopen("pts.tmp","wb");
	headtemp = fopen("head.tmp","wb");
	boxtemp = fopen("box.tmp","wb");
	partstemp = fopen("parts.tmp","wb");

    block = (Block_Border_Type *)calloc(Polycounts[3],sizeof(Block_Border_Type));
	written = 0;
	for (num = 0; num < Count3; num++)
	{
		if (Type3s[num].BorderType[3] == 0)
			continue;
		//we know it is a border type 3 line		
		if (strcmp(Type3s[num].State90l,Type3s[num].State90r) != 0)
		{//county-block boundaries are a special case
			if (strcmp(Type3s[num].State90l,"  ") != 0)
			{//left case
				sprintf(block[written].Id,"%s%s%s%s",Type3s[num].State90l,Type3s[num].Coun90l,Type3s[num].Ctbnal,Type3s[num].Blk90l);
				sprintf(block[written].Tlid,"%s",Type3s[num].Tlid);
				block[written].Frlong = Type1s[num].Frlong;
				block[written].Frlat = Type1s[num].Frlat;
				block[written].Tolong = Type1s[num].Tolong;
				block[written].Tolat = Type1s[num].Tolat;
				block[written].Chosen = 0;
				block[written].Flip = 1;
				written++;
			}
			else
			{//rightcase of county-block
				sprintf(block[written].Id,"%s%s%s%s",Type3s[num].State90r,Type3s[num].Coun90r,Type3s[num].Ctbnar,Type3s[num].Blk90r);
				sprintf(block[written].Tlid,"%s",Type3s[num].Tlid);
				block[written].Frlong = Type1s[num].Frlong;
				block[written].Frlat = Type1s[num].Frlat;
				block[written].Tolong = Type1s[num].Tolong;
				block[written].Tolat = Type1s[num].Tolat;
				block[written].Chosen = 0;
				block[written].Flip = 0;
				written++;
			}
		}
		else //internal block line, has both left and right
		{//do lefts
			sprintf(block[written].Id,"%s%s%s%s",Type3s[num].State90l,Type3s[num].Coun90l,Type3s[num].Ctbnal,Type3s[num].Blk90l);
			sprintf(block[written].Tlid,"%s",Type3s[num].Tlid);
			block[written].Frlong = Type1s[num].Frlong;
			block[written].Frlat = Type1s[num].Frlat;
			block[written].Tolong = Type1s[num].Tolong;
			block[written].Tolat = Type1s[num].Tolat;
			block[written].Chosen = 0;
			block[written].Flip = 1;
			written++;
			//now do rights
			sprintf(block[written].Id,"%s%s%s%s",Type3s[num].State90r,Type3s[num].Coun90r,Type3s[num].Ctbnar,Type3s[num].Blk90r);
			sprintf(block[written].Tlid,"%s",Type3s[num].Tlid);
			block[written].Frlong = Type1s[num].Frlong;
			block[written].Frlat = Type1s[num].Frlat;
			block[written].Tolong = Type1s[num].Tolong;
			block[written].Tolat = Type1s[num].Tolat;
			block[written].Chosen = 0;
			block[written].Flip = 0;
			written++;
		}
		if (written > Polycounts[3])
		{
			printf("\nthe number of county border lines exceeds the count");
			exit(1);
		}
	}
	printf("\nsorting block  lines by block id");
	qsort((void *)block,Polycounts[3],sizeof(Block_Border_Type),(compfn)CompareBlock);
	FileMinX = FileMinY = LARGE;
	FileMaxX = FileMaxY = -LARGE;
	CurrentMinX = CurrentMinY = LARGE;
	CurrentMaxX = CurrentMaxY = LARGE;
	curcase = 0;
	polyid = 1;
	Npts = 0; 
	nparts = 1;
	ptcount = 0;
	Build_db_Header(dbfout,0,dbBlock);
	Build_db_FieldHeaders(dbfout,dbBlock);
    sprintf(blkrecord," %-8d%-15s",polyid,block[curcase].Id);
	fwrite(&blkrecord,sizeof(blkrecord)-1,1,dbfout);
	if (block[0].Flip == 0)
	{
		curX = block[0].Tolong;
		curY = block[0].Tolat;
		Pts[Npts].Longitude = block[curcase].Frlong;
		Pts[Npts].Latitude = block[curcase].Frlat;
		Npts++;
		Get_Shape_Points(block[curcase].Tlid,block[curcase].Flip);
		Pts[Npts].Longitude = block[curcase].Tolong;
		Pts[Npts].Latitude = block[curcase].Tolat;
		Npts++;
		block[curcase].Chosen = 1;
	}
	else
	{
		curX = block[0].Frlong;
		curY = block[0].Frlat;
		Pts[Npts].Longitude = block[curcase].Tolong;
		Pts[Npts].Latitude = block[curcase].Tolat;
		Npts++;
		Get_Shape_Points(block[curcase].Tlid,block[curcase].Flip);
		Pts[Npts].Longitude = block[curcase].Frlong;
		Pts[Npts].Latitude = block[curcase].Frlat;
		Npts++;
		block[curcase].Chosen = 1;
	}
	ptcount += Npts;
	fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);	
	if (Pts[0].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < CurrentMinY)
		CurrentMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[0].Latitude;	
	if (Pts[0].Longitude < FileMinX)
		FileMinX = Pts[0].Longitude;
	if (Pts[0].Longitude > FileMaxX)
		FileMaxX = Pts[0].Longitude;
	if (Pts[0].Latitude < FileMinY)
		FileMinY = Pts[0].Latitude;
	if (Pts[0].Latitude > FileMaxY)
		FileMaxY = Pts[0].Latitude;

	if (Pts[Npts-1].Longitude < CurrentMinX)
		CurrentMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > CurrentMaxX)
		CurrentMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < CurrentMinY)
		CurrentMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > CurrentMaxY)
		CurrentMaxY = Pts[Npts-1].Latitude;	
	if (Pts[Npts-1].Longitude < FileMinX)
		FileMinX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Longitude > FileMaxX)
		FileMaxX = Pts[Npts-1].Longitude;
	if (Pts[Npts-1].Latitude < FileMinY)
		FileMinY = Pts[Npts-1].Latitude;
	if (Pts[Npts-1].Latitude > FileMaxY)
		FileMaxY = Pts[Npts-1].Latitude;		
	n = 1;
    while (n < written)
	{
		printf("\n Have written %ld of %ld block boundary lines",n, written);
		found = 0;
		for (i = 1; i < written; i++)
         {
			Npts = 0;
			if (block[i].Chosen != 0)
				continue;
			if (block[i].Flip == 0)
			{
				if ((block[i].Frlong == curX) && (block[i].Frlat == curY))
				{                          
					if (strcmp(block[i].Id,block[curcase].Id) != 0)
						continue;	            
					Get_Shape_Points(block[i].Tlid,block[i].Flip);
					Pts[Npts].Longitude = block[i].Tolong;
					Pts[Npts].Latitude = block[i].Tolat;
					Npts++;		
					n++;
					block[i].Chosen = 1;            
					found = 1;                      
					curX = block[i].Tolong;
					curY = block[i].Tolat;                
					curcase = i;
					break;
				}
			}
			else
			{
				if ((block[i].Tolong == curX) && (block[i].Tolat == curY))
				{
					if (strcmp(block[i].Id,block[curcase].Id) != 0)
						continue;	       
					Get_Shape_Points(block[i].Tlid,block[i].Flip);
					Pts[Npts].Longitude = block[i].Frlong;
					Pts[Npts].Latitude = block[i].Frlat;
					Npts++;
					n++;
					curX = block[i].Frlong;
					curY = block[i].Frlat;                        
					block[i].Chosen = 1;
					found = 1;          
					curcase = i;
					break;
				}
			}
		}//close for loop		
		if (found == 0) //initialize new case, eg, new ring or poly
		{
			fwrite(&ptcount,sizeof(int),1,headtemp);
			ptcount = 0;
			for (i = 0; i < written; i++)
            {                    
         		if (block[i].Chosen != 0)
				   continue;           
				if (strcmp(block[i].Id, block[curcase].Id) != 0)
					continue;
				//we have a new ring in current polygon
				found = 1;
				nparts++;
				Npts = 0;
				if (block[i].Flip == 0)
				{
					Pts[Npts].Longitude = block[i].Frlong;
					Pts[Npts].Latitude = block[i].Frlat;
					Npts++;
					Get_Shape_Points(block[i].Tlid,block[i].Flip);
					Pts[Npts].Longitude = block[i].Tolong;
					Pts[Npts].Latitude = block[i].Tolat;
					Npts++;
					n++;                 
					block[i].Chosen = 1;
					found = 1;
    		  		curX = block[i].Tolong;
    				curY = block[i].Tolat;
					curcase = i;
			   		break;
    			}
				else
				{
					Pts[Npts].Longitude = block[i].Tolong;
					Pts[Npts].Latitude = block[i].Tolat;
					Npts++;
					Get_Shape_Points(block[i].Tlid,block[i].Flip);
					Pts[Npts].Longitude = block[i].Frlong;
					Pts[Npts].Latitude = block[i].Frlat;
					Npts++;
					n++;                 
					block[i].Chosen = 1;
					found = 1;
    		  		curX = block[i].Frlong;
    				curY = block[i].Frlat;
					curcase = i;
			   		break;
				}
    		}//loop on i
		}//if on found
		if (found == 0) // new poly, first ring
		{
			fwrite(&nparts,sizeof(int),1, partstemp);
			nparts = 1;
			fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
			fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
			for (i = 0; i < written; i++)
			{
				if (block[i].Chosen != 0)
					continue;
				polyid++;
				sprintf(blkrecord," %-8d%-15s",polyid,block[i].Id);
				fwrite(&blkrecord,sizeof(blkrecord)-1,1,dbfout);
				Npts = 0;
				if (block[i].Flip == 0)
				{
					Pts[Npts].Longitude = block[i].Frlong;
					Pts[Npts].Latitude = block[i].Frlat;
					Npts++;
					Get_Shape_Points(block[i].Tlid,block[i].Flip);
					Pts[Npts].Longitude = block[i].Tolong;
					Pts[Npts].Latitude = block[i].Tolat;
					Npts++;
					n++;                 
					block[i].Chosen = 1;
					found = 1;
    		  		curX = block[i].Tolong;
    				curY = block[i].Tolat;
					curcase = i;
			   		break;
    			}
				else
				{
					Pts[Npts].Longitude = block[i].Tolong;
					Pts[Npts].Latitude = block[i].Tolat;
					Npts++;
					Get_Shape_Points(block[i].Tlid,block[i].Flip);
					Pts[Npts].Longitude = block[i].Frlong;
					Pts[Npts].Latitude = block[i].Frlat;
					Npts++;
					n++;                 
					block[i].Chosen = 1;
					found = 1;
    		  		curX = block[i].Frlong;
    				curY = block[i].Frlat;
					curcase = i;
			   		break;
				}
			}
		}
		//by now found should be 1
		if (found == 0)
		{
			printf("ERROR - found is zero");
			exit(1);
		}
		ptcount += Npts;
		fwrite(Pts,sizeof(Geographic_Coordinate),Npts,ptstemp);
		if (Pts[0].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < CurrentMinY)
			CurrentMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[0].Latitude;	
		if (Pts[0].Longitude < FileMinX)
			FileMinX = Pts[0].Longitude;
		if (Pts[0].Longitude > FileMaxX)
			FileMaxX = Pts[0].Longitude;
		if (Pts[0].Latitude < FileMinY)
			FileMinY = Pts[0].Latitude;
		if (Pts[0].Latitude > FileMaxY)
			FileMaxY = Pts[0].Latitude;

		if (Pts[Npts-1].Longitude < CurrentMinX)
			CurrentMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > CurrentMaxX)
			CurrentMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < CurrentMinY)
			CurrentMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > CurrentMaxY)
			CurrentMaxY = Pts[Npts-1].Latitude;	
		if (Pts[Npts-1].Longitude < FileMinX)
			FileMinX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Longitude > FileMaxX)
			FileMaxX = Pts[Npts-1].Longitude;
		if (Pts[Npts-1].Latitude < FileMinY)
			FileMinY = Pts[Npts-1].Latitude;
		if (Pts[Npts-1].Latitude > FileMaxY)
			FileMaxY = Pts[Npts-1].Latitude;		
}//close while loop
fwrite(&ptcount,sizeof(int),1,headtemp);
fwrite(&nparts,sizeof(int),1,partstemp);
fwrite(&CurrentMinX,sizeof(double),1,boxtemp);
fwrite(&CurrentMinY,sizeof(double),1,boxtemp);
fwrite(&CurrentMaxX,sizeof(double),1,boxtemp);
fwrite(&CurrentMaxY,sizeof(double),1,boxtemp);
fclose(boxtemp);
fclose(headtemp);
fclose(ptstemp);
fclose(partstemp);
printf("\n Have written %ld of %ld block boundary lines",n, written);
write_eof(dbfout);
rewind(dbfout);
Build_db_Header(dbfout,polyid,dbBlock);
fclose(dbfout);
free(block);
Build_Poly_Shape("blk");
}

void Parse_Type1_Record(long k)
{
    Nscanf(Record,1,"%d",&Type1s[k].RecordType);
    Nscanf(&Record[1],4,"%d",&Type1s[k].Version);
    Ascanf(&Record[5],10,Type1s[k].Tlid);
    Nscanf(&Record[15],1,"%d",&Type1s[k].Side1);
    Nscanf(&Record[16],1,"%c",&Type1s[k].Source);
    Ascanf(&Record[17],2,Type1s[k].Fedirp);
    Ascanf(&Record[19],30,Type1s[k].Fename);
    Ascanf(&Record[49],4,Type1s[k].Fetype);
    Ascanf(&Record[53],2,Type1s[k].Fedirs);
    Ascanf(&Record[55],3,Type1s[k].Cfcc);
    Ascanf(&Record[58],11,Type1s[k].Fraddl);
    Ascanf(&Record[69],11,Type1s[k].Toaddl);
    Ascanf(&Record[80],11,Type1s[k].Fraddr);
    Ascanf(&Record[91],11,Type1s[k].Toaddr);
    Nscanf(&Record[102],1,"%d",&Type1s[k].Friaddl);
    Nscanf(&Record[103],1,"%d",&Type1s[k].Toiaddl);
    Nscanf(&Record[104],1,"%d",&Type1s[k].Friaddr);
    Nscanf(&Record[105],1,"%d",&Type1s[k].Toiaddr);
    Ascanf(&Record[106],5,Type1s[k].Zipl);
    Ascanf(&Record[111],5,Type1s[k].Zipr);
    Ascanf(&Record[116],5,Type1s[k].Fairl);
    Ascanf(&Record[121],5,Type1s[k].Fairr);
    Nscanf(&Record[126],1,"%d",&Type1s[k].Trustl);
    Nscanf(&Record[127],1,"%d",&Type1s[k].Trustr);
    Nscanf(&Record[128],1,"%d",&Type1s[k].Census1);
    Nscanf(&Record[129],1,"%d",&Type1s[k].Census2);
    Ascanf(&Record[130],2,Type1s[k].Statel);
    Ascanf(&Record[132],2,Type1s[k].Stater);
    Ascanf(&Record[134],3,Type1s[k].Countyl);
    Ascanf(&Record[137],3,Type1s[k].Countyr);
    Ascanf(&Record[140],5,Type1s[k].Fmcdl);
    Ascanf(&Record[145],5,Type1s[k].Fmcdr);
    Ascanf(&Record[150],5,Type1s[k].Fsmcdl);
    Ascanf(&Record[155],5,Type1s[k].Fsmcdr);
    Ascanf(&Record[160],5,Type1s[k].Fpll);
    Ascanf(&Record[165],5,Type1s[k].Fplr);
    Ascanf(&Record[170],6,Type1s[k].Ctbnal);
    Ascanf(&Record[176],6,Type1s[k].Ctbnar);
    Ascanf(&Record[182],4,Type1s[k].Blkl);
    Ascanf(&Record[186],4,Type1s[k].Blkr);
    Nscanf(&Record[190],10,"%lf",&Type1s[k].Frlong);
    Nscanf(&Record[200],9,"%lf",&Type1s[k].Frlat);
    Nscanf(&Record[209],10,"%lf",&Type1s[k].Tolong);
    Nscanf(&Record[219],9,"%lf",&Type1s[k].Tolat);
	Type1s[k].Frlong /= 1000000;
	Type1s[k].Frlat /= 1000000;
	Type1s[k].Tolong /= 1000000;
	Type1s[k].Tolat /= 1000000;
}
void Parse_Type2_Record(long k)                                       
{     
    int position, i;
    Nscanf(Record,1,"%d",&Type2s[k].RecordType);
    Nscanf(&Record[1],4,"%d",&Type2s[k].Version);
    Ascanf(&Record[5],10,Type2s[k].Tlid);
    Ascanf(&Record[15],3,Type2s[k].Rtsq);
    for (i=0; i<10; i++)
      {              
      position = 18 + (i * 19);
      Nscanf(&Record[position],10,"%lf",&Type2s[k].Point[i].Longitude);
      Nscanf(&Record[position + 10],9,"%lf",&Type2s[k].Point[i].Latitude);
      Type2s[k].Point[i].Longitude = Type2s[k].Point[i].Longitude/1000000;
      Type2s[k].Point[i].Latitude = Type2s[k].Point[i].Latitude/1000000;
      }
}     
void Parse_Type3_Record(long k)
{
    Nscanf(Record,1,"%d",&Type3s[num].RecordType);
    Nscanf(&Record[1],4,"%d",&Type3s[num].Version);
    Ascanf(&Record[5],10,Type3s[num].Tlid);
    Ascanf(&Record[15],2,Type3s[num].State90l);
    Ascanf(&Record[17],2,Type3s[num].State90r);
    Ascanf(&Record[19],3,Type3s[num].Coun90l);
    Ascanf(&Record[22],3,Type3s[num].Coun90r);
    Ascanf(&Record[25],5,Type3s[num].Fmcd90l);
    Ascanf(&Record[30],5,Type3s[num].Fmcd90r);
    Ascanf(&Record[35],5,Type3s[num].Fpl90l);
    Ascanf(&Record[40],5,Type3s[num].Fpl90r);
    Ascanf(&Record[45],6,Type3s[num].Ctbnal);
    Ascanf(&Record[51],6,Type3s[num].Ctbnar);    
    Ascanf(&Record[69],4,Type3s[num].Blk90l);
    Ascanf(&Record[73],4,Type3s[num].Blk90r);
    Ascanf(&Record[77],4,Type3s[num].Airl);
    Ascanf(&Record[81],4,Type3s[num].Airr);
    Ascanf(&Record[91],2,Type3s[num].Anrcl);
    Ascanf(&Record[93],2,Type3s[num].Anrcr);
    Ascanf(&Record[103],4,Type3s[num].Vtdl);
    Ascanf(&Record[107],4,Type3s[num].Vtdr);
}                                  

void Nscanf(char *source, int n, const char *format, void *target)
{
   char buffer[BUFFLEN];

   strncpy(buffer,source,n);
   buffer[n] = '\0';         
   
   
    if ((strlen(buffer) == 1) && (buffer[0] == ' '))
       strcpy(buffer,"0");
   
   if (sscanf(buffer,format,target) < 1)
       {
       fprintf(stderr, "\nXXXX Error: Numeric Conversion Failed On String %s\n", buffer);
       fprintf(stderr, "Sent string = %s", source);
       exit(1);
       }
}
void Ascanf(char * source,int  n, char * target)
{
   int i;

   for (i = 0; i < n; i++)
      {
      target[i] = source[i];
      }
   target[n] = '\0';
}
int Compare1(RecordType1 * elem1, RecordType1 * elem2)
{
	return(strcmp(elem1->Tlid,elem2->Tlid));
}
int Compare1A(RecordType1 * elem1, RecordType1 * elem2)
{
	char buff1[12],buff2[12];
	sprintf(buff1,"%c%s",elem1->Cfcc[0],elem1->Tlid);
	sprintf(buff2,"%c%s",elem2->Cfcc[0],elem2->Tlid);
	return(strcmp(buff1,buff2));
}
int Compare2(RecordType2 * elem1, RecordType2 * elem2)
{
	char astring[14], bstring[14];
    sprintf(astring,"%10s%3s",elem1->Tlid,elem1->Rtsq);
    sprintf(bstring,"%10s%3s",elem2->Tlid,elem2->Rtsq);
    return (strcmp(astring,bstring));
}
int CompareNodes(Node_type * a, Node_type * b)
{    
     if (a->Longitude > b->Longitude)
        return 1;
     if (a->Longitude == b->Longitude)
        {if (a->Latitude > b->Latitude)
            return 1;
         if (a->Latitude == b->Latitude)
            return 0;
         return -1;
        }
     return -1;      
}
int Compare3(RecordType3 * elem1, RecordType3 * elem2)
{
	return(strcmp(elem1->Tlid,elem2->Tlid));
}
int CompareTract(Tract_Border_Type * elem1, Tract_Border_Type * elem2)
{
	return(strcmp(elem1->Id,elem2->Id));
}
int CompareGroup(BlockGroup_Border_Type * elem1, BlockGroup_Border_Type * elem2)
{
	return(strcmp(elem1->Id,elem2->Id));
}
int CompareBlock(Block_Border_Type * elem1, Block_Border_Type * elem2)
{
	return(strcmp(elem1->Id,elem2->Id));
}

void Get_Shape_Points(char *lineid, int flip)
{             
	long upper, lower, halfway, position;
	int found, seqnum, i, count;
	Geographic_Coordinate *points;	
         
//	points = (Geographic_Coordinate *)calloc(MaxShapeRecords*10,sizeof(Geographic_Coordinate));	
	lower = 0L;
	upper = Count2-1;   
	found = 0;      
	position = 0L;
	while (upper - lower > 0)
      {             
       //check for match at lower
       if (strcmp(Type2s[lower].Tlid,lineid) == 0)
          {//we have a match           
          position = lower;
          found = 1;
          break;
          }
       //if no match, try upper
       if (strcmp(Type2s[upper].Tlid,lineid) == 0)
          {//we have a match
          position = upper;
          found = 1;
          break;
          }
       //the following could happen if there are no shape points.
       if ((upper - lower) == 1) 
         break;
       //if no match, try halfway   
       halfway = (long)floor((upper + lower) / 2);      
       //check for match    
       if (strcmp(Type2s[halfway].Tlid,lineid) == 0)
          {//we have a match
          position = halfway;
          found = 1;
          break;
          }
       //no match, determine new search range
       if (strcmp(Type2s[halfway].Tlid,lineid) < 0)
          {
          lower = halfway;
          }
       else
          {
          upper = halfway;
          }
       }//close while on upper
   if (found == 0)           
   {
	   //free(points);
	   return;
   }
  points = (Geographic_Coordinate *)calloc(MaxShapeRecords*10,sizeof(Geographic_Coordinate));	  
   //we have a match, need to find the first line
   sscanf(Type2s[position].Rtsq,"%d",&seqnum);
   while (seqnum > 1)
     {
     position--;
     seqnum--;
     } 
   if (strcmp(Type2s[position].Tlid,lineid) != 0)
     {
     printf("\nERROR - nonmatching Tlid values after sequence adjustment");
     exit(1);
     } 
   count  = 0; 
   while (strcmp(Type2s[position].Tlid,lineid) == 0)
      {                	 
   		  for (i = 0; i < 10; i++)
			 {
				if (Type2s[position].Point[i].Longitude == 0.0)  //reached end of current line's shape points
					break;            
				points[count].Longitude = Type2s[position].Point[i].Longitude;
				points[count].Latitude = Type2s[position].Point[i].Latitude;				
				if (points[count].Longitude < CurrentMinX)
					CurrentMinX = points[count].Longitude;
				if (points[count].Longitude > CurrentMaxX)
					CurrentMaxX = points[count].Longitude;
				if (points[count].Latitude < CurrentMinY)
					CurrentMinY = points[count].Latitude;
				if (points[count].Latitude > CurrentMaxY)
					CurrentMaxY = points[count].Latitude;
				
				if (points[count].Longitude < FileMinX)
					FileMinX = points[count].Longitude;
				if (points[count].Longitude > FileMaxX)
					FileMaxX = points[count].Longitude;
				if (points[count].Latitude < FileMinY)
					FileMinY = points[count].Latitude;
				if (points[count].Latitude > FileMaxY)
					FileMaxY = points[count].Latitude;
				count++;                     
			 }          
		  position++;
		  if (position >= Count2)
			  break;
      }                    
   
   if (flip == 1)
     {
     for (i = count-1; i >= 0; i--)
		 Pts[Npts++] = points[i];
	 }
   else
     {
     for (i = 0; i < count; i++)                                      
		 Pts[Npts++] = points[i];
	 }
   free(points);
   
   return;
} 
void Build_Poly_Shape(char *type)
{
	FILE *polyshp, *polyshx, *ptstemp, *headtemp, *partstemp, *boxtemp;
	char fname[13];
	int oldposition, nparts, recnum, sumpts;
	int *partnpts, i;
	shape_poly_t *curpoly;
	shape_header_t *polyshphead;
	shape_record_header_t *rechead;
	shape_index_record_t *curindex;


	sprintf(fname,"%s%s.shp",type,Fipscode);
	polyshp = fopen(fname,"wb");
    sprintf(fname,"%s%s.shx",type,Fipscode);
	polyshx = fopen(fname,"wb");
	ptstemp = fopen("pts.tmp","rb");
	headtemp = fopen("head.tmp","rb");
	boxtemp = fopen("box.tmp","rb");
	partstemp = fopen("parts.tmp","rb");
	polyshphead = Create_Shape_Header(SHP_POLYGON);
	SHP_Write_Header(polyshp,polyshphead);
	SHP_Write_Header(polyshx,polyshphead); 		
	Position = 100; 
	oldposition = Position;
	recnum = 1;
	while (fread(&nparts,sizeof(int),1,partstemp) == 1)
	{
		partnpts = (int *)calloc(nparts,sizeof(int));	
		fread(partnpts,sizeof(int),nparts,headtemp);
		sumpts = 0;
		for (i = 0; i < nparts; i++)
		{		
			sumpts += partnpts[i];
		}
		rechead =(shape_record_header_t *)calloc(1,sizeof(shape_record_header_t));
		rechead->num = recnum;
		rechead->length = (4 + 32 + 4 + 4 + (4 * nparts) + (16 * sumpts) );			
		SHP_Write_Record_Header(polyshp,rechead);
		free(rechead);
		recnum++;
		curpoly = (shape_poly_t *)calloc(1,sizeof(shape_poly_t));
		curpoly->shapeType = SHP_POLYGON;
		fread(&curpoly->xMin,sizeof(double),1,boxtemp);
		fread(&curpoly->yMin,sizeof(double),1,boxtemp);
		fread(&curpoly->xMax,sizeof(double),1,boxtemp);
		fread(&curpoly->yMax,sizeof(double),1,boxtemp);
		curpoly->numParts = nparts;
		curpoly->numPoints = sumpts;
		curpoly->parts = (int *)calloc(nparts,sizeof(int ));
		curpoly->points = (point_t *)calloc(sumpts,sizeof(point_t));
		sumpts = 0;
		for (i = 0; i < nparts; i++)
		{
			if (i == 0)
				curpoly->parts[0] = 0;
			else
				curpoly->parts[i] = partnpts[i-1]+curpoly->parts[i-1];
			fread(&curpoly->points[sumpts],sizeof(point_t),partnpts[i],ptstemp);
			sumpts += partnpts[i];
		}
		free(partnpts);
		SHP_Write_Poly(polyshp,curpoly);		
		free(curpoly->parts);
		free(curpoly->points);
		free(curpoly);
		curindex = (shape_index_record_t *)calloc(1,sizeof(shape_index_record_t));
		curindex->offset = oldposition;
		curindex->length = Size;
		SHP_Write_Index(polyshx,curindex);
		free(curindex);
		oldposition = Position;
	}

	polyshphead->fileLen = Position;
	polyshphead->xMin = FileMinX;
	polyshphead->yMin = FileMinY;
	polyshphead->xMax = FileMaxX;
	polyshphead->yMax = FileMaxY;
	rewind(polyshp);
	SHP_Write_Header(polyshp,polyshphead);
	polyshphead->fileLen = IPosition;
	rewind(polyshx);
	SHP_Write_Header(polyshx,polyshphead);
	fclose(polyshx);
	free(polyshphead);
	fclose(polyshp);
	fclose(boxtemp);
	fclose(ptstemp);
	fclose(headtemp);
	fclose(partstemp);		
	unlink("box.tmp");
	unlink("head.tmp");
	unlink("parts.tmp");
	unlink("pts.tmp");	
}