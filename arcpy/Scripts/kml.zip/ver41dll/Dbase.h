/*dbase4 header*/
/*first 32 bit section of header has the following structure*/
typedef struct{
	char version;
	char yy;
	char mm;
	char dd;
	long num_recs;
	unsigned short header_len;
	unsigned short record_len;
	char zero[16];
	short has_mdx;
	char zero2[2];
}dbheader;
/*the rest of the header has the following structure, 
32 bits for each field*/
typedef struct{
	char	name[11];
	char 	type;
	char    filler[4];
	unsigned char len_field;
	unsigned char dec;
	char  has_tag;
    char  filler2[13];
}FieldInfo;
/*For each field, we will use this structure to store information*/
typedef struct{
	char *name;
	char  type;
	unsigned char len_field;
	unsigned char dec;
	char has_tag;
}FieldData;
/*functions are:
write_dbheader1 -writes the first 32 bits of the header
write_dbheader2 -writes the nfields*32 bits for each fields
write_space -writes a space at end of header
write_eof -writes end of file flag at end of dbasefile
*/



void write_eof(FILE *);
void write_eof(FILE *out)
{
	char end = 26;
	fwrite(&end,sizeof(char),1,out);
//	fclose(out);
}

//dbase structures for lines and polygons
FieldData dbNodes[] = {
	{"NODE_ID",'N',10,0,0},
	{0,0,0,0,0}
};
FieldData dbLinks[] = {
	{"TLID",'N',10,0,0},
	{"FNODE",'N',10,0,0},
	{"TNODE",'N',10,0,0},
	{"LENGTH",'N',10,5,0},
	{"FEDIRP",'C',2, 0, 0},
	{"FENAME",'C',30, 0, 0},
	{"FETYPE",'C',4, 0,0},
	{"FEDIRS",'C',2,0,0},
	{"CFCC",'C',3,0,0},
	{"FRADDL",'C',11,0,0},
	{"TOADDL",'C',11,0,0},
	{"FRADDR",'C',11,0,0},
	{"TOADDR",'C',11,0,0},
	{"ZIPL",'C',5,0,0},
	{"ZIPR",'C',5,0,0},
	{"CENSUS1",'C',1,0,0},
	{"CENSUS2",'C',1,0,0},
	{"CFCC1",'C',1,0,0},
	{"CFCC2",'C',2,0,0},
	{"SOURCE",'C',1,0,0},
	{0,0,0,0,0}
};

FieldData dbLinksNum[] = {
	{"TLID",'N',10,0,0},
	{"FNODE",'N',10,0,0},
	{"TNODE",'N',10,0,0},
	{"LENGTH",'N',10,5,0},
	{"FEDIRP",'C',2, 0, 0},
	{"FENAME",'C',30, 0, 0},
	{"FETYPE",'C',4, 0,0},
	{"FEDIRS",'C',2,0,0},
	{"CFCC",'C',3,0,0},
	{"FRADDL",'N',11,0,0},
	{"TOADDL",'N',11,0,0},
	{"FRADDR",'N',11,0,0},
	{"TOADDR",'N',11,0,0},
	{"ZIPL",'C',5,0,0},
	{"ZIPR",'C',5,0,0},
	{"CENSUS1",'C',1,0,0},
	{"CENSUS2",'C',1,0,0},
	{"CFCC1",'C',1,0,0},
	{"CFCC2",'C',2,0,0},
	{"SOURCE",'C',1,0,0},
	{0,0,0,0,0}
};

FieldData dbAllLinks[] = {
	{"TLID",'N',10,0,0},
	{"FNODE",'N',10,0,0},
	{"TNODE",'N',10,0,0},
	{"LENGTH",'N',10,5,0},
	{"FEDIRP",'C',2, 0, 0},
	{"FENAME",'C',30, 0, 0},
	{"FETYPE",'C',4, 0,0},
	{"FEDIRS",'C',2,0,0},
	{"CFCC",'C',3,0,0},
	{"FRADDL",'C',11,0,0},
	{"TOADDL",'C',11,0,0},
	{"FRADDR",'C',11,0,0},
	{"TOADDR",'C',11,0,0},
	{"ZIPL",'C',5,0,0},
	{"ZIPR",'C',5,0,0},
	{"CENSUS1",'C',1,0,0},
	{"CENSUS2",'C',1,0,0},
	{"STATEL",'C',2,0,0},
	{"STATER",'C',2,0,0},
	{"COUNTYL",'C',3,0,0},
	{"COUNTYR",'C',3,0,0},
	{"COUSUBL",'C',5,0,0},
	{"COUSUBR",'C',5,0,0},
	{"SUBMCDL",'C',5,0,0},
	{"SUBMCDR",'C',5,0,0},
	{"PLACEL",'C',5,0,0},
	{"PLACER",'C',5,0,0},
	{"TRACTL",'C',6,0,0},
	{"TRACTR",'C',6,0,0},
	{"BLOCKL",'C',4,0,0},
	{"BLOCKR",'C',4,0,0},
	{"CFCC1",'C',1,0,0},
	{"CFCC2",'C',2,0,0},
	{"SOURCE",'C',1,0,0},
	{0,0,0,0,0}
};

FieldData dbCounty[] = {
	{"GIST_ID",'N',8,0,0},
	{"FIPSSTCO",'C',5,0,0},
	{"STATE",'C',66,0,0},
	{"COUNTY",'C',66,0,0},
	{0,0,0,0,0}
};
FieldData dbTract[] = {
	{"GIST_ID",'N',8,0,0},		
	{"FIPSSTCO",'C',5,0,0},
	{"TRACT",'C',6,0,0},
	{"STFID",'C',11,0,0},
	{0,0,0,0,0}
};
FieldData dbTract00[] = {
	{"GIST_ID",'N',8,0,0},		
	{"FIPSSTCO",'C',5,0,0},
	{"TRT2000",'C',6,0,0},
	{"STFID",'C',11,0,0},
	{"TRACTID",'C',10,0,0},
	{0,0,0,0,0}
};

FieldData dbGroup[] = {
	{"GIST_ID",'N',8,0,0},
	{"FIPSSTCO",'C',5,0,0},
	{"TRACT",'C',6,0,0},
	{"GROUP",'C',1,0,0},
	{"STFID",'C',12,0,0},
	{0,0,0,0,0}
};
FieldData dbBlock[] = {
	{"GIST_ID",'N',8,0,0},
	{"FIPSSTCO",'C',5,0,0},
	{"TRACT",'C',6,0,0},	
	{"BLOCK",'C',4,0,0},
	{"STFID",'C',15,0,0},
	{0,0,0,0,0}
};
FieldData dbBlock00[] = {
	{"GIST_ID",'N',8,0,0},
	{"FIPSSTCO",'C',5,0,0},
	{"TRACT2000",'C',6,0,0},	
	{"BLOCK2000",'C',4,0,0},
	{"STFID",'C',15,0,0},
	{0,0,0,0,0}
};
FieldData dbFmcd[] = {
	{"GIST_ID",'N',8,0,0},
	{"COUNTY",'C',5,0,0},
	{"FMCD90",'C',5,0,0},
	{"NAME",'C',66,0,0},
	{0,0,0,0,0}
};
FieldData dbCousub[] = {
	{"GIST_ID",'N',8,0,0},
	{"COUNTY",'C',5,0,0},
	{"COUSUB90",'C',5,0,0},
	{"NAME",'C',66,0,0},
	{0,0,0,0,0}
};

FieldData dbFmcdcu[] = {
	{"GIST_ID",'N',8,0,0},
	{"COUNTY",'C',5,0,0},
	{"MCD_CUR",'C',5,0,0},
	{"NAME",'C',66,0,0},
	{"SUB_MCD",'C',5,0,0},
	{"SUBNAME",'C',66,0,0},
	{0,0,0,0,0}
};
FieldData dbFmcd00[] = {
	{"GIST_ID",'N',8,0,0},
	{"COUNTY",'C',5,0,0},
	{"MCD2000",'C',5,0,0},
	{"NAME",'C',66,0,0},
	{"SUB_MCD",'C',5,0,0},
	{"SUBNAME",'C',66,0,0},
	{0,0,0,0,0}
};
FieldData dbFpl[] = {
	{"GIST_ID",'N',8,0,0},	
	{"COUNTY",'C',5,0,0},
	{"FPL90",'C',5,0,0},
	{"NAME",'C',66,0,0},
	{"PLACEDC",'C',1,0,0},
	{"LSADC",'C',2,0,0},
	{"ENTITY",'C',1,0,0},
	{"FIPSCC",'C',2,0,0},
	{0,0,0,0,0}
};
FieldData dbFccity[] = {
	{"GIST_ID",'N',8,0,0},	
	{"COUNTY",'C',5,0,0},
	{"CONCITY",'C',5,0,0},
	{"NAME",'C',66,0,0},
	{0,0,0,0,0}
};
FieldData dbUga[] = {
	{"GIST_ID",'N',8,0,0},	
	{"COUNTY",'C',5,0,0},
	{"UGA",'C',5,0,0},
	{"NAME",'C',66,0,0},
	{0,0,0,0,0}
};

FieldData dbFplcu[] = {
	{"GIST_ID",'N',8,0,0},	
	{"COUNTY",'C',5,0,0},
	{"FPL_CUR",'C',5,0,0},
	{"NAME",'C',66,0,0},
	{"PLACEDC",'C',1,0,0},
	{"LSADC",'C',2,0,0},
	{"ENTITY",'C',1,0,0},
	{"FIPSCC",'C',2,0,0},
	{0,0,0,0,0}
};
FieldData dbFpl00[] = {
	{"GIST_ID",'N',8,0,0},	
	{"COUNTY",'C',5,0,0},
	{"PLACE",'C',5,0,0},
	{"NAME",'C',66,0,0},
	{"PLACEDC",'C',1,0,0},
	{"LSADC",'C',2,0,0},
	{"ENTITY",'C',1,0,0},
	{"FIPSCC",'C',2,0,0},
	{0,0,0,0,0}
};
FieldData dbAir[] = {
	{"GIST_ID",'N',8,0,0},	
	{"COUNTY",'C',5,0,0},
	{"AIR_90",'C',4,0,0},
	{"FIPSCODE",'C',5,0,0},
	{"NAME",'C',66,0,0},
	{0,0,0,0,0}
};
FieldData dbAIANHHCE90[] = {
	{"GIST_ID",'N',8,0,0},	
	{"COUNTY",'C',5,0,0},
	{"AIANHHCE",'C',4,0,0},
	{"FIPSCODE",'C',5,0,0},
	{"NAME",'C',66,0,0},
	{0,0,0,0,0}
};
FieldData dbAits[] = {
	{"GIST_ID",'N',8,0,0},	
	{"COUNTY",'C',5,0,0},	
	{"FIPSCODE",'C',5,0,0},
	{"AITSCE",'C',3,0,0},
	{"NAME",'C',66,0,0},
	{0,0,0,0,0}
};
FieldData dbAircu[] = {
	{"GIST_ID",'N',8,0,0},	
	{"COUNTY",'C',5,0,0},
	{"AIR",'C',4,0,0},
	{"FIPSCODE",'C',5,0,0},
	{"TRUST",'C',1,0,0},
	{"NAME",'C',66,0,0},
	{0,0,0,0,0}
};
FieldData dbAIANHHCE00[] = {
	{"GIST_ID",'N',8,0,0},	
	{"COUNTY",'C',5,0,0},
	{"AIANHHCE",'C',4,0,0},
	{"FIPSCODE",'C',5,0,0},
	{"TRUST",'C',1,0,0},
	{"NAME",'C',66,0,0},
	{0,0,0,0,0}
};

FieldData dbVote[] = {
	{"GIST_ID",'N',8,0,0},	
	{"COUNTY",'C',5,0,0},
	{"VOTE_DIST",'C',4,0,0},
	{"NAME",'C',66,0,0},
	{0,0,0,0,0}
};
FieldData dbVote00[] = {
	{"GIST_ID",'N',8,0,0},	
	{"COUNTY",'C',5,0,0},
	{"VOTE00",'C',6,0,0},	
	{"NAME",'C',66,0,0},
	{"PDC",'C',1,0,0},
	{0,0,0,0,0}
};
FieldData dbAnrc[] = {
	{"GIST_ID",'N',8,0,0},	
	{"COUNTY",'C',5,0,0},
	{"ANRC",'C',2,0,0},
	{"NAME",'C',66,0,0},
	{0,0,0,0,0}
};
FieldData dbAnrcType3[]= {
	{"GIST_ID",'N',8,0,0},	
	{"COUNTY",'C',5,0,0},
	{"ANRC",'C',5,0,0},
	{"NAME",'C',66,0,0},
	{0,0,0,0,0}
};
FieldData dbKgl[] = {
	{"GIST_ID",'N',8,0,0},
	{"POLYID",'N',10,0,0},
	{"CENID",'C',5,0,0},
	{"COUNTY",'C',5,0,0},
	{"CFCC",'C',3,0,0},
	{"KGLNAME",'C',30,0,0},
	{0,0,0,0,0}
};
FieldData dbKgladd[] = {
	{"POLYID",'N',10,0,0},
	{"CENID",'C',5,0,0},
	{"NAME",'C',30,0,0},
	{"ADDRESS",'C',11,0},
	{"FEDIRP",'C',2,0},
	{"FENAME",'C',30,0},
	{"FETYPE",'C',4,0},
	{"FEDIRS",'C',2,0},
	{"ZIPCODE",'C',5,0},
	{"ZIP4",'C',4,0},
	{0,0,0,0,0}
};
FieldData dbLandmarkNode[] = {
	{"GIST_ID",'N',8,0,0},
	{"CFCC",'C',3,0,0},
	{"NAME",'C',30,0,0},
	{0,0,0,0,0}
};
FieldData dbLandnames[] = {
	{"LANDPOLY",'N',10,0,0},
	{"CFCC",'C',3,0,0},
	{"LANDNAME",'C',30,0,0},
	{"FILEID",'C',5,0,0},
	{0,0,0,0,0}
};
FieldData dbWaternames[] = {
	{"LANDPOLY",'N',10,0,0},
	{"CFCC",'C',3,0,0},
	{"LANDNAME",'C',30,0,0},	
	{"FILEID",'C',5,0,0},
	{0,0,0,0,0}
};

FieldData dbLandpolys[] = {
	{"POLYID",'N',10,0,0},
	{"CENID",'C',5,0,0},	
	{"LANDPOLY",'N',10,0,0},
	{"FILEID",'C',5,0,0},
	{0,0,0,0,0}
};
FieldData dbLand[] = {
	{"GIST_ID",'N',8,0,0},
	{"POLYID",'N',10,0,0},
	{"CENID",'C',5,0,0},	
	{"COUNTY",'C',5,0,0},
	{"CFCC",'C',3,0,0},
	{"LANDNAME",'C',30,0,0},
	{"LANDPOLY",'N',10,0,0},
	{"FILEID",'C',5,0,0},
	{0,0,0,0,0}
};
FieldData dbTaz[] = {
	{"GIST_ID",'N',8,0,0},
	{"COUNTY",'C',5,0,0},
	{"TAZ",'C',6,0,0},
	{"CTPP",'C',4,0,0},
	{0,0,0,0,0}
};
FieldData dbTaz100[] = {
	{"GIST_ID",'N',8,0,0},
	{"COUNTY",'C',5,0,0},
	{"TAZ",'C',6,0,0},
	{"UA90",'C',4,0,0},
	{0,0,0,0,0}
};
FieldData dbUrb[] = {
	{"GIST_ID",'N',8,0,0},
	{"COUNTY",'C',5,0,0},
	{"UACODE",'C',5,0,0},
	{"NAME",'C',66,0,0},
	{0,0,0,0,0}
};
FieldData dbWater[] = {
	{"GIST_ID",'N',8,0,0},
	{"COUNTY",'C',5,0,0},
	{"CFCC",'C',3,0,0},
	{"LANDNAME",'C',30,0,0},	
	//{"LANDPOLY",'N',10,0,0},
	//{"FILEID",'C',5,0,0},
	{0,0,0,0,0}
};
FieldData dbMsa[] = {
	{"GIST_ID",'N',8,0,0},
	{"COUNTY",'C',5,0,0},
	{"CMSAMSA",'C',4,0,0},
	{"NAME",'C',66,0,0},
	{0,0,0,0,0}
};
FieldData dbPms[] = {
	{"GIST_ID",'N',8,0,0},
	{"COUNTY",'C',5,0,0},
	{"PMSA",'C',4,0,0},
	{"NAME",'C',66,0,0},
	{0,0,0,0,0}
};
FieldData dbCdcu[] = {
	{"GIST_ID",'N',8,0,0},
	{"COUNTY",'C',5,0,0},
	{"DISTRICT",'N',2,0,0},
	{0,0,0,0,0}
};
FieldData dbElementary[] = {
	{"GIST_ID",'N',8,0,0},
	{"COUNTY",'C',5,0,0},
	{"ELEMENTARY",'C',5,0,0},
	{0,0,0,0,0}
};
FieldData dbElementary99[] = {
	{"GIST_ID",'N',8,0,0},
	{"COUNTY",'C',5,0,0},
	{"ELEMENTARY",'C',5,0,0},
	{"NAME",'C',60,0,0},
	{0,0,0,0,0}
};
FieldData dbMiddle[] = {
	{"GIST_ID",'N',8,0,0},
	{"COUNTY",'C',5,0,0},
	{"MIDDLE",'C',5,0,0},
	{0,0,0,0,0}
};
FieldData dbSecondary[] = {
	{"GIST_ID",'N',8,0,0},
	{"COUNTY",'C',5,0,0},
	{"SECONDARY",'C',5,0,0},
	{0,0,0,0,0}
};
FieldData dbSecondary99[] = {
	{"GIST_ID",'N',8,0,0},
	{"COUNTY",'C',5,0,0},
	{"SECONDARY",'C',5,0,0},
	{"NAME",'C',60,0,0},
	{0,0,0,0,0}
};
FieldData dbUnified[] = {
	{"GIST_ID",'N',8,0,0},
	{"COUNTY",'C',5,0,0},
	{"UNIFIED",'C',5,0,0},
	{0,0,0,0,0}
};
FieldData dbUnified99[] = {
	{"GIST_ID",'N',8,0,0},
	{"COUNTY",'C',5,0,0},
	{"UNIFIED",'C',5,0,0},
	{"NAME",'C',60,0,0},
	{0,0,0,0,0}
};
FieldData dbHouse[] = {
	{"GIST_ID",'N',8,0,0},
	{"COUNTY",'C',5,0,0},
	{"ST_HOUSE",'C',6,0,0},
	{0,0,0,0,0}
};
FieldData dbSLDL[] = {
	{"GIST_ID",'N',8,0,0},
	{"COUNTY",'C',5,0,0},
	{"SLDL",'C',6,0,0},
	{0,0,0,0,0}
};
FieldData dbSenate[] = {
	{"GIST_ID",'N',8,0,0},
	{"COUNTY",'C',5,0,0},
	{"ST_SENATE",'C',6,0,0},
	{0,0,0,0,0}
};
FieldData dbSLDU[] = {
	{"GIST_ID",'N',8,0,0},
	{"COUNTY",'C',5,0,0},
	{"SLDU",'C',6,0,0},
	{0,0,0,0,0}
};
FieldData dbAltnames[] = {
	{"TLID",'N',10,0,0},
	{"FEDIRP2",'C',2, 0, 0},
	{"FENAME2",'C',30, 0, 0},
	{"FETYPE2",'C',4, 0,0},
	{"FEDIRS2",'C',2,0,0},
	{0,0,0,0,0}
};
FieldData dbAltaddresses[] = {
	{"TLID",'N',10,0,0},
	{"RTSQ",'N',3,0,0},
	{"FRADDL2",'C',11,0,0},
	{"TOADDL2",'C',11,0,0},
	{"FRADDR2",'C',11,0,0},
	{"TOADDR2",'C',11,0,0},
	{"ZIPL2",'C',5,0,0},
	{"ZIPR2",'C',5,0,0},	
	{0,0,0,0,0}
};
FieldData dbAltaddressesNum[] = {
	{"TLID",'N',10,0,0},
	{"RTSQ",'N',3,0,0},
	{"FRADDL2",'N',11,0,0},
	{"TOADDL2",'N',11,0,0},
	{"FRADDR2",'N',11,0,0},
	{"TOADDR2",'N',11,0,0},
	{"ZIPL2",'C',5,0,0},
	{"ZIPR2",'C',5,0,0},	
	{0,0,0,0,0}
};
FieldData dbZip4s[] = {
	{"TLID",'N',10,0,0},
	{"RTSQ",'N',3,0,0},
	{"ZIP4L",'C',4,0,0},
	{"ZIP4R",'C',4,0,0},
	{0,0,0,0,0}
};
FieldData dbCollectionBlocks[] = {
	{"GIST_ID",'N',8,0,0},
	{"STATE",'C',2,0,0},
	{"COUNTY",'C',3,0,0},
	{"BLKCOL",'C',5,0,0},
	{"BLKSUFCOL",'C',1,0,0},
	{"TEA",'C',1,0,0},	
	{"ZCTA",'C',5,0,0},
	{"TEA_TYPE",'C',16,0,0},
	{0,0,0,0,0}
};
FieldData dbZcta[] = {
	{"GIST_ID",'N',8,0,0},	
	{"COUNTY",'C',5,0,0},
	{"ZCTA",'C',5,0,0},	
	{0,0,0,0,0}
};
FieldData dbPolys97[] = {
	{"POLYID",'N',10,0,0},
	{"CENID",'C',5,0,0},	
	{"STATE",'C',2,0,0},
	{"COUNTY",'C',3,0,0},
	{"WATERFLAG",'N',1,0,0},
	{"CMSAMSA",'C',4,0,0},
	{"PMSA",'C',4,0,0},
	{"FAIR",'C',5,0,0},
	{"AIR",'C',5,0,0},
	{"TRUST",'C',1,0,0},
	{"ANRC",'C',2,0,0},
	{"FCCITY",'C',5,0,0},
	{"FMCD",'C',5,0,0},
	{"FSMCD",'C',5,0,0},
	{"FPL",'C',5,0,0},
	{"CDCU",'C',2,0,0},
	{"STSENATE",'C',6,0,0},
	{"STHOUSE",'C',6,0,0},	
	{"FAIR90",'C',5,0,0},
	{"FMCD90",'C',5,0,0},
	{"FPL90",'C',5,0,0},
	{"CTBNA90",'C',6,0,0},
	{"BLK90",'C',4,0,0},
	{"CD106",'C',2,0,0},
	{"CD108",'C',2,0,0},
	{"SDELM",'C',5,0,0},
	{"SDSEC",'C',5,0,0},
	{"SDUNI",'C',5,0,0},
	{"TAZ",'C',6,0,0},
	{"UA",'C',4,0,0},
	{"URBFLAG",'C',1,0,0},
	{"CTPP",'C',4,0,0},
	{"STATE90",'C',2,0,0},
	{"COUN90",'C',3,0,0},
	{"AIR90",'C',4,0,0},
	{"VOTE90",'C',4,0,0},
	{0,0,0,0,0}
};//SIZE + 2 = 150

FieldData dbPolys98[] = {
	{"POLYID",'N',10,0,0},
	{"CENID",'C',5,0,0},	
	{"STATECU",'C',2,0,0}, //get from typeS
	{"COUNTYCU",'C',3,0,0},//get from typeS
	{"WATERFLAG",'N',1,0,0},//S starts here
	{"CMSAMSA",'C',4,0,0},
	{"PMSA",'C',4,0,0},
	{"FAIR",'C',5,0,0},
	{"AIR",'C',5,0,0},
	{"TRUST",'C',1,0,0},
	{"ANRC",'C',2,0,0},
	{"FCCITY",'C',5,0,0},
	{"FMCD",'C',5,0,0},
	{"FSMCD",'C',5,0,0},
	{"FPL",'C',5,0,0},
	{"TEA",'C',1,0,0},
	{"CDCU",'C',2,0,0},
	{"STSENATE",'C',6,0,0},
	{"STHOUSE",'C',6,0,0},	
	{"CENSUS6",'C',5,0,0},	
	{"STATECOL",'C',2,0,0},
	{"COUNCOL",'C',3,0,0},
	{"BLKCOL",'C',5,0,0},
	{"BLKSUFCOL",'C',1,0,0},
	{"ZCTA",'C',5,0,0},  //S ends here
	{"FAIR90",'C',5,0,0},
	{"FMCD90",'C',5,0,0},
	{"FPL90",'C',5,0,0},
	{"CTBNA90",'C',6,0,0},
	{"BLK90",'C',4,0,0},
	{"CD106",'C',2,0,0},
	{"CD108",'C',2,0,0},
	{"SDELM",'C',5,0,0},	
	{"SDSEC",'C',5,0,0},
	{"SDUNI",'C',5,0,0},
	{"TAZ",'C',6,0,0},
	{"UA90",'C',4,0,0},
	{"URBFLAG",'C',1,0,0},
	{"CTPP",'C',4,0,0},
	{"STATE90",'C',2,0,0},
	{"COUN90",'C',3,0,0},
	{"AIR90",'C',4,0,0},
	{"VOTE90",'C',4,0,0},	
	{0,0,0,0,0}
};//SIZE + 2 = 172
FieldData dbPolys00[] = {
	{"POLYID",'N',10,0,0},
	{"CENID",'C',5,0,0},	
	{"STATE00",'C',2,0,0}, //get from typeS
	{"COUNTY00",'C',3,0,0},//get from typeS
	{"WATERFLAG",'N',1,0,0},//S starts here
	{"CMSAMSA00",'C',4,0,0}, //25
	{"PMSA00",'C',4,0,0},
	{"FAIR00",'C',5,0,0},
	{"AIR00",'C',5,0,0},
	{"TRUST00",'C',1,0,0},
	{"ANRC00",'C',2,0,0},
	{"FCCITY00",'C',5,0,0},
	{"FMCD00",'C',5,0,0},
	{"FSMCD00",'C',5,0,0},
	{"FPL00",'C',5,0,0},
	{"CENSUS6",'C',1,0,0},
	{"CDCU",'C',2,0,0},//65
	{"STSENATE00",'C',6,0,0},
	{"STHOUSE00",'C',6,0,0},		
	{"CENSUS7",'C',5,0,0},	
	{"STATECOL",'C',2,0,0},
	{"COUNCOL",'C',3,0,0},
	{"BLKCOL",'C',5,0,0},
	{"BLKSUFCOL",'C',1,0,0},
	{"ZCTA",'C',5,0,0}, 
	//{"CENSUS6",'C',1,0,0},//S ends here
	{"FAIR90",'C',5,0,0},//103
	{"FMCD90",'C',5,0,0},
	{"FPL90",'C',5,0,0},
	{"CTBNA90",'C',6,0,0},
	{"BLK90",'C',4,0,0},
	{"CD106",'C',2,0,0},
	{"CD108",'C',2,0,0},
	{"SDELM",'C',5,0,0},	
	{"SDSEC",'C',5,0,0},
	{"SDUNI",'C',5,0,0},
	{"TAZ",'C',6,0,0},
	{"UA90",'C',4,0,0},
	{"URBFLAG",'C',1,0,0},
	{"CTPP",'C',4,0,0},
	{"STATE90",'C',2,0,0},
	{"COUN90",'C',3,0,0},//162
	{"AIR90",'C',4,0,0},
	{"VOTE90",'C',4,0,0},
	{"CTBNA00",'C',6,0,0},// for 2000
	{"BLK00",'C',4,0,0}, // for 2000
	{"VOTE00",'C',6,0,0}, // for 2000
	{0,0,0,0,0}
};//SIZE + 2  = 189
FieldData dbPolys100[] = { //FOR TIGER 99
	{"POLYID",'N',10,0,0},
	{"CENID",'C',5,0,0},	
	{"STATECU",'C',2,0,0}, //S starts here
	{"COUNTYCU",'C',3,0,0},//20
	{"WATERFLAG",'N',1,0,0},
	{"CMSAMSA00",'C',4,0,0}, 
	{"PMSA00",'C',4,0,0},
	{"AIANHH00",'C',5,0,0},
	{"AIANHHCE00",'C',5,0,0},
	{"TRUST00",'C',1,0,0},//40
	{"STATE00",'C',2,0,0},
	{"COUNTY00",'C',3,0,0},
	{"CONCITY00",'C',5,0,0},
	{"COUSUB00",'C',5,0,0},
	{"SUBMCD00",'C',5,0,0},//60
	{"PLACE00",'C',5,0,0},		
	{"TRACT00",'C',6,0,0},
	{"BLOCK00",'C',4,0,0},	
	{"CDCU",'C',2,0,0},
	{"SLDU00",'C',6,0,0},
	{"SLDL00",'C',6,0,0},		
	{"UGA00",'C',5,0,0},
	{"BLKGRP00",'C',1,0,0},//95
	{"VTD00",'C',6,0,0},
	{"STATECOL",'C',2,0,0},
	{"COUNCOL",'C',3,0,0},
	{"BLKCOL",'C',5,0,0},
	{"BLKSUFCOL",'C',1,0,0},
	{"ZCTA",'C',5,0,0}, 
	{"AIANHH90",'C',5,0,0},//type A starts here	
	{"COUSUB90",'C',5,0,0},
	{"PLACE90",'C',5,0,0},
	{"TRACT90",'C',6,0,0},
	{"BLOCK90",'C',4,0,0},//142
	{"CD106",'C',2,0,0},
	{"CD108",'C',2,0,0},
	{"SDELM",'C',5,0,0},		
	{"SDSEC",'C',5,0,0},
	{"SDUNI",'C',5,0,0},
	{"TAZ2000",'C',6,0,0},
	{"UA90",'C',5,0,0},
	{"UR",'C',1,0,0},	
	{"STATE90",'C',2,0,0},
	{"COUN90",'C',3,0,0},
	{"AIANHHCE90",'C',4,0,0}, 
	{"ANRCCU",'C',5,0,0},//start type 3
	{"AITSCE",'C',3,0,0},
	{"AITS",'C',5,0,0}, //195
	{0,0,0,0,0}
};//SIZE + 2  = 197
FieldData dbCentroids[] = { //FOR TIGER 99
	{"POLYID",'N',10,0,0},
	{"CENID",'C',5,0,0},	
	{"LONGITUDE",'N',11,6,0},
	{"LATITUDE",'N',10,6,0},
	{0,0,0,0,0}
};// POLY CENTERS SIZE +2 = 38
FieldData dbUrb00[] = {
	{"GIST_ID",'N',8,0,0},
	{"COUNTY",'C',5,0,0},
	{"UACODE",'C',5,0,0},
	{"NAME",'C',66,0,0},
	{"UAUC",'C',2,0,0},
	{0,0,0,0,0}
};

FieldData dbUa00Cor[] = {  //use for ua90 redefined, too
	{"GIST_ID",'N',8,0,0},
	{"COUNTY",'C',5,0,0},
	{"UACODE",'C',5,0,0},
	{"NAME",'C',66,0,0},
	{"UAUC",'C',2,0,0},
	{0,0,0,0,0}
};

FieldData dbPuma[] = {
	{"GIST_ID",'N',8,0,0},
	{"COUNTY",'C',5,0,0},
	{"PUMA",'C',5,0,0},	
	{0,0,0,0,0}
};
FieldData dbPolysUrban[] = {
	{"POLYID",'N',10,0,0},
	{"CENID",'C',5,0,0},	
	{"STATE00",'C',2,0,0}, //get from typeS
	{"COUNTY00",'C',3,0,0},//get from typeS
	{"WATERFLAG",'N',1,0,0},//S starts here
	{"CMSAMSA00",'C',4,0,0}, //25
	{"PMSA00",'C',4,0,0},
	{"AIANHH",'C',5,0,0},
	{"AIANHHCE",'C',4,0,0},
	{"AIHHTLI",'C',1,0,0},	
	{"CONCIT",'C',5,0,0},
	{"COUSUB",'C',5,0,0},
	{"SUBMCD",'C',5,0,0},
	{"PLACE",'C',5,0,0},
	{"TRACT",'C',6,0,0},
	{"BLOCK",'C',4,0,0},	
	{"CDCU",'C',2,0,0},//65
	{"SLDU",'C',6,0,0}, //leave long for backward compatability
	{"SLDL",'C',6,0,0},				
	{"UGA",'C',5,0,0},
	{"BLKGRP",'C',1,0,0},
	{"VTD",'C',6,0,0},
	{"STATECOL",'C',2,0,0},
	{"COUNCOL",'C',3,0,0},
	{"BLOCKCOL",'C',5,0,0},
	{"BLKSUFCOL",'C',1,0,0},
	{"ZCTA5",'C',5,0,0}, 
	{"UR",'C',1,0,0},
	{"UR90",'C',1,0,0},	//S ends here 108
	{"AIAHHH90",'C',5,0,0},
	{"COUSUB90",'C',5,0,0},
	{"PLACE90",'C',5,0,0},
	{"TRACT90",'C',6,0,0},
	{"BLOCK90",'C',4,0,0},
	{"CD106",'C',2,0,0},
	{"CD108",'C',2,0,0},
	{"SDELM",'C',5,0,0},	
	{"PUMA5",'C',5,0,0},
	{"SDUNI",'C',5,0,0},
	{"TAZ",'C',6,0,0},
	{"UA",'C',5,0,0},
	{"UA90",'C',5,0,0},
	{"STATE90",'C',2,0,0},
	{"COUN90",'C',3,0,0},
	{"AIANHHCE90",'C',4,0,0}, //176
	{"ANRC",'C',5,0,0}, //start type 3
	{"AITSCE",'C',3,0,0},
	{"AITS",'C',5,0,0}, //end type 3	
	{0,0,0,0,0}
};//SIZE + 2  = 191
FieldData dbPolysCD108[] = {
	{"POLYID",'N',10,0,0},
	{"CENID",'C',5,0,0},	
	{"STATE00",'C',2,0,0}, //get from typeS
	{"COUNTY00",'C',3,0,0},//get from typeS
	{"WATERFLAG",'N',1,0,0},//S starts here
	{"CMSAMSA00",'C',4,0,0}, //25
	{"PMSA00",'C',4,0,0},
	{"AIANHH",'C',5,0,0},
	{"AIANHHCE",'C',4,0,0},
	{"AIHHTLI",'C',1,0,0},	
	{"CONCIT",'C',5,0,0},
	{"COUSUB",'C',5,0,0},
	{"SUBMCD",'C',5,0,0},
	{"PLACE",'C',5,0,0},
	{"TRACT",'C',6,0,0},
	{"BLOCK",'C',4,0,0},	
	{"CDCU",'C',2,0,0},//65
	{"SLDU",'C',6,0,0}, //leave long for backward compatability
	{"SLDL",'C',6,0,0},				
	{"UGA",'C',5,0,0},
	{"BLKGRP",'C',1,0,0},
	{"VTD",'C',6,0,0},
	{"UA00COR",'C',5,0,0}, //start 108 here
	{"UA90RED",'C',5,0,0},
	{"UR90RED",'C',1,0,0},	
	{"ZCTA5",'C',5,0,0}, 
	{"UR",'C',1,0,0},
	{"UR90",'C',1,0,0},	//S ends here 108
	{"AIAHHH90",'C',5,0,0},
	{"COUSUB90",'C',5,0,0},
	{"PLACE90",'C',5,0,0},
	{"TRACT90",'C',6,0,0},
	{"BLOCK90",'C',4,0,0},
	{"CD106",'C',2,0,0},
	{"CD108",'C',2,0,0},
	{"SDELM",'C',5,0,0},	
	{"PUMA5",'C',5,0,0},
	{"SDUNI",'C',5,0,0},
	{"TAZ",'C',6,0,0},
	{"UA",'C',5,0,0},
	{"UA90",'C',5,0,0},
	{"STATE90",'C',2,0,0},
	{"COUN90",'C',3,0,0},
	{"AIANHHCE90",'C',4,0,0}, //176
	{"ANRC",'C',5,0,0}, //start type 3
	{"AITSCE",'C',3,0,0},
	{"AITS",'C',5,0,0}, //end type 3	
	{0,0,0,0,0}
};//SIZE + 2  = 197

dbheader Header;
void Build_db_Header(FILE *, long, FieldData *);
#include <time.h>
void Build_db_Header(FILE *out, long count, FieldData *x)
{
	struct tm *newtime;
	time_t longtime;
	int i;
	unsigned short numfields, recordlen;
	time(&longtime);
	newtime = localtime(&longtime);
	Header.version = 3;
	Header.yy = newtime->tm_year;
	Header.mm = newtime->tm_mon + 1;
	Header.dd = newtime->tm_mday;
	Header.num_recs = count;
	i = 0;
	numfields = 0;
	recordlen = 0;

	while (x[i].name != NULL)
	{
		numfields++;
		recordlen += (unsigned short)x[i].len_field;		
		i++;		
	}
	Header.header_len = 32 * (numfields + 1) + 1;	
	Header.record_len = recordlen + 1;
	for (i = 0; i < 16; i++)
		Header.zero[i] = 0;	
	Header.has_mdx = 0;
	for (i = 0; i < 4; i++)
		Header.zero2[i] = 0;
	fwrite(&Header,sizeof(dbheader),1,out);			
	//return;
}
long Read_db_Header(FILE *);
long Read_db_Header(FILE *in)
{
	//CString repval;
	if (fread(&Header,sizeof(dbheader),1,in) == 1)
		return Header.num_recs;
	else
		return 0;

}

void Build_db_FieldHeaders(FILE *out, FieldData *);
void Build_db_FieldHeaders(FILE *out, FieldData *x)
{
	FieldInfo current;
	int j, i;
	char spacer = 13; 

	i = 0;
    while (x[i].name != NULL)
	{
		sprintf(current.name,"%s",x[i].name);
		for (j = strlen(x[i].name); j < 10; j++)
			current.name[j] = 0;
		current.type = x[i].type;
		for (j = 0; j < 4; j++)
   			current.filler[j] = 0;
		current.len_field = x[i].len_field;
		current.dec = x[i].dec;
		current.has_tag = 0;
		for (j = 0; j < 13; j++)
    		current.filler2[j] = 0;
		fwrite(&current,sizeof(FieldInfo),1,out);		
		i++;
	}
	fwrite(&spacer,sizeof(char),1,out);
}
