//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by mydll.rc
//
#define IDD_DIALOG1                     129
#define IDC_FIPS                        1000
#define IDC_GO                          1013
#define IDC_OUTFILES                    1015
#define IDC_BROWSE                      1016
#define IDC_CANCEL                      1017
#define IDC_PROGRESS1                   1025
#define IDC_PROCESS                     1028
#define IDC_TYPEA                       1029
#define IDC_LAYER                       1029
#define IDC_TYPEB                       1030
#define IDC_TYPEC                       1031
#define IDC_TYPED                       1032
#define IDC_TYPEE                       1033
#define IDC_TYPEF                       1034
#define IDC_TYPEH                       1035
#define IDC_TYPEX                       1036
#define IDC_COUNTY                      1037
#define IDC_TRACT                       1038
#define IDC_GROUP                       1039
#define IDC_BLOCK                       1040
#define IDC_PLACES                      1041
#define IDC_DIVISIONS                   1042
#define IDC_AIR                         1043
#define IDC_VERSION                     1043
#define IDC_VOTING                      1044
#define IDC_OUTOPTION                   1044
#define IDC_ANRC                        1045
#define IDC_TRACT00                     1046
#define IDC_COUNTYCU                    1046
#define IDC_KGL                         1047
#define IDC_LANDPTS                     1048
#define IDC_LANDPOLY                    1049
#define IDC_TAZ                         1050
#define IDC_URB                         1051
#define IDC_ELEM                        1052
#define IDC_MIDDLE                      1053
#define IDC_SECONDARY                   1054
#define IDC_UNIFIED                     1055
#define IDC_WATER                       1056
#define IDC_CMSAMSA                     1057
#define IDC_PMSA                        1058
#define IDC_CDCU                        1059
#define IDC_STSENATE                    1060
#define IDC_STHOUSE                     1061
#define IDC_BLOCK00                     1062
#define IDC_TRACT2000                   1062
#define IDC_PLACESCU                    1063
#define IDC_DIVISIONSCU                 1064
#define IDC_BLOCK2000                   1065
#define IDC_ALL                         1066
#define IDC_VOTING00                    1067
#define IDC_AIR90                       1068
#define IDC_AIRCU                       1069
#define IDC_URB2                        1070
#define IDC_COLBLKS00                   1071
#define IDC_CLIP                        1072
#define IDC_ZCTA                        1073
#define IDC_XCEEDZIPCTRL1               1076
#define IDC_F_AND_G                     1077
#define IDC_COUNTYCUPROMPT              1078
#define IDC_DIVISIONSCUPROMPT           1079
#define IDC_AIRCUPROMPT                 1080
#define IDC_ANRCPROMPT                  1081
#define IDC_CMSAPROMPT                  1082
#define IDC_PMSAPROMPT                  1083
#define IDC_STSENPROMPT                 1084
#define IDC_STHOUSEPROMPT               1085
#define IDC_PLACESCUPROMPT              1086
#define IDC_STATUS                      1093

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1094
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
