extern BOOL IsOn[31];
void ProcessFiles(void);
