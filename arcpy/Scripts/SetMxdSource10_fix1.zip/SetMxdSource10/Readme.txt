This script asks for a datasource (Personal GDB or SDE) and then loops through all feature layers in the map and set the source according to the selected source.


Simply run the Register.bat file in the Binary folder (register9x for 9.x arcgis) register32 for 32 bit machines with 10, register64 for 64 bit arcgis10 machines)

you should get the message

Types Registered Successfully

Open ArcMap, Go to Customize - Commands 
Search for SetMXDSource then add it to your map ..

Click on the tool and select your GDB to change the source of the layers, the tool is smart enough (i guess) to detect which layer goes with which FC 

Email me for assistant

hus_mhd@yahoo.com


Twitter
http://twitter.com/hnasr

Blog
http://hnaser.blogspot.com

